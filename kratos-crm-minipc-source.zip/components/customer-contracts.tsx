"use client";

import { LoadingIndicator } from "@/components/loading-indicator";
import { forwardRef, memo, useCallback, useEffect, useImperativeHandle, useRef, useState, type FormEvent } from "react";

type Contract = { id: number; customer_id: number; contract_name: string; insurer: string; valid_until: string | null; is_active: number };
type Draft = { contract_name: string; insurer: string; valid_until: string };

export type CustomerContractsHandle = { savePending: () => Promise<boolean> };

export const CustomerContracts = memo(forwardRef<CustomerContractsHandle, { customerId: number; disabled?: boolean }>(function CustomerContracts({ customerId, disabled = false }, ref) {
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [drafts, setDrafts] = useState<Record<number, Draft>>({});
  const [contractName, setContractName] = useState("");
  const [insurer, setInsurer] = useState("");
  const [validUntil, setValidUntil] = useState("");
  const [showArchived, setShowArchived] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [error, setError] = useState("");
  const requestId = useRef<string | null>(null);

  const load = useCallback(async (signal?: AbortSignal) => {
    const response = await fetch(`/api/contracts?customer_id=${customerId}`, { cache: "no-store", signal });
    const data = await response.json() as { contracts?: Contract[]; error?: string };
    if (!response.ok) throw new Error(data.error || "Verträge konnten nicht geladen werden.");
    const items = data.contracts ?? [];
    setContracts(items);
    setDrafts(Object.fromEntries(items.map(item => [item.id, { contract_name: item.contract_name, insurer: item.insurer, valid_until: item.valid_until ?? "" }])));
  }, [customerId]);

  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal).catch(cause => {
      if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "Verträge konnten nicht geladen werden.");
    }).finally(() => {
      if (!controller.signal.aborted) setLoading(false);
    });
    return () => controller.abort();
  }, [load]);

  const savePending = useCallback(async () => {
    if (saving || busyId !== null) { setError("Speichervorgang läuft noch. Bitte nach Abschluss erneut schließen."); return false; }
    const changed = contracts.filter(item => {
      const draft = drafts[item.id];
      return draft && (draft.contract_name !== item.contract_name || draft.insurer !== item.insurer || draft.valid_until !== (item.valid_until ?? ""));
    });
    const hasNewDraft = Boolean(contractName.trim() || insurer.trim() || validUntil.trim());
    if (hasNewDraft && (!contractName.trim() || !insurer.trim())) {
      setError("Zum automatischen Speichern bitte Vertrag und Versicherer ausfüllen oder den unvollständigen Eintrag leeren.");
      return false;
    }
    if (!changed.length && !hasNewDraft) return true;
    setError(""); setBusyId(changed[0]?.id ?? null);
    try {
      for (const item of changed) {
        const draft = drafts[item.id];
        const response = await fetch("/api/contracts", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id, customer_id: customerId, ...draft }) });
        const data = await response.json() as { error?: string };
        if (!response.ok) throw new Error(data.error || "Vertragsänderungen konnten nicht gespeichert werden.");
        setContracts(current => current.map(existing => existing.id === item.id ? { ...existing, ...draft, valid_until: draft.valid_until || null } : existing));
        setDrafts(current => ({ ...current, [item.id]: draft }));
      }
      if (hasNewDraft) {
        requestId.current ??= crypto.randomUUID();
        const response = await fetch("/api/contracts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ customer_id: customerId, contract_name: contractName, insurer, valid_until: validUntil, request_id: requestId.current }) });
        const data = await response.json() as { error?: string };
        if (!response.ok) throw new Error(data.error || "Neuer Vertrag konnte nicht gespeichert werden.");
        requestId.current = null; setContractName(""); setInsurer(""); setValidUntil("");
      }
      await load();
      return true;
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Vertragsänderungen konnten nicht gespeichert werden.");
      return false;
    } finally { setBusyId(null); }
  }, [busyId, contractName, contracts, customerId, drafts, insurer, load, saving, validUntil]);

  useImperativeHandle(ref, () => ({ savePending }), [savePending]);

  async function add(event: FormEvent) {
    event.preventDefault(); setSaving(true); setError("");
    try {
      requestId.current ??= crypto.randomUUID();
      const response = await fetch("/api/contracts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ customer_id: customerId, contract_name: contractName, insurer, valid_until: validUntil, request_id: requestId.current }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Vertrag konnte nicht gespeichert werden.");
      requestId.current = null; setContractName(""); setInsurer(""); setValidUntil("");
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Vertrag konnte nicht gespeichert werden."); }
    finally { setSaving(false); }
  }

  async function update(item: Contract, changes: Partial<Draft & { is_active: number }>) {
    setError(""); setBusyId(item.id);
    try {
      const response = await fetch("/api/contracts", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id, customer_id: customerId, ...changes }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Vertrag konnte nicht geändert werden.");
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Vertrag konnte nicht geändert werden."); }
    finally { setBusyId(null); }
  }

  const active = contracts.filter(item => item.is_active === 1);
  const archived = contracts.filter(item => item.is_active !== 1);
  const retryLocked = requestId.current !== null && Boolean(error);
  const inputClass = "w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm";
  return <section className="rounded-xl border border-slate-200 p-4" aria-labelledby="customer-contracts-title">
    <div className="flex items-start justify-between gap-3"><div><h3 id="customer-contracts-title" className="font-semibold">Aktive Verträge</h3><p className="mt-1 text-xs text-slate-500">{active.length} aktiv · Status manuell gepflegt · Nur eingetragene Verträge</p></div></div>
    {busyId !== null && <LoadingIndicator compact label="Wird aktualisiert …" />}
    {loading ? <div className="mt-4"><LoadingIndicator label="Verträge werden geladen …" /></div>
      : active.length ? <ul className="mt-4 space-y-3">{active.map(item => {
        const draft = drafts[item.id] ?? { contract_name: item.contract_name, insurer: item.insurer, valid_until: item.valid_until ?? "" };
        const changed = draft.contract_name !== item.contract_name || draft.insurer !== item.insurer || draft.valid_until !== (item.valid_until ?? "");
        return <li key={item.id} className="rounded-lg bg-slate-50 p-3">
          <div className="grid gap-2 sm:grid-cols-2">
            <label className="text-xs font-medium">Vertrag<input disabled={disabled || busyId !== null} aria-label="Vertragsname" maxLength={120} value={draft.contract_name} onChange={event => setDrafts(current => ({ ...current, [item.id]: { ...draft, contract_name: event.target.value } }))} className={`${inputClass} mt-1`} /></label>
            <label className="text-xs font-medium">Versicherer<input disabled={disabled || busyId !== null} aria-label="Versicherer" maxLength={120} value={draft.insurer} onChange={event => setDrafts(current => ({ ...current, [item.id]: { ...draft, insurer: event.target.value } }))} className={`${inputClass} mt-1`} /></label>
            <label className="text-xs font-medium sm:col-span-2">Ablaufdatum<input disabled={disabled || busyId !== null} aria-label="Ablaufdatum" maxLength={100} placeholder="Freitext, z. B. 31.12.2027" value={draft.valid_until} onChange={event => setDrafts(current => ({ ...current, [item.id]: { ...draft, valid_until: event.target.value } }))} className={`${inputClass} mt-1`} /></label>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" onClick={() => void update(item, draft)} disabled={disabled || !changed || saving || busyId !== null} className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium disabled:cursor-not-allowed disabled:opacity-50">Vertrag speichern</button>
            <button type="button" onClick={() => void update(item, { is_active: 0 })} disabled={disabled || saving || busyId !== null} className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium disabled:cursor-not-allowed disabled:opacity-50">Als inaktiv markieren</button>
          </div>
        </li>;
      })}</ul>
        : <p className="mt-4 text-sm text-slate-500">Noch keine aktiven Verträge eingetragen.</p>}
    {archived.length > 0 && <div className="mt-4"><button type="button" aria-expanded={showArchived} onClick={() => setShowArchived(value => !value)} className="text-sm font-medium text-brand-blue">{showArchived ? "Inaktive Verträge ausblenden" : `Inaktive Verträge anzeigen (${archived.length})`}</button>{showArchived && <ul className="mt-2 space-y-2">{archived.map(item => <li key={item.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-slate-50 px-3 py-2 text-sm"><span>{item.contract_name} · {item.insurer}</span><button type="button" onClick={() => void update(item, { is_active: 1 })} disabled={disabled || saving || busyId !== null} className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium disabled:opacity-50">Wieder aktivieren</button></li>)}</ul>}</div>}
    <form onSubmit={event => void add(event)} className="mt-5 border-t border-slate-200 pt-4">
      <h4 className="text-sm font-semibold">Vertrag hinzufügen</h4>
      <div className="mt-3 grid gap-3 sm:grid-cols-2"><label className="text-xs font-medium">Vertrag<input disabled={disabled || saving || retryLocked} required maxLength={120} value={contractName} onChange={event => setContractName(event.target.value)} className={`${inputClass} mt-1`} /></label><label className="text-xs font-medium">Versicherer<input disabled={disabled || saving || retryLocked} required maxLength={120} value={insurer} onChange={event => setInsurer(event.target.value)} className={`${inputClass} mt-1`} /></label><label className="text-xs font-medium sm:col-span-2">Ablaufdatum<input disabled={disabled || saving || retryLocked} maxLength={100} placeholder="Freitext, z. B. 31.12.2027" value={validUntil} onChange={event => setValidUntil(event.target.value)} className={`${inputClass} mt-1`} /></label></div>
      <p className="mt-2 text-xs text-slate-500">Neue Einträge werden als aktiv gespeichert. Ablaufdaten ändern den Status nicht automatisch.</p>
      <button type="submit" disabled={disabled || saving} className="mt-3 rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-300">{saving ? <LoadingIndicator compact label="Speichert …" /> : retryLocked ? "Erneut versuchen" : "Vertrag hinzufügen"}</button>
    </form>
    {error && <p role="alert" className="mt-3 text-sm text-rose-700">{error}</p>}
  </section>;
}));
