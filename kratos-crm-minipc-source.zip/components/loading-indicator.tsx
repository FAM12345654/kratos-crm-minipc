import Image from "next/image";

export function LoadingIndicator({ label, compact = false }: { label: string; compact?: boolean }) {
  const size = compact ? 20 : 40;
  return (
    <span role="status" className="inline-flex items-center gap-2 text-sm">
      <Image
        src="/familienhelden-loader.gif"
        alt=""
        width={size}
        height={size}
        className="familienhelden-loader shrink-0 motion-reduce:hidden"
        unoptimized
      />
      <span>{label}</span>
    </span>
  );
}
