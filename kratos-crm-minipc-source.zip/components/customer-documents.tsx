"use client";

import { LoadingIndicator } from "@/components/loading-indicator";
import { memo, useEffect, useState } from "react";

const categories = [
  { key: "Vollmacht", title: "Vollmacht" },
  { key: "Beratungsprotokoll", title: "Beratungsprotokolle" },
  { key: "Antrag", title: "Anträge" },
  { key: "Vertrag", title: "Verträge und Polizzen" },
  { key: "Schaden", title: "Schadenunterlagen" },
  { key: "Schriftverkehr", title: "Schriftverkehr" },
  { key: "Sonstiges", title: "Diverse Unterlagen" },
] as const;

type Document = { id: number; category: string; file_name: string; file_url: string };

export const CustomerDocuments = memo(function CustomerDocuments({ customerId }: { customerId: number }) {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const controller = new AbortController();
    void (async () => {
      try {
        const response = await fetch(`/api/documents?customer_id=${customerId}`, { cache: "no-store", signal: controller.signal });
        const data = await response.json() as { documents?: Document[]; error?: string; message?: string };
        if (!response.ok) throw new Error(data.error || data.message || "Dokumente konnten nicht geladen werden.");
        setDocuments(data.documents ?? []);
      } catch (cause) {
        if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "Dokumente konnten nicht geladen werden.");
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    })();
    return () => controller.abort();
  }, [customerId]);

  return <section className="mt-6 border-y border-slate-200 py-5" aria-labelledby="customer-documents-title">
    <div className="mb-4 flex items-end justify-between gap-3">
      <div><h3 id="customer-documents-title" className="font-semibold">Dokumentenübersicht</h3><p className="mt-1 text-xs text-slate-500">Registrierte Dateien aus der bestätigten Kundenmappe</p></div>
      {!loading && !error && <span className="text-xs text-slate-500">{documents.length} verknüpft</span>}
    </div>
    {loading ? <LoadingIndicator label="Dokumente werden geladen …" />
      : error ? <p role="alert" className="text-sm text-rose-700">{error}</p>
      : <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {categories.map(category => {
          const items = documents.filter(document => document.category === category.key);
          return <section key={category.key} className="min-h-28 rounded-xl border border-slate-200 bg-slate-50/70 p-4" aria-label={category.title}>
            <h4 className="text-sm font-semibold text-slate-800">{category.title}</h4>
            {items.length ? <ul className="mt-3 space-y-2">{items.map(document => <li key={document.id}><a href={document.file_url} target="_blank" rel="noreferrer" className="break-words text-sm text-brand-blue underline decoration-brand-cyan underline-offset-2 hover:text-brand-ink">{document.file_name}</a></li>)}</ul>
              : <p className="mt-2 text-xs text-slate-500">Noch keine Datei verknüpft</p>}
          </section>;
        })}
      </div>}
    <p className="mt-4 text-xs leading-5 text-slate-500">Die Übersicht zeigt registrierte Dateien. Weitere Dokumente können in OneDrive liegen. Eine Datei öffnet sich über ihren Namen.</p>
  </section>;
});
