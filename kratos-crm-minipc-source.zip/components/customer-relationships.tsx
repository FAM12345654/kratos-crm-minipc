"use client";

import { LoadingIndicator } from "@/components/loading-indicator";
import { forwardRef, memo, useCallback, useEffect, useImperativeHandle, useState, type FormEvent } from "react";

type Customer = { id: number; first_name: string; last_name: string };
type Relationship = { id: number; related_customer_id: number; first_name: string; last_name: string; relationship: string; note: string | null };
const types = ["Vater von", "Mutter von", "Elternteil von", "Sohn von", "Tochter von", "Kind von", "Ehemann von", "Ehefrau von", "Partner von", "Partnerin von", "Bruder von", "Schwester von", "Geschwister von", "Sonstige Beziehung"];

export type CustomerRelationshipsHandle = { savePending: () => Promise<boolean> };

export const CustomerRelationships = memo(forwardRef<CustomerRelationshipsHandle, { customerId: number; disabled?: boolean }>(function CustomerRelationships({ customerId, disabled = false }, ref) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [relationships, setRelationships] = useState<Relationship[]>([]);
  const [relatedId, setRelatedId] = useState("");
  const [relationship, setRelationship] = useState(types[0]);
  const [newRelationTouched, setNewRelationTouched] = useState(false);
  const [newNote, setNewNote] = useState("");
  const [relationshipDrafts, setRelationshipDrafts] = useState<Record<number, string>>({});
  const [noteDrafts, setNoteDrafts] = useState<Record<number, string>>({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);

  const load = useCallback(async (signal?: AbortSignal) => {
    const [peopleResponse, relationshipsResponse] = await Promise.all([
      fetch("/api/customers/options", { cache: "no-store", signal }),
      fetch(`/api/relationships?customer_id=${customerId}`, { cache: "no-store", signal }),
    ]);
    const people = await peopleResponse.json() as { customers?: Customer[]; error?: string };
    const linked = await relationshipsResponse.json() as { relationships?: Relationship[]; error?: string };
    if (!peopleResponse.ok) throw new Error(people.error || "Kunden konnten nicht geladen werden.");
    if (!relationshipsResponse.ok) throw new Error(linked.error || "Beziehungen konnten nicht geladen werden.");
    setCustomers(people.customers ?? []);
    setRelationships(linked.relationships ?? []);
    setRelationshipDrafts(Object.fromEntries((linked.relationships ?? []).map(item => [item.id, item.relationship])));
    setNoteDrafts(Object.fromEntries((linked.relationships ?? []).map(item => [item.id, item.note ?? ""])));
  }, [customerId]);

  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal).catch(cause => {
      if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "Beziehungen konnten nicht geladen werden.");
    }).finally(() => {
      if (!controller.signal.aborted) setLoading(false);
    });
    return () => controller.abort();
  }, [load]);

  const savePending = useCallback(async () => {
    if (saving || busyId !== null) { setError("Speichervorgang läuft noch. Bitte nach Abschluss erneut schließen."); return false; }
    const changed = relationships.filter(item => (relationshipDrafts[item.id] ?? item.relationship) !== item.relationship || (noteDrafts[item.id] ?? item.note ?? "") !== (item.note ?? ""));
    const hasNewDraft = Boolean(relatedId || newNote.trim() || (newRelationTouched && relationship !== types[0]));
    if (hasNewDraft && !relatedId) {
      setError("Bitte für die neue Beziehung einen Kunden auswählen oder die unvollständige Eingabe leeren.");
      return false;
    }
    if (!changed.length && !hasNewDraft) return true;
    setError(""); setBusyId(changed[0]?.id ?? null);
    try {
      for (const item of changed) {
        const nextRelationship = relationshipDrafts[item.id] ?? item.relationship;
        const nextNote = noteDrafts[item.id] ?? item.note ?? "";
        const response = await fetch("/api/relationships", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id, customer_id: customerId, relationship: nextRelationship, note: nextNote }) });
        const data = await response.json() as { error?: string };
        if (!response.ok) throw new Error(data.error || "Beziehungsänderungen konnten nicht gespeichert werden.");
        setRelationships(current => current.map(existing => existing.id === item.id ? { ...existing, relationship: nextRelationship, note: nextNote } : existing));
        setRelationshipDrafts(current => ({ ...current, [item.id]: nextRelationship }));
        setNoteDrafts(current => ({ ...current, [item.id]: nextNote }));
      }
      if (hasNewDraft) {
        const response = await fetch("/api/relationships", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ customer_id: customerId, related_customer_id: Number(relatedId), relationship, note: newNote }) });
        const data = await response.json() as { error?: string };
        if (!response.ok) throw new Error(data.error || "Neue Beziehung konnte nicht gespeichert werden.");
        setRelatedId(""); setNewNote(""); setRelationship(types[0]); setNewRelationTouched(false);
      }
      await load();
      return true;
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Beziehungsänderungen konnten nicht gespeichert werden.");
      return false;
    } finally { setBusyId(null); }
  }, [busyId, customerId, load, newNote, newRelationTouched, noteDrafts, relatedId, relationships, relationshipDrafts, relationship, saving]);

  useImperativeHandle(ref, () => ({ savePending }), [savePending]);

  async function add(event: FormEvent) {
    event.preventDefault();
    setError(""); setSaving(true);
    try {
      const response = await fetch("/api/relationships", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ customer_id: customerId, related_customer_id: Number(relatedId), relationship, note: newNote }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Beziehung konnte nicht gespeichert werden.");
      setRelatedId(""); setNewNote(""); setRelationship(types[0]); setNewRelationTouched(false);
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Beziehung konnte nicht gespeichert werden."); }
    finally { setSaving(false); }
  }

  async function updateRelationship(item: Relationship) {
    setError(""); setBusyId(item.id);
    try {
      const response = await fetch("/api/relationships", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id, customer_id: customerId, relationship: relationshipDrafts[item.id] ?? item.relationship, note: noteDrafts[item.id] ?? item.note ?? "" }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Beziehung konnte nicht geändert werden.");
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Beziehung konnte nicht geändert werden."); }
    finally { setBusyId(null); }
  }

  async function removeRelationship(item: Relationship) {
    if (!window.confirm(`Beziehung zu ${item.first_name} ${item.last_name} entfernen?`)) return;
    setError(""); setBusyId(item.id);
    try {
      const response = await fetch("/api/relationships", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id, customer_id: customerId }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Beziehung konnte nicht entfernt werden.");
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Beziehung konnte nicht entfernt werden."); }
    finally { setBusyId(null); }
  }

  const candidates = customers.filter(customer => customer.id !== customerId && !relationships.some(item => item.related_customer_id === customer.id));
  return <section className="mt-6 rounded-xl border border-slate-200 p-4" aria-labelledby="customer-relationships-title">
    <h3 id="customer-relationships-title" className="font-semibold">Kundenbeziehungen</h3>
    {busyId !== null && <LoadingIndicator compact label="Wird aktualisiert …" />}
    {loading ? <div className="mt-3"><LoadingIndicator label="Beziehungen werden geladen …" /></div>
      : relationships.length ? <ul className="mt-3 space-y-2">{relationships.map(item => {
        const noteValue = noteDrafts[item.id] ?? item.note ?? "";
        const relationValue = relationshipDrafts[item.id] ?? item.relationship;
        const changed = noteValue !== (item.note ?? "") || relationValue !== item.relationship;
        return <li key={item.id} className="grid gap-2 rounded-lg bg-slate-50 p-3 sm:grid-cols-[1fr_auto_auto] sm:items-center">
          <span className="text-sm"><span className="font-medium">{item.relationship}</span> <span>{item.first_name} {item.last_name}</span></span>
          <select disabled={disabled || busyId !== null} aria-label={`Beziehung zu ${item.first_name} ${item.last_name}`} value={relationValue} onChange={event => setRelationshipDrafts(current => ({ ...current, [item.id]: event.target.value }))} className="rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm">{types.map(type => <option key={type}>{type}</option>)}</select>
          <div className="flex gap-2"><button type="button" onClick={() => void updateRelationship(item)} disabled={disabled || saving || busyId !== null || !changed} className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium hover:bg-white disabled:cursor-not-allowed disabled:opacity-50">Ändern</button><button type="button" onClick={() => void removeRelationship(item)} disabled={disabled || saving || busyId !== null} className="rounded-lg border border-rose-200 px-3 py-1.5 text-xs font-medium text-rose-700 hover:bg-white disabled:cursor-not-allowed disabled:opacity-50">Entfernen</button></div>
          <label className="text-sm sm:col-span-3"><span className="mb-1 block font-medium">Notiz zur Beziehung</span><textarea disabled={disabled || busyId !== null} value={noteValue} maxLength={1000} onChange={event => setNoteDrafts(current => ({ ...current, [item.id]: event.target.value }))} placeholder="Besonderheiten zu dieser Beziehung" className="min-h-16 w-full rounded-lg border border-slate-300 bg-white px-3 py-2" /></label>
        </li>;
      })}</ul>
        : <p className="mt-3 text-sm text-slate-500">Noch keine Beziehungen hinterlegt.</p>}
    <form onSubmit={event => void add(event)} className="mt-4 grid gap-3 sm:grid-cols-[1fr_1fr_auto]">
      <label className="text-sm"><span className="mb-1 block font-medium">Kunde</span><select disabled={disabled || busyId !== null} value={relatedId} onChange={event => setRelatedId(event.target.value)} required className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2"><option value="">Kunde auswählen</option>{candidates.map(customer => <option key={customer.id} value={customer.id}>{customer.first_name} {customer.last_name}</option>)}</select></label>
      <label className="text-sm"><span className="mb-1 block font-medium">Beziehung</span><select disabled={disabled || busyId !== null} value={relationship} onChange={event => {setRelationship(event.target.value);setNewRelationTouched(true);}} className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2">{types.map(type => <option key={type}>{type}</option>)}</select></label>
      <label className="text-sm sm:col-span-2"><span className="mb-1 block font-medium">Notiz zur Beziehung</span><textarea disabled={disabled || busyId !== null} value={newNote} maxLength={1000} onChange={event => setNewNote(event.target.value)} placeholder="Besonderheiten zu dieser Beziehung" className="min-h-16 w-full rounded-lg border border-slate-300 bg-white px-3 py-2" /></label>
      <button type="submit" disabled={disabled || saving || !candidates.length} className="self-end rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-300">{saving ? <LoadingIndicator compact label="Speichert …" /> : "Verknüpfen"}</button>
      {(relatedId || newNote || relationship !== types[0]) && <button type="button" disabled={disabled || busyId !== null} onClick={() => {setRelatedId("");setNewNote("");setRelationship(types[0]);setNewRelationTouched(false);}} className="self-end rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium disabled:opacity-50">Eingabe zurücksetzen</button>}
    </form>
    {error && <p role="alert" className="mt-3 text-sm text-rose-700">{error}</p>}
  </section>;
}));
