import { env } from "cloudflare:workers";
import { categoryFolders, documentCategories, listCustomerDocuments, registerCustomerDocument } from "../../lib/customer-documents";

const tools = [
  {
    name: "list_customer_documents",
    description: "List registered OneDrive documents for one Kratos customer, optionally by category. An empty index does not mean no files exist; check the customer's verified folder with SharePoint. Returns file links, not document contents.",
    annotations: { readOnlyHint: true },
    inputSchema: { type:"object", properties:{ customer_id:{type:"integer",minimum:1}, category:{type:"string",enum:documentCategories} }, required:["customer_id"], additionalProperties:false },
  },
  {
    name: "register_customer_document",
    description: "Register or reclassify one verified OneDrive file in a customer's Kratos document index. Call only after SharePoint confirms a successful upload or existing file metadata. Use its exact file_name and web URL. Does not upload bytes. Never register a guessed URL or claim a Chat attachment is saved before upload succeeds.",
    annotations: { readOnlyHint:false, destructiveHint:false, idempotentHint:true },
    inputSchema: { type:"object", properties:{ customer_id:{type:"integer",minimum:1}, category:{type:"string",enum:documentCategories}, file_name:{type:"string",minLength:1,maxLength:255}, file_url:{type:"string",minLength:1,maxLength:1500} }, required:["customer_id","category","file_name","file_url"], additionalProperties:false },
  },
  {
    name: "prepare_consultation_filing",
    description: "Prepare filing of files uploaded by the user after a consultation. First resolve the exact customer. Read only the uploaded documents needed to classify each file. For each original file choose Antrag, Vollmacht, Beratungsprotokoll or another category; ask on ambiguity. Use SharePoint to discover the exact customer folder, create missing category subfolders, and upload each Chat file reference separately without overwrite. If one PDF contains several documents, split into separate files with document tools before uploading, preserving the original. After each confirmed upload call register_customer_document with returned metadata. Report saved files and failures separately. Never send files to third parties as part of filing.",
    annotations: {readOnlyHint:true},
    inputSchema:{type:"object",properties:{customer_id:{type:"integer",minimum:1}},required:["customer_id"],additionalProperties:false},
  },
  {
    name: "list_follow_ups",
    description: "List Kratos customer follow-ups through an inclusive YYYY-MM-DD date. Dates are interpreted in Europe/Berlin. Returns a total and bounded results; does not send messages.",
    annotations: { readOnlyHint: true },
    inputSchema: { type: "object", properties: { through_date: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" }, limit: { type: "integer", minimum: 1, maximum: 100 } }, required: ["through_date"], additionalProperties: false },
  },
  {
    name: "get_document_lookup",
    description: "Get the verified OneDrive folder and search terms for a customer's requested document. This returns a lookup plan, not a file inventory. Use SharePoint to verify files and fetch only the requested document. Sending requires a specific recipient and user instruction.",
    annotations: { readOnlyHint: true },
    inputSchema: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 }, document_type: { type: "string", enum: ["Vollmacht", "Vertrag", "Antrag", "Beratungsprotokoll", "Schaden", "Schriftverkehr", "Sonstiges"] } }, required: ["customer_id", "document_type"], additionalProperties: false },
  },
  {
    name: "search_customers",
    description: "Search Familienhelden customer records by name, phone, email, adviser, or status. Returns contact data and any verified OneDrive folder URL. For customer documents, use the connected Microsoft SharePoint/OneDrive plugin under Kunden/<folder_name>; fetch only the specifically requested file.",
    inputSchema: { type: "object", properties: { query: { type: "string", minLength: 2, maxLength: 100 }, limit: { type: "integer", minimum: 1, maximum: 25 } }, required: ["query"], additionalProperties: false },
  },
  {
    name: "get_customer",
    description: "Get one Familienhelden customer by exact CRM id. Includes contact details, adviser, status, verified OneDrive folder name and direct folder URL, and follow-up fields. For customer documents, use the connected SharePoint plugin inside Kunden/<folder_name>; fetch only the requested file.",
    inputSchema: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 } }, required: ["customer_id"], additionalProperties: false },
  },
  {
    name: "create_customer",
    description: "Create a Familienhelden customer CRM record. Set lead_color to green (fits), yellow (open) or red (does not fit) when known; otherwise use the neutral yellow default. Do not add contract, bank, health, or other sensitive document contents. Do not create a record unless the user explicitly asks.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false },
    inputSchema: { type: "object", properties: { first_name: { type: "string", minLength: 1, maxLength: 100 }, last_name: { type: "string", minLength: 1, maxLength: 100 }, phone: { type: "string", maxLength: 50 }, email: { type: "string", maxLength: 254 }, birthday: { type: "string", maxLength: 100 }, authority_status: { type: "string", maxLength: 100 }, lead_color: { type: "string", enum: ["green", "yellow", "red"] }, adviser: { type: "string", maxLength: 100 }, status: { type: "string", maxLength: 100 }, folder_name: { type: "string", maxLength: 200 }, folder_url: { type: "string", maxLength: 1000 }, internal_note: { type: "string", maxLength: 2000 }, last_contact_at: { type: "string", maxLength: 100 }, next_follow_up_at: { type: "string", maxLength: 100 }, next_follow_up_note: { type: "string", maxLength: 500 } }, required: ["first_name", "last_name"], additionalProperties: false },
  },
  {
    name: "update_customer",
    description: "Update an existing Familienhelden CRM customer, including free-text date fields, internal notes and lead_color (green fits, yellow open, red does not fit). Do not store sensitive contract or bank details.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true },
    inputSchema: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 }, first_name: { type: "string", minLength: 1, maxLength: 100 }, last_name: { type: "string", minLength: 1, maxLength: 100 }, phone: { type: "string", maxLength: 50 }, email: { type: "string", maxLength: 254 }, birthday: { type: "string", maxLength: 100 }, authority_status: { type: "string", maxLength: 100 }, lead_color: { type: "string", enum: ["green", "yellow", "red"] }, adviser: { type: "string", maxLength: 100 }, status: { type: "string", maxLength: 100 }, folder_name: { type: "string", maxLength: 200 }, folder_url: { type: "string", maxLength: 1000 }, internal_note: { type: "string", maxLength: 2000 }, last_contact_at: { type: "string", maxLength: 100 }, next_follow_up_at: { type: "string", maxLength: 100 }, next_follow_up_note: { type: "string", maxLength: 500 } }, required: ["customer_id"], additionalProperties: false },
  },
  {
    name: "sync_folder_links",
    description: "Save verified OneDrive customer-folder URLs for existing CRM records. Supply URLs returned by OneDrive metadata and the exact CRM ID plus folder name; every row is checked before any change. Does not read or store document contents.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true },
    inputSchema: { type: "object", properties: { links: { type: "array", minItems: 1, maxItems: 120, items: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 }, folder_name: { type: "string", minLength: 1, maxLength: 200 }, folder_url: { type: "string", minLength: 1, maxLength: 1000 } }, required: ["customer_id", "folder_name", "folder_url"], additionalProperties: false } } }, required: ["links"], additionalProperties: false },
  },
  {
    name: "import_customers",
    description: "One-time initial import of customer records explicitly approved by the user. Insert-only, maximum 120 rows, duplicate-safe by first name, last name and phone. Do not import non-customer business contacts or sensitive document details.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true },
    inputSchema: { type: "object", properties: { customers: { type: "array", maxItems: 120, items: { type: "object", properties: { first_name: { type: "string", minLength: 1, maxLength: 100 }, last_name: { type: "string", minLength: 1, maxLength: 100 }, phone: { type: "string", maxLength: 50 }, adviser: { type: "string", maxLength: 100 }, status: { type: "string", enum: ["Kunde"] }, folder_name: { type: "string", maxLength: 200 } }, required: ["first_name", "last_name"], additionalProperties: false } } }, required: ["customers"], additionalProperties: false },
  },
];

type Json = Record<string, unknown>;
const textResult = (value: unknown, isError = false) => ({ content: [{ type: "text", text: JSON.stringify(value) }], structuredContent: value, ...(isError ? { isError: true } : {}) });
const str = (v: unknown) => typeof v === "string" ? v.trim() : "";
const opt = (v: unknown) => str(v) || null;
const samePhone = (left: string, right: string) => {
  const leftDigits = left.replace(/\D/g, "");
  return leftDigits.length >= 6 && leftDigits === right.replace(/\D/g, "");
};
const fail = (message: string) => ({ isError: true, message });
const validText = (v: unknown, max: number) => v === undefined || v === null || (typeof v === "string" && v.trim().length <= max);
const validFolderUrl = (v: unknown) => validText(v, 1000) && (v === undefined || v === null || String(v).trim() === "" || /^https:\/\/familienhelden2025-my\.sharepoint\.com\//i.test(String(v).trim()));
const validLeadColor = (v: unknown) => v === undefined || v === null || ["green", "yellow", "red"].includes(String(v));
const dateKey = (value: unknown) => {
  const raw = typeof value === "string" ? value.trim() : "";
  const iso = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  const local = raw.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
  const parts = iso ? [Number(iso[1]), Number(iso[2]), Number(iso[3])] : local ? [Number(local[3]), Number(local[2]), Number(local[1])] : null;
  if (!parts) return null;
  const [year, month, day] = parts;
  const parsed = new Date(Date.UTC(year, month - 1, day));
  return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month - 1 && parsed.getUTCDate() === day ? `${year.toString().padStart(4,"0")}-${month.toString().padStart(2,"0")}-${day.toString().padStart(2,"0")}` : null;
};

async function runTool(name: string, a: Json, actor: string) {
  const db = env.DB;
  if (!db) return fail("CRM-Datenbank ist nicht verfügbar.");
  if (["list_customer_documents","prepare_consultation_filing"].includes(name)) {
    const id=Number(a.customer_id);
    if (!Number.isInteger(id)||id<1) return fail("Gültige Kunden-ID erforderlich.");
    if (a.category!==undefined&&!documentCategories.includes(a.category as typeof documentCategories[number])) return fail("Ungültige Dokumentart.");
    const result=await listCustomerDocuments(db,id,a.category as string|undefined);
    if (name==="list_customer_documents"||result.isError) return result;
    return {...result, category_folders:categoryFolders, workflow:["Kundenidentität und Mappe prüfen", "Anhänge einzeln klassifizieren; gemischte PDFs trennen, Original erhalten", "Zielordner über SharePoint verifizieren oder anlegen", "Jede Datei ohne Überschreiben hochladen", "Nur erfolgreich gespeicherte Dateien mit register_customer_document registrieren", "Gespeicherte Dateien und offene Punkte getrennt berichten"], note:"Nur ein Ablageplan. Noch keine Datei hochgeladen. Bei unklarer Zuordnung nachfragen."};
  }
  if (name==="register_customer_document") return registerCustomerDocument(db,a,actor);
  if (name === "list_follow_ups") {
    const date = str(a.through_date);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(`${date}T00:00:00Z`)) || new Date(`${date}T00:00:00Z`).toISOString().slice(0,10) !== date) return fail("Gültiges Datum im Format YYYY-MM-DD erforderlich.");
    const limit = a.limit === undefined ? 25 : Number(a.limit);
    if (!Number.isInteger(limit) || limit < 1 || limit > 100) return fail("Limit muss zwischen 1 und 100 liegen.");
    const rows = await db.prepare("SELECT id,first_name,last_name,lead_color,adviser,folder_url,next_follow_up_at,next_follow_up_note FROM customers WHERE next_follow_up_at IS NOT NULL ORDER BY next_follow_up_at,id LIMIT 500").all();
    const due = rows.results.filter((row) => { const key = dateKey(row.next_follow_up_at); return key !== null && key <= date; });
    return { total: due.length, returned: Math.min(due.length, limit), through_date: date, timezone: "Europe/Berlin", customers: due.slice(0, limit) };
  }
  if (name === "get_document_lookup") {
    const id = Number(a.customer_id);
    const terms: Record<string,string[]> = { Vollmacht: ["Vollmacht", "VM"], Vertrag: ["Vertrag", "Polizze", "Police"], Antrag: ["Antrag"], Beratungsprotokoll: ["Beratungsprotokoll", "Beratung"], Schaden: ["Schaden", "Unfall"], Schriftverkehr: ["Schriftverkehr", "Korrespondenz"], Sonstiges: [] };
    const kind = str(a.document_type);
    if (!Number.isInteger(id) || id < 1 || !Object.hasOwn(terms,kind)) return fail("Gültige CRM-ID und Dokumentart erforderlich.");
    const row = await db.prepare("SELECT id,first_name,last_name,folder_name,folder_url FROM customers WHERE id=?").bind(id).first<{id:number;first_name:string;last_name:string;folder_name:string|null;folder_url:string|null}>();
    if (!row) return fail("Kunde nicht gefunden.");
    if (!row.folder_name || !row.folder_url || !validFolderUrl(row.folder_url)) return fail("Keine bestätigte OneDrive-Kundenmappe vorhanden; Zuordnung zuerst prüfen.");
    return { customer: row, document_type: kind, search_terms: terms[kind], inventory_verified: false, next_step: "Mit SharePoint ausschließlich diese Kundenmappe einschließlich Unterordnern prüfen. Dateitreffer verifizieren, bevor ein Download oder eine Weiterleitung angeboten wird." };
  }
  if (name === "search_customers") {
    const q = str(a.query);
    if (q.length < 2 || q.length > 100) return fail("Suchtext muss 2 bis 100 Zeichen lang sein.");
    const like = `%${q.replace(/[\\%_]/g, "\\$&")}%`;
    const limit = Math.min(Math.max(Number(a.limit ?? 15) || 15, 1), 25);
    const rows = await db.prepare("SELECT id, first_name, last_name, phone, email, birthday, authority_status, lead_color, adviser, status, folder_name, folder_url, internal_note, last_contact_at, next_follow_up_at, next_follow_up_note FROM customers WHERE first_name LIKE ? ESCAPE '\\' OR last_name LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\' OR adviser LIKE ? ESCAPE '\\' OR status LIKE ? ESCAPE '\\' OR internal_note LIKE ? ESCAPE '\\' ORDER BY last_name, first_name LIMIT ?")
      .bind(like, like, like, like, like, like, like, limit).all();
    return { count: rows.results.length, customers: rows.results, document_lookup: "Bei Dokumentfragen die passende OneDrive-Mappe Kunden/<folder_name> mit dem SharePoint-Plugin gezielt durchsuchen; nur angefragte Dateien abrufen." };
  }
  if (name === "get_customer") {
    const id = Number(a.customer_id);
    if (!Number.isInteger(id) || id < 1) return fail("Ungültige customer_id.");
    const row = await db.prepare("SELECT id, first_name, last_name, phone, email, birthday, authority_status, lead_color, adviser, status, folder_name, folder_url, internal_note, last_contact_at, next_follow_up_at, next_follow_up_note, created_at, updated_at FROM customers WHERE id = ?").bind(id).first();
    return row ?? fail("Kunde nicht gefunden.");
  }
  if (name === "create_customer") {
    const first = str(a.first_name), last = str(a.last_name);
    if (!first || !last) return fail("Vor- und Nachname sind erforderlich.");
    if (first.length > 100 || last.length > 100 || !validText(a.phone, 50) || !validText(a.email, 254) || !validText(a.birthday, 100) || !validText(a.authority_status, 100) || !validLeadColor(a.lead_color) || !validText(a.adviser, 100) || !validText(a.folder_name, 200) || !validFolderUrl(a.folder_url) || !validText(a.internal_note, 2000) || !validText(a.last_contact_at, 100) || !validText(a.next_follow_up_at, 100) || !validText(a.next_follow_up_note, 500) || !validText(a.status, 100)) return fail("Ein oder mehrere Felder überschreiten die zulässige Länge oder enthalten einen ungültigen Status.");
    const phone = opt(a.phone);
    const email = opt(a.email);
    const sameName = await db.prepare("SELECT id,phone,email FROM customers WHERE lower(first_name)=lower(?) AND lower(last_name)=lower(?) ORDER BY id LIMIT 10")
      .bind(first, last).all<{id:number;phone:string|null;email:string|null}>();
    const uncertainContact = !phone && !email;
    const duplicate = sameName.results.find((row) => uncertainContact || Boolean(phone && row.phone && samePhone(phone, row.phone)) || Boolean(email && row.email && email.toLocaleLowerCase() === row.email.toLocaleLowerCase()));
    if (duplicate) return fail(`Möglicher Dublettentreffer vorhanden (CRM-ID ${duplicate.id}); bitte erst prüfen.`);
    const now = new Date().toISOString();
    const created = await db.batch([
      db.prepare("INSERT INTO customers (first_name,last_name,phone,email,birthday,authority_status,lead_color,adviser,status,folder_name,folder_url,internal_note,last_contact_at,next_follow_up_at,next_follow_up_note,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .bind(first, last, phone, email, opt(a.birthday), opt(a.authority_status) ?? "Ungeprüft", opt(a.lead_color) ?? "yellow", opt(a.adviser), opt(a.status) ?? "Kunde", opt(a.folder_name), opt(a.folder_url), opt(a.internal_note), opt(a.last_contact_at), opt(a.next_follow_up_at), opt(a.next_follow_up_note), now, actor),
      db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) SELECT last_insert_rowid(),'create',?,?").bind(JSON.stringify(Object.keys(a)), actor),
    ]);
    const id = Number(created[0].meta.last_row_id);
    return await db.prepare("SELECT * FROM customers WHERE id=?").bind(id).first();
  }
  if (name === "update_customer") {
    const id = Number(a.customer_id);
    if (!Number.isInteger(id) || id < 1) return fail("Ungültige customer_id.");
    const fieldMap: Record<string, string> = { first_name: "first_name", last_name: "last_name", phone: "phone", email: "email", birthday: "birthday", authority_status: "authority_status", lead_color: "lead_color", adviser: "adviser", status: "status", folder_name: "folder_name", folder_url: "folder_url", internal_note: "internal_note", last_contact_at: "last_contact_at", next_follow_up_at: "next_follow_up_at", next_follow_up_note: "next_follow_up_note" };
    const fields = Object.keys(fieldMap).filter((k) => Object.hasOwn(a, k));
    if (!fields.length) return fail("Keine änderbaren Felder übergeben.");
    const limits: Record<string, number> = { first_name: 100, last_name: 100, phone: 50, email: 254, birthday: 100, authority_status: 100, lead_color: 10, adviser: 100, status: 100, folder_name: 200, folder_url: 1000, internal_note: 2000, last_contact_at: 100, next_follow_up_at: 100, next_follow_up_note: 500 };
    if (fields.some((k) => !validText(a[k], limits[k])) || !validLeadColor(a.lead_color) || !validFolderUrl(a.folder_url)) return fail("Ein oder mehrere Felder überschreiten die zulässige Länge oder enthalten einen ungültigen Status.");
    const current = await db.prepare("SELECT id FROM customers WHERE id=?").bind(id).first();
    if (!current) return fail("Kunde nicht gefunden.");
    const now = new Date().toISOString();
    const sets = fields.map((k) => `${fieldMap[k]}=?`).concat(["updated_at=?", "updated_by=?"]);
    const values = fields.map((k) => opt(a[k]));
    await db.batch([
      db.prepare(`UPDATE customers SET ${sets.join(",")} WHERE id=?`).bind(...values, now, actor, id),
      db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(id, "update", JSON.stringify(fields), actor),
    ]);
    return await db.prepare("SELECT * FROM customers WHERE id=?").bind(id).first();
  }
  if (name === "sync_folder_links") {
    const links = Array.isArray(a.links) ? a.links as Json[] : [];
    if (links.length < 1 || links.length > 120) return fail("Der Linkabgleich muss 1 bis 120 Zuordnungen enthalten.");
    const rows = links.map((link) => ({ id: Number(link.customer_id), folder: str(link.folder_name), url: str(link.folder_url) }));
    if (rows.some((row) => !Number.isInteger(row.id) || row.id < 1 || !row.folder || row.folder.length > 200 || !row.url || !validFolderUrl(row.url)) || new Set(rows.map((row) => row.id)).size !== rows.length) return fail("Ungültiger OneDrive-Link oder doppelte CRM-ID; es wurde nichts geändert.");
    const current = await db.prepare("SELECT id,folder_name FROM customers").all<{id:number;folder_name:string|null}>();
    const folders = new Map(current.results.map((row) => [row.id, row.folder_name]));
    if (rows.some((row) => folders.get(row.id) !== row.folder)) return fail("Mindestens eine CRM-ID passt nicht exakt zum angegebenen Kundenordner; es wurde nichts geändert.");
    const now = new Date().toISOString();
    const statements: D1PreparedStatement[] = [];
    for (const row of rows) {
      statements.push(db.prepare("UPDATE customers SET folder_url=?,updated_at=?,updated_by=? WHERE id=? AND folder_name=?").bind(row.url, now, actor, row.id, row.folder));
      statements.push(db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(row.id, "folder_link_sync", JSON.stringify(["folder_url"]), actor));
    }
    for (let i=0;i<statements.length;i+=80) await db.batch(statements.slice(i,i+80));
    return { updated: rows.length, unmatched: 0, document_contents_read: false };
  }
  if (name === "import_customers") {
    const rows = Array.isArray(a.customers) ? a.customers as Json[] : null;
    if (!rows || rows.length > 120) return fail("Import akzeptiert maximal 120 Datensätze.");
    let inserted = 0, duplicates = 0, skipped = 0;
    const existingRows = await db.prepare("SELECT first_name,last_name,phone FROM customers").all<{first_name:string;last_name:string;phone:string|null}>();
    const keys = new Set(existingRows.results.map((r) => `${r.first_name.toLocaleLowerCase()}\u0000${r.last_name.toLocaleLowerCase()}\u0000${r.phone ?? ""}`));
    const statements: D1PreparedStatement[] = [];
    for (const row of rows) {
      const first = str(row.first_name), last = str(row.last_name), phone = opt(row.phone);
      if (!first || !last || first.length > 100 || last.length > 100 || !validText(phone, 50) || !validText(row.adviser, 100) || !validText(row.folder_name, 200) || (row.status !== undefined && row.status !== "Kunde")) { skipped++; continue; }
      const key = `${first.toLocaleLowerCase()}\u0000${last.toLocaleLowerCase()}\u0000${phone ?? ""}`;
      if (keys.has(key)) { duplicates++; continue; }
      keys.add(key);
      const now = new Date().toISOString();
      statements.push(db.prepare("INSERT INTO customers (first_name,last_name,phone,adviser,status,folder_name,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?)")
        .bind(first, last, phone, opt(row.adviser), "Kunde", opt(row.folder_name) ?? `${first} ${last}`, now, actor));
      statements.push(db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) SELECT last_insert_rowid(),'import',?,? ").bind(JSON.stringify(Object.keys(row)), actor));
    }
    for (let i=0; i<statements.length; i+=80) await db.batch(statements.slice(i, i+80));
    inserted = statements.length / 2;
    return { inserted, duplicates, skipped, total_received: rows.length };
  }
  return fail("Unbekanntes Tool.");
}

export async function POST(request: Request) {
  const actorId = request.headers.get("oai-authenticated-user-id");
  const actorEmail = request.headers.get("oai-authenticated-user-email");
  let body: Json;
  try { body = await request.json() as Json; } catch { return Response.json({ error: "invalid JSON" }, { status: 400 }); }
  const method = str(body.method);
  const params = (body.params ?? {}) as Json;
  const isInitialSeed = method === "tools/call" && str(params.name) === "import_customers";
  // Sites service access is owner-private and deliberately carries no visitor identity.
  // Restrict this path to the user-approved, insert-only first import; all other CRM
  // calls require the authenticated owner's identity for attribution and audit.
  if ((!actorId || !actorEmail) && !isInitialSeed) return Response.json({ error: "authenticated Site user required" }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const actor = actorEmail ?? "owner-private-initial-import";
  const id = body.id ?? null;
  let result: unknown;
  if (method === "server/discover") result = { supportedVersions: ["2026-07-28"], capabilities: { tools: {} }, serverInfo: { name: "familienhelden-crm", version: "1.0.0" } };
  else if (method === "initialize") result = { protocolVersion: "2026-07-28", capabilities: { tools: {} }, serverInfo: { name: "familienhelden-crm", version: "1.0.0" } };
  else if (method === "notifications/initialized" || method === "ping") result = {};
  else if (method === "tools/list") result = { tools };
  else if (method === "tools/call") {
    const name = str(params.name);
    const tool = tools.find((item) => item.name === name);
    if (!tool) result = textResult({ error: "Unknown tool" }, true);
    else {
      const args = (params.arguments ?? {}) as Json;
      const out = await runTool(name, args, actor);
      result = textResult(out, Boolean((out as Json)?.isError));
    }
  } else result = { error: { code: -32601, message: "Method not found" } };
  return Response.json({ jsonrpc: "2.0", id, result }, { headers: { "Cache-Control": "private, no-store", "MCP-Protocol-Version": "2026-07-28" } });
}
