"use client";

import { LoadingIndicator } from "@/components/loading-indicator";
import Image from "next/image";
import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { CustomerDocuments } from "../components/customer-documents";
import { CustomerRelationships, type CustomerRelationshipsHandle } from "../components/customer-relationships";
import { CustomerContracts, type CustomerContractsHandle } from "../components/customer-contracts";

type LeadColor = "green" | "yellow" | "red";
type Customer = { id:number; first_name:string; last_name:string; phone:string|null; email:string|null; birthday:string|null; authority_status:string; lead_color:LeadColor|null; adviser:string|null; status:string; folder_name:string|null; folder_url:string|null; internal_note:string|null; last_contact_at:string|null; next_follow_up_at:string|null; next_follow_up_note:string|null };
type CustomerDraft = { phone:string; email:string; birthday:string; authority_status:string; lead_color:LeadColor; adviser:string; internal_note:string; last_contact_at:string };
type NewCustomerDraft = CustomerDraft & { first_name:string; last_name:string; status:string; folder_name:string; next_follow_up_at:string; next_follow_up_note:string };
type ImportCustomer = { first_name:string; last_name:string; phone:string; adviser:string; status:"Kunde"; folder_name:string };
type ApiResponse = { error?:string; customers?:Customer[]; customer?:Customer; inserted?:number; duplicates?:number; skipped?:number; updated?:number };
type FolderLink = { customer_id:number; folder_name:string; folder_url:string };
const isFolderLink = (value:unknown): value is FolderLink => typeof value === "object" && value !== null && "customer_id" in value && Number.isInteger(value.customer_id) && "folder_name" in value && typeof value.folder_name === "string" && "folder_url" in value && typeof value.folder_url === "string";
const inputClass = "mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-brand-blue focus:ring-2 focus:ring-brand-cyan/20";
const leadColorClasses: Record<LeadColor, string> = { green: "bg-emerald-500", yellow: "bg-amber-400", red: "bg-rose-500" };
const leadColorAriaNames: Record<LeadColor, string> = { green: "Grün", yellow: "Gelb", red: "Rot" };
function LeadLightPicker({value,onChange}:{value:LeadColor;onChange:(color:LeadColor)=>void}) {
  return <div role="radiogroup" aria-label="Kundeneinstufung" className="flex items-center gap-2">{(["green","yellow","red"] as LeadColor[]).map(color=><button key={color} type="button" role="radio" aria-label={leadColorAriaNames[color]} aria-checked={value===color} onClick={()=>onChange(color)} className={`flex size-8 items-center justify-center rounded-full transition focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-cyan ${value===color?"ring-2 ring-brand-blue ring-offset-2":"hover:bg-slate-100"}`}><span className={`size-4 rounded-full ${leadColorClasses[color]}`} aria-hidden="true" /></button>)}</div>;
}
function dateKey(value:string|null|undefined):string|null {
  const raw=value?.trim()??"";
  const iso=raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  const local=raw.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
  const parts=iso?[Number(iso[1]),Number(iso[2]),Number(iso[3])]:local?[Number(local[3]),Number(local[2]),Number(local[1])]:null;
  if(!parts)return null;
  const [year,month,day]=parts;const parsed=new Date(Date.UTC(year,month-1,day));
  return parsed.getUTCFullYear()===year&&parsed.getUTCMonth()===month-1&&parsed.getUTCDate()===day?`${year.toString().padStart(4,"0")}-${month.toString().padStart(2,"0")}-${day.toString().padStart(2,"0")}`:null;
}
function customerDraft(customer:Customer):CustomerDraft {
  return { phone:customer.phone??"",email:customer.email??"",birthday:customer.birthday??"",authority_status:customer.authority_status??"",lead_color:customer.lead_color??"yellow",adviser:customer.adviser??"",internal_note:customer.internal_note??"",last_contact_at:customer.last_contact_at??"" };
}
const emptyCustomerDraft=():NewCustomerDraft=>({first_name:"",last_name:"",phone:"",email:"",birthday:"",authority_status:"Ungeprüft",lead_color:"yellow",adviser:"",status:"Kunde",folder_name:"",internal_note:"",last_contact_at:"",next_follow_up_at:"",next_follow_up_note:""});

function parseCsv(source:string): ImportCustomer[] {
  const firstLine=source.replace(/^\uFEFF/,"").split(/\r?\n/,1)[0]??"";
  const delimiter=firstLine.split(";").length>firstLine.split(",").length?";":",";
  const matrix:string[][]=[]; let row:string[]=[], cell="", quoted=false;
  const input=source.replace(/^\uFEFF/,"");
  for(let i=0;i<input.length;i++){
    const ch=input[i];
    if(ch==='"'&&quoted&&input[i+1]==='"'){cell+='"';i++;}
    else if(ch==='"') quoted=!quoted;
    else if(ch===delimiter&&!quoted){row.push(cell);cell="";}
    else if((ch==="\n"||ch==="\r")&&!quoted){if(ch==="\r"&&input[i+1]==="\n")i++;row.push(cell);matrix.push(row);row=[];cell="";}
    else cell+=ch;
  }
  if(cell.length||row.length){row.push(cell);matrix.push(row);}
  if(matrix.length<2) throw new Error("Die CSV-Datei enthält keine Datensätze.");
  const headers=matrix[0].map(h=>h.trim().toLowerCase());
  const ix=(name:string)=>headers.indexOf(name.toLowerCase());
  const firstIx=ix("First Name"),lastIx=ix("Last Name"),phoneIx=ix("Phone Number"),descIx=ix("Description");
  if([firstIx,lastIx,phoneIx,descIx].some(i=>i<0)) throw new Error("Erwartete Spalten: First Name, Last Name, Phone Number und Description.");
  return matrix.slice(1).map(r=>{
    const first_name=(r[firstIx]??"").trim(),last_name=(r[lastIx]??"").trim(),phone=(r[phoneIx]??"").trim(),description=(r[descIx]??"").trim();
    if(!/^Kunde\b/i.test(description)||!first_name||!last_name) return null;
    const adviser=description.match(/Betreuer:\s*([^|]+)/i)?.[1]?.trim()??"";
    return {first_name,last_name,phone,adviser:adviser==="?"?"":adviser,status:"Kunde" as const,folder_name:`${first_name} ${last_name}`};
  }).filter((r):r is ImportCustomer=>r!==null);
}

export default function Home() {
  const [query, setQuery] = useState("");
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [onlyDue, setOnlyDue] = useState(false);
  const [leadFilter, setLeadFilter] = useState<LeadColor|"all">("all");
  const today = new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Berlin" }).format(new Date());
  const dueCustomers = useMemo(() => customers.filter(c => { const key=dateKey(c.next_follow_up_at); return key!==null&&key<=today; }), [customers, today]);
  const filteredCustomers = useMemo(() => onlyDue ? dueCustomers : customers, [onlyDue, dueCustomers, customers]);
  const visibleCustomers = useMemo(() => leadFilter === "all" ? filteredCustomers : filteredCustomers.filter(c => (c.lead_color??"yellow") === leadFilter), [leadFilter, filteredCustomers]);
  const customerDialog = useRef<HTMLDialogElement>(null);
  const relationshipsRef = useRef<CustomerRelationshipsHandle>(null);
  const contractsRef = useRef<CustomerContractsHandle>(null);
  const customerSaveInFlight = useRef(false);
  const closeInFlight = useRef(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer|null>(null);
  const [draft, setDraft] = useState<CustomerDraft|null>(null);
  const [saving, setSaving] = useState(false);
  const [closing, setClosing] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [saveMessage, setSaveMessage] = useState("");
  const [newCustomer, setNewCustomer] = useState<NewCustomerDraft>(emptyCustomerDraft());
  const [creatingCustomer, setCreatingCustomer] = useState(false);
  const [createError, setCreateError] = useState("");
  const [createMessage, setCreateMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [importRows,setImportRows]=useState<ImportCustomer[]>([]);
  const [importFile,setImportFile]=useState("");
  const [importMessage,setImportMessage]=useState("");
  const [importing,setImporting]=useState(false);
  const [importError,setImportError]=useState("");
  const [folderLinks,setFolderLinks]=useState<FolderLink[]>([]);
  const [folderLinkFile,setFolderLinkFile]=useState("");
  const [folderLinkMessage,setFolderLinkMessage]=useState("");
  const [folderLinkError,setFolderLinkError]=useState("");
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setLoading(true); setError("");
      try {
        const response = await fetch(`/api/customers?q=${encodeURIComponent(query)}`, { cache: "no-store", signal: controller.signal });
        const data = await response.json() as ApiResponse;
        if (!response.ok) throw new Error(data.error ?? "Kundendaten konnten nicht geladen werden.");
        if (active) setCustomers(data.customers ?? []);
      } catch (e) { if (active && !controller.signal.aborted) setError(e instanceof Error ? e.message : "Fehler beim Laden."); }
      finally { if (active) setLoading(false); }
    }, 180);
    return () => { active = false; window.clearTimeout(timer); controller.abort(); };
  }, [query]);
  async function chooseImportFile(file:File|null){
    setImportRows([]);setImportFile("");setImportError("");setImportMessage("");
    if(!file)return;
    try{const rows=parseCsv(await file.text());if(rows.length!==105)throw new Error(`Es wurden ${rows.length} als Kunde gekennzeichnete Zeilen erkannt. Erwartet werden exakt 105 geprüfte Kunden.`);setImportRows(rows);setImportFile(file.name);}
    catch(e){setImportError(e instanceof Error?e.message:"CSV konnte nicht gelesen werden.");}
  }
  async function importCustomers(){
    if(importRows.length!==105)return;
    setImporting(true);setImportError("");setImportMessage("");
    try{
      const response=await fetch("/api/customers",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({customers:importRows})});
      const data=await response.json() as ApiResponse;if(!response.ok)throw new Error(data.error??"Import fehlgeschlagen.");
      setImportMessage(`${data.inserted} Kunden importiert, ${data.duplicates} Dubletten übersprungen, ${data.skipped} Zeilen ignoriert.`);setImportRows([]);setImportFile("");setQuery("");
      const refreshed=await fetch("/api/customers",{cache:"no-store"});const result=await refreshed.json() as ApiResponse;if(refreshed.ok)setCustomers(result.customers??[]);
    }catch(e){setImportError(e instanceof Error?e.message:"Import fehlgeschlagen.");}
    finally{setImporting(false);}
  }
  async function chooseFolderLinkFile(file:File|null){
    setFolderLinks([]);setFolderLinkFile("");setFolderLinkError("");setFolderLinkMessage("");
    if(!file)return;
    try{const data:unknown=JSON.parse(await file.text());const links=Array.isArray(data)?data:typeof data === "object" && data !== null && "folder_links" in data ? data.folder_links : null;if(!Array.isArray(links)||links.length<1||links.length>120||!links.every(isFolderLink))throw new Error("Erwartet wird eine JSON-Liste bestätigter CRM-ID/Ordnername/OneDrive-Link-Zuordnungen.");setFolderLinks(links);setFolderLinkFile(file.name);}
    catch(e){setFolderLinkError(e instanceof Error?e.message:"Datei konnte nicht gelesen werden.");}
  }
  async function syncFolderLinks(){
    if(!folderLinks.length)return;
    setImporting(true);setFolderLinkError("");setFolderLinkMessage("");
    try{const response=await fetch("/api/customers",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({folder_links:folderLinks})});const data=await response.json() as ApiResponse;if(!response.ok)throw new Error(data.error??"Ordnerlinks konnten nicht gespeichert werden.");setFolderLinkMessage(`${data.updated} bestätigte Kundenordnerlinks gespeichert.`);setFolderLinks([]);setFolderLinkFile("");const refreshed=await fetch("/api/customers",{cache:"no-store"});const result=await refreshed.json() as ApiResponse;if(refreshed.ok)setCustomers(result.customers??[]);}
    catch(e){setFolderLinkError(e instanceof Error?e.message:"Ordnerlinks konnten nicht gespeichert werden.");}
    finally{setImporting(false);}
  }
  const customerProfileOpen = selectedCustomer !== null;
  useEffect(() => {
    if (customerProfileOpen && customerDialog.current && !customerDialog.current.open) {
      customerDialog.current.show();
      if (window.matchMedia("(max-width: 767px)").matches) {
        customerDialog.current.scrollIntoView({ block: "start" });
      }
    }
  }, [customerProfileOpen]);

  function hasUnsavedCustomerChanges() {
    return Boolean(selectedCustomer && draft && JSON.stringify(draft) !== JSON.stringify(customerDraft(selectedCustomer)));
  }

  function openCustomer(customer: Customer) {
    if (customer.id === selectedCustomer?.id) return;
    if (saving || customerSaveInFlight.current || closing || closeInFlight.current) {
      setSaveMessage("Speichert gerade. Bitte nach Abschluss erneut öffnen.");
      return;
    }
    if (!selectedCustomer) {
      setSelectedCustomer(customer);
      setDraft(customerDraft(customer));
      setSaveError("");
      setSaveMessage("");
      return;
    }
    void switchCustomer(customer);
  }
  function finishClosingCustomer(){customerDialog.current?.close();setSelectedCustomer(null);setDraft(null);setSaveError("");setSaveMessage("");}
  async function persistCustomer():Promise<boolean>{
    if(customerSaveInFlight.current||!selectedCustomer||!draft)return false;
    customerSaveInFlight.current=true;
    setSaving(true);setSaveError("");setSaveMessage("");
    try{
      const response=await fetch("/api/customers",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({customer_id:selectedCustomer.id,fields:draft})});
      const data=await response.json() as ApiResponse;if(!response.ok||!data.customer)throw new Error(data.error??"Änderungen konnten nicht gespeichert werden.");
      setCustomers(current=>current.map(customer=>customer.id===data.customer!.id?data.customer!:customer));setSelectedCustomer(data.customer);setDraft(customerDraft(data.customer));setSaveMessage("Änderungen gespeichert.");
      return true;
    }catch(e){setSaveError(e instanceof Error?e.message:"Änderungen konnten nicht gespeichert werden.");return false;}
    finally{customerSaveInFlight.current=false;setSaving(false);}
  }
  async function saveAllPending():Promise<boolean>{
    const childResults=await Promise.all([contractsRef.current?.savePending()??true,relationshipsRef.current?.savePending()??true]);
    if(childResults.some(result=>!result))return false;
    if(hasUnsavedCustomerChanges()&&!await persistCustomer())return false;
    return true;
  }
  async function switchCustomer(customer:Customer){
    if(closeInFlight.current)return;
    closeInFlight.current=true;setClosing(true);
    try{
      if(!await saveAllPending())return;
      setSelectedCustomer(customer);setDraft(customerDraft(customer));setSaveError("");setSaveMessage("");
    }finally{closeInFlight.current=false;setClosing(false);}
  }
  async function closeCustomer(){
    if(closeInFlight.current){setSaveMessage("Speichert gerade. Bitte warten, bis der Speichervorgang abgeschlossen ist.");return;}
    if(saving||customerSaveInFlight.current||closing){setSaveMessage("Speichert gerade. Bitte nach Abschluss erneut schließen.");return;}
    closeInFlight.current=true;
    setClosing(true);
    try{
      if(await saveAllPending())finishClosingCustomer();
    }finally{closeInFlight.current=false;setClosing(false);}
  }
  useEffect(() => {
    if (!customerProfileOpen) return;
    function handleOutsidePointerDown(event: PointerEvent) {
      const target = event.target;
      if (!(target instanceof Element) || customerDialog.current?.contains(target)) return;
      if (target.closest("[data-customer-row]")) return;
      void closeCustomer();
    }
    function handleEscape(event: KeyboardEvent) {
      if (event.key !== "Escape") return;
      event.preventDefault();
      event.stopPropagation();
      void closeCustomer();
    }
    document.addEventListener("pointerdown", handleOutsidePointerDown);
    document.addEventListener("keydown", handleEscape, true);
    return () => {
      document.removeEventListener("pointerdown", handleOutsidePointerDown);
      document.removeEventListener("keydown", handleEscape, true);
    };
  });
  function saveCustomer(event:FormEvent<HTMLFormElement>){event.preventDefault();void persistCustomer();}
  async function createCustomer(event:FormEvent<HTMLFormElement>){
    event.preventDefault();setCreatingCustomer(true);setCreateError("");setCreateMessage("");
    try{
      const response=await fetch("/api/customers",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({customer:newCustomer})});
      const data=await response.json() as ApiResponse;if(!response.ok||!data.customer)throw new Error(data.error??"Kunde konnte nicht angelegt werden.");
      setCustomers(current=>[...current.filter(customer=>customer.id!==data.customer!.id),data.customer!].sort((a,b)=>a.last_name.localeCompare(b.last_name,"de")||a.first_name.localeCompare(b.first_name,"de")));
      setQuery("");setLeadFilter("all");setOnlyDue(false);setNewCustomer(emptyCustomerDraft());setCreateMessage(`${data.customer.first_name} ${data.customer.last_name} wurde angelegt (CRM-ID ${data.customer.id}).`);
    }catch(e){setCreateError(e instanceof Error?e.message:"Kunde konnte nicht angelegt werden.");}
    finally{setCreatingCustomer(false);}
  }
  return <main className="min-h-screen bg-background text-foreground">
    <header className="bg-[#504070] text-white">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-4 sm:px-6">
        <div className="flex items-center gap-3"><Image src="/familienhelden-signet.svg" alt="" width={42} height={42} unoptimized /><div><p className="text-xs font-semibold uppercase tracking-[.18em] text-violet-100">Familienhelden</p><h1 className="text-2xl font-semibold">Kratos</h1></div></div>
        <span className="rounded-full border border-white/30 bg-white/10 px-3 py-1.5 text-xs font-medium text-white">Private Datenbank</span>
      </div>
    </header>
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
      <details className="mb-6 rounded-2xl border border-brand-cyan/35 bg-white p-5 shadow-sm">
        <summary className="cursor-pointer font-semibold text-brand-blue">Kunden manuell anlegen</summary>
        <p className="mt-2 text-sm text-slate-600">Felder sind Freitext. Ein möglicher Namens- oder Kontaktdublettentreffer wird vor dem Speichern zur Prüfung angehalten.</p>
        <form className="mt-4" onSubmit={event=>void createCustomer(event)}>
          <fieldset disabled={creatingCustomer} className="grid gap-4 sm:grid-cols-2">
            <legend className="sr-only">Neuen Kunden anlegen</legend>
            {([['Vorname','first_name'],['Nachname','last_name'],['Telefon','phone'],['E-Mail','email'],['Geburtstag / Datum','birthday'],['Vollmacht','authority_status'],['Betreuer','adviser'],['Status','status'],['Letzter Kontakt','last_contact_at'],['Wiedervorlage / Datum','next_follow_up_at'],['Kundenmappe','folder_name']] as const).map(([label,key])=><label key={key} className="block text-sm font-medium">{label}<input type="text" required={key==='first_name'||key==='last_name'} value={newCustomer[key]} onChange={event=>setNewCustomer({...newCustomer,[key]:event.target.value})} className={inputClass} /></label>)}
            <div className="sm:col-span-2"><LeadLightPicker value={newCustomer.lead_color} onChange={color=>setNewCustomer({...newCustomer,lead_color:color})} /></div>
            <label className="block text-sm font-medium sm:col-span-2">Wiedervorlage-Notiz<input type="text" value={newCustomer.next_follow_up_note} onChange={event=>setNewCustomer({...newCustomer,next_follow_up_note:event.target.value})} className={inputClass} /></label>
            <label className="block text-sm font-medium sm:col-span-2">Notizen<textarea value={newCustomer.internal_note} onChange={event=>setNewCustomer({...newCustomer,internal_note:event.target.value})} rows={4} className={inputClass} placeholder="Freie interne Notizen zum Kunden" /></label>
          </fieldset>
          {createError&&<p role="alert" className="mt-3 text-sm text-rose-700">{createError}</p>}{createMessage&&<p role="status" className="mt-3 text-sm text-emerald-800">{createMessage}</p>}
          <button type="submit" disabled={creatingCustomer} className="mt-4 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-300">{creatingCustomer ? <LoadingIndicator compact label="Legt an …" /> : "Kunden speichern"}</button>
        </form>
      </details>
      {customers.length===0&&!query&&<section className="mb-6 rounded-2xl border border-brand-cyan/35 bg-white p-6 shadow-sm"><div className="mb-3"><h2 className="font-semibold">Geprüfte Kunden importieren</h2><p className="mt-1 text-sm text-slate-600">Nur die geprüfte Familienhelden-Kundendatei mit genau 105 Kunden wird angenommen. Kontakte ohne bestätigte Kundenmappe werden nicht importiert.</p></div><input type="file" accept=".csv,text/csv" onChange={e=>void chooseImportFile(e.target.files?.[0]??null)} className="block w-full max-w-xl text-sm file:mr-4 file:rounded-lg file:border-0 file:bg-primary file:px-4 file:py-2.5 file:font-medium file:text-white hover:file:bg-brand-blue/90"/>{importFile&&<p className="mt-3 text-sm text-emerald-800">{importFile}: {importRows.length} geprüfte Kunden erkannt.</p>}{importError&&<p role="alert" className="mt-3 text-sm text-rose-700">{importError}</p>}{importMessage&&<p role="status" className="mt-3 text-sm font-medium text-emerald-800">{importMessage}</p>}<button onClick={()=>void importCustomers()} disabled={importRows.length!==105||importing} className="mt-4 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-300">{importing ? <LoadingIndicator compact label="Import läuft …" /> : "105 geprüfte Kunden ins CRM importieren"}</button></section>}
      <section className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><h2 className="font-semibold">Bestätigte OneDrive-Ordnerlinks aktualisieren</h2><p className="mt-1 text-sm text-slate-600">Es werden nur Einträge mit exakt passender CRM-ID und Kundenordnerbezeichnung gespeichert.</p><input type="file" accept=".json,application/json" onChange={e=>void chooseFolderLinkFile(e.target.files?.[0]??null)} className="mt-3 block w-full max-w-xl text-sm file:mr-4 file:rounded-lg file:border-0 file:bg-brand-ink file:px-4 file:py-2 file:font-medium file:text-white"/>{folderLinkFile&&<p className="mt-2 text-sm text-slate-600">{folderLinkFile}: {folderLinks.length} Zuordnungen erkannt.</p>}{folderLinkError&&<p role="alert" className="mt-2 text-sm text-rose-700">{folderLinkError}</p>}{folderLinkMessage&&<p role="status" className="mt-2 text-sm text-emerald-800">{folderLinkMessage}</p>}<button type="button" onClick={()=>void syncFolderLinks()} disabled={!folderLinks.length||importing} className="mt-3 rounded-lg bg-brand-ink px-3 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-300">{importing ? <LoadingIndicator compact label="Speichern läuft …" /> : "Bestätigte Links speichern"}</button></section>
      <section className="mb-6 grid gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm md:grid-cols-[1fr_auto] md:items-end">
        <label className="block"><span className="mb-2 block text-sm font-medium">Kunden suchen</span><input maxLength={100} value={query} onChange={e=>setQuery(e.target.value)} placeholder="Name, Telefonnummer, E-Mail oder Betreuer" className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-brand-blue focus:ring-2 focus:ring-brand-cyan/20" /></label>
        <p className="text-sm text-slate-500">Suche ab 2 Zeichen · höchstens 200 Treffer</p>
      </section>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <button type="button" aria-pressed={onlyDue} onClick={()=>setOnlyDue(!onlyDue)} className="rounded-xl border border-brand-cyan/50 bg-white px-4 py-2 text-sm font-medium text-brand-blue">{onlyDue?"Alle Suchtreffer anzeigen":`Fällige Wiedervorlagen (${dueCustomers.length})`}</button>
        <span className="mr-2 text-xs text-slate-500">Fällige Datumsangaben: JJJJ-MM-TT oder TT.MM.JJJJ.</span>
        <div role="group" aria-label="Kunden nach Einstufung filtern" className="flex flex-wrap gap-2">
          {(["all","green","yellow","red"] as const).map(color=><button key={color} type="button" aria-pressed={leadFilter===color} onClick={()=>setLeadFilter(color)} className={`rounded-xl border px-3 py-2 text-sm font-medium ${leadFilter===color?"border-brand-blue bg-brand-blue text-white":"border-slate-200 bg-white text-slate-700 hover:border-brand-cyan"}`}>{color==="all"?"Alle Einstufungen":color==="green"?"Grün":color==="yellow"?"Gelb":"Rot"}</button>)}
        </div>
      </div>
      <div className={selectedCustomer ? "grid items-start gap-4 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]" : "grid gap-4"}>
      <section className={`kratos-customer-list min-w-0 overflow-hidden rounded-2xl border border-border bg-white shadow-sm ${selectedCustomer ? "is-split" : ""}`}>
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4"><h2 className="font-semibold">Kundenbestand</h2><span className="text-sm text-slate-500">{loading ? (customers.length > 0 ? <LoadingIndicator compact label="Lädt …" /> : null) : `${visibleCustomers.length} angezeigt`}</span></div>
        {error ? <div className="p-6 text-sm text-rose-700">{error}</div> : loading && !customers.length ? <div className="p-6"><LoadingIndicator label="Kundendaten werden geladen …" /></div> : visibleCustomers.length === 0 ? <div className="p-6 text-sm text-slate-500">Keine passenden Kunden gefunden.</div> : <div className="overflow-x-auto"><table className="w-full min-w-[920px] text-left text-sm"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr><th className="px-6 py-3">Kunde</th><th className="px-6 py-3"><span className="sr-only">Einstufung</span></th><th className="px-6 py-3">Telefon / E-Mail</th><th className="px-6 py-3">Betreuer</th><th className="px-6 py-3">Status</th><th className="px-6 py-3">Wiedervorlage</th><th className="px-6 py-3">OneDrive-Mappe</th></tr></thead><tbody>{visibleCustomers.map(c=>{const color=c.lead_color??"yellow";return <tr key={c.id} data-customer-row onClick={()=>openCustomer(c)} className="cursor-pointer border-t border-slate-100 align-top hover:bg-slate-50 focus-within:bg-slate-50"><td className="px-6 py-4 font-medium"><button type="button" onClick={event=>{event.stopPropagation();openCustomer(c);}} aria-haspopup="dialog" className="text-left text-brand-blue hover:underline focus:outline-none focus-visible:rounded focus-visible:ring-2 focus-visible:ring-brand-cyan">{c.first_name} {c.last_name}<span className="mt-1 block text-xs font-normal">Profil öffnen <span aria-hidden="true">→</span><span className="sr-only"> · CRM-ID {c.id}</span></span></button><span className="mt-1 block text-xs font-normal text-slate-400" aria-hidden="true">CRM-ID {c.id}</span></td><td className="px-6 py-4"><span role="img" aria-label={leadColorAriaNames[color]} className={`inline-block size-4 rounded-full ${leadColorClasses[color]}`} /></td><td className="px-6 py-4 text-slate-600">{c.phone||"–"}<span className="mt-1 block text-xs">{c.email||"–"}</span></td><td className="px-6 py-4 text-slate-600">{c.adviser||"–"}</td><td className="px-6 py-4"><span className="rounded-full bg-brand-cyan/10 px-2.5 py-1 text-xs font-medium text-brand-blue">{c.status}</span></td><td className="px-6 py-4 text-slate-600">{c.next_follow_up_at||"–"}{c.next_follow_up_note&&<span className="mt-1 block max-w-48 text-xs">{c.next_follow_up_note}</span>}</td><td className="px-6 py-4 text-slate-600">{c.folder_name||"–"}</td></tr>})}</tbody></table></div>}
      </section>
      {selectedCustomer&&draft&&<dialog ref={customerDialog} aria-labelledby="customer-detail-title"
        onClick={event=>{if(event.target===customerDialog.current)void closeCustomer();}}
        onCancel={event=>{event.preventDefault();closeCustomer();}}
        className="relative m-0 w-full min-w-0 scroll-mt-4 rounded-2xl border border-border bg-white p-4 text-[#29203e] shadow-sm sm:p-6">
        <div className="flex items-start justify-between gap-4"><div><p className="text-xs font-semibold uppercase tracking-wide text-brand-blue">Kundenprofil · CRM-ID {selectedCustomer.id}</p><h2 id="customer-detail-title" className="mt-1 text-xl font-semibold">{selectedCustomer.first_name} {selectedCustomer.last_name}</h2></div><button type="button" onClick={()=>void closeCustomer()} disabled={saving||closing} className="rounded-lg border border-slate-200 px-3 py-1.5 text-sm hover:bg-slate-50 disabled:opacity-50">{saving||closing?<LoadingIndicator compact label="Speichert …" />:"Schließen"}</button></div>
        <div aria-busy={closing||saving} className="mt-6 grid items-start gap-6 lg:grid-cols-2">
          <section aria-labelledby="customer-fields-title">
            <h3 id="customer-fields-title" className="text-lg font-semibold">Kundendaten</h3>
            <form className="mt-4" onSubmit={event=>void saveCustomer(event)}>
              <fieldset disabled={saving||closing} className="grid gap-4 sm:grid-cols-2">
                <legend className="sr-only">Kundendaten bearbeiten</legend>
                <div className="sm:col-span-2"><LeadLightPicker value={draft.lead_color} onChange={color=>setDraft({...draft,lead_color:color})} /></div>
                {([['Telefon','phone'],['E-Mail','email'],['Geburtstag / Datum','birthday'],['Vollmacht','authority_status'],['Betreuer','adviser'],['Letzter Kontakt','last_contact_at']] as const).map(([label,key])=><label key={key} className="block text-sm font-medium">{label}<input type="text" value={draft[key]} onChange={event=>setDraft({...draft,[key]:event.target.value})} className={inputClass} /></label>)}
                <label className="block text-sm font-medium sm:col-span-2">Notizen<textarea value={draft.internal_note} onChange={event=>setDraft({...draft,internal_note:event.target.value})} rows={4} className={inputClass} placeholder="Freie interne Notizen zum Kunden" /></label>
              </fieldset>
              {saveError&&<p role="alert" className="mt-3 text-sm text-rose-700">{saveError}</p>}{saveMessage&&<p role="status" className="mt-3 text-sm text-emerald-800">{saveMessage}</p>}
              <div className="mt-4 flex justify-end"><button type="submit" disabled={saving||closing} className="rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-300">{saving?<LoadingIndicator compact label="Speichert …" />:"Änderungen speichern"}</button></div>
            </form>
          </section>
          <CustomerContracts ref={contractsRef} key={selectedCustomer.id} customerId={selectedCustomer.id} disabled={closing}/>
        </div>
        <CustomerRelationships ref={relationshipsRef} key={`relationships-${selectedCustomer.id}`} customerId={selectedCustomer.id} disabled={closing}/>
        <CustomerDocuments key={`documents-${selectedCustomer.id}`} customerId={selectedCustomer.id}/></dialog>}
      </div>
      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-5"><h2 className="font-semibold">Dokumente über Kratos anfragen</h2><p className="mt-2 text-sm text-slate-600">Nenne im Chat den Kunden und die gewünschte Unterlage, zum Beispiel „Suche die Vollmacht von …“. Für das Weiterleiten nenne zusätzlich die Empfängeradresse.</p><p className="mt-2 text-xs text-slate-500">WhatsApp-Abgleich und Maklerkontakte folgen, sobald die Verbindung und Kontaktdaten vorliegen.</p></section>
      <p className="mt-5 text-xs leading-5 text-slate-500">OneDrive bleibt die führende Ablage für Verträge und Dokumente. Inhalte werden nur bei konkreter Kundenfrage gezielt gesucht. Das CRM enthält keine Bank- oder Vertragsdokumente.</p>
    </div>
  </main>;
}
