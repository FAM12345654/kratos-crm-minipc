import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";

function rejectWrite(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin || new URL(origin).origin !== new URL(request.url).origin) return Response.json({ error: "Ungültiger Herkunftsserver." }, { status: 403 });
  if (!request.headers.get("content-type")?.includes("application/json")) return Response.json({ error: "JSON erwartet." }, { status: 415 });
  return null;
}

export async function GET(request: Request) {
  if (!await getChatGPTUser()) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  if (!env.DB) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  const customerId = Number(new URL(request.url).searchParams.get("customer_id"));
  if (!Number.isInteger(customerId) || customerId < 1) return Response.json({ error: "Ungültige Kunden-ID." }, { status: 400 });
  const result = await env.DB.prepare("SELECT id,customer_id,contract_name,insurer,valid_until,is_active FROM customer_contracts WHERE customer_id=? ORDER BY is_active DESC,contract_name,insurer,id").bind(customerId).all();
  return Response.json({ contracts: result.results }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte zuerst über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const rejected = rejectWrite(request);
  if (rejected) return rejected;
  if (!env.DB) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  let body: { customer_id?: unknown; contract_name?: unknown; insurer?: unknown; valid_until?: unknown; request_id?: unknown };
  try { body = await request.json() as typeof body; }
  catch { return Response.json({ error: "Ungültige JSON-Daten." }, { status: 400 }); }
  const customerId = Number(body.customer_id);
  const name = typeof body.contract_name === "string" ? body.contract_name.trim() : "";
  const insurer = typeof body.insurer === "string" ? body.insurer.trim() : "";
  const validUntil = typeof body.valid_until === "string" ? body.valid_until.trim() : "";
  const requestId = typeof body.request_id === "string" ? body.request_id : null;
  if (!Number.isInteger(customerId) || customerId < 1 || !name || name.length > 120 || !insurer || insurer.length > 120 || validUntil.length > 100 || (requestId !== null && !/^[0-9a-f-]{36}$/i.test(requestId))) return Response.json({ error: "Bitte Vertrag, Versicherer und gültige Feldlängen prüfen." }, { status: 400 });
  const customer = await env.DB.prepare("SELECT id FROM customers WHERE id=?").bind(customerId).first();
  if (!customer) return Response.json({ error: "Kunde nicht gefunden." }, { status: 404 });
  const existing = requestId ? await env.DB.prepare("SELECT customer_id,contract_name,insurer,valid_until FROM customer_contracts WHERE request_id=?").bind(requestId).first<{ customer_id: number; contract_name: string; insurer: string; valid_until: string | null }>() : null;
  if (existing) {
    if (existing.customer_id !== customerId || existing.contract_name !== name || existing.insurer !== insurer || existing.valid_until !== (validUntil || null)) return Response.json({ error: "Diese Speicheranfrage wurde bereits mit anderen Daten verwendet." }, { status: 409 });
    return Response.json({ created: false, replayed: true }, { headers: { "Cache-Control": "private, no-store" } });
  }
  const now = new Date().toISOString();
  try {
    await env.DB.batch([
      env.DB.prepare("INSERT INTO customer_contracts (customer_id,contract_name,insurer,valid_until,request_id,is_active,created_at,updated_at,created_by,updated_by) VALUES (?,?,?,?,?,1,?,?,?,?)").bind(customerId, name, insurer, validUntil || null, requestId, now, now, user.email, user.email),
      env.DB.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(customerId, "contract_create", JSON.stringify(["contract_name", "insurer", "valid_until", "is_active"]), user.email),
    ]);
  } catch {
    const replay = requestId ? await env.DB.prepare("SELECT customer_id,contract_name,insurer,valid_until FROM customer_contracts WHERE request_id=?").bind(requestId).first<{ customer_id: number; contract_name: string; insurer: string; valid_until: string | null }>() : null;
    if (replay && replay.customer_id === customerId && replay.contract_name === name && replay.insurer === insurer && replay.valid_until === (validUntil || null)) return Response.json({ created: false, replayed: true }, { headers: { "Cache-Control": "private, no-store" } });
    return Response.json({ error: "Vertrag konnte nicht gespeichert werden." }, { status: 500, headers: { "Cache-Control": "private, no-store" } });
  }
  return Response.json({ created: true }, { status: 201, headers: { "Cache-Control": "private, no-store" } });
}

export async function PATCH(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte zuerst über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const rejected = rejectWrite(request);
  if (rejected) return rejected;
  if (!env.DB) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  let body: { id?: unknown; customer_id?: unknown; contract_name?: unknown; insurer?: unknown; valid_until?: unknown; is_active?: unknown };
  try { body = await request.json() as typeof body; }
  catch { return Response.json({ error: "Ungültige JSON-Daten." }, { status: 400 }); }
  const id = Number(body.id), customerId = Number(body.customer_id);
  if (!Number.isInteger(id) || id < 1 || !Number.isInteger(customerId) || customerId < 1) return Response.json({ error: "Ungültiger Vertrag oder Kunde." }, { status: 400 });
  const current = await env.DB.prepare("SELECT id FROM customer_contracts WHERE id=? AND customer_id=?").bind(id, customerId).first();
  if (!current) return Response.json({ error: "Vertrag nicht gefunden." }, { status: 404 });
  const fields = ["contract_name", "insurer", "valid_until", "is_active"].filter(key => Object.hasOwn(body, key));
  if (!fields.length || fields.some(key => key === "is_active" ? body.is_active !== 0 && body.is_active !== 1 && body.is_active !== false && body.is_active !== true : typeof body[key as "contract_name" | "insurer" | "valid_until"] !== "string")) return Response.json({ error: "Ungültige Vertragsdaten." }, { status: 400 });
  const values = new Map<string, string | number | null>();
  for (const key of fields) {
    const value = body[key as keyof typeof body];
    if (key === "is_active") values.set(key, value === 1 || value === true ? 1 : 0);
    else {
      const cleaned = (value as string).trim();
      const max = key === "valid_until" ? 100 : 120;
      if ((key !== "valid_until" && !cleaned) || cleaned.length > max) return Response.json({ error: "Vertrag, Versicherer und Feldlängen prüfen." }, { status: 400 });
      values.set(key, cleaned || null);
    }
  }
  const now = new Date().toISOString();
  const assignments = [...values.keys()].map(key => `${key}=?`).concat(["updated_at=?", "updated_by=?"]);
  await env.DB.batch([
    env.DB.prepare(`UPDATE customer_contracts SET ${assignments.join(",")} WHERE id=? AND customer_id=?`).bind(...values.values(), now, user.email, id, customerId),
    env.DB.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(customerId, "contract_update", JSON.stringify(fields), user.email),
  ]);
  return Response.json({ updated: true }, { headers: { "Cache-Control": "private, no-store" } });
}
