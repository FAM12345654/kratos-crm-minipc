import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";

export async function GET(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const db = env.DB;
  if (!db) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  const query = new URL(request.url).searchParams.get("q")?.trim() ?? "";
  if (query.length > 100) return Response.json({ error: "Suchtext darf höchstens 100 Zeichen lang sein." }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  const like = `%${query.replace(/[\\%_]/g, "\\$&")}%`;
  const rows = query.length >= 2
    ? await db.prepare("SELECT id,first_name,last_name,phone,email,birthday,authority_status,lead_color,adviser,status,folder_name,folder_url,internal_note,last_contact_at,next_follow_up_at,next_follow_up_note FROM customers WHERE first_name LIKE ? ESCAPE '\\' OR last_name LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\' OR adviser LIKE ? ESCAPE '\\' OR status LIKE ? ESCAPE '\\' OR internal_note LIKE ? ESCAPE '\\' ORDER BY last_name,first_name LIMIT 200").bind(like,like,like,like,like,like,like).all()
    : await db.prepare("SELECT id,first_name,last_name,phone,email,birthday,authority_status,lead_color,adviser,status,folder_name,folder_url,internal_note,last_contact_at,next_follow_up_at,next_follow_up_note FROM customers ORDER BY last_name,first_name LIMIT 200").all();
  return Response.json({ customers: rows.results }, { headers: { "Cache-Control": "private, no-store" } });
}

const editableLimits: Record<string, number> = { phone: 50, email: 254, birthday: 100, authority_status: 100, adviser: 100, status: 100, folder_name: 200, internal_note: 2000, last_contact_at: 100, next_follow_up_at: 100, next_follow_up_note: 500 };
const leadColors = ["green", "yellow", "red"];

export async function PATCH(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte zuerst über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const origin = request.headers.get("origin");
  if (!origin || new URL(origin).origin !== new URL(request.url).origin) return Response.json({ error: "Ungültiger Herkunftsserver." }, { status: 403 });
  if (!request.headers.get("content-type")?.includes("application/json")) return Response.json({ error: "JSON erwartet." }, { status: 415 });
  const db = env.DB;
  if (!db) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  let body: { customer_id?: unknown; fields?: Record<string, unknown> };
  try { body = await request.json() as typeof body; }
  catch { return Response.json({ error: "Ungültige JSON-Daten." }, { status: 400 }); }
  const id = Number(body.customer_id);
  const fields = body.fields && typeof body.fields === "object" && !Array.isArray(body.fields) ? body.fields : {};
  const keys = Object.keys(fields);
  if (!Number.isInteger(id) || id < 1 || !keys.length || keys.some(key => !Object.hasOwn(editableLimits, key) && key !== "lead_color")) return Response.json({ error: "Kundennummer oder bearbeitbare Felder sind ungültig." }, { status: 400 });
  if (keys.some(key => key === "lead_color" ? !leadColors.includes(String(fields[key])) : typeof fields[key] !== "string" || String(fields[key]).trim().length > editableLimits[key])) return Response.json({ error: "Ein Feld ist zu lang oder enthält einen ungültigen Wert." }, { status: 400 });
  const current = await db.prepare("SELECT id FROM customers WHERE id=?").bind(id).first();
  if (!current) return Response.json({ error: "Kunde nicht gefunden." }, { status: 404 });
  const now = new Date().toISOString();
  const sets = keys.map(key => `${key}=?`).concat(["updated_at=?", "updated_by=?"]);
  const values = keys.map(key => typeof fields[key] === "string" ? String(fields[key]).trim() || null : fields[key]);
  await db.batch([
    db.prepare(`UPDATE customers SET ${sets.join(",")} WHERE id=?`).bind(...values, now, user.email, id),
    db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(id, "update", JSON.stringify(keys), user.email),
  ]);
  const customer = await db.prepare("SELECT id,first_name,last_name,phone,email,birthday,authority_status,lead_color,adviser,status,folder_name,folder_url,internal_note,last_contact_at,next_follow_up_at,next_follow_up_note FROM customers WHERE id=?").bind(id).first();
  return Response.json({ customer }, { headers: { "Cache-Control": "private, no-store" } });
}

type ImportRow = { first_name?: unknown; last_name?: unknown; phone?: unknown; adviser?: unknown; status?: unknown; folder_name?: unknown };
type FolderLinkRow = { customer_id?: unknown; folder_name?: unknown; folder_url?: unknown };
const clean = (v: unknown, max: number) => typeof v === "string" && v.trim().length <= max ? v.trim() : "";

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte zuerst über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const origin = request.headers.get("origin");
  if (!origin || new URL(origin).origin !== new URL(request.url).origin) return Response.json({ error: "Ungültiger Herkunftsserver." }, { status: 403 });
  if (!request.headers.get("content-type")?.includes("application/json")) return Response.json({ error: "JSON erwartet." }, { status: 415 });
  const db = env.DB;
  if (!db) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  let body: { customers?: ImportRow[]; folder_links?: FolderLinkRow[]; customer?: Record<string, unknown> };
  try { body = await request.json() as typeof body; }
  catch { return Response.json({ error: "Ungültige JSON-Datei." }, { status: 400 }); }
  if (body.customer) {
    const c=body.customer;
    const first=clean(c.first_name,100),last=clean(c.last_name,100),phone=clean(c.phone,50),email=clean(c.email,254),birthday=clean(c.birthday,100),authority=clean(c.authority_status,100),adviser=clean(c.adviser,100),status=clean(c.status,100)||"Kunde",folder=clean(c.folder_name,200),note=clean(c.internal_note,2000),lastContact=clean(c.last_contact_at,100),followUp=clean(c.next_follow_up_at,100),followUpNote=clean(c.next_follow_up_note,500),leadColor=clean(c.lead_color,10)||"yellow";
    const lengths:Record<string,number>={phone:50,email:254,birthday:100,authority_status:100,adviser:100,status:100,folder_name:200,internal_note:2000,last_contact_at:100,next_follow_up_at:100,next_follow_up_note:500};
    if(!first||!last||first.length>100||last.length>100||typeof c.lead_color!=="undefined"&&!leadColors.includes(String(c.lead_color))||Object.entries(lengths).some(([key,max])=>typeof c[key]==="string"&&(c[key] as string).trim().length>max)) return Response.json({error:"Bitte Vor- und Nachnamen ausfüllen und Feldlängen sowie Ampelfarbe prüfen."},{status:400});
    const matches=await db.prepare("SELECT id,phone,email FROM customers WHERE lower(first_name)=lower(?) AND lower(last_name)=lower(?) ORDER BY id LIMIT 10").bind(first,last).all<{id:number;phone:string|null;email:string|null}>();
    const phoneDigits=phone.replace(/\D/g,"");
    const duplicate=matches.results.find(row=>!phone&&!email||Boolean(phoneDigits.length>=6&&row.phone&&phoneDigits===row.phone.replace(/\D/g,""))||Boolean(email&&row.email&&email.toLocaleLowerCase()===row.email.toLocaleLowerCase())||(!row.phone&&!row.email));
    if(duplicate)return Response.json({error:`Möglicher Dublettentreffer (CRM-ID ${duplicate.id}); bitte zuerst den bestehenden Kunden prüfen.`},{status:409});
    const now=new Date().toISOString();
    const created=await db.batch([
      db.prepare("INSERT INTO customers (first_name,last_name,phone,email,birthday,authority_status,lead_color,adviser,status,folder_name,internal_note,last_contact_at,next_follow_up_at,next_follow_up_note,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").bind(first,last,phone||null,email||null,birthday||null,authority||"Ungeprüft",leadColor,adviser||null,status,folder||null,note||null,lastContact||null,followUp||null,followUpNote||null,now,user.email),
      db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) SELECT last_insert_rowid(),'create',?,?").bind(JSON.stringify(["first_name","last_name","phone","email","birthday","authority_status","lead_color","adviser","status","folder_name","internal_note","last_contact_at","next_follow_up_at","next_follow_up_note"]),user.email),
    ]);
    const customerId=Number(created[0].meta.last_row_id);
    const customer=await db.prepare("SELECT id,first_name,last_name,phone,email,birthday,authority_status,lead_color,adviser,status,folder_name,folder_url,internal_note,last_contact_at,next_follow_up_at,next_follow_up_note FROM customers WHERE id=?").bind(customerId).first();
    return Response.json({customer},{status:201,headers:{"Cache-Control":"private, no-store"}});
  }
  if (Array.isArray(body.folder_links)) {
    const links = body.folder_links;
    if (links.length < 1 || links.length > 120) return Response.json({ error: "Der Linkabgleich muss 1 bis 120 Datensätze enthalten." }, { status: 400 });
    const parsed = links.map((link) => {
      const customerId = Number(link.customer_id);
      const folderName = clean(link.folder_name, 200);
      const folderUrl = clean(link.folder_url, 1000);
      let validUrl = false;
      try { const url = new URL(folderUrl); validUrl = url.protocol === "https:" && url.hostname === "familienhelden2025-my.sharepoint.com"; } catch {}
      return { customerId, folderName, folderUrl, valid: Number.isInteger(customerId) && customerId > 0 && !!folderName && validUrl };
    });
    if (parsed.some((row) => !row.valid) || new Set(parsed.map((row) => row.customerId)).size !== parsed.length) return Response.json({ error: "Ungültiger oder doppelter Kundenlink; es wurde nichts geändert." }, { status: 400 });
    const existingRows = await db.prepare("SELECT id,folder_name FROM customers").all<{id:number;folder_name:string|null}>();
    const existing = new Map(existingRows.results.map((row) => [row.id, row.folder_name]));
    if (parsed.some((row) => existing.get(row.customerId) !== row.folderName)) return Response.json({ error: "Mindestens eine CRM-ID passt nicht exakt zum bestätigten OneDrive-Ordnernamen; es wurde nichts geändert." }, { status: 409 });
    const statements: D1PreparedStatement[] = [];
    for (const row of parsed) {
      statements.push(db.prepare("UPDATE customers SET folder_url=?,updated_at=?,updated_by=? WHERE id=? AND folder_name=?").bind(row.folderUrl, new Date().toISOString(), user.email, row.customerId, row.folderName));
      statements.push(db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(row.customerId, "folder_link_sync", JSON.stringify(["folder_url"]), user.email));
    }
    for (let i=0;i<statements.length;i+=80) await db.batch(statements.slice(i,i+80));
    return Response.json({ updated: parsed.length, unmatched: 0 }, { headers: { "Cache-Control": "private, no-store" } });
  }
  if (!Array.isArray(body.customers) || body.customers.length < 1 || body.customers.length > 120) return Response.json({ error: "Der Import muss 1 bis 120 Kunden enthalten." }, { status: 400 });

  const existing = await db.prepare("SELECT first_name,last_name,phone FROM customers").all<{first_name:string;last_name:string;phone:string|null}>();
  const seen = new Set(existing.results.map(r=>`${r.first_name.toLocaleLowerCase()}\u0000${r.last_name.toLocaleLowerCase()}\u0000${r.phone??""}`));
  const statements: D1PreparedStatement[] = [];
  let duplicates=0, skipped=0;
  for (const row of body.customers) {
    const first=clean(row.first_name,100), last=clean(row.last_name,100), phone=clean(row.phone,50), adviser=clean(row.adviser,100), folder=clean(row.folder_name,200);
    if (!first || !last || row.status !== "Kunde" || !folder) { skipped++; continue; }
    const key=`${first.toLocaleLowerCase()}\u0000${last.toLocaleLowerCase()}\u0000${phone}`;
    if (seen.has(key)) { duplicates++; continue; }
    seen.add(key);
    const now=new Date().toISOString();
    statements.push(db.prepare("INSERT INTO customers (first_name,last_name,phone,adviser,status,folder_name,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?)").bind(first,last,phone||null,adviser||null,"Kunde",folder,now,user.email));
    statements.push(db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) SELECT last_insert_rowid(),'initial_import',?,?").bind(JSON.stringify(["first_name","last_name","phone","adviser","status","folder_name"]),user.email));
  }
  for (let i=0;i<statements.length;i+=80) await db.batch(statements.slice(i,i+80));
  return Response.json({ inserted: statements.length/2, duplicates, skipped, received: body.customers.length }, { headers: { "Cache-Control": "private, no-store" } });
}
