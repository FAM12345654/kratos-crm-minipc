import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";

export async function GET() {
  if (!await getChatGPTUser()) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  if (!env.DB) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503, headers: { "Cache-Control": "private, no-store" } });
  const customers = await env.DB.prepare("SELECT id,first_name,last_name FROM customers ORDER BY last_name,first_name LIMIT 1000").all();
  return Response.json({ customers: customers.results }, { headers: { "Cache-Control": "private, no-store" } });
}
