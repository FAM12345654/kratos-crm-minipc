import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";

const reverse: Record<string, string> = {
  "Vater von": "Kind von",
  "Mutter von": "Kind von",
  "Elternteil von": "Kind von",
  "Sohn von": "Elternteil von",
  "Tochter von": "Elternteil von",
  "Kind von": "Elternteil von",
  "Ehemann von": "Ehefrau von",
  "Ehefrau von": "Ehemann von",
  "Partner von": "Partnerin von",
  "Partnerin von": "Partner von",
  "Bruder von": "Geschwister von",
  "Schwester von": "Geschwister von",
  "Geschwister von": "Geschwister von",
  "Sonstige Beziehung": "Sonstige Beziehung",
};

export async function GET(request: Request) {
  if (!await getChatGPTUser()) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const db = env.DB;
  if (!db) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  const customerId = Number(new URL(request.url).searchParams.get("customer_id"));
  if (!Number.isInteger(customerId) || customerId < 1) return Response.json({ error: "Ungültige Kunden-ID." }, { status: 400 });
  const result = await db.prepare(`
    SELECT r.id,r.customer_b_id AS related_customer_id,c.first_name,c.last_name,r.relationship_a_to_b AS relationship,r.note,r.created_at
    FROM customer_relationships r JOIN customers c ON c.id=r.customer_b_id WHERE r.customer_a_id=?
    UNION ALL
    SELECT r.id,r.customer_a_id AS related_customer_id,c.first_name,c.last_name,r.relationship_b_to_a AS relationship,r.note,r.created_at
    FROM customer_relationships r JOIN customers c ON c.id=r.customer_a_id WHERE r.customer_b_id=?
    ORDER BY last_name,first_name
  `).bind(customerId, customerId).all();
  return Response.json({ relationships: result.results }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte zuerst über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const origin = request.headers.get("origin");
  if (!origin || new URL(origin).origin !== new URL(request.url).origin) return Response.json({ error: "Ungültiger Herkunftsserver." }, { status: 403 });
  if (!request.headers.get("content-type")?.includes("application/json")) return Response.json({ error: "JSON erwartet." }, { status: 415 });
  const db = env.DB;
  if (!db) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  let body: { customer_id?: unknown; related_customer_id?: unknown; relationship?: unknown; note?: unknown };
  try { body = await request.json() as typeof body; }
  catch { return Response.json({ error: "Ungültige JSON-Daten." }, { status: 400 }); }
  const customerId = Number(body.customer_id), relatedId = Number(body.related_customer_id), relationship = typeof body.relationship === "string" ? body.relationship : "";
  if (!Number.isInteger(customerId) || customerId < 1 || !Number.isInteger(relatedId) || relatedId < 1 || customerId === relatedId || !Object.hasOwn(reverse, relationship)) return Response.json({ error: "Bitte zwei verschiedene Kunden und eine gültige Beziehung auswählen." }, { status: 400 });
  if (body.note !== undefined && (typeof body.note !== "string" || body.note.trim().length > 1000)) return Response.json({ error: "Die Beziehungsnotiz darf höchstens 1.000 Zeichen enthalten." }, { status: 400 });
  const note = typeof body.note === "string" ? body.note.trim() : "";
  const exists = await db.prepare("SELECT id FROM customers WHERE id IN (?,?)").bind(customerId, relatedId).all<{ id: number }>();
  if (exists.results.length !== 2) return Response.json({ error: "Mindestens einer der Kunden wurde nicht gefunden." }, { status: 404 });
  const a = Math.min(customerId, relatedId), b = Math.max(customerId, relatedId);
  const labelAToB = customerId === a ? relationship : reverse[relationship];
  const labelBToA = customerId === a ? reverse[relationship] : relationship;
  const duplicate = await db.prepare("SELECT relationship_a_to_b,relationship_b_to_a,note FROM customer_relationships WHERE customer_a_id=? AND customer_b_id=?").bind(a, b).first<{ relationship_a_to_b: string; relationship_b_to_a: string; note: string | null }>();
  if (duplicate) {
    if (duplicate.relationship_a_to_b === labelAToB && duplicate.relationship_b_to_a === labelBToA && (duplicate.note ?? "") === note) return Response.json({ created: false, replayed: true }, { headers: { "Cache-Control": "private, no-store" } });
    return Response.json({ error: "Diese Kunden sind bereits miteinander verknüpft." }, { status: 409 });
  }
  try {
    await db.batch([
      db.prepare("INSERT INTO customer_relationships (customer_a_id,customer_b_id,relationship_a_to_b,relationship_b_to_a,note,created_by) VALUES (?,?,?,?,?,?)").bind(a, b, labelAToB, labelBToA, note, user.email),
      db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(customerId, "relationship_create", JSON.stringify(["customer_relationships", "relationship", "note"]), user.email),
      db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(relatedId, "relationship_create", JSON.stringify(["customer_relationships", "relationship", "note"]), user.email),
    ]);
  } catch {
    const replay = await db.prepare("SELECT relationship_a_to_b,relationship_b_to_a,note FROM customer_relationships WHERE customer_a_id=? AND customer_b_id=?").bind(a, b).first<{ relationship_a_to_b: string; relationship_b_to_a: string; note: string | null }>();
    if (replay && replay.relationship_a_to_b === labelAToB && replay.relationship_b_to_a === labelBToA && (replay.note ?? "") === note) return Response.json({ created: false, replayed: true }, { headers: { "Cache-Control": "private, no-store" } });
    return Response.json({ error: "Beziehung konnte nicht gespeichert werden." }, { status: 500, headers: { "Cache-Control": "private, no-store" } });
  }
  return Response.json({ created: true }, { status: 201, headers: { "Cache-Control": "private, no-store" } });
}

export async function PATCH(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte zuerst über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const origin = request.headers.get("origin");
  if (!origin || new URL(origin).origin !== new URL(request.url).origin) return Response.json({ error: "Ungültiger Herkunftsserver." }, { status: 403 });
  if (!request.headers.get("content-type")?.includes("application/json")) return Response.json({ error: "JSON erwartet." }, { status: 415 });
  const db = env.DB;
  if (!db) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  let body: { id?: unknown; customer_id?: unknown; relationship?: unknown; note?: unknown };
  try { body = await request.json() as typeof body; }
  catch { return Response.json({ error: "Ungültige JSON-Daten." }, { status: 400 }); }
  const id = Number(body.id), customerId = Number(body.customer_id), relationship = typeof body.relationship === "string" ? body.relationship : "";
  if (!Number.isInteger(id) || id < 1 || !Number.isInteger(customerId) || customerId < 1 || !Object.hasOwn(reverse, relationship)) return Response.json({ error: "Ungültige Beziehung." }, { status: 400 });
  if (body.note !== undefined && (typeof body.note !== "string" || body.note.trim().length > 1000)) return Response.json({ error: "Die Beziehungsnotiz darf höchstens 1.000 Zeichen enthalten." }, { status: 400 });
  const row = await db.prepare("SELECT customer_a_id,customer_b_id,note FROM customer_relationships WHERE id=?").bind(id).first<{ customer_a_id: number; customer_b_id: number; note: string }>();
  if (!row || (row.customer_a_id !== customerId && row.customer_b_id !== customerId)) return Response.json({ error: "Beziehung nicht gefunden." }, { status: 404 });
  const labelAToB = customerId === row.customer_a_id ? relationship : reverse[relationship];
  const labelBToA = customerId === row.customer_a_id ? reverse[relationship] : relationship;
  const note = typeof body.note === "string" ? body.note.trim() : row.note;
  await db.batch([
    db.prepare("UPDATE customer_relationships SET relationship_a_to_b=?,relationship_b_to_a=?,note=? WHERE id=?").bind(labelAToB, labelBToA, note, id),
    db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(row.customer_a_id, "relationship_update", JSON.stringify(["relationship", "note"]), user.email),
    db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(row.customer_b_id, "relationship_update", JSON.stringify(["relationship", "note"]), user.email),
  ]);
  return Response.json({ updated: true }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function DELETE(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte zuerst über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const origin = request.headers.get("origin");
  if (!origin || new URL(origin).origin !== new URL(request.url).origin) return Response.json({ error: "Ungültiger Herkunftsserver." }, { status: 403 });
  if (!request.headers.get("content-type")?.includes("application/json")) return Response.json({ error: "JSON erwartet." }, { status: 415 });
  const db = env.DB;
  if (!db) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  let body: { id?: unknown; customer_id?: unknown };
  try { body = await request.json() as typeof body; }
  catch { return Response.json({ error: "Ungültige JSON-Daten." }, { status: 400 }); }
  const id = Number(body.id), customerId = Number(body.customer_id);
  if (!Number.isInteger(id) || id < 1 || !Number.isInteger(customerId) || customerId < 1) return Response.json({ error: "Ungültige Beziehung." }, { status: 400 });
  const row = await db.prepare("SELECT customer_a_id,customer_b_id FROM customer_relationships WHERE id=?").bind(id).first<{ customer_a_id: number; customer_b_id: number }>();
  if (!row || (row.customer_a_id !== customerId && row.customer_b_id !== customerId)) return Response.json({ error: "Beziehung nicht gefunden." }, { status: 404 });
  await db.batch([
    db.prepare("DELETE FROM customer_relationships WHERE id=?").bind(id),
    db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(row.customer_a_id, "relationship_delete", JSON.stringify(["customer_relationships"]), user.email),
    db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(row.customer_b_id, "relationship_delete", JSON.stringify(["customer_relationships"]), user.email),
  ]);
  return Response.json({ deleted: true }, { headers: { "Cache-Control": "private, no-store" } });
}
