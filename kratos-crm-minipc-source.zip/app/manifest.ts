import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    id: "/",
    name: "Kratos · Familienhelden",
    short_name: "Kratos",
    description: "Privater Maklerassistent für Familienhelden.",
    lang: "de-AT",
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#f4f0fa",
    theme_color: "#504070",
    icons: [
      {
        src: "/kratos-icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
    ],
  };
}
