import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Kratos · Familienhelden",
  description: "Private Kratos-Datenbank für die Kundenbetreuung von Familienhelden.",
  manifest: "/manifest.webmanifest",
  themeColor: "#504070",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="de">
      <body className="antialiased">
        <svg aria-hidden="true" width="0" height="0" className="absolute">
          <defs>
            <filter id="familienhelden-loader-ink" colorInterpolationFilters="sRGB">
              <feColorMatrix type="matrix" values="0 0 0 0 .196  0 0 0 0 .141  0 0 0 0 .282  -1.1 0 0 1 0" />
            </filter>
          </defs>
        </svg>
        {children}
      </body>
    </html>
  );
}
