import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const customers = sqliteTable("customers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  phone: text("phone"),
  email: text("email"),
  birthday: text("birthday"),
  authorityStatus: text("authority_status").notNull().default("Ungeprüft"),
  leadColor: text("lead_color").notNull().default("yellow"),
  adviser: text("adviser"),
  status: text("status").notNull().default("Kunde"),
  folderName: text("folder_name"),
  folderUrl: text("folder_url"),
  internalNote: text("internal_note"),
  lastContactAt: text("last_contact_at"),
  nextFollowUpAt: text("next_follow_up_at"),
  nextFollowUpNote: text("next_follow_up_note"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedBy: text("updated_by").notNull().default("system-import"),
}, (table) => ({
  namePhoneUnique: uniqueIndex("customers_name_phone_unique").on(table.firstName, table.lastName, table.phone),
  nameIndex: index("customers_name_idx").on(table.lastName, table.firstName),
  phoneIndex: index("customers_phone_idx").on(table.phone),
}));

export const auditEvents = sqliteTable("audit_events", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id").notNull(),
  action: text("action").notNull(),
  changedFields: text("changed_fields").notNull(),
  actorEmail: text("actor_email").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const customerDocuments = sqliteTable("customer_documents", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id").references(() => customers.id, { onDelete: "cascade" }),
  category: text("category").notNull(),
  fileName: text("file_name").notNull(),
  fileUrl: text("file_url").notNull(),
  source: text("source").notNull().default("OneDrive"),
  registeredAt: text("registered_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  registeredBy: text("registered_by").notNull(),
}, table => ({ fileUnique: uniqueIndex("customer_documents_file_unique").on(table.customerId, table.fileUrl), customerIndex: index("customer_documents_customer_idx").on(table.customerId, table.category) }));

export const customerRelationships = sqliteTable("customer_relationships", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerAId: integer("customer_a_id").notNull().references(() => customers.id, { onDelete: "cascade" }),
  customerBId: integer("customer_b_id").notNull().references(() => customers.id, { onDelete: "cascade" }),
  relationshipAToB: text("relationship_a_to_b").notNull(),
  relationshipBToA: text("relationship_b_to_a").notNull(),
  note: text("note").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  createdBy: text("created_by").notNull(),
}, table => ({
  pairUnique: uniqueIndex("customer_relationship_pair_unique").on(table.customerAId, table.customerBId),
  customerBIndex: index("customer_relationship_b_idx").on(table.customerBId),
}));

export const customerContracts = sqliteTable("customer_contracts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id").notNull().references(() => customers.id, { onDelete: "cascade" }),
  contractName: text("contract_name").notNull(),
  insurer: text("insurer").notNull(),
  validUntil: text("valid_until"),
  requestId: text("request_id"),
  isActive: integer("is_active").notNull().default(1),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  createdBy: text("created_by").notNull(),
  updatedBy: text("updated_by").notNull(),
}, table => ({
  customerIndex: index("customer_contracts_customer_active_idx").on(table.customerId, table.isActive, table.contractName),
  requestIdUnique: uniqueIndex("customer_contracts_request_id_unique").on(table.requestId),
}));
