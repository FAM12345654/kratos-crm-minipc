export const documentCategories = ["Antrag", "Vollmacht", "Beratungsprotokoll", "Vertrag", "Schaden", "Schriftverkehr", "Sonstiges"] as const;
export const categoryFolders: Record<string,string> = {
  Antrag: "Anträge", Vollmacht: "01 Vollmacht", Beratungsprotokoll: "Beratungsprotokolle",
  Vertrag: "03 Verträge und Polizzen", Schaden: "04 Schaden und Fahrzeug", Schriftverkehr: "06 Schriftverkehr", Sonstiges: "99 Nicht zugeordnet",
};
export function belongsToCustomer(fileUrl:string, folderUrl:string): boolean {
  try {
    const file = new URL(fileUrl), folder = new URL(folderUrl);
    if (file.protocol !== "https:" || file.hostname !== "familienhelden2025-my.sharepoint.com" || file.origin !== folder.origin || file.username || file.password || file.search || file.hash) return false;
    const filePath = decodeURIComponent(file.pathname), root = decodeURIComponent(folder.pathname).replace(/\/+$/, "");
    if (filePath.split("/").some(p=>p === "." || p === ".." || p.includes("\\"))) return false;
    return filePath.startsWith(root + "/") && filePath.length > root.length + 1;
  } catch { return false; }
}
export async function listCustomerDocuments(db:D1Database, customerId:number, category?:string) {
  const customer = await db.prepare("SELECT id,first_name,last_name,folder_name,folder_url FROM customers WHERE id=?").bind(customerId).first();
  if (!customer) return { isError:true, message:"Kunde nicht gefunden." };
  const documents = category
    ? await db.prepare("SELECT id,category,file_name,file_url,source,registered_at FROM customer_documents WHERE customer_id=? AND category=? ORDER BY category,file_name,id").bind(customerId,category).all()
    : await db.prepare("SELECT id,category,file_name,file_url,source,registered_at FROM customer_documents WHERE customer_id=? ORDER BY category,file_name,id").bind(customerId).all();
  return { customer, documents:documents.results, indexed_count:documents.results.length, inventory_complete:false, note:"Das Verzeichnis enthält registrierte Dateien. Fehlende Einträge bedeuten nicht, dass in OneDrive keine weiteren Dateien liegen." };
}
export async function registerCustomerDocument(db:D1Database, args:Record<string,unknown>, actor:string) {
  const id=Number(args.customer_id), category=String(args.category??""), name=String(args.file_name??"").trim(), url=String(args.file_url??"").trim();
  if (!Number.isInteger(id)||id<1||!documentCategories.includes(category as typeof documentCategories[number])||!name||name.length>255||/[\\/\r\n]/.test(name)||url.length>1500) return {isError:true,message:"Ungültige CRM-ID, Dokumentart oder Dateiangaben."};
  const customer=await db.prepare("SELECT folder_url FROM customers WHERE id=?").bind(id).first<{folder_url:string|null}>();
  if (!customer?.folder_url||!belongsToCustomer(url,customer.folder_url)) return {isError:true,message:"Die Datei liegt nicht in der bestätigten Kundenmappe. Erst OneDrive-Zuordnung prüfen."};
  if (decodeURIComponent(new URL(url).pathname).split("/").pop() !== name) return {isError:true,message:"Dateiname und OneDrive-Link stimmen nicht überein."};
  await db.batch([
    db.prepare("INSERT INTO customer_documents (customer_id,category,file_name,file_url,registered_by) VALUES (?,?,?,?,?) ON CONFLICT(customer_id,file_url) DO UPDATE SET category=excluded.category,file_name=excluded.file_name,registered_by=excluded.registered_by").bind(id,category,name,url,actor),
    db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(id,"register_document",JSON.stringify(["document_metadata"]),actor),
  ]);
  return {registered:true,customer_id:id,category,file_name:name,file_url:url};
}
