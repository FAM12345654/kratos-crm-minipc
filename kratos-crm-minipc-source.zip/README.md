# Kratos CRM — Familienhelden

Quellcode der Familienhelden-Kundenverwaltung. Dieses Repository enthält die derzeit veröffentlichte Sites-Webanwendung und ihre Cloudflare-D1-Anbindung.

> **Status Mini-PC:** Dies ist noch kein produktionsfertiger Windows-CRM-Server. Der bestehende D1-Datenadapter, die ChatGPT-Anmeldung und die bereitgestellte Laufzeit gehören zur gehosteten Sites-App. Für den Mini-PC müssen erst ein SQLite-Adapter, ein abgesicherter OAuth-Zugang, Graph-Token-Erneuerung, Dienstbetrieb sowie Backup und Wiederherstellung implementiert und geprüft werden. Die Anleitung unter [`docs/mini-pc-server-setup.md`](docs/mini-pc-server-setup.md) trennt den sicheren lokalen Entwicklungsvorlauf von der späteren Servereinrichtung.

## Lokaler Entwicklungsvorlauf auf Windows

1. Git for Windows und Node.js LTS installieren. Offizielle Links stehen in der [Mini-PC-Anleitung](docs/mini-pc-server-setup.md#offizielle-downloads).
2. Repository klonen und Abhängigkeiten installieren:

   ```powershell
   git clone https://github.com/FAM12345654/kratos-crm-minipc.git C:\Kratos\source
   Set-Location C:\Kratos\source
   npm install --global pnpm@10
   pnpm install --frozen-lockfile
   ```

3. Prüfungen und lokale Vorschau starten:

   ```powershell
   pnpm run lint
   pnpm exec tsc --noEmit
   pnpm run dev
   ```

   Die Vorschau läuft lokal unter `http://127.0.0.1:5173`. Für synthetische lokale Anmeldung `/signin-with-chatgpt?return_to=/` öffnen. Die Vorschau verwendet lokale Wrangler-/D1-Testdaten und ist keine produktive Serverinstanz.

## Daten und Geheimnisse

Keine echten Kundendaten in die lokale Vorschau oder ins GitHub-Repository kopieren. `.env*`, `.dev.vars*`, private Schlüssel, `.wrangler/`, `.sites-runtime/`, `node_modules/`, Builds und `outputs/` sind ausgeschlossen. Zugangsdaten werden später separat auf dem Zielsystem eingerichtet und gehören weder in Git noch in Screenshots oder Logs.

## Weiterführende Dokumentation

- [Quellcode als ZIP herunterladen](kratos-crm-minipc-source.zip)
- [Mini-PC: Downloads, lokaler Vorlauf und Serverstatus](docs/mini-pc-server-setup.md)
- [Implementierungsstatus](docs/kratos-implementierungsstatus-2026-11-02.md)
