# Kratos – Implementierungsstatus (2. November 2026)

## Phase 1: Bestand sichern und Sicherheitslücke bei Löschfunktionen schließen

### Geprüfter Stand

- Bestehende Kratos-Site: Version 9, Quellcommit `a9185208d2d6f0ba3d7676fe60185de575b99123`.
- Lokaler Quellstand war vor der Änderung sauber. Sicherungsbranch `backup/2026-11-02-pre-ai-maklerassistent` zeigt auf diesen Commit.
- Die Anwendung nutzt Cloudflare D1 (`DB`) für strukturierte Kundendaten. SharePoint/OneDrive bleibt Dokumentablage; ein R2-Bucket ist nicht konfiguriert.
- Bereits vorhanden sind Kundenbestand und Suche, Kundenanlage/-änderung über MCP, Wiedervorlagen, Kundenordner-Links und ein Dokumentenindex. Dokumentdateien werden nicht durch die App selbst hochgeladen.
- Die Site ist als privat/owner-only eingerichtet. Produktive Site und D1 wurden in dieser Phase nicht geändert.

### Änderung

- Das MCP-Werkzeug `delete_customer` und sein ausführender Codepfad wurden entfernt. Kundenlöschungen stehen damit über die Kratos-MCP-Schnittstelle nicht mehr zur Verfügung.
- Die Weboberfläche hat jetzt ein installierbares PWA-Manifest für Windows und Android sowie ein eigenes App-Symbol. Die PWA bleibt online-only; private Kundendaten werden nicht in einem Offline-Cache auf dem Gerät gespeichert.
- Zwei vorhandene Lintfehler in der Ordnerlink-Validierung und beim Laden von Dokumenten wurden behoben.
- Die Kundenerstellung prüft jetzt mögliche Dubletten über exakten Vor- und Nachnamen sowie übereinstimmende Telefonnummer (Ziffern normalisiert) oder E-Mail. Bei fehlenden Kontaktdaten blockiert ein gleicher Name zur manuellen Prüfung. Es erfolgt kein automatisches Zusammenführen.
- Geburtstage sind als optionales Datum in Schema und MCP-Anlage/-Änderung ergänzt, werden in Kundenlisten und Profil angezeigt und mit einer additiven Drizzle-Migration (`0003_absurd_mercury.sql`) eingeführt.
- Bestehende Update-, Audit- und Dokumentenpfade blieben unberührt.

### Prüfung

- Quelltextsuche nach `delete_customer` und `DELETE FROM customers` unter `app/`: keine Treffer.
- Backup-Branch vorhanden und zeigt auf den geprüften Ausgangscommit.
- `pnpm run build`: erfolgreich; die neue Manifestroute `/manifest.webmanifest` wird mitgebaut.
- Lokaler Smoke-Test: `GET /manifest.webmanifest` liefert HTTP 200 mit `application/manifest+json`.
- `pnpm run lint`: erfolgreich.
- `git diff --check`: erfolgreich.
- Read-only Anschlussprüfung: Das Todoist-Projekt „Geschäft – Versicherungen“ und der primäre Google-Kalender sind vorhanden. Es wurden keine Aufgaben oder Termine angelegt.
- Read-only Anschlussprüfung: Das Todoist-Projekt „Geschäft – Versicherungen“ und der primäre Google-Kalender des Kontos sind vorhanden. Es wurden keine Aufgaben oder Termine angelegt.
- Lokaler D1-Funktionstest mit synthetischen Namen: Neuanlage erfolgreich; gleiche Nummer mit anderer Formatierung geblockt; gleicher Name mit anderer Nummer erlaubt; gleicher Name ohne Kontaktangaben zur Prüfung geblockt; `delete_customer` fehlt in `tools/list`.
- Geburtstagsprüfung mit synthetischem Datensatz: gültiges Datum `2000-02-29` angelegt und zurückgelesen; unmögliches Datum `2001-02-29` abgewiesen.

### Offene Punkte / nächste Phase

- Sites hat Version 10 am 2. November 2026 für die owner-private Site veröffentlicht. Der Sites-Publishing-Workflow wendet ausstehende Hosted-D1-Migrationen vor dem Worker-Upload an; die additive Geburtstagsmigration wurde dabei produktiv angewandt.
- Das PWA-Manifest ist vorbereitet, aber Installation und Verhalten auf einem echten Android-Gerät/Windows-Browser wurden noch nicht verifiziert.
- Die Todoist- und Google-Kalender-Konten sind in dieser Sitzung lesend erreichbar; eine dauerhafte, automatisierte Synchronisierung aus der Kratos-Site besteht noch nicht.
- Veröffentlichung: Version 10, Quellcommit `9ed4cedad9b2fa313debda22984affa38d1d2ed3`, URL `https://familienhelden-kunden-crm.hopfentorpedo123.chatgpt.site`. Das Site-Titelfeld lautet jetzt „Kratos · Familienhelden“; Zugang blieb bei einem Account ohne Gruppen oder externe Besucher.
- Live-Smoke-Test über das private MCP: eindeutige Nichttreffer-Suche erfolgreich, 0 Ergebnisse; keine Kundendaten ausgelesen.
- Die isolierte lokale Testdatenbank unter `.wrangler/kratos-synthetic-test` enthält vier synthetische Testkunden; keine produktiven Kundendaten wurden für die Funktionstests verwendet.
- Der Versuch, diesen lokalen Testordner nach Abschluss rekursiv zu entfernen, wurde von der automatischen Sicherheitsprüfung mit „blocked by policy“ abgelehnt. Der Ordner bleibt auf die drei synthetischen Testdatensätze begrenzt.
- Strukturierte Vertragsdaten und das Aufgabenmodell sind noch nicht umgesetzt. Die Dublettenprüfung deckt aktuell nur die Kundenerstellung ab; Bearbeitungs- und Importszenarien benötigen eigene Tests.
- Die Veröffentlichung erfolgte nach ausdrücklicher Freigabe. Für eine echte Geräteinstallation und die nächsten Datenmodelle bleiben weitere Tests und Freigaben nötig.
- Die Abnahmetests A–H sind noch offen; ein produktiver Test mit echten Kundendaten wurde nicht durchgeführt.

## Phase 2: Vollmachtsstatus (lokal vorbereitet)

- Vor der Änderung wurde der aktuelle Live-Quellstand 265d7493fd40af85c150ea012ba54984585c6e53 auf `backup/2026-11-02-v11-live` gesichert.
- `authority_status` ist ein optional änderbares Kundenfeld mit den Werten `Ungeprüft`, `Vorhanden`, `Fehlt` und `Widerrufen`. Neue und bestehende Datensätze erhalten neutral `Ungeprüft`; Dateiklassifizierung ändert den Status nicht automatisch.
- Feld ergänzt in Schema, MCP create/update/search/get, Kundenlisten und Profil. Drizzle-Migration `0004_outgoing_catseye.sql` ist additiv und fügt einen festen Default hinzu.
- Lokale Funktionstests erfolgreich: neutraler Default, bestätigter Status speichern/lesen, ungültigen Status zurückweisen; Löschwerkzeug fehlt weiterhin in `tools/list`.
- `pnpm run lint`, `pnpm run build` und lokale D1-Migration 0004 erfolgreich.
- Migration 0004 ist **nicht produktiv angewandt**; diese Phase ist lokal geprüft und wartet auf eine eigene Freigabe zur Veröffentlichung.