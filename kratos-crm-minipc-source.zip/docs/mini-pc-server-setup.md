# Kratos auf dem Windows-Mini-PC

Stand: 6. November 2026

## Was dieses Repository bereitstellt

Das Repository enthält den Quellcode der aktuellen Kratos-Weboberfläche, die Worker-Routen, D1-Schema und Migrationen. Die App wurde für die gehostete Sites-Laufzeit mit Cloudflare D1 geschrieben.

Es gibt noch **keinen fertigen Windows-CRM-Server-Download**. Ein lokaler Start der bestehenden App ist nur eine Entwickler-Vorschau mit Wrangler/Miniflare und einer lokalen Testdatenbank. Sie ist nicht für echte Kundendaten, Dauerbetrieb oder externe Zugriffe freigegeben. Die CRM-Daten der veröffentlichten App werden dadurch nicht auf den Mini-PC kopiert.

Die Anleitung hier bereitet Quellcode und lokale Vorschau vor. Sie führt keine echte Datenmigration, Netzfreigabe, Tunnelinstallation oder Produktionseinrichtung aus.

## Offizielle Downloads

- [Node.js LTS für Windows](https://nodejs.org/en/download) — Node `>=22.13.0`; aktuelle LTS-Version und passenden x64-/ARM64-Installer auf der offiziellen Seite auswählen.
- [Git for Windows](https://git-scm.com/install/windows) — offiziellen Installer für die Architektur des Mini-PCs wählen.
- [PowerShell 7](https://learn.microsoft.com/powershell/scripting/install/installing-powershell-on-windows) — optional; Windows PowerShell 5.1 ist für die unten stehenden Grundschritte ausreichend.

Installationsdateien direkt vom offiziellen Anbieter laden. Installer nicht in das Repository einchecken. Nach der Installation ein neues PowerShell-Fenster öffnen und `git --version`, `node --version` sowie `npm --version` prüfen.

## Quellcode aus GitHub holen

Das Repository soll privat angelegt werden, da es interne CRM-Geschäftslogik enthält. Nach Erstellung des privaten Repositories den Platzhalter `OWNER` durch den GitHub-Benutzernamen ersetzen:

```powershell
git clone https://github.com/OWNER/kratos-crm-minipc.git C:\Kratos\source
Set-Location C:\Kratos\source
```

Wenn GitHub nach Anmeldung fragt, ausschließlich den offiziellen Browser-Anmeldeablauf verwenden. Keine Passwörter oder Tokens in diesen Befehl, in Git-Konfiguration, Skripte oder Chat schreiben.

## Lokale Vorschau mit synthetischen Daten

```powershell
npm install --global pnpm@10
pnpm install --frozen-lockfile
pnpm run lint
pnpm exec tsc --noEmit
pnpm run dev
```

Die Vorschau bindet standardmäßig an `127.0.0.1:5173`. Für die synthetische lokale Anmeldung öffne:

```text
http://127.0.0.1:5173/signin-with-chatgpt?return_to=/
```

Die lokale Wrangler-Datenbank liegt im ignorierten `.wrangler/`-Ordner. Sie ist ein lokaler Testbestand, kein Import der produktiven Datenbank. `pnpm run start` startet nach einem Build ebenfalls nur einen lokalen Wrangler-Vorschau-Worker und richtet keinen Windows-Dienst ein.

## Was vor einem echten Serverbetrieb noch fehlt

1. D1-Zugriff durch einen auf dem Mini-PC unterstützten SQLite-Adapter ersetzen und SQL, Transaktionen sowie parallele Schreibzugriffe testen.
2. Einen geprüften OAuth-Provider für ChatGPT/Claude anbinden; Identität und Berechtigungen serverseitig erzwingen. Der lokale Mock-Login ist dafür ungeeignet.
3. Microsoft-Graph-Anmeldung samt sicherer Token-Erneuerung und getrenntem, geschütztem Token-Speicher implementieren.
4. Eingeschränktes Dienstkonto, Start/Neustart, Protokollrotation und verifizierte verschlüsselte Backups mit Wiederherstellungsprobe einrichten.
5. Einen konkreten, abgesicherten HTTPS-Zugangsweg auswählen und prüfen. Keine Routerfreigabe für Datenbank, SMB oder Verwaltungszugang.
6. Mit ausschließlich synthetischen Daten Funktion, Rechte, Backups und Wiederherstellung abnehmen. Eine echte Migration braucht einen separaten Plan mit Sicherung, Prüfsummen, Zählungen und Rückfallweg.

Bis diese Punkte implementiert und abgenommen sind, bleibt die lokale Vorschau auf `127.0.0.1` und verwendet ausschließlich synthetische Daten. OneDrive-Originale und die aktuelle Produktion bleiben unverändert.
