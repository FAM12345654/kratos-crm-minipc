ALTER TABLE `customer_relationships` ADD `note` text DEFAULT '' NOT NULL;
