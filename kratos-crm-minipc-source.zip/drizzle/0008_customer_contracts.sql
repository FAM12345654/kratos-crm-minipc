CREATE TABLE `customer_contracts` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `customer_id` integer NOT NULL,
  `contract_name` text NOT NULL,
  `insurer` text NOT NULL,
  `valid_until` text,
  `is_active` integer DEFAULT 1 NOT NULL,
  `created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` text NOT NULL,
  `updated_by` text NOT NULL,
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `customer_contracts_customer_active_idx` ON `customer_contracts` (`customer_id`,`is_active`,`contract_name`);
