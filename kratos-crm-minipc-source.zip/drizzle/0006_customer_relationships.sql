CREATE TABLE `customer_relationships` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `customer_a_id` integer NOT NULL,
  `customer_b_id` integer NOT NULL,
  `relationship_a_to_b` text NOT NULL,
  `relationship_b_to_a` text NOT NULL,
  `created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` text NOT NULL,
  FOREIGN KEY (`customer_a_id`) REFERENCES `customers`(`id`) ON DELETE cascade,
  FOREIGN KEY (`customer_b_id`) REFERENCES `customers`(`id`) ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `customer_relationship_pair_unique` ON `customer_relationships` (`customer_a_id`,`customer_b_id`);
--> statement-breakpoint
CREATE INDEX `customer_relationship_b_idx` ON `customer_relationships` (`customer_b_id`);
