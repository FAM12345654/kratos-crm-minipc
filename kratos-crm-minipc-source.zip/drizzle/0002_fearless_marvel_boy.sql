CREATE TABLE `customer_documents` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`customer_id` integer,
	`category` text NOT NULL,
	`file_name` text NOT NULL,
	`file_url` text NOT NULL,
	`source` text DEFAULT 'OneDrive' NOT NULL,
	`registered_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`registered_by` text NOT NULL,
	FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `customer_documents_file_unique` ON `customer_documents` (`customer_id`,`file_url`);--> statement-breakpoint
CREATE INDEX `customer_documents_customer_idx` ON `customer_documents` (`customer_id`,`category`);