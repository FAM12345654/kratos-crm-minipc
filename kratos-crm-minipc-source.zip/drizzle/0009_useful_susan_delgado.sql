ALTER TABLE `customer_contracts` ADD COLUMN `request_id` text;--> statement-breakpoint
CREATE UNIQUE INDEX `customer_contracts_request_id_unique` ON `customer_contracts` (`request_id`);
