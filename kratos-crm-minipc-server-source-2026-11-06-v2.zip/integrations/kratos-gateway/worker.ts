import { createKratosGateway, KRATOS_GATEWAY_TOOLS, type KratosToolDefinition } from "../../lib/kratos-universal-gateway";
import { createKratosRemoteJwtVerifier } from "../../lib/kratos-oauth-verifier";
import { kratosTools, runKratosTool, type KratosToolBindings } from "../../lib/kratos-tool-service";

export type KratosGatewayEnvironment = KratosToolBindings & {
  KRATOS_RESOURCE_ORIGIN?: string;
  KRATOS_OAUTH_ISSUER?: string;
  KRATOS_OAUTH_JWKS_URI?: string;
  /** JSON array of stable, explicitly approved OAuth subjects. Not email addresses. */
  KRATOS_ALLOWED_SUBJECTS?: string;
};

/** Separate deployment entry. Does not modify the private Sites application's authentication. */
export function createConfiguredKratosGateway(env: KratosGatewayEnvironment) {
  if (!env.DB || !env.KRATOS_RESOURCE_ORIGIN || !env.KRATOS_OAUTH_ISSUER ||
    !env.KRATOS_OAUTH_JWKS_URI || !env.KRATOS_ALLOWED_SUBJECTS) {
    throw new Error("Kratos gateway requires explicit database and OAuth configuration.");
  }
  const subjects: unknown = JSON.parse(env.KRATOS_ALLOWED_SUBJECTS);
  if (!Array.isArray(subjects) || subjects.length < 1 || subjects.length > 20 ||
    subjects.some((s) => typeof s !== "string" || !s.trim() || s.length > 255)) {
    throw new Error("An explicit OAuth subject allowlist is required.");
  }
  if (new URL(env.KRATOS_RESOURCE_ORIGIN).origin !== env.KRATOS_RESOURCE_ORIGIN) {
    throw new Error("Use the exact canonical gateway origin as OAuth audience.");
  }
  return createKratosGateway({
    resourceOrigin: env.KRATOS_RESOURCE_ORIGIN,
    issuer: env.KRATOS_OAUTH_ISSUER,
    allowedSubjects: subjects as string[],
    verifyAccessToken: createKratosRemoteJwtVerifier({
      issuer: env.KRATOS_OAUTH_ISSUER,
      audience: env.KRATOS_RESOURCE_ORIGIN,
      jwksUri: env.KRATOS_OAUTH_JWKS_URI,
    }),
    tools: kratosTools.filter((tool) => (KRATOS_GATEWAY_TOOLS as readonly string[]).includes(tool.name)).map((tool) => tool.name === "get_stored_customer_file" ? {
      ...tool,
      description: "Get physical-file metadata for an exact Kratos file ID. Does not return file contents or a gateway download link. Actual download currently requires the owner's separate private Kratos Site session.",
    } : tool).map((tool) => ({
      ...tool,
      annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true },
      securitySchemes: [{ type: "oauth2", scopes: ["kratos:read"] }],
    })) as KratosToolDefinition[],
    executeTool: async (name, args, identity) => {
      const out = await runKratosTool(name, args, `oauth:${identity.subject}`, env);
      if (name === "get_stored_customer_file" && out && typeof out === "object" && "download_path" in out) {
        // A Site-relative path would incorrectly resolve against this independent gateway.
        const result = { ...out } as Record<string, unknown>;
        delete result.download_path;
        return { ...result, gateway_download_available: false, download_requires: "private Kratos Site session" };
      }
      return out;
    },
    serverName: "Kratos",
  });
}

const handlers = new WeakMap<KratosGatewayEnvironment, ReturnType<typeof createConfiguredKratosGateway>>();
const worker = {
  async fetch(request: Request, env: KratosGatewayEnvironment): Promise<Response> {
    let handler = handlers.get(env);
    if (!handler) {
      try {
        handler = createConfiguredKratosGateway(env);
        handlers.set(env, handler);
      } catch {
        return Response.json({ error: "Kratos gateway is not configured." }, {
          status: 503, headers: { "Cache-Control": "private, no-store" },
        });
      }
    }
    return handler(request);
  },
};
export default worker;
