import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import path from "node:path";
import { lstat } from "node:fs/promises";
import { DatabaseSync } from "node:sqlite";
import { createHash } from "node:crypto";
import { createKratosJwtVerifier, createKratosRemoteJwtVerifier } from "../../lib/kratos-oauth-verifier";
import { createKratosEntraJwtVerifier, createKratosRemoteEntraJwtVerifier, type KratosEntraConfiguration } from "../../lib/kratos-entra-verifier";
import { createKratosGateway, KRATOS_GATEWAY_TOOLS, KRATOS_READ_SCOPE, resolveKratosResourceUrl, type KratosToolDefinition } from "../../lib/kratos-universal-gateway";
import { kratosTools, runKratosTool } from "../../lib/kratos-tool-service";
import { KratosSqliteReadAdapter } from "../../lib/kratos-sqlite-read-adapter";
import { createKratosCaseApi } from "../../lib/kratos-case-api";
import { openKratosLocalDocumentReader } from "../../lib/kratos-local-document-reader";
import { assertKratosLocalPath, KratosLocalDocumentError, KratosLocalDocumentStore } from "../../lib/kratos-local-document-store";
import type { JWTVerifyGetKey } from "jose";

const LOOPBACK = "127.0.0.1";
const MAX_BODY_BYTES = 64 * 1024;
const MAX_RESPONSE_BYTES = 1024 * 1024;
const MAX_TIMEOUT_MS = 30_000;
const MAX_ACTIVE_DOWNLOADS = 2;
const MAX_UPLOAD_BYTES = 1024 * 1024;
const MAX_ACTIVE_UPLOADS = 2;
const DOCUMENT_WRITE_SCOPE = "kratos:documents:write";
const UPLOAD_PATH = "/v1/documents/upload";
const UPLOAD_METADATA_HEADERS = ["x-kratos-customer-id", "x-kratos-folder-id", "x-kratos-file-name", "x-kratos-sha256", "idempotency-key"];

export type KratosLocalServerConfig = {
  databasePath: string;
  resourceOrigin: string;
  resourceUrl?: string;
  issuer?: string;
  jwksUri?: string;
  /** Explicit opt-in. Generic URLs must be omitted when using this profile. */
  entra?: KratosEntraConfiguration;
  /** Separate opt-in. Never enabled by a request or by a token scope alone. */
  caseApi?: { enableWrites: boolean; allowedCustomerIds: number[]; todoistProjectId?: string };
  documentDownloads?: { root: string; allowedCustomerIds: number[] };
  documentUploads?: { root: string; allowedCustomerIds: number[]; privateRootConfirmed: true };
  allowedSubjects: string[];
  port?: number;
  /** Test/operator-provided trusted signing key resolver; still uses the real JWT verifier. */
  verificationKey?: JWTVerifyGetKey;
  bodyLimitBytes?: number;
  requestDeadlineMs?: number;
  responseDeadlineMs?: number;
};

class TransportError extends Error {
  constructor(readonly status: number, readonly code: string, readonly headers: Record<string, string> = {}) { super(code); }
}

function canonicalHttpsOrigin(value: string, label: string): string {
  let parsed: URL;
  try { parsed = new URL(value); } catch { throw new Error(`${label} is invalid.`); }
  if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.search || parsed.hash || parsed.pathname !== "/" || value !== parsed.origin) throw new Error(`${label} must be a canonical HTTPS origin.`);
  return parsed.origin;
}

function validateConfig(config: KratosLocalServerConfig): void {
  if (!config || typeof config !== "object") throw new Error("Local gateway configuration is required.");
  if (typeof config.databasePath !== "string" || !path.isAbsolute(config.databasePath) || config.databasePath.startsWith("\\\\")) throw new Error("An absolute existing local SQLite database path is required.");
  canonicalHttpsOrigin(config.resourceOrigin, "resourceOrigin");
  resolveKratosResourceUrl(config.resourceOrigin, config.resourceUrl);
  if (config.entra !== undefined) {
    if (config.issuer !== undefined || config.jwksUri !== undefined) throw new Error("Entra and generic OAuth configuration cannot be combined.");
    // Builds the verifier (no network request) to validate IDs before opening SQLite.
    createKratosRemoteEntraJwtVerifier(config.entra);
  } else for (const [label, value] of [["issuer", config.issuer], ["jwksUri", config.jwksUri]] as const) {
    let parsed: URL;
    try { if (typeof value !== "string") throw new Error(); parsed = new URL(value); } catch { throw new Error(`${label} is invalid.`); }
    if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.hash || parsed.search) throw new Error(`${label} must be an HTTPS URL without credentials, query, or fragment.`);
  }
  if (!Array.isArray(config.allowedSubjects) || config.allowedSubjects.length < 1 || config.allowedSubjects.length > 20 || config.allowedSubjects.some((subject) => typeof subject !== "string" || !subject || subject.trim() !== subject || subject.length > 255)) throw new Error("An explicit stable subject allowlist is required.");
  if (config.entra && config.allowedSubjects.some((subject) => !subject.startsWith(config.entra!.tenantId + ":") || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(subject.slice(config.entra!.tenantId.length + 1)))) throw new Error("Entra subjects must be explicit tenant:object IDs.");
  if (config.caseApi !== undefined) {
    const cases = config.caseApi;
    if (config.entra || !cases || typeof cases !== "object" || typeof cases.enableWrites !== "boolean" ||
        !Array.isArray(cases.allowedCustomerIds) || cases.allowedCustomerIds.length < 1 || cases.allowedCustomerIds.length > 1000 ||
        cases.allowedCustomerIds.some((id) => !Number.isSafeInteger(id) || id < 1) || new Set(cases.allowedCustomerIds).size !== cases.allowedCustomerIds.length ||
        config.allowedSubjects.some((subject) => subject.length > 249) ||
        (cases.todoistProjectId !== undefined && (typeof cases.todoistProjectId !== "string" || !cases.todoistProjectId || cases.todoistProjectId.trim() !== cases.todoistProjectId || cases.todoistProjectId.length > 255))) throw new Error("An explicit generic-auth case profile and customer allowlist are required.");
  }
  if (config.documentDownloads !== undefined) {
    const documents = config.documentDownloads;
    if (!documents || typeof documents.root !== "string" || !path.isAbsolute(documents.root) || documents.root.startsWith("\\\\") ||
        !Array.isArray(documents.allowedCustomerIds) || documents.allowedCustomerIds.length < 1 || documents.allowedCustomerIds.length > 1000 ||
        documents.allowedCustomerIds.some((id) => !Number.isSafeInteger(id) || id < 1) || new Set(documents.allowedCustomerIds).size !== documents.allowedCustomerIds.length) {
      throw new Error("An explicit local document root and customer allowlist are required.");
    }
  }
  if (config.documentUploads !== undefined) {
    const uploads = config.documentUploads;
    if (config.entra || !uploads || uploads.privateRootConfirmed !== true || typeof uploads.root !== "string" || !path.isAbsolute(uploads.root) || uploads.root.startsWith("\\\\") ||
        !Array.isArray(uploads.allowedCustomerIds) || uploads.allowedCustomerIds.length < 1 || uploads.allowedCustomerIds.length > 1000 ||
        uploads.allowedCustomerIds.some((id) => !Number.isSafeInteger(id) || id < 1) || new Set(uploads.allowedCustomerIds).size !== uploads.allowedCustomerIds.length) {
      throw new Error("An explicit generic-auth upload profile, private local document root and customer allowlist are required.");
    }
  }
  if (config.port !== undefined && (!Number.isInteger(config.port) || config.port < 0 || config.port > 65535)) throw new Error("Port must be 0 through 65535.");
  if (config.bodyLimitBytes !== undefined && (!Number.isInteger(config.bodyLimitBytes) || config.bodyLimitBytes < 1 || config.bodyLimitBytes > MAX_BODY_BYTES)) throw new Error("Request body limit exceeds the 64 KiB maximum.");
  for (const timeout of [config.requestDeadlineMs, config.responseDeadlineMs]) if (timeout !== undefined && (!Number.isInteger(timeout) || timeout < 1 || timeout > MAX_TIMEOUT_MS)) throw new Error("Request and response deadlines must be at most 30 seconds.");
}

function sendJson(response: ServerResponse, status: number, value: Record<string, unknown>, extraHeaders: Record<string, string> = {}): void {
  if (response.destroyed || response.headersSent) return;
  const body = Buffer.from(JSON.stringify(value));
  response.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "content-length": body.length, ...extraHeaders });
  response.end(body);
}

function criticalHeaderCount(request: IncomingMessage, headerName: string): number {
  let count = 0;
  for (let index = 0; index < request.rawHeaders.length; index += 2) if (request.rawHeaders[index].toLowerCase() === headerName) count += 1;
  return count;
}

function validateRequestTarget(target: string, resourceOrigin: string): string {
  if (typeof target !== "string" || !target.startsWith("/") || target.startsWith("//") || target.includes("\\") || target.includes("#") || target.includes("?") || /[\u0000-\u0020\u007f]/.test(target) || /%(?![a-f0-9]{2})/i.test(target)) throw new TransportError(400, "invalid_request_target");
  let url: URL;
  try { url = new URL(target, resourceOrigin); } catch { throw new TransportError(400, "invalid_request_target"); }
  if (url.origin !== resourceOrigin || url.username || url.password || url.search || url.hash || !url.pathname.startsWith("/")) throw new TransportError(400, "invalid_request_target");
  return url.href;
}

async function readBoundedBody(request: IncomingMessage, maxBytes: number, deadlineMs: number): Promise<Buffer> {
  const contentLength = request.headers["content-length"];
  if (contentLength !== undefined) {
    if (typeof contentLength !== "string" || !/^\d+$/.test(contentLength)) throw new TransportError(400, "invalid_content_length");
  }
  const chunks: Buffer[] = [];
  let length = 0;
  let tooLarge = false;
  const iterator = request[Symbol.asyncIterator]();
  let timer: NodeJS.Timeout | undefined;
  const collect = async () => {
    for (;;) {
      const next = await iterator.next();
      if (next.done) {
        if (tooLarge) throw new TransportError(413, "body_too_large");
        return Buffer.concat(chunks, length);
      }
      const chunk = Buffer.isBuffer(next.value) ? next.value : Buffer.from(next.value);
      if (!tooLarge && length + chunk.length > maxBytes) tooLarge = true;
      if (tooLarge) length = maxBytes;
      else { length += chunk.length; chunks.push(chunk); }
    }
  };
  try {
    return await Promise.race([
      collect(),
      new Promise<Buffer>((_resolve, reject) => { timer = setTimeout(() => reject(new TransportError(408, "request_timeout")), deadlineMs); }),
    ]);
  } catch (error) {
    if (error instanceof TransportError) throw error;
    throw new TransportError(400, "invalid_request_body");
  } finally { if (timer) clearTimeout(timer); }
}

async function boundedResponse(response: Response): Promise<{ body: Buffer; headers: Record<string, string> }> {
  const reader = response.body?.getReader();
  if (!reader) return { body: Buffer.alloc(0), headers: {} };
  const chunks: Buffer[] = [];
  let length = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > MAX_RESPONSE_BYTES) {
        await reader.cancel().catch(() => {});
        throw new TransportError(502, "response_too_large");
      }
      chunks.push(Buffer.from(value));
    }
  } finally { reader.releaseLock(); }
  const headers: Record<string, string> = {};
  for (const key of ["www-authenticate", "allow", "content-type", "cache-control"]) {
    const value = response.headers.get(key);
    if (value) headers[key] = value;
  }
  return { body: Buffer.concat(chunks, length), headers };
}

function makeVerifier(config: KratosLocalServerConfig) {
  const resourceUrl = resolveKratosResourceUrl(config.resourceOrigin, config.resourceUrl);
  const issuer = config.entra ? `https://login.microsoftonline.com/${config.entra.tenantId}/v2.0` : config.issuer!;
  return config.entra
    ? config.verificationKey ? createKratosEntraJwtVerifier({ ...config.entra, verificationKey: config.verificationKey }) : createKratosRemoteEntraJwtVerifier(config.entra)
    : config.verificationKey
      ? createKratosJwtVerifier({ issuer, audience: resourceUrl, verificationKey: config.verificationKey })
      : createKratosRemoteJwtVerifier({ issuer, audience: resourceUrl, jwksUri: config.jwksUri! });
}

function makeDocumentDownload(config: KratosLocalServerConfig, verifier: ReturnType<typeof makeVerifier>, read: Awaited<ReturnType<typeof openKratosLocalDocumentReader>>) {
  const subjects = new Set(config.allowedSubjects);
  const resourceUrl = resolveKratosResourceUrl(config.resourceOrigin, config.resourceUrl);
  const metadataPath = resourceUrl.endsWith("/mcp") ? "/.well-known/oauth-protected-resource/mcp" : "/.well-known/oauth-protected-resource";
  const scope = config.entra ? `${resourceUrl}/kratos.read` : KRATOS_READ_SCOPE;
  const challenge = { "www-authenticate": `Bearer resource_metadata="${config.resourceOrigin}${metadataPath}", scope="${scope}"` };
  return async (request: Request, fileId: number) => {
    const origin = request.headers.get("origin");
    if ((origin !== null && origin !== config.resourceOrigin) || request.headers.get("sec-fetch-site") === "cross-site") {
      throw new TransportError(403, "cross_origin_request_rejected");
    }
    const bearer = /^Bearer\s+([^\s]+)$/i.exec(request.headers.get("authorization") ?? "");
    if (!bearer) throw new TransportError(401, "unauthorized", challenge);
    const identity = await verifier(bearer[1]).catch(() => null);
    request.signal.throwIfAborted();
    if (!identity) throw new TransportError(401, "unauthorized", challenge);
    if (!subjects.has(identity.subject) || !identity.scopes.includes(KRATOS_READ_SCOPE)) throw new TransportError(403, "forbidden");
    const bytes = await read(fileId, request.signal).catch(() => null);
    request.signal.throwIfAborted();
    if (bytes === "too_large") throw new TransportError(413, "document_too_large");
    if (bytes === null) throw new TransportError(404, "not_found");
    return { bytes, fileId };
  };
}

function uploadId(value: string | string[] | undefined): number {
  if (typeof value !== "string" || !/^[1-9][0-9]*$/.test(value) || !Number.isSafeInteger(Number(value))) throw new TransportError(400, "invalid_upload_metadata");
  return Number(value);
}

function makeDocumentUpload(config: KratosLocalServerConfig, verifier: ReturnType<typeof makeVerifier>, profile: NonNullable<KratosLocalServerConfig["documentUploads"]>) {
  const subjects = [...config.allowedSubjects];
  const customers = [...profile.allowedCustomerIds];
  const resourceUrl = resolveKratosResourceUrl(config.resourceOrigin, config.resourceUrl);
  const metadataPath = resourceUrl.endsWith("/mcp") ? "/.well-known/oauth-protected-resource/mcp" : "/.well-known/oauth-protected-resource";
  const challenge = { "www-authenticate": `Bearer resource_metadata="${config.resourceOrigin}${metadataPath}", scope="${DOCUMENT_WRITE_SCOPE}"` };
  return async (incoming: IncomingMessage, assertActive: () => void) => {
    const headers = incoming.headers;
    if ((headers.origin !== undefined && headers.origin !== config.resourceOrigin) || headers["sec-fetch-site"] === "cross-site") {
      throw new TransportError(403, "cross_origin_request_rejected");
    }
    if (UPLOAD_METADATA_HEADERS.some((name) => criticalHeaderCount(incoming, name) > 1)) throw new TransportError(400, "duplicate_header");
    const bearer = /^Bearer\s+([^\s]+)$/i.exec(headers.authorization ?? "");
    const identity = bearer ? await verifier(bearer[1]).catch(() => null) : null;
    assertActive();
    if (!identity) throw new TransportError(401, "unauthorized", challenge);
    if (!subjects.includes(identity.subject) || !identity.scopes.includes(DOCUMENT_WRITE_SCOPE)) throw new TransportError(403, "forbidden");
    if (headers["content-type"]?.toLowerCase() !== "application/octet-stream" || headers["content-encoding"] !== undefined) {
      throw new TransportError(415, "unsupported_upload_content_type");
    }
    const customerId = uploadId(headers["x-kratos-customer-id"]);
    if (!customers.includes(customerId)) throw new TransportError(404, "not_found");
    const folderId = headers["x-kratos-folder-id"] === undefined ? null : uploadId(headers["x-kratos-folder-id"]);
    const encodedName = headers["x-kratos-file-name"];
    const expectedSha256 = headers["x-kratos-sha256"];
    const key = headers["idempotency-key"];
    if (typeof encodedName !== "string" || !encodedName || encodedName.length > 3072 ||
        typeof expectedSha256 !== "string" || !/^[a-f0-9]{64}$/.test(expectedSha256) ||
        typeof key !== "string" || !/^[A-Za-z0-9._-]{1,128}$/.test(key)) throw new TransportError(400, "invalid_upload_metadata");
    let fileName: string;
    try { fileName = decodeURIComponent(encodedName); } catch { throw new TransportError(400, "invalid_upload_metadata"); }
    if (!fileName.trim() || fileName.length > 255 || /[\\/\u0000-\u001f\u007f]/.test(fileName) || fileName === "." || fileName === "..") throw new TransportError(400, "invalid_upload_metadata");
    if (Number(headers["content-length"]) > MAX_UPLOAD_BYTES) throw new TransportError(413, "body_too_large");
    const bytes = await readBoundedBody(incoming, MAX_UPLOAD_BYTES, config.requestDeadlineMs ?? 15_000);
    assertActive();
    if (createHash("sha256").update(bytes).digest("hex") !== expectedSha256) throw new TransportError(422, "integrity_mismatch");

    // The write identity is local to this authenticated subject and issuer.
    const namespace = createHash("sha256").update(JSON.stringify([config.issuer, identity.subject])).digest("hex");
    const store = await KratosLocalDocumentStore.open({
      databasePath: config.databasePath, root: profile.root, privateRootConfirmed: profile.privateRootConfirmed,
      ownerSubject: identity.subject, allowedOwnerSubjects: subjects, allowedCustomerIds: customers, actorId: `oauth:${identity.subject}`,
    });
    try {
      const result = await store.upload({
        customerId, folderId, fileName, expectedSize: bytes.length, expectedSha256,
        source: { driveId: `kratos-local-http-v1:${namespace}`, itemId: key, version: "1", path: fileName, sha256: expectedSha256 },
      }, (async function* () { yield bytes; })(), assertActive);
      return { status: result.duplicate ? 200 : 201, payload: { id: result.file.id, size_bytes: result.file.size_bytes, sha256: result.file.sha256, duplicate: result.duplicate } };
    } catch (error) {
      if (error instanceof KratosLocalDocumentError) {
        if (["storage_access_denied", "customer_unavailable", "folder_customer_mismatch", "invalid_folder_hierarchy"].includes(error.code)) throw new TransportError(404, "not_found");
        if (error.code === "source_conflict") throw new TransportError(409, "upload_conflict");
        if (error.code === "integrity_mismatch") throw new TransportError(422, "integrity_mismatch");
      }
      throw error;
    } finally { store.close(); }
  };
}

function makeGateway(config: KratosLocalServerConfig, adapter: KratosSqliteReadAdapter, verifier: ReturnType<typeof makeVerifier>) {
  const resourceOrigin = canonicalHttpsOrigin(config.resourceOrigin, "resourceOrigin");
  const resourceUrl = resolveKratosResourceUrl(resourceOrigin, config.resourceUrl);
  const issuer = config.entra ? `https://login.microsoftonline.com/${config.entra.tenantId}/v2.0` : config.issuer!;
  const externalReadScope = config.entra ? `${resourceUrl}/kratos.read` : "kratos:read";
  const tools = kratosTools.filter((tool) => (KRATOS_GATEWAY_TOOLS as readonly string[]).includes(tool.name)).map((tool) => tool.name === "get_stored_customer_file" ? {
    ...tool,
    description: config.documentDownloads
      ? "Get physical-file metadata for an exact Kratos file ID. Authorized local files may be retrieved separately with GET /v1/documents/{id}. This tool does not return file contents."
      : "Get physical-file metadata for an exact Kratos file ID. Does not return file contents or a gateway download link. Local document downloads are disabled.",
  } : tool).map((tool) => ({
    ...tool,
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true },
    securitySchemes: [{ type: "oauth2", scopes: [externalReadScope] }],
  })) as KratosToolDefinition[];
  return createKratosGateway({
    resourceOrigin,
    resourceUrl,
    issuer,
    externalReadScope,
    verifyAccessToken: verifier,
    allowedSubjects: config.allowedSubjects,
    tools,
    bodyLimitBytes: config.bodyLimitBytes ?? MAX_BODY_BYTES,
    serverName: "Kratos",
    executeTool: async (name, args, identity) => {
      const result = await runKratosTool(name, args, `oauth:${identity.subject}`, adapter.bindings());
      if (name === "get_stored_customer_file" && result && typeof result === "object" && "download_path" in result) {
        const safeResult = { ...(result as Record<string, unknown>) };
        delete safeResult.download_path;
        return config.documentDownloads
          ? { ...safeResult, local_download_path_template: "/v1/documents/{id}", download_requires: "separate authorization and file verification for eligible local files" }
          : { ...safeResult, gateway_download_available: false, download_requires: "a separate private Kratos Site session" };
      }
      return result;
    },
  });
}

export type KratosLocalServer = {
  server: Server;
  listen(): Promise<{ address: string; port: number }>;
  close(): Promise<void>;
};

export async function createKratosLocalServer(config: KratosLocalServerConfig): Promise<KratosLocalServer> {
  validateConfig(config);
  const adapter = await KratosSqliteReadAdapter.open(config.databasePath);
  let gateway: (request: Request) => Promise<Response>;
  let caseRouter: ((request: Request) => Promise<Response>) | undefined;
  let downloadDocument: ReturnType<typeof makeDocumentDownload> | undefined;
  let uploadDocument: ReturnType<typeof makeDocumentUpload> | undefined;
  let caseConnection: DatabaseSync | undefined;
  try {
    const verifier = makeVerifier(config);
    gateway = makeGateway(config, adapter, verifier);
    if (config.documentDownloads) {
      const read = await openKratosLocalDocumentReader(adapter.DB!, config.documentDownloads.root, config.documentDownloads.allowedCustomerIds);
      downloadDocument = makeDocumentDownload(config, verifier, read);
    }
    if (config.documentUploads) {
      await assertKratosLocalPath(config.documentUploads.root, "directory");
      await assertKratosLocalPath(config.databasePath, "file");
      uploadDocument = makeDocumentUpload(config, verifier, config.documentUploads);
    }
    if (config.caseApi) {
      const info = await lstat(config.databasePath);
      if (!info.isFile() || info.isSymbolicLink()) throw new Error("Existing regular local database required.");
      caseConnection = new DatabaseSync(config.databasePath, { readOnly: !config.caseApi.enableWrites });
      // Verify the operator-applied schema without creating tables or changing journal mode.
      for (const sql of ["SELECT owner_subject,case_id,version,snapshot_json FROM kratos_cases LIMIT 0", "SELECT owner_subject,case_id,event_id,payload_fingerprint,actor_id FROM kratos_case_events LIMIT 0", "SELECT owner_subject,case_id,action_id,proposal_json FROM kratos_case_outbox LIMIT 0"]) caseConnection.prepare(sql).all();
      const customers = new Set(config.caseApi.allowedCustomerIds);
      caseRouter = createKratosCaseApi({ database: caseConnection, resourceOrigin: config.resourceOrigin, verifyAccessToken: verifier, allowedSubjects: config.allowedSubjects, enableWrites: config.caseApi.enableWrites, canAccessCustomer: (_identity, customerId) => customers.has(customerId), todoistProjectId: config.caseApi.todoistProjectId });
    }
  } catch { try { caseConnection?.close(); } finally { adapter.close(); } throw new Error("Local gateway could not initialize its configured database services."); }
  let adapterClosed = false;
  const closeDatabases = () => {
    if (adapterClosed) return;
    adapterClosed = true;
    try { caseConnection?.close(); } finally { adapter.close(); }
  };
  const activeRequests = new Set<AbortController>();
  let activeDownloads = 0;
  let activeUploads = 0;
  const server = createServer({ maxHeaderSize: 16 * 1024 }, async (incoming, outgoing) => {
    const cancellation = new AbortController();
    activeRequests.add(cancellation);
    const abortRequest = () => cancellation.abort();
    const abortDisconnectedResponse = () => { if (!outgoing.writableEnded) abortRequest(); };
    incoming.once("aborted", abortRequest);
    outgoing.once("close", abortDisconnectedResponse);
    try {
      const expectedHost = `${LOOPBACK}:${(server.address() as { port: number } | null)?.port ?? config.port ?? 8788}`;
      if (criticalHeaderCount(incoming, "host") !== 1 || incoming.headers.host !== expectedHost) throw new TransportError(421, "misdirected_request");
      for (const name of ["authorization", "origin", "content-type", "content-length"]) if (criticalHeaderCount(incoming, name) > 1) throw new TransportError(400, "duplicate_header");
      const resourceOrigin = canonicalHttpsOrigin(config.resourceOrigin, "resourceOrigin");
      const url = validateRequestTarget(incoming.url ?? "", resourceOrigin);
      if (new URL(url).pathname === UPLOAD_PATH) {
        if (!uploadDocument || incoming.url !== UPLOAD_PATH) throw new TransportError(404, "not_found");
        if (incoming.method !== "POST") throw new TransportError(405, "method_not_allowed", { allow: "POST" });
        if (activeUploads >= MAX_ACTIVE_UPLOADS) throw new TransportError(503, "upload_busy");
        activeUploads++;
        const timeout = config.responseDeadlineMs ?? 15_000;
        const deadline = performance.now() + timeout;
        const assertActive = () => {
          if (performance.now() >= deadline) throw new TransportError(504, "gateway_timeout");
          if (cancellation.signal.aborted || outgoing.destroyed) throw new TransportError(408, "request_cancelled");
        };
        const dispatch = uploadDocument(incoming, assertActive);
        void dispatch.then(() => { activeUploads--; }, () => { activeUploads--; });
        let timer: NodeJS.Timeout | undefined;
        try {
          const result = await Promise.race([
            dispatch,
            new Promise<never>((_resolve, reject) => { timer = setTimeout(() => { cancellation.abort(); reject(new TransportError(504, "gateway_timeout")); }, timeout); }),
          ]);
          sendJson(outgoing, result.status, result.payload, { connection: "close" });
        } catch (error) {
          if (error instanceof TransportError) throw error;
          throw new TransportError(502, "gateway_failed");
        } finally { if (timer) clearTimeout(timer); }
        return;
      }
      const headers = new Headers();
      for (const [name, value] of Object.entries(incoming.headers)) {
        if (name === "host" || name === "connection" || name === "content-length" || name === "transfer-encoding" || name === "expect" || name === "forwarded" || name.startsWith("x-forwarded-")) continue;
        if (typeof value === "string") headers.set(name, value);
        else if (Array.isArray(value)) headers.set(name, value.join(", "));
      }
      let body: Buffer | undefined;
      if (incoming.method === "POST") {
        body = await readBoundedBody(incoming, config.bodyLimitBytes ?? MAX_BODY_BYTES, config.requestDeadlineMs ?? 15_000);
      } else if ((incoming.headers["content-length"] && incoming.headers["content-length"] !== "0") || incoming.headers["transfer-encoding"]) {
        throw new TransportError(400, "unexpected_request_body");
      }
      if (cancellation.signal.aborted) throw new TransportError(408, "request_cancelled");
      const request = new Request(url, { method: incoming.method, headers, signal: cancellation.signal, ...(body ? { body, duplex: "half" } : {}) } as RequestInit);
      let response: Response | { bytes: Buffer; fileId: number };
      let responseTimer: NodeJS.Timeout | undefined;
      try {
        const pathname = new URL(url).pathname;
        let dispatch: Promise<typeof response>;
        if (/^\/v1\/documents(?:\/|$)/.test(pathname)) {
          const match = /^\/v1\/documents\/([1-9][0-9]*)$/.exec(pathname);
          const id = Number(match?.[1]);
          if (!downloadDocument || !Number.isSafeInteger(id) || incoming.url !== pathname) throw new TransportError(404, "not_found");
          if (request.method !== "GET") throw new TransportError(405, "method_not_allowed", { allow: "GET" });
          if (activeDownloads >= MAX_ACTIVE_DOWNLOADS) throw new TransportError(503, "download_busy");
          activeDownloads++;
          const sent = new Promise<void>((resolve) => {
            const finish = () => {
              outgoing.removeListener("finish", finish);
              outgoing.removeListener("close", finish);
              resolve();
            };
            outgoing.once("finish", finish);
            outgoing.once("close", finish);
          });
          dispatch = downloadDocument(request, id);
          // An aborted read can still have I/O in flight. Keep the slot until it
          // settles and the connection has flushed or discarded the response.
          void Promise.allSettled([sent, dispatch]).then(() => { activeDownloads--; });
        } else if (/^\/v1\/cases(?:\/|$)/.test(pathname)) {
          dispatch = caseRouter ? caseRouter(request) : Promise.resolve(Response.json({ error: "not_found" }, { status: 404, headers: { "cache-control": "no-store" } }));
        } else {
          dispatch = gateway(request);
        }
        response = await Promise.race([
          dispatch,
          new Promise<never>((_resolve, reject) => { responseTimer = setTimeout(() => { cancellation.abort(); reject(new TransportError(504, "gateway_timeout")); }, config.responseDeadlineMs ?? 15_000); }),
        ]);
      } catch (error) { if (error instanceof TransportError) throw error; throw new TransportError(502, "gateway_failed"); }
      finally { if (responseTimer) clearTimeout(responseTimer); }
      if (!(response instanceof Response)) {
        if (cancellation.signal.aborted || outgoing.destroyed) return;
        const sendTimer = setTimeout(() => outgoing.destroy(), config.responseDeadlineMs ?? 15_000);
        sendTimer.unref();
        outgoing.once("finish", () => clearTimeout(sendTimer));
        outgoing.once("close", () => clearTimeout(sendTimer));
        outgoing.writeHead(200, {
          "content-type": "application/octet-stream",
          "content-disposition": `attachment; filename="kratos-document-${response.fileId}.bin"`,
          "x-content-type-options": "nosniff",
          "cache-control": "no-store",
          "content-length": response.bytes.length,
          connection: "close",
        });
        outgoing.end(response.bytes);
        return;
      }
      const bounded = await boundedResponse(response);
      outgoing.writeHead(response.status, { ...bounded.headers, "content-length": bounded.body.length, "connection": "close" });
      outgoing.end(bounded.body);
    } catch (error) {
      const status = error instanceof TransportError ? error.status : 400;
      const code = error instanceof TransportError ? error.code : "invalid_request";
      const shouldClose = !incoming.complete || status === 408 || status === 413 || status === 421 || status >= 500;
      if (!incoming.complete) outgoing.once("finish", () => incoming.destroy());
      const headers = error instanceof TransportError ? error.headers : {};
      sendJson(outgoing, status, { error: code }, shouldClose ? { ...headers, connection: "close" } : headers);
    } finally {
      activeRequests.delete(cancellation);
      incoming.removeListener("aborted", abortRequest);
      outgoing.removeListener("close", abortDisconnectedResponse);
      // Also stops any asynchronous dispatch still pending after an error response.
      cancellation.abort();
    }
  });
  // Node's header/request timeout is only a coarse safety ceiling. The body
  // reader above applies its own absolute deadline once headers are parsed.
  server.headersTimeout = MAX_TIMEOUT_MS;
  server.requestTimeout = MAX_TIMEOUT_MS;
  server.keepAliveTimeout = 1_000;
  server.maxHeadersCount = 100;
  server.maxRequestsPerSocket = 100;
  let activeClose: Promise<void> | null = null;
  const sockets = new Set<import("node:net").Socket>();
  server.on("connection", (socket) => { sockets.add(socket); socket.once("close", () => sockets.delete(socket)); });

  return {
    server,
    listen: () => new Promise((resolve, reject) => {
      const onError = () => {
        server.removeAllListeners("error");
        closeDatabases();
        reject(new Error("Local loopback server could not be started."));
      };
      server.once("error", onError);
      server.listen(config.port ?? 8788, LOOPBACK, () => {
        server.removeListener("error", onError);
        const address = server.address();
        if (!address || typeof address === "string" || address.address !== LOOPBACK) {
          server.close();
          closeDatabases();
          reject(new Error("Local server did not bind exclusively to 127.0.0.1."));
          return;
        }
        resolve({ address: LOOPBACK, port: address.port });
      });
    }),
    close: async () => {
      if (activeClose) return activeClose;
      activeClose = (async () => {
        for (const request of activeRequests) request.abort();
        if (server.listening) {
          let stoppedComplete = false;
          const stopped = new Promise<void>((resolve) => server.close(() => { stoppedComplete = true; resolve(); }));
          server.closeIdleConnections();
          const grace = new Promise<void>((resolve) => setTimeout(resolve, 250));
          await Promise.race([stopped, grace]);
          if (!stoppedComplete) {
            server.closeAllConnections();
            for (const socket of sockets) socket.destroy();
            await Promise.race([stopped, new Promise<void>((resolve) => setTimeout(resolve, 500))]);
          }
        }
        closeDatabases();
      })();
      return activeClose;
    },
  };
}
