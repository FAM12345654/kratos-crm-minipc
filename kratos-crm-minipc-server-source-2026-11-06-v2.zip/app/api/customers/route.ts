import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { findPotentialCustomerDuplicate } from "../../../lib/customer-dedupe";

export async function GET(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const db = env.DB;
  if (!db) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  const query = new URL(request.url).searchParams.get("q")?.trim() ?? "";
  const like = `%${query.replace(/[\\%_]/g, "\\$&")}%`;
  const rows = query.length >= 2
    ? await db.prepare("SELECT id,first_name,last_name,phone,email,birthday,authority_status,adviser,status,folder_name,folder_url,last_contact_at,next_follow_up_at,next_follow_up_note FROM customers WHERE first_name LIKE ? ESCAPE '\\' OR last_name LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\' OR adviser LIKE ? ESCAPE '\\' OR status LIKE ? ESCAPE '\\' ORDER BY last_name,first_name LIMIT 200").bind(like,like,like,like,like,like).all()
    : await db.prepare("SELECT id,first_name,last_name,phone,email,birthday,authority_status,adviser,status,folder_name,folder_url,last_contact_at,next_follow_up_at,next_follow_up_note FROM customers ORDER BY last_name,first_name LIMIT 200").all();
  return Response.json({ customers: rows.results }, { headers: { "Cache-Control": "private, no-store" } });
}

type ImportRow = { first_name?: unknown; last_name?: unknown; phone?: unknown; adviser?: unknown; status?: unknown; folder_name?: unknown };
type FolderLinkRow = { customer_id?: unknown; folder_name?: unknown; folder_url?: unknown };
const clean = (v: unknown, max: number) => typeof v === "string" && v.trim().length <= max ? v.trim() : "";

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte zuerst über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const origin = request.headers.get("origin");
  if (!origin || new URL(origin).origin !== new URL(request.url).origin) return Response.json({ error: "Ungültiger Herkunftsserver." }, { status: 403 });
  if (!request.headers.get("content-type")?.includes("application/json")) return Response.json({ error: "JSON erwartet." }, { status: 415 });
  const db = env.DB;
  if (!db) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  let body: { customers?: ImportRow[]; folder_links?: FolderLinkRow[] };
  try { body = await request.json() as { customers?: ImportRow[] }; }
  catch { return Response.json({ error: "Ungültige JSON-Datei." }, { status: 400 }); }
  if (Array.isArray(body.folder_links)) {
    const links = body.folder_links;
    if (links.length < 1 || links.length > 120) return Response.json({ error: "Der Linkabgleich muss 1 bis 120 Datensätze enthalten." }, { status: 400 });
    const parsed = links.map((link) => {
      const customerId = Number(link.customer_id);
      const folderName = clean(link.folder_name, 200);
      const folderUrl = clean(link.folder_url, 1000);
      let validUrl = false;
      try { const url = new URL(folderUrl); validUrl = url.protocol === "https:" && url.hostname === "familienhelden2025-my.sharepoint.com"; } catch {}
      return { customerId, folderName, folderUrl, valid: Number.isInteger(customerId) && customerId > 0 && !!folderName && validUrl };
    });
    if (parsed.some((row) => !row.valid) || new Set(parsed.map((row) => row.customerId)).size !== parsed.length) return Response.json({ error: "Ungültiger oder doppelter Kundenlink; es wurde nichts geändert." }, { status: 400 });
    const existingRows = await db.prepare("SELECT id,folder_name FROM customers").all<{id:number;folder_name:string|null}>();
    const existing = new Map(existingRows.results.map((row) => [row.id, row.folder_name]));
    if (parsed.some((row) => existing.get(row.customerId) !== row.folderName)) return Response.json({ error: "Mindestens eine CRM-ID passt nicht exakt zum bestätigten OneDrive-Ordnernamen; es wurde nichts geändert." }, { status: 409 });
    const statements: D1PreparedStatement[] = [];
    for (const row of parsed) {
      statements.push(db.prepare("UPDATE customers SET folder_url=?,updated_at=?,updated_by=? WHERE id=? AND folder_name=?").bind(row.folderUrl, new Date().toISOString(), user.email, row.customerId, row.folderName));
      statements.push(db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(row.customerId, "folder_link_sync", JSON.stringify(["folder_url"]), user.email));
    }
    for (let i=0;i<statements.length;i+=80) await db.batch(statements.slice(i,i+80));
    return Response.json({ updated: parsed.length, unmatched: 0 }, { headers: { "Cache-Control": "private, no-store" } });
  }
  if (!Array.isArray(body.customers) || body.customers.length < 1 || body.customers.length > 120) return Response.json({ error: "Der Import muss 1 bis 120 Kunden enthalten." }, { status: 400 });

  const existing = await db.prepare("SELECT first_name,last_name,phone,email FROM customers").all<{first_name:string;last_name:string;phone:string|null;email:string|null}>();
  const seen = [...existing.results];
  const statements: D1PreparedStatement[] = [];
  let duplicates=0, skipped=0;
  for (const row of body.customers) {
    const first=clean(row.first_name,100), last=clean(row.last_name,100), phone=clean(row.phone,50), adviser=clean(row.adviser,100), folder=clean(row.folder_name,200);
    if (!first || !last || row.status !== "Kunde" || !folder) { skipped++; continue; }
    if (findPotentialCustomerDuplicate({first_name:first,last_name:last,phone},seen)) { duplicates++; continue; }
    seen.push({first_name:first,last_name:last,phone:phone||null,email:null});
    const now=new Date().toISOString();
    statements.push(db.prepare("INSERT INTO customers (first_name,last_name,phone,adviser,status,folder_name,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?)").bind(first,last,phone||null,adviser||null,"Kunde",folder,now,user.email));
    statements.push(db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) SELECT last_insert_rowid(),'initial_import',?,?").bind(JSON.stringify(["first_name","last_name","phone","adviser","status","folder_name"]),user.email));
  }
  for (let i=0;i<statements.length;i+=80) await db.batch(statements.slice(i,i+80));
  return Response.json({ inserted: statements.length/2, duplicates, skipped, received: body.customers.length }, { headers: { "Cache-Control": "private, no-store" } });
}
