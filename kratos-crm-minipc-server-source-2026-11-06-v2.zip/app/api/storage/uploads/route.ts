import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { createStorageUploadSession, hasSameOrigin, StorageConflictError, type StorageUploadMetadata } from "../../../../lib/kratos-storage";

const privateHeaders = { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };

function optionalId(value: unknown): number | null | undefined {
  if (value === undefined) return undefined;
  if (value === null) return null;
  const number = Number(value);
  return Number.isInteger(number) && number > 0 ? number : undefined;
}

function optionalString(value: unknown): string | undefined {
  return typeof value === "string" && value !== "" ? value : undefined;
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: privateHeaders });
  if (!env.DB || !env.BUCKET) return Response.json({ error: "Kratos-Dokumentenspeicher ist nicht verfügbar." }, { status: 503, headers: privateHeaders });
  if (!hasSameOrigin(request)) return Response.json({ error: "Ungültige Herkunft." }, { status: 403, headers: privateHeaders });
  if (!request.headers.get("content-type")?.toLowerCase().includes("application/json")) return Response.json({ error: "JSON erwartet." }, { status: 415, headers: privateHeaders });
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; }
  catch { return Response.json({ error: "Ungültiges JSON." }, { status: 400, headers: privateHeaders }); }
  const allowed = new Set(["file_name", "mime_type", "expected_size_bytes", "customer_id", "folder_id", "source_drive_id", "source_item_id", "source_version", "source_path", "source_created_at", "source_modified_at", "source_sha256"]);
  if (Object.keys(body).some((key) => !allowed.has(key))) return Response.json({ error: "Unbekanntes Upload-Feld." }, { status: 400, headers: privateHeaders });
  const customerId = optionalId(body.customer_id), folderId = optionalId(body.folder_id);
  if ((body.customer_id !== undefined && body.customer_id !== null && customerId === undefined) || (body.folder_id !== undefined && body.folder_id !== null && folderId === undefined)) return Response.json({ error: "Ungültige Kunden- oder Ordner-ID." }, { status: 400, headers: privateHeaders });
  if (typeof body.file_name !== "string" || typeof body.expected_size_bytes !== "number" || !Number.isInteger(body.expected_size_bytes)) return Response.json({ error: "Dateiname und erwartete Bytegröße sind erforderlich." }, { status: 400, headers: privateHeaders });
  const metadata: StorageUploadMetadata = {
    customerId,
    folderId,
    sourceDriveId: optionalString(body.source_drive_id),
    sourceItemId: optionalString(body.source_item_id),
    sourceVersion: optionalString(body.source_version),
    sourcePath: optionalString(body.source_path),
    sourceCreatedAt: optionalString(body.source_created_at),
    sourceModifiedAt: optionalString(body.source_modified_at),
    sourceSha256: optionalString(body.source_sha256),
  };
  try {
    const result = await createStorageUploadSession(env.DB, env.BUCKET, {
      fileName: body.file_name,
      mimeType: typeof body.mime_type === "string" ? body.mime_type : "application/octet-stream",
      expectedSizeBytes: body.expected_size_bytes,
      metadata,
      actor: user.email,
    });
    const isRepeat = result.duplicate || ("resumed" in result && result.resumed);
    return Response.json(result, { status: isRepeat ? 200 : 201, headers: privateHeaders });
  } catch (error) {
    if (error instanceof StorageConflictError) return Response.json({ error: error.message }, { status: 409, headers: privateHeaders });
    const message = error instanceof Error ? error.message : "";
    if (message.includes("Ungültig") || message.includes("erforderlich") || message.includes("benötigen") || message.includes("20 MiB") || message.includes("200 GiB") || message.includes("relativ") || message.includes("überschreiten")) return Response.json({ error: message }, { status: 400, headers: privateHeaders });
    return Response.json({ error: "Upload konnte nicht gestartet werden." }, { status: 502, headers: privateHeaders });
  }
}
