import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../../../../chatgpt-auth";
import { hasSameOrigin, StorageConflictError, uploadStoragePart, STORAGE_PART_SIZE_BYTES } from "../../../../../../../lib/kratos-storage";

const privateHeaders = { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };

export async function PUT(request: Request, context: { params: Promise<{ uploadId: string; partNumber: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: privateHeaders });
  if (!env.DB || !env.BUCKET) return Response.json({ error: "Kratos-Dokumentenspeicher ist nicht verfügbar." }, { status: 503, headers: privateHeaders });
  if (!hasSameOrigin(request)) return Response.json({ error: "Ungültige Herkunft." }, { status: 403, headers: privateHeaders });
  if (request.headers.get("content-type")?.split(";")[0].trim().toLowerCase() !== "application/octet-stream") return Response.json({ error: "application/octet-stream erwartet." }, { status: 415, headers: privateHeaders });
  const { uploadId, partNumber: rawPartNumber } = await context.params;
  const partNumber = Number(rawPartNumber);
  if (!/^[0-9a-f-]{36}$/i.test(uploadId) || !Number.isInteger(partNumber) || partNumber < 1 || partNumber > 10_000) return Response.json({ error: "Ungültige Upload- oder Part-ID." }, { status: 400, headers: privateHeaders });
  const contentLength = request.headers.get("content-length");
  if (contentLength === null || !/^\d+$/.test(contentLength)) return Response.json({ error: "Content-Length wird für begrenzte Uploadparts benötigt." }, { status: 411, headers: privateHeaders });
  const expectedPartSize = Number(contentLength);
  if (expectedPartSize > STORAGE_PART_SIZE_BYTES) return Response.json({ error: "Uploadparts sind auf 20 MiB begrenzt." }, { status: 413, headers: privateHeaders });
  try {
    const result = await uploadStoragePart(env.DB, env.BUCKET, uploadId, partNumber, user.email, expectedPartSize, request.body);
    return Response.json(result, { status: result.duplicate ? 200 : 201, headers: privateHeaders });
  } catch (error) {
    if (error instanceof StorageConflictError) return Response.json({ error: error.message }, { status: 409, headers: privateHeaders });
    const message = error instanceof Error ? error.message : "";
    const status = message.includes("überschreitet") ? 413 : message.includes("muss") || message.includes("fehlt") || message.includes("Leere") ? 400 : 502;
    return Response.json({ error: message || "Uploadpart konnte nicht gespeichert werden." }, { status, headers: privateHeaders });
  }
}
