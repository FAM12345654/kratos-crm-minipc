import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../../chatgpt-auth";
import { abortStorageUploadSession, completeStorageUploadSession, getStorageUploadSession, hasSameOrigin, StorageConflictError } from "../../../../../lib/kratos-storage";

const privateHeaders = { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };
type RouteContext = { params: Promise<{ uploadId: string }> };

async function authorize(request: Request, context: RouteContext) {
  const user = await getChatGPTUser();
  if (!user) return { response: Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: privateHeaders }) } as const;
  if (!env.DB || !env.BUCKET) return { response: Response.json({ error: "Kratos-Dokumentenspeicher ist nicht verfügbar." }, { status: 503, headers: privateHeaders }) } as const;
  const uploadId = (await context.params).uploadId;
  if (!/^[0-9a-f-]{36}$/i.test(uploadId)) return { response: Response.json({ error: "Ungültige Upload-ID." }, { status: 400, headers: privateHeaders }) } as const;
  return { user, uploadId, db: env.DB, bucket: env.BUCKET } as const;
}

export async function GET(request: Request, context: RouteContext) {
  const auth = await authorize(request, context);
  if ("response" in auth) return auth.response;
  const result = await getStorageUploadSession(auth.db, auth.uploadId, auth.user.email);
  if (!result) return Response.json({ error: "Upload-Session nicht gefunden." }, { status: 404, headers: privateHeaders });
  return Response.json(result, { headers: privateHeaders });
}

export async function POST(request: Request, context: RouteContext) {
  const auth = await authorize(request, context);
  if ("response" in auth) return auth.response;
  if (!hasSameOrigin(request)) return Response.json({ error: "Ungültige Herkunft." }, { status: 403, headers: privateHeaders });
  try {
    const result = await completeStorageUploadSession(auth.db, auth.bucket, auth.uploadId, auth.user.email);
    return Response.json(result, { status: result.duplicate ? 200 : 201, headers: privateHeaders });
  } catch (error) {
    if (error instanceof StorageConflictError) return Response.json({ error: error.message }, { status: 409, headers: privateHeaders });
    const message = error instanceof Error ? error.message : "";
    const status = message.includes("R2 konnte") || message.includes("nicht vollständig") ? 502 : 400;
    return Response.json({ error: message || "Upload konnte nicht abgeschlossen werden." }, { status, headers: privateHeaders });
  }
}

export async function DELETE(request: Request, context: RouteContext) {
  const auth = await authorize(request, context);
  if ("response" in auth) return auth.response;
  if (!hasSameOrigin(request)) return Response.json({ error: "Ungültige Herkunft." }, { status: 403, headers: privateHeaders });
  try {
    const result = await abortStorageUploadSession(auth.db, auth.bucket, auth.uploadId, auth.user.email);
    return Response.json(result, { headers: privateHeaders });
  } catch (error) {
    if (error instanceof StorageConflictError) return Response.json({ error: error.message }, { status: 409, headers: privateHeaders });
    return Response.json({ error: "Upload-Session konnte nicht abgebrochen werden." }, { status: 502, headers: privateHeaders });
  }
}
