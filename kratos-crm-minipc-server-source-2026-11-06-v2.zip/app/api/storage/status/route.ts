import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import hosting from "../../../../.openai/hosting.json";
import { MAX_SINGLE_UPLOAD_BYTES, STORAGE_PART_SIZE_BYTES, MAX_MULTIPART_UPLOAD_BYTES } from "../../../../lib/kratos-storage";

export async function GET() {
  const headers = { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };
  if (!await getChatGPTUser()) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers });
  if (!env.DB || !env.BUCKET) return Response.json({ project_id: hosting.project_id, configured: false, error: "Privater Binärspeicher ist nicht konfiguriert." }, { status: 503, headers });
  try { await env.DB.prepare("SELECT id FROM storage_files LIMIT 1").first(); }
  catch { return Response.json({ project_id: hosting.project_id, configured: false, error: "Storage-Schema ist noch nicht bereit." }, { status: 503, headers }); }
  return Response.json({ project_id: hosting.project_id, storage: "r2", configured: true, max_single_upload_bytes: MAX_SINGLE_UPLOAD_BYTES, part_size_bytes: STORAGE_PART_SIZE_BYTES, max_multipart_upload_bytes: MAX_MULTIPART_UPLOAD_BYTES, jurisdiction_verified: false, backup_verified: false }, { headers });
}
