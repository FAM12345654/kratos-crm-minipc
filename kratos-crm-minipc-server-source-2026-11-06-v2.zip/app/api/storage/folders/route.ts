import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { createStorageFolder, hasSameOrigin, listStorageFolders } from "../../../../lib/kratos-storage";

const privateHeaders = { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };

function optionalInteger(value: string | null): number | null | undefined {
  if (value === null) return undefined;
  if (value === "root" || value === "unresolved") return null;
  const number = Number(value);
  return Number.isInteger(number) && number > 0 ? number : undefined;
}

export async function GET(request: Request) {
  if (!await getChatGPTUser()) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: privateHeaders });
  if (!env.DB || !env.BUCKET) return Response.json({ error: "Kratos-Dokumentenspeicher ist nicht verfügbar." }, { status: 503, headers: privateHeaders });
  const query = new URL(request.url).searchParams;
  const customerParam = query.get("customer_id");
  const parentParam = query.get("parent_folder_id");
  const customerId = optionalInteger(customerParam);
  const parentFolderId = optionalInteger(parentParam);
  if (customerParam !== null && customerId === undefined) return Response.json({ error: "Ungültige Kunden-ID." }, { status: 400, headers: privateHeaders });
  if (parentParam !== null && parentFolderId === undefined) return Response.json({ error: "Ungültige übergeordnete Ordner-ID." }, { status: 400, headers: privateHeaders });
  const limit = Number(query.get("limit") ?? 50), offset = Number(query.get("offset") ?? 0);
  try {
    const result = await listStorageFolders(env.DB, {
      ...(customerParam !== null ? { customerId } : {}),
      ...(parentParam !== null ? { parentFolderId } : {}),
      query: query.get("q") ?? undefined,
      limit,
      offset,
    });
    return Response.json(result, { headers: privateHeaders });
  } catch {
    return Response.json({ error: "Ordnerliste konnte nicht gelesen werden." }, { status: 400, headers: privateHeaders });
  }
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: privateHeaders });
  if (!env.DB || !env.BUCKET) return Response.json({ error: "Kratos-Dokumentenspeicher ist nicht verfügbar." }, { status: 503, headers: privateHeaders });
  if (!hasSameOrigin(request)) return Response.json({ error: "Ungültige Herkunft." }, { status: 403, headers: privateHeaders });
  if (!request.headers.get("content-type")?.toLowerCase().includes("application/json")) return Response.json({ error: "JSON erwartet." }, { status: 415, headers: privateHeaders });
  let body: { name?: unknown; customer_id?: unknown; parent_folder_id?: unknown };
  try { body = await request.json() as typeof body; }
  catch { return Response.json({ error: "Ungültiges JSON." }, { status: 400, headers: privateHeaders }); }
  const result = await createStorageFolder(env.DB, {
    name: body.name,
    customerId: body.customer_id,
    parentFolderId: body.parent_folder_id,
  }, user.email);
  if ("error" in result && typeof result.error === "string") {
    const error = result.error;
    const status = error.includes("nicht gefunden") ? 404
      : error.includes("unterschiedlichen") || error.includes("kollidiert") ? 409
      : 400;
    return Response.json({ error }, { status, headers: privateHeaders });
  }
  return Response.json({ folder: result.folder, created: result.created }, { status: result.created ? 201 : 200, headers: privateHeaders });
}
