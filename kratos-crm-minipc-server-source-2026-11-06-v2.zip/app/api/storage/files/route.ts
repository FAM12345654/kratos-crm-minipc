import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { hasSameOrigin, listStoredFiles, MAX_SINGLE_UPLOAD_BYTES, StorageConflictError, storeUploadedFile } from "../../../../lib/kratos-storage";

const privateHeaders = { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };

function optionalInteger(value: string | null): number | null | undefined {
  if (value === null) return undefined;
  if (value === "unresolved" || value === "root") return null;
  const number = Number(value);
  return Number.isInteger(number) && number > 0 ? number : undefined;
}

export async function GET(request: Request) {
  if (!await getChatGPTUser()) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: privateHeaders });
  if (!env.DB || !env.BUCKET) return Response.json({ error: "Kratos-Dokumentenspeicher ist nicht verfügbar." }, { status: 503, headers: privateHeaders });
  const params = new URL(request.url).searchParams;
  const customerParam = params.get("customer_id"), folderParam = params.get("folder_id");
  const customerId = optionalInteger(customerParam), folderId = optionalInteger(folderParam);
  if (customerParam !== null && customerId === undefined) return Response.json({ error: "Ungültige Kunden-ID." }, { status: 400, headers: privateHeaders });
  if (folderParam !== null && folderId === undefined) return Response.json({ error: "Ungültige Ordner-ID." }, { status: 400, headers: privateHeaders });
  const query = params.get("q") ?? "";
  if (query.length > 100) return Response.json({ error: "Suchtext darf höchstens 100 Zeichen lang sein." }, { status: 400, headers: privateHeaders });
  try {
    const result = await listStoredFiles(env.DB, {
      ...(customerParam !== null ? { customerId } : {}),
      ...(folderParam !== null ? { folderId } : {}),
      query,
      limit: Number(params.get("limit") ?? 25),
      offset: Number(params.get("offset") ?? 0),
    });
    return Response.json(result, { headers: privateHeaders });
  } catch {
    return Response.json({ error: "Dateiliste konnte nicht gelesen werden." }, { status: 400, headers: privateHeaders });
  }
}

function textField(form: FormData, key: string): string | undefined {
  const value = form.get(key);
  return typeof value === "string" && value !== "" ? value : undefined;
}

function optionalNumberField(form: FormData, key: string): number | null | undefined {
  const value = textField(form, key);
  if (value === undefined) return undefined;
  if (value === "unresolved" || value === "root") return null;
  const number = Number(value);
  return Number.isInteger(number) && number > 0 ? number : undefined;
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: privateHeaders });
  if (!env.DB || !env.BUCKET) return Response.json({ error: "Kratos-Dokumentenspeicher ist nicht verfügbar." }, { status: 503, headers: privateHeaders });
  if (!hasSameOrigin(request)) return Response.json({ error: "Ungültige Herkunft." }, { status: 403, headers: privateHeaders });
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("multipart/form-data;")) return Response.json({ error: "multipart/form-data mit einer Datei erwartet." }, { status: 415, headers: privateHeaders });
  const contentLengthHeader = request.headers.get("content-length");
  if (contentLengthHeader !== null && (!/^\d+$/.test(contentLengthHeader) || Number(contentLengthHeader) > MAX_SINGLE_UPLOAD_BYTES + 256 * 1024)) return Response.json({ error: "Einzeluploads sind auf 20 MiB begrenzt; große Dateien verwenden den resumierbaren Upload." }, { status: 413, headers: privateHeaders });
  if (!request.body) return Response.json({ error: "Uploadinhalt fehlt." }, { status: 400, headers: privateHeaders });
  let requestBytes = 0;
  const boundedBody = request.body.pipeThrough(new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) {
      requestBytes += chunk.byteLength;
      if (requestBytes > MAX_SINGLE_UPLOAD_BYTES + 256 * 1024) throw new Error("STORAGE_BODY_LIMIT");
      controller.enqueue(chunk);
    },
  }));
  const boundedHeaders = new Headers(request.headers);
  boundedHeaders.delete("content-length");
  const boundedRequest = new Request(request.url, { method: "POST", headers: boundedHeaders, body: boundedBody });
  let form: FormData;
  try { form = await boundedRequest.formData(); }
  catch (error) {
    const status = error instanceof Error && error.message.includes("STORAGE_BODY_LIMIT") ? 413 : 400;
    return Response.json({ error: status === 413 ? "Einzeluploads sind auf 20 MiB begrenzt; große Dateien verwenden den resumierbaren Upload." : "Ungültiger Multipart-Upload." }, { status, headers: privateHeaders });
  }
  const allowed = new Set(["file", "customer_id", "folder_id", "source_drive_id", "source_item_id", "source_version", "source_path", "source_created_at", "source_modified_at", "source_sha256"]);
  if ([...form.keys()].some((key) => !allowed.has(key))) return Response.json({ error: "Unbekanntes Upload-Feld." }, { status: 400, headers: privateHeaders });
  const files = form.getAll("file");
  if (files.length !== 1 || typeof File === "undefined" || !(files[0] instanceof File)) return Response.json({ error: "Genau eine Datei ist erforderlich." }, { status: 400, headers: privateHeaders });
  const customerId = optionalNumberField(form, "customer_id"), folderId = optionalNumberField(form, "folder_id");
  if (textField(form, "customer_id") && customerId === undefined) return Response.json({ error: "Ungültige Kunden-ID." }, { status: 400, headers: privateHeaders });
  if (textField(form, "folder_id") && folderId === undefined) return Response.json({ error: "Ungültige Ordner-ID." }, { status: 400, headers: privateHeaders });
  try {
    const result = await storeUploadedFile(env.DB, env.BUCKET, files[0], {
      customerId,
      folderId,
      sourceDriveId: textField(form, "source_drive_id"),
      sourceItemId: textField(form, "source_item_id"),
      sourceVersion: textField(form, "source_version"),
      sourcePath: textField(form, "source_path"),
      sourceCreatedAt: textField(form, "source_created_at"),
      sourceModifiedAt: textField(form, "source_modified_at"),
      sourceSha256: textField(form, "source_sha256"),
    }, user.email);
    return Response.json(result, { status: result.duplicate ? 200 : 201, headers: privateHeaders });
  } catch (error) {
    if (error instanceof StorageConflictError) return Response.json({ error: error.message }, { status: 409, headers: privateHeaders });
    const message = error instanceof Error ? error.message : "";
    if (message.includes("Ungültig") || message.includes("erforderlich") || message.includes("benötigt") || message.includes("relativ") || message.includes("überschreiten") || message.includes("begrenzt")) return Response.json({ error: message }, { status: 400, headers: privateHeaders });
    return Response.json({ error: "Datei konnte nicht sicher gespeichert werden; Importstatus prüfen, bevor erneut hochgeladen wird." }, { status: 502, headers: privateHeaders });
  }
}
