import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../../../chatgpt-auth";
import { getStoredFileMetadata } from "../../../../../../lib/kratos-storage";

const privateHeaders = { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };

export async function GET(_request: Request, context: { params: Promise<{ fileId: string }> }) {
  if (!await getChatGPTUser()) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: privateHeaders });
  if (!env.DB || !env.BUCKET) return Response.json({ error: "Kratos-Dokumentenspeicher ist nicht verfügbar." }, { status: 503, headers: privateHeaders });
  const id = Number((await context.params).fileId);
  if (!Number.isInteger(id) || id < 1) return Response.json({ error: "Ungültige Datei-ID." }, { status: 400, headers: privateHeaders });
  const metadata = await getStoredFileMetadata(env.DB, id);
  if (!metadata) return Response.json({ error: "Datei nicht gefunden." }, { status: 404, headers: privateHeaders });
  return Response.json(metadata, { headers: privateHeaders });
}
