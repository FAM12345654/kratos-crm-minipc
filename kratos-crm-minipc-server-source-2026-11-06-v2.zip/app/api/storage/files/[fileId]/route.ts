import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../../chatgpt-auth";
import { getStoredFileMetadata, getStoredFileObjectKey, recordStorageAudit } from "../../../../../lib/kratos-storage";

const privateHeaders = {
  "Cache-Control": "private, no-store",
  "X-Content-Type-Options": "nosniff",
  "Content-Security-Policy": "default-src 'none'; sandbox",
};

type RouteContext = { params: Promise<{ fileId: string }> };

async function authorizedFileId(context: RouteContext) {
  const user = await getChatGPTUser();
  if (!user) return { response: Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: privateHeaders }) } as const;
  const { fileId: rawId } = await context.params;
  const id = Number(rawId);
  if (!Number.isInteger(id) || id < 1) return { response: Response.json({ error: "Ungültige Datei-ID." }, { status: 400, headers: privateHeaders }) } as const;
  if (!env.DB || !env.BUCKET) return { response: Response.json({ error: "Kratos-Dokumentenspeicher ist nicht verfügbar." }, { status: 503, headers: privateHeaders }) } as const;
  return { user, id, db: env.DB, bucket: env.BUCKET } as const;
}

function encodeHeaderFileName(name: string) {
  return encodeURIComponent(name).replace(/[!'()*]/g, (char) => "%" + char.charCodeAt(0).toString(16).toUpperCase());
}

export async function GET(_request: Request, context: RouteContext) {
  const auth = await authorizedFileId(context);
  if ("response" in auth) return auth.response;
  const metadata = await getStoredFileMetadata(auth.db, auth.id);
  if (!metadata) return Response.json({ error: "Datei nicht gefunden." }, { status: 404, headers: privateHeaders });
  if (metadata.import_state !== "stored" && metadata.import_state !== "unresolved") return Response.json({ error: "Datei ist noch nicht vollständig geprüft und verfügbar." }, { status: 409, headers: privateHeaders });
  const objectKey = await getStoredFileObjectKey(auth.db, auth.id);
  if (!objectKey) return Response.json({ error: "Dateiobjekt ist nicht verfügbar." }, { status: 404, headers: privateHeaders });
  const object = await auth.bucket.get(objectKey);
  if (!object || !("body" in object) || !object.body) return Response.json({ error: "Dateiobjekt ist nicht verfügbar." }, { status: 404, headers: privateHeaders });
  await recordStorageAudit(auth.db, { fileId: auth.id, action: "download", actor: auth.user.email });
  const asciiName = metadata.file_name.replace(/[^\x20-\x7e]|["\\]/g, "_");
  const headers = new Headers({
    ...privateHeaders,
    "Content-Type": "application/octet-stream",
    "Content-Disposition": "attachment; filename=\"" + asciiName + "\"; filename*=UTF-8''" + encodeHeaderFileName(metadata.file_name),
    "Content-Length": String(metadata.size_bytes),
  });
  return new Response(object.body, { status: 200, headers });
}
