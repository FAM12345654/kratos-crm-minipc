import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { documentCategories, listCustomerDocuments } from "../../../lib/customer-documents";

export async function GET(request:Request) {
  if (!await getChatGPTUser()) return Response.json({error:"Bitte über ChatGPT anmelden."},{status:401});
  if (!env.DB) return Response.json({error:"Datenbank nicht verfügbar."},{status:503});
  const params=new URL(request.url).searchParams, id=Number(params.get("customer_id")), category=params.get("category")||undefined;
  if (!Number.isInteger(id)||id<1||(category&&!documentCategories.includes(category as typeof documentCategories[number]))) return Response.json({error:"Ungültige Kunden-ID oder Kategorie."},{status:400});
  const result=await listCustomerDocuments(env.DB,id,category);
  return Response.json(result,{status:result.isError?404:200,headers:{"Cache-Control":"private, no-store"}});
}
