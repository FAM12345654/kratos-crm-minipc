import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";

export async function GET(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Bitte über ChatGPT anmelden." }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const customerId = Number(new URL(request.url).searchParams.get("customer_id"));
  if (!Number.isInteger(customerId) || customerId < 1) return Response.json({ error: "Gültige Kunden-ID erforderlich." }, { status: 400 });
  if (!env.DB) return Response.json({ error: "CRM-Datenbank nicht verfügbar." }, { status: 503 });
  const customer = await env.DB.prepare("SELECT id FROM customers WHERE id=?").bind(customerId).first();
  if (!customer) return Response.json({ error: "Kunde nicht gefunden." }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  const rows = await env.DB.prepare("SELECT id,customer_id,insurance_type,provider,status,start_date,end_date,cancellation_deadline,document_url FROM customer_contracts WHERE customer_id=? ORDER BY COALESCE(end_date,'9999-12-31'),id").bind(customerId).all();
  return Response.json({ contracts: rows.results }, { headers: { "Cache-Control": "private, no-store" } });
}
