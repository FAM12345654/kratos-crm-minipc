import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Kratos · Familienhelden",
  description: "Private Kratos-Datenbank für die Kundenbetreuung von Familienhelden.",
  manifest: "/manifest.webmanifest",
  themeColor: "#0f766e",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="de">
      <body className="antialiased">{children}</body>
    </html>
  );
}
