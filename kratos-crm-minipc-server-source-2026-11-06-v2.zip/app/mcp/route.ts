import { env } from "cloudflare:workers";
import { kratosTools, runKratosTool } from "../../lib/kratos-tool-service";

type Json = Record<string, unknown>;
const textResult = (value: unknown, isError = false) => ({ content: [{ type: "text", text: JSON.stringify(value) }], structuredContent: value, ...(isError ? { isError: true } : {}) });
const str = (v: unknown) => typeof v === "string" ? v.trim() : "";
const fail = (message: string) => ({ isError: true, message });

export async function POST(request: Request) {
  const actorId = request.headers.get("oai-authenticated-user-id");
  const actorEmail = request.headers.get("oai-authenticated-user-email");
  let body: Json;
  try { body = await request.json() as Json; } catch { return Response.json({ error: "invalid JSON" }, { status: 400 }); }
  if (!actorId || !actorEmail) return Response.json({ error: "authenticated Site user required" }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
  const method = str(body.method);
  const params = (body.params ?? {}) as Json;
  const actor = actorEmail;
  const id = body.id ?? null;
  let result: unknown;
  if (method === "server/discover") result = { supportedVersions: ["2026-07-28"], capabilities: { tools: {} }, serverInfo: { name: "familienhelden-crm", version: "1.0.0" } };
  else if (method === "initialize") result = { protocolVersion: "2026-07-28", capabilities: { tools: {} }, serverInfo: { name: "familienhelden-crm", version: "1.0.0" } };
  else if (method === "notifications/initialized" || method === "ping") result = {};
  else if (method === "tools/list") result = { tools: kratosTools };
  else if (method === "tools/call") {
    const name = str(params.name);
    const tool = kratosTools.find((item) => item.name === name);
    if (!tool) result = textResult({ error: "Unknown tool" }, true);
    else {
      const args = (params.arguments ?? {}) as Json;
      try {
        const out = await runKratosTool(name, args, actor, env);
        result = textResult(out, Boolean((out as Json)?.isError));
      } catch (error) {
        console.error("Kratos MCP operation failed", { tool: name, errorType: error instanceof Error ? error.name : "unknown" });
        result = textResult(fail("Datenbankaktion fehlgeschlagen. Ergebnis prüfen, bevor ein Schreibvorgang erneut versucht wird."), true);
      }
    }
  } else result = { error: { code: -32601, message: "Method not found" } };
  return Response.json({ jsonrpc: "2.0", id, result }, { headers: { "Cache-Control": "private, no-store", "MCP-Protocol-Version": "2026-07-28" } });
}

