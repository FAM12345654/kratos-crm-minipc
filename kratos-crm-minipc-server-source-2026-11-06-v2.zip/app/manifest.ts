import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    id: "/",
    name: "Kratos · Familienhelden",
    short_name: "Kratos",
    description: "Private Kundendatenbank für Familienhelden mit Vertragsdaten, Wiedervorlagen und Dokumentverknüpfungen.",
    lang: "de-AT",
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#f5f7fb",
    theme_color: "#0f766e",
    icons: [
      {
        src: "/kratos-icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
    ],
  };
}
