"use client";

import { useEffect, useState } from "react";
import { CustomerDocuments } from "../components/customer-documents";
import { CustomerContracts } from "../components/customer-contracts";
import { CustomerMobileList } from "../components/customer-mobile-list";

type Customer = { id:number; first_name:string; last_name:string; phone:string|null; email:string|null; birthday:string|null; authority_status:string; adviser:string|null; status:string; folder_name:string|null; folder_url:string|null; last_contact_at:string|null; next_follow_up_at:string|null; next_follow_up_note:string|null };
type ImportCustomer = { first_name:string; last_name:string; phone:string; adviser:string; status:"Kunde"; folder_name:string };
type ApiResponse = { error?:string; customers?:Customer[]; inserted?:number; duplicates?:number; skipped?:number; updated?:number };
type FolderLink = { customer_id:number; folder_name:string; folder_url:string };
const isFolderLink = (value:unknown): value is FolderLink => typeof value === "object" && value !== null && "customer_id" in value && Number.isInteger(value.customer_id) && "folder_name" in value && typeof value.folder_name === "string" && "folder_url" in value && typeof value.folder_url === "string";

function parseCsv(source:string): ImportCustomer[] {
  const firstLine=source.replace(/^\uFEFF/,"").split(/\r?\n/,1)[0]??"";
  const delimiter=firstLine.split(";").length>firstLine.split(",").length?";":",";
  const matrix:string[][]=[]; let row:string[]=[], cell="", quoted=false;
  const input=source.replace(/^\uFEFF/,"");
  for(let i=0;i<input.length;i++){
    const ch=input[i];
    if(ch==='"'&&quoted&&input[i+1]==='"'){cell+='"';i++;}
    else if(ch==='"') quoted=!quoted;
    else if(ch===delimiter&&!quoted){row.push(cell);cell="";}
    else if((ch==="\n"||ch==="\r")&&!quoted){if(ch==="\r"&&input[i+1]==="\n")i++;row.push(cell);matrix.push(row);row=[];cell="";}
    else cell+=ch;
  }
  if(cell.length||row.length){row.push(cell);matrix.push(row);}
  if(matrix.length<2) throw new Error("Die CSV-Datei enthält keine Datensätze.");
  const headers=matrix[0].map(h=>h.trim().toLowerCase());
  const ix=(name:string)=>headers.indexOf(name.toLowerCase());
  const firstIx=ix("First Name"),lastIx=ix("Last Name"),phoneIx=ix("Phone Number"),descIx=ix("Description");
  if([firstIx,lastIx,phoneIx,descIx].some(i=>i<0)) throw new Error("Erwartete Spalten: First Name, Last Name, Phone Number und Description.");
  return matrix.slice(1).map(r=>{
    const first_name=(r[firstIx]??"").trim(),last_name=(r[lastIx]??"").trim(),phone=(r[phoneIx]??"").trim(),description=(r[descIx]??"").trim();
    if(!/^Kunde\b/i.test(description)||!first_name||!last_name) return null;
    const adviser=description.match(/Betreuer:\s*([^|]+)/i)?.[1]?.trim()??"";
    return {first_name,last_name,phone,adviser:adviser==="?"?"":adviser,status:"Kunde" as const,folder_name:`${first_name} ${last_name}`};
  }).filter((r):r is ImportCustomer=>r!==null);
}

export default function Home() {
  const [query, setQuery] = useState("");
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [onlyDue, setOnlyDue] = useState(false);
  const today = new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Berlin" }).format(new Date());
  const dueCustomers = customers.filter(c => c.next_follow_up_at && c.next_follow_up_at.slice(0,10) <= today);
  const visibleCustomers = onlyDue ? dueCustomers : customers;
  const [selectedCustomer, setSelectedCustomer] = useState<Customer|null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [importRows,setImportRows]=useState<ImportCustomer[]>([]);
  const [importFile,setImportFile]=useState("");
  const [importMessage,setImportMessage]=useState("");
  const [importing,setImporting]=useState(false);
  const [importError,setImportError]=useState("");
  const [folderLinks,setFolderLinks]=useState<FolderLink[]>([]);
  const [folderLinkFile,setFolderLinkFile]=useState("");
  const [folderLinkMessage,setFolderLinkMessage]=useState("");
  const [folderLinkError,setFolderLinkError]=useState("");
  useEffect(() => {
    let active = true;
    const timer = window.setTimeout(async () => {
      setLoading(true); setError("");
      try {
        const response = await fetch(`/api/customers?q=${encodeURIComponent(query)}`, { cache: "no-store" });
        const data = await response.json() as ApiResponse;
        if (!response.ok) throw new Error(data.error ?? "Kundendaten konnten nicht geladen werden.");
        if (active) setCustomers(data.customers ?? []);
      } catch (e) { if (active) setError(e instanceof Error ? e.message : "Fehler beim Laden."); }
      finally { if (active) setLoading(false); }
    }, 180);
    return () => { active = false; window.clearTimeout(timer); };
  }, [query]);
  async function chooseImportFile(file:File|null){
    setImportRows([]);setImportFile("");setImportError("");setImportMessage("");
    if(!file)return;
    try{const rows=parseCsv(await file.text());if(rows.length!==105)throw new Error(`Es wurden ${rows.length} als Kunde gekennzeichnete Zeilen erkannt. Erwartet werden exakt 105 geprüfte Kunden.`);setImportRows(rows);setImportFile(file.name);}
    catch(e){setImportError(e instanceof Error?e.message:"CSV konnte nicht gelesen werden.");}
  }
  async function importCustomers(){
    if(importRows.length!==105)return;
    setImporting(true);setImportError("");setImportMessage("");
    try{
      const response=await fetch("/api/customers",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({customers:importRows})});
      const data=await response.json() as ApiResponse;if(!response.ok)throw new Error(data.error??"Import fehlgeschlagen.");
      setImportMessage(`${data.inserted} Kunden importiert, ${data.duplicates} Dubletten übersprungen, ${data.skipped} Zeilen ignoriert.`);setImportRows([]);setImportFile("");setQuery("");
      const refreshed=await fetch("/api/customers",{cache:"no-store"});const result=await refreshed.json() as ApiResponse;if(refreshed.ok)setCustomers(result.customers??[]);
    }catch(e){setImportError(e instanceof Error?e.message:"Import fehlgeschlagen.");}
    finally{setImporting(false);}
  }
  async function chooseFolderLinkFile(file:File|null){
    setFolderLinks([]);setFolderLinkFile("");setFolderLinkError("");setFolderLinkMessage("");
    if(!file)return;
    try{const data:unknown=JSON.parse(await file.text());const links=Array.isArray(data)?data:typeof data === "object" && data !== null && "folder_links" in data ? data.folder_links : null;if(!Array.isArray(links)||links.length<1||links.length>120||!links.every(isFolderLink))throw new Error("Erwartet wird eine JSON-Liste bestätigter CRM-ID/Ordnername/OneDrive-Link-Zuordnungen.");setFolderLinks(links);setFolderLinkFile(file.name);}
    catch(e){setFolderLinkError(e instanceof Error?e.message:"Datei konnte nicht gelesen werden.");}
  }
  async function syncFolderLinks(){
    if(!folderLinks.length)return;
    setImporting(true);setFolderLinkError("");setFolderLinkMessage("");
    try{const response=await fetch("/api/customers",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({folder_links:folderLinks})});const data=await response.json() as ApiResponse;if(!response.ok)throw new Error(data.error??"Ordnerlinks konnten nicht gespeichert werden.");setFolderLinkMessage(`${data.updated} bestätigte Kundenordnerlinks gespeichert.`);setFolderLinks([]);setFolderLinkFile("");const refreshed=await fetch("/api/customers",{cache:"no-store"});const result=await refreshed.json() as ApiResponse;if(refreshed.ok)setCustomers(result.customers??[]);}
    catch(e){setFolderLinkError(e instanceof Error?e.message:"Ordnerlinks konnten nicht gespeichert werden.");}
    finally{setImporting(false);}
  }
  return <main className="min-h-screen bg-[#f5f7fb] text-slate-900">
    <header className="border-b border-slate-200 bg-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div><p className="text-xs font-semibold uppercase tracking-[.18em] text-teal-700">Familienhelden</p><h1 className="mt-1 text-2xl font-semibold">Kratos</h1></div>
        <span className="rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-800">Private Datenbank</span>
      </div>
    </header>
    <div className="mx-auto max-w-6xl px-6 py-8">
      {customers.length===0&&!query&&<section className="mb-6 rounded-2xl border border-teal-200 bg-white p-6 shadow-sm"><div className="mb-3"><h2 className="font-semibold">Geprüfte Kunden importieren</h2><p className="mt-1 text-sm text-slate-600">Nur die geprüfte Familienhelden-Kundendatei mit genau 105 Kunden wird angenommen. Kontakte ohne bestätigte Kundenmappe werden nicht importiert.</p></div><input type="file" accept=".csv,text/csv" onChange={e=>void chooseImportFile(e.target.files?.[0]??null)} className="block w-full max-w-xl text-sm file:mr-4 file:rounded-lg file:border-0 file:bg-teal-700 file:px-4 file:py-2.5 file:font-medium file:text-white hover:file:bg-teal-800"/>{importFile&&<p className="mt-3 text-sm text-emerald-800">{importFile}: {importRows.length} geprüfte Kunden erkannt.</p>}{importError&&<p role="alert" className="mt-3 text-sm text-rose-700">{importError}</p>}{importMessage&&<p role="status" className="mt-3 text-sm font-medium text-emerald-800">{importMessage}</p>}<button onClick={()=>void importCustomers()} disabled={importRows.length!==105||importing} className="mt-4 rounded-xl bg-teal-700 px-4 py-2.5 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-300">{importing?"Import läuft …":"105 geprüfte Kunden ins CRM importieren"}</button></section>}
      <section className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><h2 className="font-semibold">Bestätigte OneDrive-Ordnerlinks aktualisieren</h2><p className="mt-1 text-sm text-slate-600">Es werden nur Einträge mit exakt passender CRM-ID und Kundenordnerbezeichnung gespeichert.</p><input type="file" accept=".json,application/json" onChange={e=>void chooseFolderLinkFile(e.target.files?.[0]??null)} className="mt-3 block w-full max-w-xl text-sm file:mr-4 file:rounded-lg file:border-0 file:bg-slate-700 file:px-4 file:py-2 file:font-medium file:text-white"/>{folderLinkFile&&<p className="mt-2 text-sm text-slate-600">{folderLinkFile}: {folderLinks.length} Zuordnungen erkannt.</p>}{folderLinkError&&<p role="alert" className="mt-2 text-sm text-rose-700">{folderLinkError}</p>}{folderLinkMessage&&<p role="status" className="mt-2 text-sm text-emerald-800">{folderLinkMessage}</p>}<button type="button" onClick={()=>void syncFolderLinks()} disabled={!folderLinks.length||importing} className="mt-3 rounded-lg bg-slate-800 px-3 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-300">{importing?"Speichern läuft …":"Bestätigte Links speichern"}</button></section>
      <section className="mb-6 grid gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm md:grid-cols-[1fr_auto] md:items-end">
        <label className="block"><span className="mb-2 block text-sm font-medium">Kunden suchen</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Name, Telefonnummer, E-Mail oder Betreuer" className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-teal-600 focus:ring-2 focus:ring-teal-100" /></label>
        <p className="text-sm text-slate-500">Suche ab 2 Zeichen · höchstens 200 Treffer</p>
      </section>
      <div className="mb-4 flex flex-wrap items-center gap-3"><button type="button" aria-pressed={onlyDue} onClick={()=>setOnlyDue(!onlyDue)} className="rounded-xl border border-teal-300 bg-white px-4 py-2 text-sm font-medium text-teal-800">{onlyDue?"Alle Suchtreffer anzeigen":`Fällige Wiedervorlagen (${dueCustomers.length})`}</button><span className="text-xs text-slate-500">Bis {today} · Europe/Berlin · innerhalb der aktuellen Suchtreffer</span></div>
      <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4"><h2 className="font-semibold">Kundenbestand</h2><span className="text-sm text-slate-500">{loading ? "Lädt …" : `${visibleCustomers.length} angezeigt`}</span></div>
        {error ? <div className="p-6 text-sm text-rose-700">{error}</div> : loading && !customers.length ? <div className="p-6 text-sm text-slate-500">Kundendaten werden geladen …</div> : visibleCustomers.length === 0 ? <div className="p-6 text-sm text-slate-500">Keine passenden Kunden gefunden.</div> : <><div className="sm:hidden"><CustomerMobileList customers={visibleCustomers} onSelect={setSelectedCustomer}/></div><div className="hidden overflow-x-auto sm:block"><table className="w-full min-w-[850px] text-left text-sm"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr><th className="px-6 py-3">Kunde</th><th className="px-6 py-3">Telefon / E-Mail</th><th className="px-6 py-3">Betreuer</th><th className="px-6 py-3">Status</th><th className="px-6 py-3">Wiedervorlage</th><th className="px-6 py-3">OneDrive-Mappe</th></tr></thead><tbody>{visibleCustomers.map(c=><tr key={c.id} className="border-t border-slate-100 align-top"><td className="px-6 py-4 font-medium"><button type="button" onClick={()=>setSelectedCustomer(c)} className="text-left hover:text-teal-800 hover:underline focus:outline-none focus-visible:rounded focus-visible:ring-2 focus-visible:ring-teal-600" aria-label={`${c.first_name} ${c.last_name} öffnen`}>{c.first_name} {c.last_name}<span className="mt-1 block text-xs font-normal text-slate-400">CRM-ID {c.id}</span></button></td><td className="px-6 py-4 text-slate-600">{c.phone||"–"}<span className="mt-1 block text-xs">{c.email||"–"}</span></td><td className="px-6 py-4 text-slate-600">{c.adviser||"–"}</td><td className="px-6 py-4"><span className="rounded-full bg-teal-50 px-2.5 py-1 text-xs font-medium text-teal-800">{c.status}</span></td><td className="px-6 py-4 text-slate-600">{c.next_follow_up_at||"–"}{c.next_follow_up_note&&<span className="mt-1 block max-w-48 text-xs">{c.next_follow_up_note}</span>}</td><td className="px-6 py-4 text-slate-600">{c.folder_name||"–"}</td></tr>)}</tbody></table></div></>}
      </section>
      {selectedCustomer&&<div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)setSelectedCustomer(null);}}><section role="dialog" aria-modal="true" aria-labelledby="customer-detail-title" className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-semibold uppercase tracking-wide text-teal-700">Kundenprofil · CRM-ID {selectedCustomer.id}</p><h2 id="customer-detail-title" className="mt-1 text-xl font-semibold">{selectedCustomer.first_name} {selectedCustomer.last_name}</h2></div><button type="button" onClick={()=>setSelectedCustomer(null)} className="rounded-lg border border-slate-200 px-3 py-1.5 text-sm hover:bg-slate-50">Schließen</button></div><dl className="mt-6 grid gap-x-5 gap-y-4 sm:grid-cols-2"><div><dt className="text-xs text-slate-500">Telefon</dt><dd className="mt-1 text-sm">{selectedCustomer.phone||"–"}</dd></div><div><dt className="text-xs text-slate-500">E-Mail</dt><dd className="mt-1 text-sm">{selectedCustomer.email||"–"}</dd></div><div><dt className="text-xs text-slate-500">Geburtstag</dt><dd className="mt-1 text-sm">{selectedCustomer.birthday||"–"}</dd></div><div><dt className="text-xs text-slate-500">Vollmacht</dt><dd className="mt-1 text-sm">{selectedCustomer.authority_status}</dd></div><div><dt className="text-xs text-slate-500">Betreuer</dt><dd className="mt-1 text-sm">{selectedCustomer.adviser||"–"}</dd></div><div><dt className="text-xs text-slate-500">Status</dt><dd className="mt-1 text-sm">{selectedCustomer.status}</dd></div><div><dt className="text-xs text-slate-500">Letzter Kontakt</dt><dd className="mt-1 text-sm">{selectedCustomer.last_contact_at||"–"}</dd></div><div><dt className="text-xs text-slate-500">Wiedervorlage</dt><dd className="mt-1 text-sm">{selectedCustomer.next_follow_up_at||"–"}</dd></div><div className="sm:col-span-2"><dt className="text-xs text-slate-500">OneDrive-Kundenmappe</dt><dd className="mt-1 text-sm">{selectedCustomer.folder_name||"Kein bestätigter Ordner"}</dd>{selectedCustomer.folder_url?<a href={selectedCustomer.folder_url} target="_blank" rel="noreferrer" className="mt-2 inline-flex rounded-lg bg-teal-700 px-3 py-2 text-sm font-medium text-white hover:bg-teal-800">Mappe in OneDrive öffnen</a>:<p className="mt-2 text-sm text-amber-700">Der direkte Ordnerlink wird noch geprüft.</p>}</div>{selectedCustomer.next_follow_up_note&&<div className="sm:col-span-2"><dt className="text-xs text-slate-500">Wiedervorlage-Notiz</dt><dd className="mt-1 text-sm">{selectedCustomer.next_follow_up_note}</dd></div>}</dl><CustomerContracts key={selectedCustomer.id} customerId={selectedCustomer.id}/><CustomerDocuments key={selectedCustomer.id} customerId={selectedCustomer.id}/></section></div>}
      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-5"><h2 className="font-semibold">Kundendokumente</h2><p className="mt-2 text-sm text-slate-600">Das Kundenprofil zeigt separat gespeicherte Kratos-Dateien und zusätzliche OneDrive-Verweise. Ein OneDrive-Link bestätigt keine Kopie im Kratos-Speicher.</p><p className="mt-2 text-xs text-slate-500">Eine leere Dateiliste bedeutet nicht, dass die OneDrive-Kundenmappe leer ist. Der vollständige Import ist noch nicht abgeschlossen.</p></section>
      <p className="mt-5 text-xs leading-5 text-slate-500">Die OneDrive-Originale bleiben unverändert erhalten. Als geprüft gilt eine Kratos-Kopie erst nach dem Vergleich von Dateianzahl, Dateigrößen und SHA-256-Prüfsummen.</p>
    </div>
  </main>;
}
