"use client";

type Customer = { id:number; first_name:string; last_name:string; phone:string|null; email:string|null; adviser:string|null; status:string; folder_name:string|null; folder_url:string|null; next_follow_up_at:string|null; next_follow_up_note:string|null };

export function CustomerMobileList<T extends Customer>({customers,onSelect}:{customers:T[];onSelect:(customer:T)=>void}) {
  return <div className="space-y-3 p-4">
    {customers.map(customer=><article key={customer.id} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <button type="button" onClick={()=>onSelect(customer)} className="text-left font-semibold text-slate-900 hover:text-teal-800" aria-label={`${customer.first_name} ${customer.last_name} öffnen`}>
          {customer.first_name} {customer.last_name}<span className="mt-1 block text-xs font-normal text-slate-400">CRM-ID {customer.id}</span>
        </button>
        <span className="shrink-0 rounded-full bg-teal-50 px-2.5 py-1 text-xs font-medium text-teal-800">{customer.status}</span>
      </div>
      <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
        <div><dt className="text-xs text-slate-500">Telefon</dt><dd className="mt-1 break-words">{customer.phone||"–"}</dd></div>
        <div><dt className="text-xs text-slate-500">Betreuer</dt><dd className="mt-1 break-words">{customer.adviser||"–"}</dd></div>
        <div className="col-span-2"><dt className="text-xs text-slate-500">E-Mail</dt><dd className="mt-1 break-all">{customer.email||"–"}</dd></div>
        <div className="col-span-2"><dt className="text-xs text-slate-500">Wiedervorlage</dt><dd className="mt-1">{customer.next_follow_up_at||"–"}{customer.next_follow_up_note&&<span className="mt-1 block text-xs text-slate-600">{customer.next_follow_up_note}</span>}</dd></div>
      </dl>
      <div className="mt-4 flex items-center justify-between gap-3 border-t border-slate-100 pt-3 text-sm">
        <span className="truncate text-slate-600">{customer.folder_name||"Keine bestätigte Mappe"}</span>
        {customer.folder_url&&<a href={customer.folder_url} target="_blank" rel="noreferrer" className="shrink-0 text-teal-800 underline">Mappe öffnen</a>}
      </div>
    </article>)}
  </div>;
}
