"use client";

import { useEffect, useState } from "react";

type Contract = { id:number; insurance_type:string; provider:string|null; status:string; start_date:string|null; end_date:string|null; cancellation_deadline:string|null; document_url:string|null };

export function CustomerContracts({customerId}:{customerId:number}) {
  const [contracts,setContracts]=useState<Contract[]>([]),[error,setError]=useState(""),[loading,setLoading]=useState(true);
  useEffect(()=>{const controller=new AbortController();
    void (async()=>{try{const response=await fetch(`/api/contracts?customer_id=${customerId}`,{cache:"no-store",signal:controller.signal});const data=await response.json() as {contracts?:Contract[];error?:string};if(!response.ok)throw Error(data.error||"Verträge konnten nicht geladen werden.");setContracts(data.contracts??[]);}catch(e){if(!controller.signal.aborted)setError(e instanceof Error?e.message:"Ladefehler");}finally{if(!controller.signal.aborted)setLoading(false);}})();return()=>controller.abort();
  },[customerId]);
  return <section className="mt-6 border-t border-slate-200 pt-5"><h3 className="font-semibold">Verträge</h3>
    {loading?<p role="status" className="mt-3 text-sm text-slate-500">Verträge werden geladen …</p>:error?<p role="alert" className="mt-3 text-sm text-rose-700">{error}</p>:contracts.length?<ul className="mt-3 space-y-3">{contracts.map(contract=><li key={contract.id} className="rounded-xl border border-slate-200 p-4"><p className="font-medium">{contract.insurance_type}{contract.provider?` · ${contract.provider}`:""}</p><p className="mt-1 text-sm text-slate-600">Status: {contract.status}</p><dl className="mt-3 grid gap-2 text-sm sm:grid-cols-3"><div><dt className="text-xs text-slate-500">Beginn</dt><dd>{contract.start_date||"Unbekannt"}</dd></div><div><dt className="text-xs text-slate-500">Ablauf / Vertragsende</dt><dd>{contract.end_date||"Unbekannt"}</dd></div><div><dt className="text-xs text-slate-500">Kündigungsfrist bis</dt><dd>{contract.cancellation_deadline||"Unbekannt"}</dd></div></dl>{contract.document_url&&<a href={contract.document_url} target="_blank" rel="noreferrer" className="mt-3 inline-block text-sm text-teal-800 underline">Bestätigtes Dokument öffnen</a>}</li>)}</ul>:<p className="mt-3 text-sm text-slate-600">Noch keine strukturierten Vertragsdaten hinterlegt.</p>}
    <p className="mt-3 text-xs text-slate-500">Ablaufdatum und Kündigungsfrist werden getrennt geführt. Unbekannte Daten bleiben leer.</p>
  </section>;
}
