"use client";
import { useEffect, useState } from "react";

type StoredFile = { id: string; file_name: string; size_bytes: number; sha256: string | null; import_state: string; source_path: string | null };
export function CustomerStoredDocuments({ customerId }: { customerId: number }) {
  const [files, setFiles] = useState<StoredFile[]>([]), [query, setQuery] = useState(""), [search, setSearch] = useState(""), [offset, setOffset] = useState(0);
  const [more, setMore] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState(""), [revision, setRevision] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    void (async () => {
      try {
        setError("");
        const response = await fetch(`/api/storage/files?customer_id=${customerId}&q=${encodeURIComponent(search)}&limit=50&offset=${offset}`, { cache: "no-store", signal: controller.signal });
        const data = await response.json() as { files?: StoredFile[]; has_more?: boolean; error?: string };
        if (!response.ok) throw Error(data.error || "Kratos-Dateispeicher ist noch nicht verfügbar.");
        setFiles(data.files ?? []); setMore(Boolean(data.has_more));
      } catch (e) { if (!controller.signal.aborted) { setFiles([]); setError(e instanceof Error ? e.message : "Dateiliste konnte nicht geladen werden."); } }
    })();
    return () => controller.abort();
  }, [customerId, search, offset, revision]);
  async function upload(form: HTMLFormElement) {
    const input = form.elements.namedItem("file") as HTMLInputElement;
    const file = input.files?.[0]; if (!file) return;
    if (file.size > 20 * 1024 * 1024) { setError("Dieser direkte Upload ist auf 20 MiB begrenzt. Größere Dateien benötigen den wiederaufnehmbaren Import."); return; }
    setBusy(true); setError("");
    try {
      const data = new FormData(); data.set("file", file); data.set("customer_id", String(customerId));
      const response = await fetch("/api/storage/files", { method: "POST", body: data });
      const result = await response.json() as { error?: string }; if (!response.ok) throw Error(result.error || "Upload fehlgeschlagen.");
      form.reset(); setOffset(0); setRevision(value => value + 1);
    } catch (e) { setError(e instanceof Error ? e.message : "Upload fehlgeschlagen."); } finally { setBusy(false); }
  }
  return <section className="mt-6 border-t border-slate-200 pt-5"><h3 className="font-semibold">Im Kratos-Speicher abgelegte Dateien</h3>
    <form className="mt-3 flex gap-2" onSubmit={e => { e.preventDefault(); setOffset(0); setSearch(query); }}><input aria-label="Dateiname suchen" value={query} onChange={e => setQuery(e.target.value)} className="min-w-0 flex-1 rounded-lg border p-2" placeholder="Dateiname oder Originalpfad"/><button className="rounded-lg border px-3" type="submit">Suchen</button></form>
    {error && <p role="alert" className="mt-3 text-sm text-rose-700">{error}</p>}
    <ul className="mt-3 space-y-3">{files.map(file => <li key={file.id} className="rounded-lg border p-3"><a className="text-teal-800 underline" href={`/api/storage/files/${encodeURIComponent(file.id)}`}>{file.file_name}</a><p className="break-all text-xs text-slate-500">{file.source_path || "Direkter Upload"} · {file.size_bytes} Bytes · {file.import_state}</p><p className="break-all text-xs text-slate-500">SHA-256: {file.sha256 || "Noch nicht verifiziert"}</p></li>)}</ul>
    {!error && !files.length && <p className="mt-3 text-sm text-slate-600">Keine Dateien in dieser Auswahl. Dies ist kein Nachweis einer vollständigen Migration.</p>}
    <div className="mt-3 flex gap-2"><button disabled={!offset} onClick={() => setOffset(Math.max(0, offset - 50))} className="rounded border px-3 py-1 disabled:opacity-40">Zurück</button><button disabled={!more} onClick={() => setOffset(offset + 50)} className="rounded border px-3 py-1 disabled:opacity-40">Weiter</button></div>
    <form className="mt-4 space-y-2" onSubmit={e => { e.preventDefault(); void upload(e.currentTarget); }}><label className="block text-sm">Datei für diesen Kunden ablegen (bis 20 MiB)<input required name="file" type="file" className="mt-2 block w-full text-sm"/></label><button disabled={busy} className="rounded-lg bg-teal-700 px-3 py-2 text-sm text-white disabled:opacity-50">{busy ? "Wird gespeichert …" : "In Kratos speichern"}</button></form>
  </section>;
}
