"use client";
import { useEffect, useState } from "react";
import { CustomerStoredDocuments } from "./customer-stored-documents";
const categories=["Antrag","Vollmacht","Beratungsprotokoll","Vertrag","Schaden","Schriftverkehr","Sonstiges"];
type Document={id:number;category:string;file_name:string;file_url:string};
export function CustomerDocuments({customerId}:{customerId:number}) {
  const [documents,setDocuments]=useState<Document[]>([]),[category,setCategory]=useState(""),[error,setError]=useState(""),[loading,setLoading]=useState(true);
  useEffect(()=>{const controller=new AbortController();
    void (async()=>{try{const r=await fetch(`/api/documents?customer_id=${customerId}&category=${encodeURIComponent(category)}`,{cache:"no-store",signal:controller.signal});const data=await r.json() as {documents?:Document[];error?:string;message?:string};if(!r.ok)throw Error(data.error||data.message||"Dokumente konnten nicht geladen werden.");setDocuments(data.documents??[]);}catch(e){if(!controller.signal.aborted)setError(e instanceof Error?e.message:"Ladefehler");}finally{if(!controller.signal.aborted)setLoading(false);}})();return()=>controller.abort();
  },[customerId,category]);
  return <><CustomerStoredDocuments customerId={customerId}/><section className="mt-6 border-t border-slate-200 pt-5"><h3 className="font-semibold">Zusätzliche OneDrive-Verweise</h3><label className="mt-3 block text-sm">Dokumentart<select value={category} onChange={e=>{setLoading(true);setError("");setDocuments([]);setCategory(e.target.value);}} className="ml-3 rounded-lg border border-slate-300 p-2"><option value="">Alle</option>{categories.map(c=><option key={c}>{c}</option>)}</select></label>
    {loading?<p role="status" className="mt-3 text-sm">Dokumente werden geladen …</p>:error?<p role="alert" className="mt-3 text-sm text-rose-700">{error}</p>:documents.length?<ul className="mt-3 space-y-3">{documents.map(d=><li key={d.id}><a href={d.file_url} target="_blank" rel="noreferrer" className="text-sm text-teal-800 underline">{d.file_name}</a><span className="block text-xs text-slate-500">{d.category}</span></li>)}</ul>:<p className="mt-3 text-sm text-slate-600">Noch keine Dateien in dieser Auswahl registriert. In der OneDrive-Mappe können weitere Dokumente liegen.</p>}
    <p className="mt-4 text-xs leading-5 text-slate-500">Nach der Beratung: Dateien im Chat hochladen und „Für diesen Kunden getrennt ablegen“ schreiben. Kratos führt erfolgreich gespeicherte Dokumente hier auf. Unklare Zuordnungen werden zuerst geklärt.</p>
  </section></>;
}
