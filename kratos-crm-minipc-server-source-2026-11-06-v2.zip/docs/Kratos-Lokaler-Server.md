# Kratos: lokaler Leseserver

Stand 05.11.2026: implementiert und mit synthetischen SQLite-Daten getestet. Kein dauerhaft laufender Dienst, keine Installation auf dem Mini-PC und keine externe Verbindung damit nachgewiesen.

## Umfang

Der Node-HTTP-Server verwendet den vorhandenen Kratos-Toolservice und den nativen SQLite-Leseadapter. Er bindet ausschließlich an `127.0.0.1`, standardmäßig Port 8788. Er stellt `POST /mcp`, `POST /v1/tools/<name>`, `GET /openapi.json` und `GET /.well-known/oauth-protected-resource` bereit. Die Werkzeug-Allowlist umfasst Kundensuche, begrenzte Kundendetails, Wiedervorlagen und Dokumentmetadaten. Der separate HTTP-Abruf liefert auf ausdrückliche Aktivierung lokale Datei-Anhänge.

Die Datenbank muss bereits als lokale SQLite-Datei mit dem bestehenden Kratos-Schema vorliegen. Der Start erzeugt keine Datenbank, Migration oder Testdaten. Produktions-D1 ist damit weder exportiert noch übertragen.

## Konfiguration und Start

Im Projektordner mit installierten Abhängigkeiten und passender Node-Version starten:

```powershell
node scripts/start-kratos-local.mjs
```

Vorher folgende Prozess-Umgebungsvariablen aus einer geschützten Betreiberkonfiguration setzen; die CLI lädt keine `.env`-Datei automatisch:

| Variable | Bedeutung |
| --- | --- |
| `KRATOS_LOCAL_DB_PATH` | Absoluter Pfad zur vorhandenen lokalen SQLite-Datei; kein UNC-Pfad |
| `KRATOS_LOCAL_RESOURCE_ORIGIN` | Geplante kanonische HTTPS-Origin ohne Pfad und abschließenden Slash |
| `KRATOS_LOCAL_RESOURCE_URL` | Optional: exakt die Origin oder diese Origin mit `/mcp`; Standard ist die Origin |
| `KRATOS_LOCAL_AUTH_MODE` | `generic` (bisheriger Standard) oder ausdrücklich `entra` |
| `KRATOS_LOCAL_OAUTH_ISSUER` | Nur generic: exakte vertrauenswürdige HTTPS-Issuer-URL |
| `KRATOS_LOCAL_OAUTH_JWKS_URI` | Nur generic: fest konfigurierte HTTPS-Adresse öffentlicher Signaturschlüssel |
| `KRATOS_LOCAL_ALLOWED_SUBJECTS` | JSON-Array explizit freigegebener stabiler Benutzer-Subjects |
| `KRATOS_LOCAL_PORT` | Optional, 1–65535; Standard 8788 |

Keine Token oder privaten Schlüssel in Startbefehle, Logs oder Repository schreiben. Im Modus generic erwartet der Dienst signierte Access-Tokens mit `typ: at+jwt`, RS256/ES256, passendem Issuer und Audience gleich Resource-Origin, `sub`, `iat`, `exp`, maximal einer Stunde Laufzeit und `scope` mit `kratos:read`. Zusätzlich muss das Subject freigegeben sein. Ein Microsoft-Graph-Token erfüllt diese Voraussetzungen nicht automatisch. Der bestehende OneDrive-Import-Login ist kein Kratos-API-Login.

Für `KRATOS_LOCAL_AUTH_MODE=entra` zusätzlich setzen:

| Variable | Bedeutung |
| --- | --- |
| `KRATOS_LOCAL_ENTRA_TENANT_ID` | Freigegebene Mandanten-GUID |
| `KRATOS_LOCAL_ENTRA_API_CLIENT_ID` | Neue Kratos-API-Client-GUID, nicht OneDrive-Import-App |
| `KRATOS_LOCAL_ENTRA_ALLOWED_CLIENT_IDS` | JSON-Array freigegebener separater Client-App-GUIDs |
| `KRATOS_LOCAL_ALLOWED_SUBJECTS` | JSON-Array aus exakt `<Mandanten-GUID>:<Benutzer-Object-GUID>` |

Im Entra-Modus die generischen Issuer-/JWKS-Variablen entfernen. Im generischen Modus keine `KRATOS_LOCAL_ENTRA_*`-Variablen setzen. Gemischte Profile werden abgewiesen. Issuer und Schlüsseladresse werden im Entra-Modus aus dem festgelegten Mandanten abgeleitet. Der veröffentlichte Scope ist `<KRATOS_LOCAL_RESOURCE_URL>/kratos.read` beziehungsweise ohne optionale URL `<KRATOS_LOCAL_RESOURCE_ORIGIN>/kratos.read`; das Microsoft-Token muss zur API-GUID gehören und den delegierten `scp`-Wert `kratos.read` enthalten. Die interne Berechtigung bleibt `kratos:read`.

Die Ressourcen-URL wird ausschließlich aus dieser Betreiberkonfiguration übernommen. Es gibt keine automatische Ableitung aus Host-/Forwarded-Headern oder Client-Wünschen. Andere Pfade, fremde Origins, Query, Fragment oder zusätzliche abschließende Slashes werden abgewiesen. Bei `/mcp` verweist die OAuth-Challenge auf `/.well-known/oauth-protected-resource/mcp`; die Metadaten nennen die konfigurierte URL als `resource`. Die Root-Metadaten bleiben als Discovery-Einstieg verfügbar und beschreiben dieselbe konfigurierte Ressource. Im generischen Modus muss auch die Token-Audience exakt der ausgewählten Ressourcen-URL entsprechen. Im Entra-Modus bleibt sie die API-GUID.

Dieser auswählbare Modus ersetzt nicht die Registrierung und Benutzerzuweisung bei Microsoft. Konkreter Vorschlag und offene Client-/Resource-Fragen: [Microsoft-365-Anmeldung](Kratos-Microsoft-365-Anmeldung.md). Kein API-Schlüssel, Passwort oder OAuth-Client-Geheimnis ist für die serverseitige Tokenprüfung erforderlich.

Die Meldung `status: ready` belegt ausschließlich den geöffneten lokalen Listener. Sie bestätigt weder eine funktionierende OAuth-Anmeldung noch einen extern erreichbaren HTTPS-Zugang. Beenden mit Strg+C; der Server schließt Verbindungen begrenzt und gibt anschließend SQLite frei. Das generierte Bundle liegt im ignorierten Verzeichnis `.wrangler/kratos-local`.

## Transport und Betrieb

### Start und Restore gemeinsam proben

Im Projektverzeichnis genügt `node scripts/kratos-local-rehearsal.mjs`. Die Probe erstellt eine temporäre SQLite-Datenbank mit dem Kratos-Schema. Sie lädt eine synthetische Datei per signiertem HTTP-Aufruf hoch und prüft, dass eine Wiederholung dieselbe Datei-ID liefert. Danach sichert sie Datenbank und Objekt und stellt beide in einem neuen Verzeichnis wieder her. Ein temporärer Server auf einem freien Loopback-Port prüft den Zugriff auf die wiederhergestellte Datei mit einem kurzlebigen Testtoken.

Die Ausgabe enthält Status, Prüf-ID und Größenangaben. Der Testserver endet nach der Probe. Datenbank, Backup und Testobjekte werden aus dem eigens angelegten temporären Verzeichnis entfernt. Dieselbe Probe kann nach erfolgreichem SSH-Zugang auf dem Mini-PC ausgeführt werden.

### Lokale Dokumente abrufen

Der optionale Abruf verwendet `GET /v1/documents/<datei-id>` mit einem gültigen Bearer-Token. Der Server prüft die erlaubte Identität, Leseberechtigung und Kunden-ID. Er liefert den Anhang erst nach Prüfung der vollständigen Größe und SHA-256. Das Limit pro Datei beträgt 20 MiB. Zwei gleichzeitige Abrufe teilen sich die Kapazität.

| Einstellung | Wert |
| --- | --- |
| `KRATOS_LOCAL_DOCUMENTS_ENABLED` | `true` aktiviert den Abruf |
| `KRATOS_LOCAL_DOCUMENTS_ROOT` | Absoluter Pfad zum bestehenden privaten Dokumentenspeicher |
| `KRATOS_LOCAL_DOCUMENTS_CUSTOMER_IDS` | JSON-Array ausdrücklich erlaubter Kunden-IDs |

Die Dateiliste und Dateimetadaten liefern die numerische ID. Der Abruf verwendet die lokale SQLite-Datenbank und den zugehörigen Speicherordner. Ein Client muss Bearer-Authentifizierung und Binärantworten unterstützen. Für ChatGPT und Claude steht die Abnahme des tatsächlichen Connectors noch aus.

### Lokale Dokumente hochladen

Der separat aktivierbare Upload akzeptiert `POST /v1/documents/upload` mit `application/octet-stream` und höchstens 1 MiB. Der generische JWT-Modus verlangt den ausdrücklich gewährten Scope `kratos:documents:write`, eine erlaubte Identität und einen freigegebenen Kunden. Der Entra-Modus bleibt lesend.

| Einstellung | Wert |
| --- | --- |
| `KRATOS_LOCAL_DOCUMENT_UPLOADS_ENABLED` | `true` aktiviert den Upload |
| `KRATOS_LOCAL_DOCUMENT_UPLOADS_ROOT` | Absoluter Pfad zum bestehenden privaten Dokumentenspeicher |
| `KRATOS_LOCAL_DOCUMENT_UPLOADS_CUSTOMER_IDS` | JSON-Array ausdrücklich erlaubter Kunden-IDs |
| `KRATOS_LOCAL_DOCUMENT_UPLOADS_PRIVATE_ROOT_CONFIRMED` | `true` bestätigt den privat eingerichteten Speicherordner |

Mit jedem Aufruf übergibt der Client `X-Kratos-Customer-Id`, `X-Kratos-File-Name` als UTF-8 mit Prozentkodierung, `X-Kratos-Sha256` als 64 kleine Hex-Zeichen und einen `Idempotency-Key`. `X-Kratos-Folder-Id` ist optional und muss zum Kunden gehören. Der Schlüssel bindet die Wiederholung an dieselbe Identität und denselben Inhalt. Die erste Speicherung liefert HTTP 201, die verifizierte Wiederholung HTTP 200 mit derselben Datei-ID. Abweichende Inhalte oder Metadaten unter demselben Schlüssel ergeben HTTP 409.

Der Server prüft den Hash vor der Speicherung und prüft die gespeicherten Bytes erneut. Bei Abbruch oder Fristüberschreitung prüft er vor der Datenbankfreigabe, ob der Vorgang noch aktiv ist. Ein Abbruch nach einem bereits bestätigten Datenbank-Commit lässt sich mit demselben Schlüssel auflösen. Eine unvollständige Binärkopie kann als unreferenziertes Objekt im privaten Speicher verbleiben und wird im Backup-Bericht gesondert gezählt.

Anfragen müssen den tatsächlichen lokalen Host `127.0.0.1:<Port>` verwenden. Ein späterer HTTPS-Reverse-Proxy muss diesen Host explizit setzen; Forwarded-Header ändern die konfigurierte Resource-Origin nicht. Der Proxy ist noch nicht eingerichtet. Vor Veröffentlichung sind Domain, TLS, OAuth-Anbieter, Benutzerfreigabe und Schutz des Zielrechners konkret abzunehmen.

Der Server begrenzt gestreamte Anfragen auf 64 KiB, Antworten auf 1 MiB und Wartezeiten. Er protokolliert keine Dokumentinhalte oder Zugangsdaten. Betriebssystem-, Proxy- und Dienstlogs benötigen dieselbe Datenminimierung. Windows-Dienst/Autostart, Backup und Wiederherstellung sind separate offene Betriebsschritte. SSH-Fernwartung ersetzt weder API-Authentifizierung noch HTTPS.

## Nachweise und nächste Schritte

Synthetische Tests prüfen echten JWT-Signaturpfad, Benutzer-/Scopeabwehr, Tool-Aufruf, Host-Prüfung, chunked Größengrenze, Zeitlimit, Portkonflikt, begrenztes Herunterfahren, CLI-Konfigurationsfehler und SQLite-Schreibabwehr. Sie sind keine Live-Abnahme eines OAuth-Anbieters.

1. Mini-PC einmalig anhand des getrennten SSH-Pakets einrichten und Hostfingerprint prüfen.
2. OAuth-Anbieter und HTTPS-Adresse festlegen; Kompatibilität der konkreten Token vor Freigabe prüfen.
3. Geschützte lokale Datenbank, Backup und Restore mit synthetischen Daten abnehmen.
4. Erst danach produktive Datenübernahme und externe GPT-/Claude-Anbindung gesondert prüfen. Die vollständige Dokumentmigration bleibt ein eigener Auftrag mit Pilot- und Integritätsprüfung.
