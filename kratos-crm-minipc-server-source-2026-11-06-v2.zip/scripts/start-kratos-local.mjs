import { mkdir, writeFile } from "node:fs/promises";
import { build } from "esbuild";
import path from "node:path";
import { pathToFileURL } from "node:url";

function required(name) {
  const value = process.env[name];
  if (typeof value !== "string" || !value.trim()) throw new Error("missing_required_configuration");
  return value;
}

function configuration() {
  const authMode = process.env.KRATOS_LOCAL_AUTH_MODE ?? "generic";
  if (!["generic", "entra"].includes(authMode)) throw new Error("invalid_auth_mode");
  const databasePath = required("KRATOS_LOCAL_DB_PATH");
  if (!path.isAbsolute(databasePath) || databasePath.startsWith("\\\\")) throw new Error("invalid_database_path");
  const allowedSubjects = JSON.parse(required("KRATOS_LOCAL_ALLOWED_SUBJECTS"));
  if (!Array.isArray(allowedSubjects) || allowedSubjects.length < 1 || allowedSubjects.length > 20 || allowedSubjects.some((subject) => typeof subject !== "string" || !subject.trim() || subject.trim() !== subject || subject.length > 255)) throw new Error("invalid_subject_allowlist");
  const rawPort = process.env.KRATOS_LOCAL_PORT ?? "8788";
  if (!/^\d+$/.test(rawPort)) throw new Error("invalid_port");
  const port = Number(rawPort);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("invalid_port");
  const resourceOrigin = required("KRATOS_LOCAL_RESOURCE_ORIGIN");
  const origin = new URL(resourceOrigin);
  if (origin.protocol !== "https:" || resourceOrigin !== origin.origin || origin.username || origin.password) throw new Error("invalid_resource_origin");
  const resourceUrl = process.env.KRATOS_LOCAL_RESOURCE_URL ?? resourceOrigin;
  if (resourceUrl !== resourceOrigin && resourceUrl !== `${resourceOrigin}/mcp`) throw new Error("invalid_resource_url");
  let auth;
  if (authMode === "entra") {
    if (process.env.KRATOS_LOCAL_OAUTH_ISSUER !== undefined || process.env.KRATOS_LOCAL_OAUTH_JWKS_URI !== undefined) throw new Error("mixed_auth_profiles");
    const guid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
    const tenantId = required("KRATOS_LOCAL_ENTRA_TENANT_ID");
    const apiClientId = required("KRATOS_LOCAL_ENTRA_API_CLIENT_ID");
    const allowedClientIds = JSON.parse(required("KRATOS_LOCAL_ENTRA_ALLOWED_CLIENT_IDS"));
    if (!guid.test(tenantId) || !guid.test(apiClientId) || !Array.isArray(allowedClientIds) || allowedClientIds.length < 1 || allowedClientIds.length > 20 || allowedClientIds.some((id) => typeof id !== "string" || !guid.test(id) || id === apiClientId) || new Set(allowedClientIds).size !== allowedClientIds.length) throw new Error("invalid_entra_configuration");
    if (allowedSubjects.some((subject) => !subject.startsWith(tenantId + ":") || !guid.test(subject.slice(tenantId.length + 1)))) throw new Error("invalid_entra_subject");
    auth = { entra: { tenantId, apiClientId, allowedClientIds } };
  } else {
    if (Object.keys(process.env).some((key) => key.startsWith("KRATOS_LOCAL_ENTRA_"))) throw new Error("mixed_auth_profiles");
    const issuer = required("KRATOS_LOCAL_OAUTH_ISSUER"), jwksUri = required("KRATOS_LOCAL_OAUTH_JWKS_URI");
    for (const value of [issuer, jwksUri]) {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash || (url.port && url.port !== "443")) throw new Error("invalid_oauth_url");
    }
    auth = { issuer, jwksUri };
  }
  const rawCases = process.env.KRATOS_LOCAL_CASES_ENABLED ?? "false";
  if (!["true", "false"].includes(rawCases)) throw new Error("invalid_case_api_flag");
  let caseApi;
  if (rawCases === "true") {
    if (authMode !== "generic" || allowedSubjects.some((subject) => subject.length > 249)) throw new Error("unsupported_case_auth_profile");
    const rawWrites = required("KRATOS_LOCAL_CASES_WRITES_ENABLED");
    if (!["true", "false"].includes(rawWrites)) throw new Error("invalid_case_write_flag");
    const allowedCustomerIds = JSON.parse(required("KRATOS_LOCAL_CASES_CUSTOMER_IDS"));
    if (!Array.isArray(allowedCustomerIds) || allowedCustomerIds.length < 1 || allowedCustomerIds.length > 1000 || allowedCustomerIds.some((id) => !Number.isSafeInteger(id) || id < 1) || new Set(allowedCustomerIds).size !== allowedCustomerIds.length) throw new Error("invalid_case_customers");
    const todoistProjectId = process.env.KRATOS_LOCAL_CASES_TODOIST_PROJECT_ID;
    if (todoistProjectId !== undefined && (!todoistProjectId || todoistProjectId.trim() !== todoistProjectId || todoistProjectId.length > 255)) throw new Error("invalid_case_project");
    caseApi = { enableWrites: rawWrites === "true", allowedCustomerIds, ...(todoistProjectId !== undefined ? { todoistProjectId } : {}) };
  } else if (Object.keys(process.env).some((key) => key.startsWith("KRATOS_LOCAL_CASES_") && key !== "KRATOS_LOCAL_CASES_ENABLED")) throw new Error("disabled_case_api_configuration");
  const rawDocuments = process.env.KRATOS_LOCAL_DOCUMENTS_ENABLED ?? "false";
  if (!["true", "false"].includes(rawDocuments)) throw new Error("invalid_document_download_flag");
  let documentDownloads;
  if (rawDocuments === "true") {
    const root = required("KRATOS_LOCAL_DOCUMENTS_ROOT");
    if (!path.isAbsolute(root) || root.startsWith("\\\\")) throw new Error("invalid_document_root");
    const allowedCustomerIds = JSON.parse(required("KRATOS_LOCAL_DOCUMENTS_CUSTOMER_IDS"));
    if (!Array.isArray(allowedCustomerIds) || allowedCustomerIds.length < 1 || allowedCustomerIds.length > 1000 || allowedCustomerIds.some((id) => !Number.isSafeInteger(id) || id < 1) || new Set(allowedCustomerIds).size !== allowedCustomerIds.length) throw new Error("invalid_document_customers");
    documentDownloads = { root, allowedCustomerIds };
  } else if (Object.keys(process.env).some((key) => key.startsWith("KRATOS_LOCAL_DOCUMENTS_") && key !== "KRATOS_LOCAL_DOCUMENTS_ENABLED")) throw new Error("disabled_document_download_configuration");
  const rawUploads = process.env.KRATOS_LOCAL_DOCUMENT_UPLOADS_ENABLED ?? "false";
  if (!["true", "false"].includes(rawUploads)) throw new Error("invalid_document_upload_flag");
  let documentUploads;
  if (rawUploads === "true") {
    if (authMode !== "generic" || process.env.KRATOS_LOCAL_DOCUMENT_UPLOADS_PRIVATE_ROOT_CONFIRMED !== "true") throw new Error("invalid_document_upload_profile");
    const root = required("KRATOS_LOCAL_DOCUMENT_UPLOADS_ROOT");
    if (!path.isAbsolute(root) || root.startsWith("\\\\")) throw new Error("invalid_document_upload_root");
    const allowedCustomerIds = JSON.parse(required("KRATOS_LOCAL_DOCUMENT_UPLOADS_CUSTOMER_IDS"));
    if (!Array.isArray(allowedCustomerIds) || allowedCustomerIds.length < 1 || allowedCustomerIds.length > 1000 || allowedCustomerIds.some((id) => !Number.isSafeInteger(id) || id < 1) || new Set(allowedCustomerIds).size !== allowedCustomerIds.length) throw new Error("invalid_document_upload_customers");
    documentUploads = { root, allowedCustomerIds, privateRootConfirmed: true };
  } else if (Object.keys(process.env).some((key) => key.startsWith("KRATOS_LOCAL_DOCUMENT_UPLOADS_") && key !== "KRATOS_LOCAL_DOCUMENT_UPLOADS_ENABLED")) throw new Error("disabled_document_upload_configuration");
  return {
    databasePath,
    resourceOrigin,
    resourceUrl,
    ...auth,
    ...(caseApi ? { caseApi } : {}),
    ...(documentDownloads ? { documentDownloads } : {}),
    ...(documentUploads ? { documentUploads } : {}),
    allowedSubjects,
    port,
  };
}

async function main() {
  const config = configuration();
  const outputPath = path.resolve(".wrangler/kratos-local/server.mjs");
  await mkdir(path.dirname(outputPath), { recursive: true });
  const bundle = await build({ entryPoints: [path.resolve("integrations/kratos-local-server/server.ts")], bundle: true, platform: "node", format: "esm", write: false });
  await writeFile(outputPath, bundle.outputFiles[0].contents, { mode: 0o600 });
  const { createKratosLocalServer } = await import(pathToFileURL(outputPath).href + `?build=${Date.now()}`);
  const app = await createKratosLocalServer(config);
  const address = await app.listen();
  process.stdout.write(JSON.stringify({ status: "ready", host: address.address, port: address.port, transport: "loopback-http", read_only: config.caseApi?.enableWrites !== true && !config.documentUploads, case_api_enabled: Boolean(config.caseApi), document_downloads_enabled: Boolean(config.documentDownloads), document_uploads_enabled: Boolean(config.documentUploads), migration_or_seed: false }) + "\n");
  let closing = false;
  const close = async () => {
    if (closing) return;
    closing = true;
    try { await app.close(); process.exitCode = 0; }
    catch { process.stderr.write('{"error":"Kratos local server shutdown failed."}\n'); process.exitCode = 1; }
  };
  process.once("SIGINT", () => { void close(); });
  process.once("SIGTERM", () => { void close(); });
}

main().catch(() => {
  process.stderr.write('{"error":"Kratos local server failed to start. Check required local configuration."}\n');
  process.exitCode = 1;
});
