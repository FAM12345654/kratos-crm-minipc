import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { lstat, mkdir, open, writeFile, unlink } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { build } from 'esbuild';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const failure = () => { throw new Error('invalid_operator_configuration'); };
function required(name) { const value = process.env[name]; if (typeof value !== 'string' || !value.trim()) failure(); return value; }
function absolute(value) { if (typeof value !== 'string' || !path.isAbsolute(value) || value.startsWith('\\\\') || value.includes('\0')) failure(); return path.resolve(value); }
function parseArgs() {
 const command = process.argv[2];
 const allowed = { list: ['customer-id','folder-id','query','limit','offset'], upload: ['customer-id','folder-id','input','name','sha256','mime'], download: ['file-id','output'], backup: ['destination'], restore: ['backup','destination','manifest-sha256'] };
 if (!Object.hasOwn(allowed, command)) failure();
 const args = Object.create(null);
 for (let index = 3; index < process.argv.length; index += 2) {
  const flag = process.argv[index], value = process.argv[index + 1];
  if (!flag?.startsWith('--') || !allowed[command].includes(flag.slice(2)) || value === undefined || Object.hasOwn(args, flag.slice(2))) failure();
  args[flag.slice(2)] = value;
 }
 return { command, args };
}
function integer(value, minimum, maximum) { if (typeof value !== 'string' || !/^\d+$/.test(value)) failure(); const n = Number(value); if (!Number.isSafeInteger(n) || n < minimum || n > maximum) failure(); return n; }
function identity() {
 const ownerSubject = required('KRATOS_DOC_OWNER_SUBJECT'), actorId = required('KRATOS_DOC_ACTOR_ID');
 const allowedOwnerSubjects = JSON.parse(required('KRATOS_DOC_ALLOWED_OWNER_SUBJECTS'));
 const allowedCustomerIds = JSON.parse(required('KRATOS_DOC_ALLOWED_CUSTOMER_IDS'));
 if (!Array.isArray(allowedOwnerSubjects) || !allowedOwnerSubjects.length || allowedOwnerSubjects.length > 20 || allowedOwnerSubjects.some(x => typeof x !== 'string' || !x.trim() || x.length > 255) || !allowedOwnerSubjects.includes(ownerSubject) || ownerSubject.length > 255 || actorId.length > 255) failure();
 if (!Array.isArray(allowedCustomerIds) || allowedCustomerIds.length > 10000 || allowedCustomerIds.some(x => !Number.isSafeInteger(x) || x < 1) || new Set(allowedCustomerIds).size !== allowedCustomerIds.length) failure();
 if (process.env.KRATOS_DOC_PRIVATE_ROOT_CONFIRMED !== 'true') failure();
 const unassigned = process.env.KRATOS_DOC_ALLOW_UNASSIGNED;
 if (unassigned !== undefined && !['true','false'].includes(unassigned)) failure();
 return { ownerSubject, actorId, allowedOwnerSubjects, allowedCustomerIds, privateRootConfirmed: true, allowUnassigned: unassigned === 'true' };
}
async function checkedPath(value, kind) {
 const resolved = absolute(value); let current = path.parse(resolved).root;
 const pieces = resolved.slice(current.length).split(path.sep).filter(Boolean);
 if (!pieces.length && kind === 'file') failure();
 for (let index = 0; index < pieces.length; index++) {
  current = path.join(current, pieces[index]); const item = await lstat(current);
  if (item.isSymbolicLink() || (index < pieces.length - 1 && !item.isDirectory())) failure();
  if (index === pieces.length - 1 && (kind === 'file' ? !item.isFile() || item.nlink !== 1 : !item.isDirectory())) failure();
 }
 return resolved;
}
async function newTarget(value) {
 const target = absolute(value); await checkedPath(path.dirname(target), 'directory');
 try { await lstat(target); } catch (error) { if (error.code === 'ENOENT') return target; throw error; }
 failure();
}
async function configuration() {
 const { command, args } = parseArgs(), operator = identity();
 const config = { command, args, operator };
 if (command !== 'restore') {
  config.databasePath = await checkedPath(required('KRATOS_DOC_DB_PATH'), 'file');
  config.root = await checkedPath(required('KRATOS_DOC_ROOT'), 'directory');
 }
 if (command === 'upload' || command === 'list') {
  config.customerId = args['customer-id'] === 'null' ? null : integer(args['customer-id'], 1, Number.MAX_SAFE_INTEGER);
  if (config.customerId === null ? !operator.allowUnassigned : !operator.allowedCustomerIds.includes(config.customerId)) failure();
  if (args['folder-id'] !== undefined) config.folderId = args['folder-id'] === 'null' ? null : integer(args['folder-id'], 1, Number.MAX_SAFE_INTEGER);
 }
 if (command === 'list') {
  config.limit = integer(args.limit ?? '25', 1, 100); config.offset = integer(args.offset ?? '0', 0, 100000);
  if (args.query !== undefined && args.query.length > 255) failure();
 }
 if (command === 'upload') {
  config.input = await checkedPath(args.input, 'file');
  config.fileName = args.name ?? path.basename(config.input);
  if (!config.fileName.trim() || config.fileName.length > 255 || /[\\/\u0000-\u001f\u007f]/.test(config.fileName) || ['.','..'].includes(config.fileName)) failure();
  if (args.sha256 !== undefined && !/^[a-f0-9]{64}$/.test(args.sha256)) failure();
  if (args.mime !== undefined && (args.mime.length > 255 || !/^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/i.test(args.mime))) failure();
 }
 if (command === 'download') { if (process.env.KRATOS_DOC_PRIVATE_TARGET_CONFIRMED !== 'true') failure(); config.fileId = integer(args['file-id'], 1, Number.MAX_SAFE_INTEGER); config.output = await newTarget(args.output); }
 if (command === 'backup' || command === 'restore') {
  if (process.env.KRATOS_DOC_PRIVATE_TARGET_CONFIRMED !== 'true') failure();
  config.destination = await newTarget(args.destination);
  const noOverlap = source => { const a = path.resolve(source).toLowerCase(), b = config.destination.toLowerCase(); if (a === b || a.startsWith(b + path.sep) || b.startsWith(a + path.sep)) failure(); };
  if (command === 'backup') { noOverlap(config.root); noOverlap(config.databasePath); }
  if (command === 'restore') {
   config.backup = await checkedPath(args.backup, 'directory');
   noOverlap(config.backup);
   if (typeof args['manifest-sha256'] !== 'string' || !/^[a-f0-9]{64}$/.test(args['manifest-sha256'])) failure();
   await checkedPath(path.join(config.backup, 'manifest.json'), 'file');
  }
 }
 return config;
}
async function modules() {
 const runtime = path.join(project, '.wrangler', 'kratos-local-documents'); await mkdir(runtime, { recursive: true });
 const result = await build({ stdin: { contents: "export * from './lib/kratos-local-document-store'; export * from './lib/kratos-local-backup';", resolveDir: project }, bundle: true, platform: 'node', format: 'esm', write: false, logLevel: 'silent' });
 const target = path.join(runtime, randomUUID() + '.mjs'); await writeFile(target, result.outputFiles[0].contents, { flag: 'wx', mode: 0o600 });
 try { return await import(pathToFileURL(target).href); }
 finally { await unlink(target).catch(() => { /* Only this invocation's code artifact; retry cleanup later if locked. */ }); }
}
async function main() {
 const config = await configuration(); // No bundles or listeners exist before complete config/path validation.
 const { KratosLocalDocumentStore, createKratosLocalBackup, restoreKratosLocalBackup, hashKratosLocalFile } = await modules();
 let summary;
 if (config.command === 'backup') {
  summary = await createKratosLocalBackup({ databasePath: config.databasePath, documentRoot: config.root, destination: config.destination, privateTargetConfirmed: true });
 } else if (config.command === 'restore') {
  const result = await restoreKratosLocalBackup({ backupDirectory: config.backup, destination: config.destination, privateTargetConfirmed: true, expectedManifestSha256: config.args['manifest-sha256'] });
  summary = { files: result.files, bytes: result.bytes, verified: true };
 } else {
  const store = await KratosLocalDocumentStore.open({ ...config.operator, databasePath: config.databasePath, root: config.root });
  try {
   if (config.command === 'list') {
    const files = store.list(config.customerId, { folderId: config.folderId, query: config.args.query, limit: config.limit, offset: config.offset });
    summary = { count: files.length, files: files.map(file => ({ file_id: file.id, size_bytes: file.size_bytes, sha256: file.sha256 })) };
   } else if (config.command === 'upload') {
    const input = await lstat(config.input);
    if (!input.isFile() || input.isSymbolicLink() || input.nlink !== 1) failure();
    const source = await hashKratosLocalFile(config.input);
    if (config.args.sha256 !== undefined && config.args.sha256 !== source.sha256) failure();
    const bytes = createReadStream(config.input);
    try {
     const result = await store.upload({ customerId: config.customerId, folderId: config.folderId, fileName: config.fileName, mimeType: config.args.mime, expectedSize: source.size, expectedSha256: source.sha256 }, bytes);
     summary = { file_id: result.file.id, size_bytes: result.file.size_bytes, sha256: result.file.sha256, duplicate: result.duplicate };
    } finally { bytes.destroy(); }
   } else {
    const result = await store.read(config.fileId), output = await open(config.output, 'wx', 0o600);
    try {
     for await (const chunk of result.bytes) {
      let written = 0;
      while (written < chunk.length) { const part = await output.write(chunk, written, chunk.length - written); if (!part.bytesWritten) failure(); written += part.bytesWritten; }
     }
     await output.sync();
    } finally { await output.close(); }
    const checked = await hashKratosLocalFile(config.output);
    if (checked.size !== result.file.size_bytes || checked.sha256 !== result.file.sha256) failure();
    summary = { file_id: result.file.id, size_bytes: checked.size, sha256: checked.sha256, verified: true };
   }
  } finally { store.close(); }
 }
 process.stdout.write(JSON.stringify({ status: 'complete', command: config.command, ...summary }) + '\n');
}
main().catch(() => { process.stderr.write('{"error":"Kratos local document operation failed."}\n'); process.exitCode = 1; });
