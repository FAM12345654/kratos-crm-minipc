import test from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { mkdir, writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import { generateKeyPair, exportJWK, SignJWT } from 'jose';

const output=path.resolve('.wrangler/kratos-gateway-test/worker.mjs');
await mkdir(path.dirname(output),{recursive:true});
const bundled=await build({entryPoints:['integrations/kratos-gateway/worker.ts'],bundle:true,platform:'node',format:'esm',write:false});
await writeFile(output,bundled.outputFiles[0].contents);
const worker=(await import(pathToFileURL(output).href)).default;
const origin='https://gateway.kratos.invalid';
const issuer='https://login.kratos.invalid/';
const pair=await generateKeyPair('RS256');
const jwk=await exportJWK(pair.publicKey);jwk.kid='synthetic-key';
const request=(token,args={customer_id:7,fields:['status']},name='get_customer')=>new Request(origin+'/v1/tools/'+name,{
  method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(args),
});
async function token(claims={}) {
  const now=Math.floor(Date.now()/1000);
  return new SignJWT({iss:issuer,aud:origin,sub:'synthetic-owner',iat:now,exp:now+300,scope:'kratos:read',...claims})
    .setProtectedHeader({alg:'RS256',typ:'at+jwt',kid:'synthetic-key'}).sign(pair.privateKey);
}

test('unconfigured deployment denies all access',async()=>{
  const response=await worker.fetch(request(),{});
  assert.equal(response.status,503);
});
test('real JWT verifier and shared customer service work together without a real database',async()=>{
  let reads=0;
  const db={prepare(sql){
    assert.equal(sql,'SELECT id,status FROM customers WHERE id = ?');
    return {bind(id){assert.equal(id,7);return {async first(){reads++;return {id:7,status:'Kunde'};}};}};
  }};
  const env={DB:db,KRATOS_RESOURCE_ORIGIN:origin,KRATOS_OAUTH_ISSUER:issuer,KRATOS_OAUTH_JWKS_URI:issuer+'keys',KRATOS_ALLOWED_SUBJECTS:'["synthetic-owner"]'};
  const original=globalThis.fetch;
  globalThis.fetch=async(url,options)=>{
    assert.equal(String(url),issuer+'keys');assert.equal(options.redirect,'error');
    return Response.json({keys:[jwk]});
  };
  try{
    const missing=await worker.fetch(request(),env);assert.equal(missing.status,401);assert.equal(reads,0);
    const valid=await token();
    const good=await worker.fetch(request(valid),env);assert.equal(good.status,200);assert.deepEqual(await good.json(),{id:7,status:'Kunde'});assert.equal(reads,1);
    const wrongUser=await worker.fetch(request(await token({sub:'another-user'})),env);assert.equal(wrongUser.status,403);assert.equal(reads,1);
    const wrongAudience=await worker.fetch(request(await token({aud:'https://other.invalid'})),env);assert.equal(wrongAudience.status,401);assert.equal(reads,1);
    const write=await worker.fetch(request(valid,{customer_id:7,status:'Privat'},'update_customer'),env);assert.ok([403,404].includes(write.status));assert.equal(reads,1);
  }finally{globalThis.fetch=original;}
});
