import { createHash, randomUUID } from 'node:crypto';
import { lstat, realpath, readFile, writeFile, rename, unlink } from 'node:fs/promises';
import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

function fail(code) { const error = new Error(code); error.code = code; throw error; }
export async function directLocalPath(value, directory = false) {
  if (typeof value !== 'string' || !path.isAbsolute(value) || value.startsWith('\\\\')) fail('invalid_configuration');
  const resolved = path.resolve(value);
  for (let current = resolved; ; current = path.dirname(current)) {
    if ((await lstat(current)).isSymbolicLink()) fail('unsafe_path');
    if (path.dirname(current) === current) break;
  }
  const actual = await realpath(resolved);
  if ((process.platform === 'win32' ? actual.toLowerCase() !== resolved.toLowerCase() : actual !== resolved)) fail('unsafe_path');
  const info = await lstat(resolved);
  if (directory ? !info.isDirectory() : !info.isFile()) fail('unsafe_path');
  return resolved;
}

function reportDigest(report) {
  const payload = { ...report }; delete payload.checksum;
  return createHash('sha256').update(JSON.stringify(payload)).digest('hex');
}
export function verifyProcessReport(report) {
  return Boolean(report && report.schema_version === 1 && typeof report.checksum === 'string' && reportDigest(report) === report.checksum);
}

function gatewayConfiguration(value) {
  const url = new URL(value);
  if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1' || !url.port || value !== url.origin || url.username || url.password) fail('invalid_configuration');
  return url.origin;
}

export async function runKratosProcessCheck(config) {
  if (!config || (!config.databasePath && !config.gatewayUrl)) fail('invalid_configuration');
  const target = config.gatewayUrl ? gatewayConfiguration(config.gatewayUrl) : null;
  const reportDirectory = config.reportDirectory ? await directLocalPath(config.reportDirectory, true) : null;
  const started = Date.now();
  const checks = [];
  if (config.databasePath) {
    let database;
    try {
      const databasePath = await directLocalPath(config.databasePath);
      database = new DatabaseSync(databasePath, { readOnly: true });
      database.exec('PRAGMA busy_timeout=1000');
      const rows = database.prepare('PRAGMA quick_check(1)').all();
      if (rows.length !== 1 || Object.values(rows[0])[0] !== 'ok') fail('database_integrity_failed');
      if (!database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='customers'").get()) fail('database_schema_missing');
      if (database.prepare('PRAGMA foreign_key_check').get()) fail('database_integrity_failed');
      checks.push({ component: 'database', status: 'ok', code: 'database_readable_and_checked' });
    } catch (error) {
      const code = ['database_integrity_failed', 'database_schema_missing', 'unsafe_path'].includes(error.code) ? error.code : 'database_unavailable';
      checks.push({ component: 'database', status: 'failed', code });
    } finally { database?.close(); }
  } else checks.push({ component: 'database', status: 'not_configured', code: 'not_configured' });
  if (target) {
    try {
      const response = await fetch(target + '/mcp', {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}', redirect: 'error', signal: AbortSignal.timeout(3000),
      });
      const challenge = response.headers.get('www-authenticate') ?? '';
      await response.body?.cancel();
      if (response.status !== 401 || !/^Bearer /i.test(challenge) || !challenge.includes('resource_metadata=')) fail('gateway_auth_boundary_failed');
      checks.push({ component: 'gateway', status: 'ok', code: 'gateway_requires_authentication' });
    } catch (error) {
      checks.push({ component: 'gateway', status: 'failed', code: error.code === 'gateway_auth_boundary_failed' ? error.code : 'gateway_unavailable' });
    }
  } else checks.push({ component: 'gateway', status: 'not_configured', code: 'not_configured' });
  const report = {
    schema_version: 1, run_id: randomUUID(), checked_at: new Date().toISOString(), duration_ms: Date.now() - started,
    status: checks.some((check) => check.status === 'failed') ? 'failed' : checks.some((check) => check.status === 'not_configured') ? 'partial' : 'ok',
    checks, scope: 'technical_probe_only', checksum_kind: 'sha256_accidental_corruption_check',
  };
  report.checksum = reportDigest(report);
  if (reportDirectory) {
    // Reports contain only technical codes, IDs and time; never paths, query results or exception messages.
    await directLocalPath(reportDirectory, true);
    const runFile = path.join(reportDirectory, report.run_id + '.json');
    await writeFile(runFile, JSON.stringify(report) + '\n', { flag: 'wx', mode: 0o600 });
    const latest = path.join(reportDirectory, 'latest.json');
    try { if ((await lstat(latest)).isSymbolicLink()) fail('unsafe_path'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    const temporary = path.join(reportDirectory, '.' + report.run_id + '.tmp');
    try { await writeFile(temporary, JSON.stringify(report) + '\n', { flag: 'wx', mode: 0o600 }); await rename(temporary, latest); }
    finally { await unlink(temporary).catch((error) => { if (error.code !== 'ENOENT') throw error; }); }
  }
  return report;
}

async function main() {
  const args = process.argv.slice(2);
  if (args.some((argument) => !['--watch', '--status'].includes(argument)) || (args.includes('--watch') && args.includes('--status'))) fail('invalid_configuration');
  const watch = args.includes('--watch');
  const interval = Number(process.env.KRATOS_CHECK_INTERVAL_MS ?? 300000);
  if (!Number.isSafeInteger(interval) || interval < 30000 || interval > 86400000) fail('invalid_configuration');
  const config = {
    databasePath: process.env.KRATOS_CHECK_DB_PATH,
    gatewayUrl: process.env.KRATOS_CHECK_GATEWAY_URL,
    reportDirectory: process.env.KRATOS_CHECK_REPORT_DIRECTORY,
  };
  if (args.includes('--status')) {
    if (!config.reportDirectory) fail('invalid_configuration');
    const directory = await directLocalPath(config.reportDirectory, true);
    const report = await readVerifiedProcessReport(path.join(directory, 'latest.json'), { maxAgeMs: interval * 2 });
    process.stdout.write(JSON.stringify({ run_id: report.run_id, status: report.status, checks: report.checks }) + '\n');
    process.exitCode = report.status === 'failed' ? 1 : 0;
    return;
  }
  if (watch && !config.reportDirectory) fail('invalid_configuration');
  do {
    const report = await runKratosProcessCheck(config);
    process.stdout.write(JSON.stringify({ run_id: report.run_id, status: report.status, checks: report.checks }) + '\n');
    if (!watch) { process.exitCode = report.status === 'failed' ? 1 : 0; return; }
    await new Promise((resolve) => setTimeout(resolve, interval));
  } while (watch);
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main().catch(() => { process.stderr.write('{"error":"Kratos technical check failed. Check local configuration."}\n'); process.exitCode = 2; });
}

// Re-export for operators checking a retained report without executing probes.
export async function readVerifiedProcessReport(file, { maxAgeMs = 600000, now = Date.now() } = {}) {
  if (!Number.isSafeInteger(maxAgeMs) || maxAgeMs < 1 || !Number.isSafeInteger(now)) fail('invalid_configuration');
  const report = JSON.parse(await readFile(await directLocalPath(file), 'utf8'));
  if (!verifyProcessReport(report)) fail('report_integrity_failed');
  const checkedAt = Date.parse(report.checked_at);
  if (!Number.isFinite(checkedAt) || now - checkedAt > maxAgeMs || checkedAt > now + 30000) fail('report_stale');
  return report;
}
