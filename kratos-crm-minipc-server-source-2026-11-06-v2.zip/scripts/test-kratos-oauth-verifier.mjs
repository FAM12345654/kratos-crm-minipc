import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPair, exportJWK, createLocalJWKSet, SignJWT } from 'jose';
import { createKratosJwtVerifier, createKratosRemoteJwtVerifier } from '../lib/kratos-oauth-verifier.ts';

const issuer = 'https://login.kratos.invalid/';
const audience = 'https://api.kratos.invalid';
const { privateKey, publicKey } = await generateKeyPair('RS256');
const verificationKey = createLocalJWKSet({keys:[await exportJWK(publicKey)]});
const verify = createKratosJwtVerifier({issuer,audience,verificationKey});
const now = () => Math.floor(Date.now()/1000);
async function sign(overrides={}, header={alg:'RS256',typ:'at+jwt'}, key=privateKey) {
  return new SignJWT({iss:issuer,aud:audience,sub:'synthetic-owner',scope:'kratos:read',iat:now(),exp:now()+300,...overrides}).setProtectedHeader(header).sign(key);
}

test('valid signed access token returns stable subject and scopes',async()=>{
  assert.deepEqual(await verify(await sign()),{subject:'synthetic-owner',scopes:['kratos:read']});
});
test('rejects wrong issuer, audience, expiry, not-before, subject, scope and excessive lifetime',async()=>{
  for(const claims of [{iss:'https://evil.invalid'},{aud:'https://other.invalid'},{exp:now()-1},{nbf:now()+60},{sub:''},{scope:[]},{exp:now()+7200},{iat:now()-7200,exp:now()+300}]) {
    await assert.rejects(verify(await sign(claims)));
  }
  const noExpiry = await new SignJWT({iss:issuer,aud:audience,sub:'synthetic-owner',iat:now(),scope:'kratos:read'}).setProtectedHeader({alg:'RS256',typ:'at+jwt'}).sign(privateKey);
  await assert.rejects(verify(noExpiry));
});
test('rejects forged signatures, unsigned tokens and identity tokens',async()=>{
  const other=await generateKeyPair('RS256');
  await assert.rejects(verify(await sign({},undefined,other.privateKey)));
  await assert.rejects(verify('eyJhbGciOiJub25lIn0.eyJzdWIiOiJvd25lciJ9.'));
  await assert.rejects(verify(await sign({},{alg:'RS256',typ:'JWT'})));
});
test('configuration rejects unsafe or credential-bearing URLs before use',()=>{
  for(const jwksUri of ['http://localhost/keys','https://user:secret@keys.invalid/keys','https://keys.invalid/keys?token=x','https://keys.invalid:8443/keys']) {
    assert.throws(()=>createKratosRemoteJwtVerifier({issuer,audience,jwksUri}));
  }
  assert.throws(()=>createKratosJwtVerifier({issuer:'http://login.invalid',audience,verificationKey}));
});
