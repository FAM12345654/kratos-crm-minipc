import { Readable } from "node:stream";

const GRAPH_ORIGIN = "https://graph.microsoft.com";
const RETRYABLE = new Set([429, 500, 502, 503, 504]);
const DOWNLOAD_HOSTS = ["graph.microsoft.com", "sharepoint.com", "1drv.com", "onedrive.live.com"];

export class GraphSourceError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "GraphSourceError";
    this.code = code;
  }
}

function retryAfterMs(headers, now = Date.now()) {
  const value = headers?.get?.("retry-after");
  if (!value) return null;
  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds >= 0) return seconds * 1000;
  const time = Date.parse(value);
  return Number.isFinite(time) ? Math.max(0, time - now) : null;
}

function assertGraphUrl(value) {
  let url;
  try {
    url = new URL(value, GRAPH_ORIGIN);
  } catch {
    throw new GraphSourceError("unsafe_graph_url", "Rejected invalid Microsoft Graph URL.");
  }
  if (url.protocol !== "https:" || url.origin !== GRAPH_ORIGIN || url.username || url.password || !url.pathname.startsWith("/v1.0/")) {
    throw new GraphSourceError("unsafe_graph_url", "Rejected Microsoft Graph URL outside the approved Graph v1.0 origin.");
  }
  return url;
}

function allowedDownloadUrl(value, base) {
  let url;
  try {
    url = new URL(value, base);
  } catch {
    throw new GraphSourceError("unsafe_download_url", "Rejected invalid file download URL.");
  }
  const hostname = url.hostname.toLowerCase();
  const approved = DOWNLOAD_HOSTS.some((domain) => hostname === domain || hostname.endsWith("." + domain));
  if (url.protocol !== "https:" || (url.port && url.port !== "443") || !approved || url.username || url.password) {
    throw new GraphSourceError("unsafe_download_url", "Rejected file download URL outside the HTTPS Microsoft storage allowlist.");
  }
  return url;
}

export class GraphReadOnlySource {
  constructor({ accessToken, accessTokenProvider, expectedRootWebUrl, fetchImpl = fetch, sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)), random = Math.random, maxAttempts = 6, baseDelayMs = 500, requestTimeoutMs = 30000 } = {}) {
    if ((!accessToken || typeof accessToken !== "string") && typeof accessTokenProvider !== "function") throw new GraphSourceError("missing_token", "A Graph access token or in-memory access token provider is required for a live read-only import.");
    this.accessToken = accessToken;
    this.accessTokenProvider = accessTokenProvider;
    this.expectedRootWebUrl = expectedRootWebUrl;
    this.fetchImpl = fetchImpl;
    this.sleep = sleep;
    this.random = random;
    this.maxAttempts = maxAttempts;
    this.baseDelayMs = baseDelayMs;
    this.requestTimeoutMs = requestTimeoutMs;
  }

  async requestGraph(urlOrPath) {
    const url = assertGraphUrl(urlOrPath);
    const response = await this.#retry(async () => this.fetchImpl(url, {
      method: "GET",
      headers: { Authorization: "Bearer " + (this.accessTokenProvider ? await this.accessTokenProvider() : this.accessToken), Accept: "application/json" },
      redirect: "manual",
      signal: AbortSignal.timeout(this.requestTimeoutMs),
    }));
    if (response.status >= 300 && response.status < 400) throw new GraphSourceError("graph_redirect", "Microsoft Graph API redirected; the importer refuses to forward authorization.");
    if (!response.ok) throw new GraphSourceError("graph_http_" + response.status, "Microsoft Graph read failed with HTTP " + response.status + ".");
    return response.json();
  }

  async #retry(fetchRequest) {
    for (let attempt = 0; attempt < this.maxAttempts; attempt += 1) {
      let response;
      try {
        response = await fetchRequest();
      } catch {
        if (attempt + 1 >= this.maxAttempts) throw new GraphSourceError("network_error", "Microsoft Graph request failed after retry attempts.");
        await this.#wait(this.#backoff(attempt));
        continue;
      }
      if (!RETRYABLE.has(response.status)) return response;
      if (attempt + 1 >= this.maxAttempts) return response;
      const delay = retryAfterMs(response.headers) ?? this.#backoff(attempt);
      try { await response.body?.cancel?.(); } catch {}
      await this.#wait(delay);
    }
    throw new GraphSourceError("retry_exhausted", "Microsoft Graph retry limit exhausted.");
  }

  #backoff(attempt) {
    return Math.round(Math.min(30000, this.baseDelayMs * (2 ** attempt)) * (0.75 + this.random() * 0.5));
  }

  async #wait(milliseconds) {
    let remaining = milliseconds;
    while (remaining > 0) {
      const chunk = Math.min(remaining, 2147483647);
      await this.sleep(chunk);
      remaining -= chunk;
    }
  }

  async getItem(driveId, itemId) {
    const url = GRAPH_ORIGIN + "/v1.0/drives/" + encodeURIComponent(driveId) + "/items/" + encodeURIComponent(itemId);
    return this.requestGraph(url);
  }

  async verifyCustomerRoot(driveId, rootItemId) {
    const root = await this.getItem(driveId, rootItemId);
    if (!root.folder || root.name !== "Kunden" || root.deleted) throw new GraphSourceError("unverified_customer_root", "Configured Graph root must be the verified Kunden folder.");
    if (this.expectedRootWebUrl && !matchesExpectedRootWebUrl(root.webUrl ?? root.web_url, this.expectedRootWebUrl)) {
      throw new GraphSourceError("unverified_customer_root", "Graph root URL does not match the explicitly verified Kunden location.");
    }
    return root;
  }

  async snapshotDrive(driveId, rootItemId) {
    if (!rootItemId) throw new GraphSourceError("missing_customer_root", "A verified Kunden folder item ID is required; full-drive imports are disabled.");
    const url = GRAPH_ORIGIN + "/v1.0/drives/" + encodeURIComponent(driveId) + "/items/" + encodeURIComponent(rootItemId) + "/delta";
    const items = [];
    let next = url;
    let deltaLink = null;
    while (next) {
      const page = await this.requestGraph(next);
      if (!Array.isArray(page.value)) throw new GraphSourceError("invalid_delta_page", "Microsoft Graph delta response did not contain an item page.");
      items.push(...page.value);
      if (page["@odata.nextLink"]) next = assertGraphUrl(page["@odata.nextLink"]).href;
      else {
        deltaLink = page["@odata.deltaLink"] ? assertGraphUrl(page["@odata.deltaLink"]).href : null;
        next = null;
      }
    }
    if (!deltaLink) throw new GraphSourceError("incomplete_delta", "Initial drive delta did not return a final deltaLink; bulk import is blocked.");
    return { items, deltaLink, complete: true };
  }

  async changesSince(deltaLink) {
    let next = assertGraphUrl(deltaLink).href;
    const changes = [];
    let latestDeltaLink = null;
    while (next) {
      const page = await this.requestGraph(next);
      if (!Array.isArray(page.value)) throw new GraphSourceError("invalid_delta_page", "Microsoft Graph delta response did not contain an item page.");
      changes.push(...page.value);
      if (page["@odata.nextLink"]) next = assertGraphUrl(page["@odata.nextLink"]).href;
      else {
        latestDeltaLink = page["@odata.deltaLink"] ? assertGraphUrl(page["@odata.deltaLink"]).href : null;
        next = null;
      }
    }
    if (!latestDeltaLink) throw new GraphSourceError("incomplete_delta", "Change reconciliation did not return a final deltaLink.");
    return { changes, deltaLink: latestDeltaLink, complete: true };
  }

  async *walkRecursive({ driveId, rootItemId }) {
    if (!rootItemId) throw new GraphSourceError("missing_customer_root", "A verified Kunden folder item ID is required; full-drive imports are disabled.");
    const stack = [{ parentId: rootItemId, relativeSegments: [] }];
    const visitedFolders = new Set();
    while (stack.length) {
      const folder = stack.pop();
      const folderKey = folder.parentId || "root";
      if (visitedFolders.has(folderKey)) continue;
      visitedFolders.add(folderKey);
      const base = GRAPH_ORIGIN + "/v1.0/drives/" + encodeURIComponent(driveId) + "/items/" + encodeURIComponent(folder.parentId) + "/children";
      let next = base;
      while (next) {
        const page = await this.requestGraph(next);
        if (!Array.isArray(page.value)) throw new GraphSourceError("invalid_children_page", "Microsoft Graph children response did not contain an item page.");
        const folders = [];
        for (const item of page.value) {
          const relativeSegments = [...folder.relativeSegments, item.name];
          const relativePath = relativeSegments.join("/");
          yield { item, relativePath, relativeSegments };
          if (item.folder && !item.remoteItem) folders.push({ parentId: item.id, relativeSegments });
        }
        for (let index = folders.length - 1; index >= 0; index -= 1) stack.push(folders[index]);
        next = page["@odata.nextLink"] ? assertGraphUrl(page["@odata.nextLink"]).href : null;
      }
    }
  }

  async downloadContent(driveId, itemId) {
    const url = assertGraphUrl(GRAPH_ORIGIN + "/v1.0/drives/" + encodeURIComponent(driveId) + "/items/" + encodeURIComponent(itemId) + "/content");
    const response = await this.#retry(async () => this.fetchImpl(url, {
      method: "GET",
      headers: { Authorization: "Bearer " + (this.accessTokenProvider ? await this.accessTokenProvider() : this.accessToken) },
      redirect: "manual",
      signal: AbortSignal.timeout(this.requestTimeoutMs),
    }));
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get("location");
      if (!location) throw new GraphSourceError("missing_download_location", "Microsoft Graph content response did not include a download location.");
        try { await response.body?.cancel?.(); } catch {}
        return this.#downloadRedirect(location, url.href);
    }
    if (!response.ok || !response.body) throw new GraphSourceError("download_http_" + response.status, "Microsoft Graph file download failed with HTTP " + response.status + ".");
    return Readable.fromWeb(response.body);
  }

  async #downloadRedirect(firstUrl, baseUrl) {
    let url = allowedDownloadUrl(firstUrl, baseUrl);
    for (let redirects = 0; redirects <= 5; redirects += 1) {
      const response = await this.#retry(() => this.fetchImpl(url, { method: "GET", redirect: "manual", signal: AbortSignal.timeout(this.requestTimeoutMs) }));
      if (response.status >= 300 && response.status < 400) {
        if (redirects === 5) throw new GraphSourceError("download_redirect_limit", "File download redirect limit exceeded.");
        const location = response.headers.get("location");
        if (!location) throw new GraphSourceError("missing_redirect_location", "File download redirect omitted its destination.");
        try { await response.body?.cancel?.(); } catch {}
        url = allowedDownloadUrl(location, url.href);
        continue;
      }
      if (!response.ok || !response.body) throw new GraphSourceError("download_http_" + response.status, "File download failed with HTTP " + response.status + ".");
      return Readable.fromWeb(response.body);
    }
    throw new GraphSourceError("download_redirect_limit", "File download redirect limit exceeded.");
  }
}

export const graphUrlPolicy = { assertGraphUrl, allowedDownloadUrl, retryAfterMs };

export function matchesExpectedRootWebUrl(value, expected) {
  try {
    const actual = new URL(value);
    const target = new URL(expected);
    const decodePath = (pathname) => pathname.split("/").map((segment) => decodeURIComponent(segment)).join("/");
    return actual.protocol === "https:" && actual.username === "" && actual.password === "" &&
      actual.hostname.toLowerCase() === target.hostname.toLowerCase() &&
      actual.port === "" && actual.search === "" && actual.hash === "" &&
      decodePath(actual.pathname) === decodePath(target.pathname);
  } catch {
    return false;
  }
}
