import { createHash, randomUUID } from "node:crypto";
import { createReadStream, createWriteStream } from "node:fs";
import { chmod, link, lstat, mkdir, realpath, stat, unlink } from "node:fs/promises";
import path from "node:path";
import { Transform } from "node:stream";
import { pipeline } from "node:stream/promises";

export function safeRelativeKey(value) {
  if (typeof value !== "string" || !value || value.includes("\\") || value.startsWith("/") || /^[A-Za-z]:/.test(value)) {
    throw new Error("Unsafe destination key.");
  }
  const parts = value.split("/");
  if (parts.some((part) => !part || part === "." || part === "..")) throw new Error("Unsafe destination key.");
  if (parts.some((part) => /[\u0000-\u001f<>:\"|?*]/.test(part) || /[. ]$/.test(part) || /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$/i.test(part))) {
    throw new Error("Destination key contains a path segment that must be reversibly encoded first.");
  }
  return parts.join(path.sep);
}

function percentEncodeCharacter(character) {
  return Array.from(Buffer.from(character, "utf8"), (byte) => "%" + byte.toString(16).padStart(2, "0").toUpperCase()).join("");
}

export function encodePathSegment(value) {
  if (typeof value !== "string" || !value || value === "." || value === "..") throw new Error("Unsafe source path segment.");
  let encoded = Array.from(value, (character) => /[\u0000-\u001f<>:\"|?*%/\\]/.test(character) ? percentEncodeCharacter(character) : character).join("");
  while (/[. ]$/.test(encoded)) {
    const characters = Array.from(encoded);
    encoded = characters.slice(0, -1).join("") + percentEncodeCharacter(characters.at(-1));
  }
  if (/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$/i.test(encoded)) {
    const characters = Array.from(encoded);
    encoded = percentEncodeCharacter(characters[0]) + characters.slice(1).join("");
  }
  return encoded;
}

export async function streamToFileAndHash(readable, filePath) {
  const hash = createHash("sha256");
  let sizeBytes = 0;
  const meter = new Transform({
    transform(chunk, _encoding, callback) {
      hash.update(chunk);
      sizeBytes += chunk.length;
      callback(null, chunk);
    },
  });
  const output = createWriteStream(filePath, { flags: "wx", mode: 0o600 });
  let created = false;
  output.once("open", () => { created = true; });
  try {
    await pipeline(readable, meter, output);
  } catch (error) {
    if (created) await unlink(filePath).catch(() => {});
    throw error;
  }
  return { sha256: hash.digest("hex"), sizeBytes };
}

export async function hashFile(filePath) {
  const hash = createHash("sha256");
  let sizeBytes = 0;
  for await (const chunk of createReadStream(filePath)) {
    hash.update(chunk);
    sizeBytes += chunk.length;
  }
  return { sha256: hash.digest("hex"), sizeBytes };
}

export class LocalStagingDestination {
  constructor(rootDirectory) {
    if (!rootDirectory || !path.isAbsolute(rootDirectory)) throw new Error("Staging directory must be an absolute path.");
    this.rootDirectory = path.resolve(rootDirectory);
    this.temporaryDirectory = path.join(this.rootDirectory, ".temporary");
    this.kind = "local-staging";
    this.aclVerified = process.platform !== "win32";
  }

  async initialize() {
    // Check the nearest existing ancestor before mkdir can traverse a junction.
    let ancestor = this.rootDirectory;
    for (;;) {
      try {
        const info = await lstat(ancestor);
        const actual = await realpath(ancestor);
        const equal = process.platform === "win32" ? actual.toLowerCase() === ancestor.toLowerCase() : actual === ancestor;
        if (!info.isDirectory() || info.isSymbolicLink() || !equal) throw new Error("Staging root traverses a symbolic link or junction; choose a direct private directory.");
        break;
      } catch (error) {
        const parent = path.dirname(ancestor);
        if (error?.code !== "ENOENT" || parent === ancestor) throw error;
        ancestor = parent;
      }
    }
    await mkdir(this.rootDirectory, { recursive: true, mode: 0o700 });
    await mkdir(this.temporaryDirectory, { recursive: true, mode: 0o700 });
    const [rootStat, tempStat] = await Promise.all([lstat(this.rootDirectory), lstat(this.temporaryDirectory)]);
    if (!rootStat.isDirectory() || !tempStat.isDirectory() || rootStat.isSymbolicLink() || tempStat.isSymbolicLink()) throw new Error("Staging directories must not be symbolic links.");
    const requestedRoot = path.resolve(this.rootDirectory);
    const actualRoot = await realpath(this.rootDirectory);
    const sameRoot = process.platform === "win32" ? requestedRoot.toLowerCase() === actualRoot.toLowerCase() : requestedRoot === actualRoot;
    if (!sameRoot) throw new Error("Staging root traverses a symbolic link or junction; choose a direct private directory.");
    if (process.platform !== "win32") {
      await chmod(this.rootDirectory, 0o700);
      await chmod(this.temporaryDirectory, 0o700);
    }
    this.rootDirectory = actualRoot;
    this.temporaryDirectory = path.join(this.rootDirectory, ".temporary");
    return { rootDirectory: this.rootDirectory, aclVerified: this.aclVerified };
  }

  async createTempStream(sourceKey, readable) {
    const name = createHash("sha256").update(sourceKey).digest("hex") + "." + randomUUID() + ".part";
    const filePath = path.join(this.temporaryDirectory, name);
    const result = await streamToFileAndHash(readable, filePath);
    return { filePath, ...result };
  }

  targetPath(key) {
    const relative = safeRelativeKey(key);
    const target = path.resolve(this.rootDirectory, relative);
    if (!target.startsWith(this.rootDirectory + path.sep)) throw new Error("Destination path escapes the staging root.");
    return target;
  }

  async #ensureParent(target) {
    const parent = path.dirname(target);
    const relative = path.relative(this.rootDirectory, parent);
    let cursor = this.rootDirectory;
    for (const part of relative.split(path.sep).filter(Boolean)) {
      cursor = path.join(cursor, part);
      let info;
      try {
        info = await lstat(cursor);
      } catch (error) {
        if (error?.code !== "ENOENT") throw error;
        await mkdir(cursor, { mode: 0o700 });
        info = await lstat(cursor);
      }
      if (!info.isDirectory() || info.isSymbolicLink()) throw new Error("Destination parent is not a private directory.");
      if (process.platform !== "win32") await chmod(cursor, 0o700);
    }
  }

  async exists(key) {
    try {
      const info = await lstat(this.targetPath(key));
      return info.isFile() && !info.isSymbolicLink();
    } catch (error) {
      if (error?.code === "ENOENT") return false;
      throw error;
    }
  }

  async ensureFolder(key) {
    const target = this.targetPath(key);
    await this.#ensureParent(target);
    try {
      await mkdir(target, { mode: 0o700 });
      if (process.platform !== "win32") await chmod(target, 0o700);
      return { created: true, folderId: key };
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      const info = await lstat(target);
      if (!info.isDirectory() || info.isSymbolicLink()) throw new Error("Folder target conflicts with a non-directory item.");
      return { created: false, folderId: key };
    }
  }

  async verify(key) {
    const target = this.targetPath(key);
    const info = await lstat(target);
    if (!info.isFile() || info.isSymbolicLink()) throw new Error("Existing target is not a regular file.");
    return hashFile(target);
  }

  async commitExclusive(tempFilePath, key) {
    const target = this.targetPath(key);
    await this.#ensureParent(target);
    try {
      await link(tempFilePath, target);
    } catch (error) {
      if (error?.code === "EEXIST") return { created: false, conflict: true };
      throw error;
    }
    if (process.platform !== "win32") await chmod(target, 0o600);
    const targetInfo = await stat(target);
    const stagedInfo = await stat(tempFilePath);
    if (targetInfo.ino !== stagedInfo.ino) throw new Error("Exclusive target verification failed.");
    return { created: true, ...(await hashFile(target)) };
  }

  async cleanupTemp(tempFilePath) {
    const resolved = path.resolve(tempFilePath);
    if (!resolved.startsWith(this.temporaryDirectory + path.sep) || !resolved.endsWith(".part")) throw new Error("Refusing to clean a path outside the private temporary directory.");
    await unlink(resolved).catch((error) => { if (error?.code !== "ENOENT") throw error; });
  }

  async checkTargetHash(key) {
    if (!(await this.exists(key))) return null;
    return this.verify(key);
  }
}
