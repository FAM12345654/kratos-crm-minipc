import { createReadStream } from "node:fs";
import { lstat, realpath } from "node:fs/promises";
import path from "node:path";
import { LocalStagingDestination } from "./local-staging.mjs";

/** Programmatic pilot destination. The caller owns the authenticated local store. */
export class KratosLocalImportDestination {
  kind = "kratos-local";
  #store;
  #staging;
  #temporary = new Map();

  constructor({ store, stagingDirectory }) {
    this.#store = store;
    this.#staging = new LocalStagingDestination(stagingDirectory);
  }

  async initialize() {
    const projectId = await this.#store.importIdentity();
    return { ...(await this.#staging.initialize()), projectId };
  }

  async ensureFolder(_key, metadata) {
    if (metadata.customer_id == null) return { unresolved: true };
    return { folderId: this.#store.resolveImportFolder(metadata.customer_id, Number(metadata.folder_id), metadata.folder_segments, true) };
  }

  // Conflicts are resolved by the store's unique drive/item/version key.
  async exists() { return false; }

  async createTempStream(sourceKey, bytes) {
    const temp = await this.#staging.createTempStream(sourceKey, bytes);
    this.#temporary.set(temp.filePath, temp);
    return temp;
  }

  async cleanupTemp(filePath) {
    if (!this.#temporary.has(filePath)) throw new Error("Unknown private import temporary file.");
    await this.#assertDirectPath(path.dirname(filePath));
    await this.#staging.cleanupTemp(filePath);
    this.#temporary.delete(filePath);
  }

  async #assertDirectPath(filePath) {
    const canonical = await realpath(filePath);
    const comparable = (value) => process.platform === "win32" ? value.toLowerCase() : value;
    if (comparable(canonical) !== comparable(filePath)) throw new Error("Invalid private import temporary path.");
  }

  async commitExclusive(filePath, _key, metadata) {
    if (metadata.customer_id == null) return { created: false };
    const staged = this.#temporary.get(filePath);
    if (!staged || staged.sha256 !== metadata.source_sha256) throw new Error("Unknown private import temporary file.");
    await this.#assertDirectPath(filePath);
    const info = await lstat(filePath);
    if (!info.isFile() || info.isSymbolicLink() || info.nlink !== 1 || info.size !== staged.sizeBytes) throw new Error("Invalid private import temporary file.");
    const folderId = this.#store.resolveImportFolder(metadata.customer_id, Number(metadata.folder_id), metadata.folder_segments, true);
    const bytes = createReadStream(filePath);
    try {
      const { file, duplicate } = await this.#store.upload({
        customerId: metadata.customer_id,
        folderId,
        fileName: metadata.file_name,
        mimeType: metadata.mime_type,
        expectedSize: staged.sizeBytes,
        expectedSha256: staged.sha256,
        source: {
          driveId: metadata.source_drive_id, itemId: metadata.source_item_id, version: metadata.source_version,
          path: metadata.source_path, sha256: staged.sha256, createdAt: metadata.source_created_at ?? undefined, modifiedAt: metadata.source_modified_at ?? undefined,
        },
      }, bytes);
      return { created: !duplicate, duplicate, destinationId: file.id, destinationFolderId: folderId, destinationKind: this.kind, sha256: file.sha256, sizeBytes: file.size_bytes };
    } finally {
      bytes.destroy();
    }
  }

  async checkTargetHash(_key, { destinationId, previous, driveId, item, customerId, baseFolderId, folderSegments, relativePath, expectedSha256 }) {
    const folderId = this.#store.resolveImportFolder(customerId, Number(baseFolderId), folderSegments);
    if (folderId === null) return null;
    const file = await this.#store.verifyImportedFile(destinationId ?? previous.destination_id, customerId, folderId, item.name, {
      driveId: String(driveId), itemId: String(item.id), version: item.eTag, path: relativePath, sha256: expectedSha256,
    }, item.size);
    return file ? { sha256: file.sha256, sizeBytes: file.size_bytes, customer_id: file.customer_id, folder_id: file.folder_id } : null;
  }
}
