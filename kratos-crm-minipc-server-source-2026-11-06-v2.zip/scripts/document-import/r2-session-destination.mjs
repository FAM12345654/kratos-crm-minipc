import { createHash } from "node:crypto";
import { open, readFile } from "node:fs/promises";
import { Readable } from "node:stream";

const MAX_PART_BYTES = 20 * 1024 * 1024;

export class KratosStorageError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "KratosStorageError";
    this.code = code;
  }
}

export class KratosR2SessionDestination {
  constructor({ baseUrl, expectedProjectId, authHeaders, localStaging, fetchImpl = fetch, timeoutMs = 30000 } = {}) {
    if (!baseUrl || !expectedProjectId || typeof authHeaders !== "function" || !localStaging) throw new KratosStorageError("missing_session_auth", "R2 destination requires an approved Sites project ID, base URL, private local staging, and an injected authenticated Site session provider.");
    const parsed = new URL(baseUrl);
    if (parsed.protocol !== "https:" && !(parsed.protocol === "http:" && ["127.0.0.1", "localhost"].includes(parsed.hostname))) {
      throw new KratosStorageError("unsafe_storage_origin", "Kratos storage endpoint must use HTTPS (HTTP is allowed only on loopback for synthetic tests).");
    }
    this.baseUrl = parsed.origin;
    this.authHeaders = authHeaders;
    this.expectedProjectId = String(expectedProjectId);
    this.localStaging = localStaging;
    this.fetchImpl = fetchImpl;
    this.timeoutMs = timeoutMs;
    this.kind = "kratos-r2";
    this.aclVerified = true;
  }

  async initialize() {
    const staging = await this.localStaging.initialize();
    const response = await this.#request("/api/storage/status");
    const status = await response.json();
    if (String(status.project_id) !== this.expectedProjectId || status.storage !== "r2" || status.configured !== true) {
      throw new KratosStorageError("storage_target_mismatch", "Authenticated storage status does not match the explicitly approved Kratos project and R2 target.");
    }
    this.storageLimits = status;
    return { destination: "kratos-r2", aclVerified: staging.aclVerified, projectId: status.project_id };
  }

  async createTempStream(sourceKey, readable) {
    return this.localStaging.createTempStream(sourceKey, readable);
  }

  async cleanupTemp(filePath) {
    return this.localStaging.cleanupTemp(filePath);
  }

  #url(route) {
    const url = new URL(route, this.baseUrl);
    if (url.origin !== this.baseUrl || url.protocol !== new URL(this.baseUrl).protocol) throw new KratosStorageError("unsafe_storage_url", "Rejected storage URL outside the configured Kratos origin.");
    return url;
  }

  async #request(route, { method = "GET", headers = {}, body } = {}) {
    const url = this.#url(route);
    const sessionHeaders = await this.authHeaders();
    if (!sessionHeaders || typeof sessionHeaders !== "object") throw new KratosStorageError("missing_session_auth", "Approved Site session did not provide authenticated request headers.");
    if (Object.keys(sessionHeaders).some((key) => key.toLowerCase().startsWith("oai-authenticated-user-"))) throw new KratosStorageError("spoofed_site_identity", "Do not spoof Sites-injected identity headers from the standalone importer.");
    const suppliedOrigin = Object.entries(sessionHeaders).find(([key]) => key.toLowerCase() === "origin")?.[1];
    if (suppliedOrigin && String(suppliedOrigin) !== this.baseUrl) throw new KratosStorageError("origin_mismatch", "Authenticated Site session Origin does not match the approved storage host.");
    const originHeaders = method === "GET" || method === "HEAD" ? {} : { Origin: this.baseUrl };
    const response = await this.fetchImpl(url, {
      method,
      headers: { ...sessionHeaders, ...originHeaders, ...headers },
      body,
      redirect: "manual",
      signal: AbortSignal.timeout(this.timeoutMs),
    });
    if (response.status >= 300 && response.status < 400) {
      try { await response.body?.cancel?.(); } catch {}
      throw new KratosStorageError("storage_redirect", "Kratos storage request redirected; authentication was not forwarded.");
    }
    if (!response.ok) {
      try { await response.body?.cancel?.(); } catch {}
      throw new KratosStorageError("storage_http_" + response.status, "Kratos storage request failed with HTTP " + response.status + ".");
    }
    return response;
  }

  async exists(key, context = {}) {
    // The server's source_drive_id/source_item_id/source_version uniqueness makes complete idempotent.
    // Do not guess a target from a path or perform an unbounded metadata scan.
    if (String(key).startsWith("quarantine/") || context.previous?.destination_kind === "local-staging") return this.localStaging.exists(key);
    return false;
  }

  async checkTargetHash(_key, context = {}) {
    if (context.destinationKind === "local-staging" || context.previous?.destination_kind === "local-staging") return this.localStaging.checkTargetHash(_key);
    const id = context.destinationId ?? context.previous?.destination_id;
    if (!id) return null;
    const response = await this.#request("/api/storage/files/" + encodeURIComponent(id) + "/metadata");
    const metadata = await response.json();
    const fileResponse = await this.#request("/api/storage/files/" + encodeURIComponent(id));
    if (!fileResponse.body) throw new KratosStorageError("missing_target_body", "Kratos returned no stored file body for independent verification.");
    const hash = createHash("sha256");
    let sizeBytes = 0;
    for await (const chunk of Readable.fromWeb(fileResponse.body)) {
      hash.update(chunk);
      sizeBytes += chunk.length;
    }
    return {
      sha256: hash.digest("hex"),
      sizeBytes,
      metadata_sha256: metadata.sha256,
      metadata_size_bytes: Number(metadata.size_bytes),
      customer_id: metadata.customer_id,
      folder_id: metadata.folder_id,
    };
  }

  async ensureFolder(_key, metadata) {
    if (metadata.customer_id == null) {
      const local = await this.localStaging.ensureFolder(_key);
      return { ...local, destinationKind: "local-staging", unresolved: true };
    }
    const folderId = await this.#resolveFolder(metadata);
    if (!folderId) throw new KratosStorageError("missing_customer_folder", "Unassigned folders must be quarantined locally until a target policy is approved.");
    return { created: true, folderId };
  }

  async #resolveFolder(metadata) {
    if (metadata.customer_id == null) return null;
    if (!metadata.folder_id) throw new KratosStorageError("missing_customer_folder", "Mapped Kratos customer is missing its approved storage folder ID.");
    let parentFolderId = String(metadata.folder_id);
    const rootQuery = new URLSearchParams({ customer_id: String(metadata.customer_id) });
    const rootResponse = await this.#request("/api/storage/folders?" + rootQuery);
    const rootBody = await rootResponse.json();
    const rootFolders = Array.isArray(rootBody) ? rootBody : rootBody.folders;
    if (!Array.isArray(rootFolders) || !rootFolders.some((folder) => String(folder.folder_id ?? folder.id) === parentFolderId)) {
      throw new KratosStorageError("customer_folder_mismatch", "Approved base folder is not present in the mapped Kratos customer.");
    }
    for (const segment of metadata.folder_segments ?? []) {
      const query = new URLSearchParams({ customer_id: String(metadata.customer_id), parent_folder_id: parentFolderId });
      const response = await this.#request("/api/storage/folders?" + query);
      const listed = await response.json();
      const folders = Array.isArray(listed) ? listed : listed.folders;
      if (!Array.isArray(folders)) throw new KratosStorageError("invalid_folder_list", "Kratos storage folder list has an unexpected shape.");
      const matches = folders.filter((folder) => folder.name === segment);
      if (matches.length > 1) throw new KratosStorageError("ambiguous_storage_folder", "Multiple target folders have the same name; import is unresolved.");
      if (matches.length === 1) {
        parentFolderId = String(matches[0].folder_id ?? matches[0].id);
        continue;
      }
      const createdResponse = await this.#request("/api/storage/folders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: segment, parent_folder_id: parentFolderId, customer_id: Number(metadata.customer_id) }),
      });
      const created = await createdResponse.json();
      const createdId = created.folder_id ?? created.folder?.id;
      if (!createdId) throw new KratosStorageError("invalid_folder_create", "Kratos storage did not return a folder ID.");
      parentFolderId = String(createdId);
      const verifyResponse = await this.#request("/api/storage/folders?" + query);
      const verifyBody = await verifyResponse.json();
      const verifyFolders = Array.isArray(verifyBody) ? verifyBody : verifyBody.folders;
      if (!Array.isArray(verifyFolders) || verifyFolders.filter((folder) => String(folder.folder_id ?? folder.id) === parentFolderId && folder.name === segment).length !== 1) {
        throw new KratosStorageError("folder_create_unverified", "Created Kratos folder could not be verified under its expected parent.");
      }
    }
    return parentFolderId;
  }

  async commitExclusive(tempFilePath, _key, metadata) {
    if (metadata.customer_id == null) {
      const local = await this.localStaging.commitExclusive(tempFilePath, _key);
      return { ...local, destinationKind: "local-staging", destinationState: "unresolved", destinationId: null };
    }
    const targetFolderId = await this.#resolveFolder(metadata);
    const fileInfo = await import("node:fs/promises").then((fs) => fs.stat(tempFilePath));
    const sourceVersion = String(metadata.source_version ?? "");
    if (!metadata.source_drive_id || !metadata.source_item_id || !sourceVersion || !/^[a-f0-9]{64}$/i.test(String(metadata.source_sha256 ?? ""))) {
      throw new KratosStorageError("missing_source_identity", "R2 import requires stable Graph drive/item/eTag identity and a full source SHA-256.");
    }
    const payload = {
      file_name: metadata.file_name,
      mime_type: metadata.mime_type ?? "application/octet-stream",
      expected_size_bytes: fileInfo.size,
      customer_id: metadata.customer_id == null ? undefined : Number(metadata.customer_id),
      folder_id: targetFolderId ?? undefined,
      source_drive_id: String(metadata.source_drive_id),
      source_item_id: String(metadata.source_item_id),
      source_version: sourceVersion,
      source_path: String(metadata.source_path ?? ""),
      source_sha256: String(metadata.source_sha256),
      source_created_at: metadata.source_created_at ?? undefined,
      source_modified_at: metadata.source_modified_at ?? undefined,
    };
    const maxSingleUpload = Math.min(Number(this.storageLimits?.max_single_upload_bytes ?? MAX_PART_BYTES), MAX_PART_BYTES);
    const result = fileInfo.size <= maxSingleUpload
      ? await this.#putSmall(tempFilePath, payload, fileInfo.size)
      : await this.#putMultipart(tempFilePath, payload, fileInfo.size);
    if (result.size_bytes != null && Number(result.size_bytes) !== fileInfo.size) throw new KratosStorageError("target_size_mismatch", "Kratos stored file size does not match the source.");
    if (String(result.sha256 ?? "").toLowerCase() !== String(metadata.source_sha256).toLowerCase()) throw new KratosStorageError("target_hash_mismatch", "Kratos stored file SHA-256 does not match the source.");
    return {
      created: !result.duplicate,
      duplicate: Boolean(result.duplicate),
      sha256: result.sha256,
      sizeBytes: Number(result.size_bytes),
      destinationId: String(result.file_id),
      destinationState: result.import_state,
      destinationKind: "kratos-r2",
      destinationCustomerId: metadata.customer_id == null ? null : Number(metadata.customer_id),
      destinationFolderId: targetFolderId,
    };
  }

  async #putSmall(tempFilePath, metadata, sizeBytes) {
    const bytes = await readFile(tempFilePath);
    const form = new FormData();
    form.append("file", new Blob([bytes], { type: metadata.mime_type }), metadata.file_name);
    for (const [key, value] of Object.entries(metadata)) if (value !== undefined) form.append(key, String(value));
    const response = await this.#request("/api/storage/files", { method: "POST", body: form });
    const result = await response.json();
    if (Number(result.size_bytes) !== sizeBytes) throw new KratosStorageError("target_size_mismatch", "Kratos single-part upload size differs from the source.");
    return result;
  }

  async #putMultipart(tempFilePath, metadata, sizeBytes) {
    const maximum = Number(this.storageLimits?.max_multipart_upload_bytes ?? Number.MAX_SAFE_INTEGER);
    if (sizeBytes > maximum) throw new KratosStorageError("target_limit_exceeded", "File exceeds the verified Kratos multipart size limit.");
    const initResponse = await this.#request("/api/storage/uploads", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(metadata),
    });
    const session = await initResponse.json();
    if (!session.upload_id || !Number.isInteger(session.part_size_bytes) || session.part_size_bytes < 1 || session.part_size_bytes > MAX_PART_BYTES) {
      throw new KratosStorageError("invalid_upload_session", "Kratos returned an invalid multipart session.");
    }
    const partSize = session.part_size_bytes;
    const partCount = Math.ceil(sizeBytes / partSize);
    if (partCount > Number(session.max_parts)) throw new KratosStorageError("upload_too_many_parts", "File exceeds the Kratos multipart session part limit.");
    const sessionPath = "/api/storage/uploads/" + encodeURIComponent(session.upload_id);
    let stateResponse = await this.#request(sessionPath);
    let state = await stateResponse.json();
    if (state.status === "complete" && state.file_id) {
      const metadataResponse = await this.#request("/api/storage/files/" + encodeURIComponent(state.file_id) + "/metadata");
      return metadataResponse.json();
    }
    if (Number(state.expected_size_bytes) !== sizeBytes) throw new KratosStorageError("upload_session_size_mismatch", "Resumed Kratos upload session size differs from the staged source.");
    const completed = new Map((state.parts ?? []).map((part) => [Number(part.part_number), part]));
    const handle = await open(tempFilePath, "r");
    try {
      for (let partNumber = 1; partNumber <= partCount; partNumber += 1) {
        const offset = (partNumber - 1) * partSize;
        const length = Math.min(partSize, sizeBytes - offset);
        const buffer = Buffer.allocUnsafe(length);
        const { bytesRead } = await handle.read(buffer, 0, length, offset);
        if (bytesRead !== length) throw new KratosStorageError("staged_read_short", "Staged source file ended before its recorded size.");
        const expectedHash = createHash("sha256").update(buffer).digest("hex");
        const previous = completed.get(partNumber);
        if (previous && Number(previous.size_bytes) === length && String(previous.sha256).toLowerCase() === expectedHash) continue;
        if (previous) throw new KratosStorageError("part_conflict", "Existing Kratos upload part differs from the staged source; session left untouched.");
        try {
          const response = await this.#request(sessionPath + "/parts/" + partNumber, {
            method: "PUT",
            headers: { "Content-Type": "application/octet-stream", "Content-Length": String(length) },
            body: buffer,
          });
          const part = await response.json();
          if (Number(part.part_number) !== partNumber || Number(part.size_bytes) !== length || String(part.sha256).toLowerCase() !== expectedHash) {
            throw new KratosStorageError("part_hash_mismatch", "Kratos multipart part verification failed.");
          }
        } catch (error) {
          // Recheck the server-side session after a lost response before retrying or failing.
          stateResponse = await this.#request(sessionPath);
          state = await stateResponse.json();
          const acknowledged = (state.parts ?? []).find((part) => Number(part.part_number) === partNumber);
          if (acknowledged && Number(acknowledged.size_bytes) === length && String(acknowledged.sha256).toLowerCase() === expectedHash) continue;
          throw error;
        }
      }
    } finally {
      await handle.close();
    }
    try {
      const completeResponse = await this.#request(sessionPath + "/complete", { method: "POST" });
      return await completeResponse.json();
    } catch (error) {
      const finalResponse = await this.#request(sessionPath);
      const finalState = await finalResponse.json();
      if (finalState.status === "complete" && finalState.file_id) {
        const metadataResponse = await this.#request("/api/storage/files/" + encodeURIComponent(finalState.file_id) + "/metadata");
        return await metadataResponse.json();
      }
      throw error;
    }
  }
}

export const storagePartSizeLimit = MAX_PART_BYTES;
