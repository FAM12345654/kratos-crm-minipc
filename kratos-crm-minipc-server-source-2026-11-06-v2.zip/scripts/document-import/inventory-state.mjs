import { randomUUID } from "node:crypto";
import { lstat, mkdir, open, readFile, rename, unlink } from "node:fs/promises";
import path from "node:path";
import { safeSourceMetadata } from "./checkpoint.mjs";

export const INVENTORY_STATE_VERSION = 1;

export class InventoryStateError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "InventoryStateError";
    this.code = code;
  }
}

function requiredScope({ driveId, rootItemId }) {
  if (typeof driveId !== "string" || !driveId || typeof rootItemId !== "string" || !rootItemId) {
    throw new InventoryStateError("invalid_scope", "Drive and verified root item IDs are required for inventory state.");
  }
  return { driveId, rootItemId };
}

function validateCursor(deltaLink, driveId, rootItemId) {
  let url;
  try { url = new URL(deltaLink); }
  catch { throw new InventoryStateError("invalid_delta_cursor", "Inventory delta cursor is invalid; a full scoped rescan is required."); }
  const expectedPath = "/v1.0/drives/" + encodeURIComponent(driveId) + "/items/" + encodeURIComponent(rootItemId) + "/delta";
  if (url.protocol !== "https:" || url.origin !== "https://graph.microsoft.com" || url.username || url.password || url.hash || url.pathname !== expectedPath) {
    throw new InventoryStateError("invalid_delta_cursor", "Inventory delta cursor is outside the configured Graph scope; a full scoped rescan is required.");
  }
  return url.href;
}

function itemId(item) {
  return typeof item?.id === "string" && item.id ? item.id : null;
}

function cleanItem(item, driveId) {
  const id = itemId(item);
  if (!id) throw new InventoryStateError("invalid_inventory_item", "Graph inventory contains an item without a stable ID.");
  if (item.parentReference?.driveId && String(item.parentReference.driveId) !== driveId) {
    throw new InventoryStateError("cross_drive_item", "Graph inventory contains an item outside the configured drive.");
  }
  const metadata = safeSourceMetadata(item);
  metadata.id = id;
  if (item.deleted === true || (item.deleted && typeof item.deleted === "object")) metadata.deleted = true;
  if (item.remoteItem === true || (item.remoteItem && typeof item.remoteItem === "object")) metadata.remoteItem = true;
  return metadata;
}

function removeSubtree(items, itemToRemove) {
  const stack = [String(itemToRemove)];
  const visited = new Set();
  while (stack.length) {
    const target = stack.pop();
    if (visited.has(target)) continue;
    visited.add(target);
    for (const item of items.values()) {
      if (String(item.parentReference?.id ?? "") === target && !visited.has(item.id)) stack.push(item.id);
    }
    items.delete(target);
  }
}

function canonicalState({ driveId, rootItemId, deltaLink, items }) {
  const scope = requiredScope({ driveId, rootItemId });
  const cursor = validateCursor(deltaLink, scope.driveId, scope.rootItemId);
  if (!Array.isArray(items)) throw new InventoryStateError("invalid_inventory_state", "Inventory item list is invalid.");
  const byId = new Map();
  for (const raw of items) {
    const item = cleanItem(raw, scope.driveId);
    if (item.deleted) throw new InventoryStateError("invalid_inventory_state", "Persisted inventory cannot contain tombstones.");
    if (item.id === scope.rootItemId) throw new InventoryStateError("invalid_inventory_state", "Persisted inventory must exclude its root folder.");
    if (typeof item.name !== "string" || !item.name || typeof item.parentReference?.id !== "string" || !item.parentReference.id) {
      throw new InventoryStateError("incomplete_inventory_item", "Graph inventory lacks a name or parent reference; import is blocked until a complete rescan.");
    }
    if (item.file && (!Number.isSafeInteger(Number(item.size)) || Number(item.size) < 0)) {
      throw new InventoryStateError("invalid_inventory_size", "Graph file inventory lacks a valid size; import is blocked until a complete rescan.");
    }
    if (byId.has(item.id)) throw new InventoryStateError("duplicate_inventory_id", "Persisted inventory contains duplicate item IDs.");
    byId.set(item.id, item);
  }
  for (const item of byId.values()) {
    const ancestry = new Set([item.id]);
    let parentId = item.parentReference.id;
    while (parentId !== scope.rootItemId) {
      if (ancestry.has(parentId)) throw new InventoryStateError("inventory_cycle", "Graph inventory contains a cyclic folder hierarchy.");
      ancestry.add(parentId);
      const parent = byId.get(parentId);
      if (!parent || !parent.folder) throw new InventoryStateError("inventory_out_of_scope", "Graph inventory has a missing or non-folder parent; import is blocked.");
      parentId = parent.parentReference.id;
    }
  }
  return {
    schema_version: INVENTORY_STATE_VERSION,
    drive_id: scope.driveId,
    root_item_id: scope.rootItemId,
    delta_link: cursor,
    items: [...byId.values()].sort((left, right) => left.id.localeCompare(right.id)),
  };
}

function mergeMetadata(previous, update) {
  const merged = { ...previous };
  for (const [key, value] of Object.entries(update)) {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      const oldNested = merged[key] && typeof merged[key] === "object" && !Array.isArray(merged[key]) ? merged[key] : {};
      merged[key] = mergeMetadata(oldNested, value);
    } else {
      merged[key] = value;
    }
  }
  return merged;
}

export function createInventorySnapshot({ driveId, rootItemId, items, deltaLink }) {
  const scope = requiredScope({ driveId, rootItemId });
  const cursor = validateCursor(deltaLink, scope.driveId, scope.rootItemId);
  if (!Array.isArray(items)) throw new InventoryStateError("invalid_inventory_snapshot", "Graph delta snapshot item list is invalid.");

  // Delta pagination may repeat an ID; the final occurrence is authoritative.
  const latest = new Map();
  for (const raw of items) {
    const item = cleanItem(raw, scope.driveId);
    if (item.id === scope.rootItemId) continue;
    latest.set(item.id, item);
  }
  const live = new Map([...latest].filter(([, item]) => !item.deleted));
  for (const [id, item] of latest) if (item.deleted) removeSubtree(live, id);
  return canonicalState({ driveId, rootItemId, deltaLink: cursor, items: [...live.values()] });
}

export function applyInventoryChanges(state, { driveId, rootItemId, changes, deltaLink }) {
  const scope = requiredScope({ driveId, rootItemId });
  const current = canonicalState({ driveId: state?.drive_id, rootItemId: state?.root_item_id, deltaLink: state?.delta_link, items: state?.items });
  if (current.drive_id !== scope.driveId || current.root_item_id !== scope.rootItemId) {
    throw new InventoryStateError("scope_mismatch", "Saved inventory state does not match the configured Graph drive and root.");
  }
  const cursor = validateCursor(deltaLink, scope.driveId, scope.rootItemId);
  if (!Array.isArray(changes)) throw new InventoryStateError("invalid_delta_page", "Graph delta changes are incomplete; inventory state was not updated.");

  const items = new Map(current.items.map((item) => [item.id, item]));
  const latestChanges = new Map();
  for (const raw of changes) {
    const update = cleanItem(raw, scope.driveId);
    const previousUpdate = latestChanges.get(update.id);
    latestChanges.set(update.id, previousUpdate && !previousUpdate.deleted && !update.deleted ? mergeMetadata(previousUpdate, update) : update);
  }
  const updatedIds = new Set();
  for (const update of latestChanges.values()) {
    if (update.id === scope.rootItemId) {
      if (update.deleted) throw new InventoryStateError("root_deleted", "Configured Kunden root was deleted; inventory state was not updated.");
      continue;
    }
    if (update.deleted) continue;
    const previous = items.get(update.id);
    const merged = previous ? mergeMetadata(previous, update) : update;
    delete merged.deleted;
    items.set(update.id, cleanItem(merged, scope.driveId));
    updatedIds.add(update.id);
  }
  for (const [id, update] of latestChanges) if (update.deleted && id !== scope.rootItemId) removeSubtree(items, id);
  for (const id of updatedIds) {
    const item = items.get(id);
    const parentId = item?.parentReference?.id;
    if (item && parentId && parentId !== scope.rootItemId && !items.has(parentId)) removeSubtree(items, id);
  }
  return canonicalState({ driveId, rootItemId, deltaLink: cursor, items: [...items.values()] });
}

export class InventoryStateStore {
  constructor(filePath) {
    if (typeof filePath !== "string" || !path.isAbsolute(filePath)) throw new InventoryStateError("invalid_state_path", "Inventory state path must be absolute.");
    this.filePath = path.resolve(filePath);
  }

  async load({ driveId, rootItemId }) {
    const scope = requiredScope({ driveId, rootItemId });
    try {
      const info = await lstat(this.filePath);
      if (info.isSymbolicLink() || !info.isFile()) throw new InventoryStateError("unsafe_state_file", "Inventory state must be a regular file.");
      const value = JSON.parse(await readFile(this.filePath, "utf8"));
      if (!value || value.schema_version !== INVENTORY_STATE_VERSION) throw new InventoryStateError("state_version_mismatch", "Inventory state schema version is unsupported; a reviewed full rescan is required.");
      if (value.drive_id !== scope.driveId || value.root_item_id !== scope.rootItemId) throw new InventoryStateError("scope_mismatch", "Saved inventory state does not match the configured Graph drive and root.");
      return canonicalState({ driveId: value.drive_id, rootItemId: value.root_item_id, deltaLink: value.delta_link, items: value.items });
    } catch (error) {
      if (error?.code === "ENOENT") return null;
      if (error instanceof InventoryStateError) throw error;
      throw new InventoryStateError("invalid_inventory_state", "Saved inventory state is unreadable or corrupt; refusing to import until it is reviewed.");
    }
  }

  async save(state) {
    const canonical = canonicalState({ driveId: state?.drive_id, rootItemId: state?.root_item_id, deltaLink: state?.delta_link, items: state?.items });
    await mkdir(path.dirname(this.filePath), { recursive: true, mode: 0o700 });
    try {
      const existing = await lstat(this.filePath);
      if (existing.isSymbolicLink() || !existing.isFile()) throw new InventoryStateError("unsafe_state_file", "Inventory state must be a regular file.");
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
    }
    const tempPath = this.filePath + "." + randomUUID() + ".tmp";
    let handle;
    try {
      handle = await open(tempPath, "wx", 0o600);
      await handle.writeFile(JSON.stringify(canonical) + "\n", "utf8");
      await handle.sync();
      await handle.close();
      handle = null;
      await rename(tempPath, this.filePath);
      if (process.platform !== "win32") {
        const directory = await open(path.dirname(this.filePath), "r");
        try { await directory.sync(); } finally { await directory.close(); }
      }
      return canonical;
    } catch (error) {
      if (handle) await handle.close().catch(() => undefined);
      await unlink(tempPath).catch(() => undefined);
      if (error instanceof InventoryStateError) throw error;
      throw new InventoryStateError("state_write_failed", "Inventory state could not be saved atomically.");
    }
  }
}

export function isExpiredDeltaCursor(error) {
  return error?.code === "graph_http_410" || error?.code === "delta_cursor_expired";
}
