import { createHash } from "node:crypto";
import { encodePathSegment } from "./local-staging.mjs";
import { safeSourceMetadata, sourceCheckpointKey } from "./checkpoint.mjs";
import { applyInventoryChanges, createInventorySnapshot, isExpiredDeltaCursor } from "./inventory-state.mjs";

const ALLOWED_STATUSES = new Set(["successful", "failed", "skipped", "unresolved"]);

function normalizedSourcePath(value) {
  return String(value ?? "").replace(/\\/g, "/").replace(/^\/+|\/+$/g, "").normalize("NFC");
}

export class ImportMappingError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "ImportMappingError";
    this.code = code;
  }
}

function mappingIdentity(value) {
  if (value === undefined || value === null || value === "") return "";
  if (typeof value === "number" && Number.isSafeInteger(value) && value > 0) return String(value);
  if (typeof value === "string" && value.trim() === value && value.length <= 255) return value;
  return null;
}

export function validateFolderMappings(folderMappings) {
  if (!Array.isArray(folderMappings)) throw new ImportMappingError("invalid_mapping", "Folder mappings must be an array.");
  const byPath = new Map();
  for (const mapping of folderMappings) {
    if (!mapping || typeof mapping !== "object" || typeof mapping.relativePath !== "string" || !mapping.relativePath) {
      throw new ImportMappingError("invalid_mapping", "Each folder mapping requires a relative source path.");
    }
    const rawPath = mapping.relativePath.replace(/\\/g, "/");
    if (rawPath.startsWith("/") || /^[A-Za-z]:/.test(rawPath)) throw new ImportMappingError("invalid_mapping", "Folder mapping paths must be relative.");
    const pathKey = normalizedSourcePath(rawPath);
    const segments = pathKey.split("/");
    if (!pathKey || segments.some((segment) => !segment || segment === "." || segment === "..")) {
      throw new ImportMappingError("invalid_mapping", "Folder mapping paths must not contain empty, dot, or parent segments.");
    }
    const customerId = mapping.customerId == null ? "" : mappingIdentity(mapping.customerId);
    const folderId = mapping.folderId == null ? "" : mappingIdentity(mapping.folderId);
    if (customerId === null || folderId === null) throw new ImportMappingError("invalid_mapping", "Folder mapping customer and folder IDs must use stable scalar identifiers.");
    const prior = byPath.get(pathKey);
    if (prior && (prior.customerId !== customerId || prior.folderId !== folderId)) {
      throw new ImportMappingError("mapping_conflict", "A normalized source folder path has conflicting customer or destination folder mappings.");
    }
    byPath.set(pathKey, { customerId, folderId });
  }
  return true;
}

function resolveMapping(relativePath, folderMappings) {
  const sourcePath = normalizedSourcePath(relativePath);
  const matches = (folderMappings ?? [])
    .map((mapping) => ({ ...mapping, prefix: normalizedSourcePath(mapping.relativePath) }))
    .filter((mapping) => mapping.prefix && (sourcePath === mapping.prefix || sourcePath.startsWith(mapping.prefix + "/")))
    .sort((left, right) => right.prefix.length - left.prefix.length);
  return matches[0] ?? null;
}

function targetKey({ driveId, item, relativeSegments, mapping, customerId }) {
  const prefixLength = mapping ? normalizedSourcePath(mapping.relativePath).split("/").length : 0;
  const segments = relativeSegments.slice(prefixLength).map(encodePathSegment);
  const fileName = segments.pop();
  const sourceId = createHash("sha256").update(String(item.id)).digest("hex").slice(0, 10);
  const version = createHash("sha256").update(String(item.eTag)).digest("hex").slice(0, 10);
  const dot = fileName.lastIndexOf(".");
  const taggedName = dot > 0
    ? fileName.slice(0, dot) + "--" + sourceId + "-" + version + fileName.slice(dot)
    : fileName + "--" + sourceId + "-" + version;
  const prefix = mapping ? "customers/" + customerId : "quarantine/" + createHash("sha256").update(String(driveId)).digest("hex").slice(0, 12);
  return [prefix, ...segments, taggedName].join("/");
}

function folderTargetKey({ driveId, relativeSegments, mapping, customerId }) {
  const prefixLength = mapping ? normalizedSourcePath(mapping.relativePath).split("/").length : 0;
  const segments = relativeSegments.slice(prefixLength).map(encodePathSegment);
  const prefix = mapping ? "customers/" + customerId : "quarantine/" + createHash("sha256").update(String(driveId)).digest("hex").slice(0, 12);
  return [prefix, ...segments].join("/");
}

function itemIsDirectory(item) {
  return Boolean(item?.folder) && !item?.remoteItem;
}

function sameOptionalScalar(left, right) {
  if (left == null || right == null) return left == null && right == null;
  return String(left) === String(right);
}

function itemFacetMismatch(initial, walked) {
  if (!initial || !walked || String(initial.id) !== String(walked.id)) return true;
  if (initial.deleted || walked.deleted) return true;
  if (!sameOptionalScalar(initial.eTag, walked.eTag) || !sameOptionalScalar(initial.cTag, walked.cTag) || initial.name !== walked.name) return true;
  if (Boolean(initial.file) !== Boolean(walked.file) || Boolean(initial.folder) !== Boolean(walked.folder) || Boolean(initial.remoteItem) !== Boolean(walked.remoteItem)) return true;
  if (initial.file && (initial.size == null || walked.size == null || Number(initial.size) !== Number(walked.size))) return true;
  const initialParent = initial.parentReference?.id;
  const walkedParent = walked.parentReference?.id;
  return !sameOptionalScalar(initialParent, walkedParent);
}

function pilotSubtreeFingerprint({ driveId, rootItemId, pilotRoot, treeItems, folderMappings, destination, destinationProjectId }) {
  const prefix = normalizedSourcePath(treeItems.find(({ item }) => String(item.id) === String(pilotRoot.id))?.relativePath ?? "");
  if (!prefix) throw new Error("Pilot folder path is missing from the reconciled source tree.");
  const entries = treeItems.filter(({ item, relativePath }) => String(item.id) === String(pilotRoot.id) || normalizedSourcePath(relativePath).startsWith(prefix + "/"))
    .map(({ item, relativePath, relativeSegments }) => {
      const mapping = resolveMapping(relativePath, folderMappings);
      const customerId = mapping?.customerId == null ? null : Number(mapping.customerId);
      const destinationKey = itemIsDirectory(item)
        ? folderTargetKey({ driveId, relativeSegments, mapping, customerId })
        : item.file ? targetKey({ driveId, item, relativeSegments, mapping, customerId }) : null;
      return {
        id: String(item.id), eTag: item.eTag ?? null, cTag: item.cTag ?? null,
        name: item.name ?? null, size: item.file ? Number(item.size) : null,
        parentId: item.parentReference?.id == null ? null : String(item.parentReference.id),
        relativePath: normalizedSourcePath(relativePath),
        kind: item.remoteItem ? "remoteItem" : item.folder ? "folder" : item.file ? "file" : "other",
        customerId, folderId: mapping?.folderId ?? null, mappingPath: mapping ? normalizedSourcePath(mapping.relativePath) : null,
        destinationKey,
      };
    }).sort((left, right) => left.id.localeCompare(right.id));
  return createHash("sha256").update(JSON.stringify({
    driveId: String(driveId), rootItemId: String(rootItemId), pilotItemId: String(pilotRoot.id),
    pilotETag: pilotRoot.eTag ?? null, destinationKind: destination.kind,
    destinationProjectId: destinationProjectId ?? null, entries,
  })).digest("hex");
}

function statusRecord({ driveId, item, sourceKey, status, reason, relativePath, targetKey: key, customerId, metadata, sha256, sizeBytes }) {
  if (!ALLOWED_STATUSES.has(status)) throw new Error("Invalid import result status.");
  return {
    record_type: "source_item",
    source_key: sourceKey,
    drive_id: String(driveId),
    item_id: String(item.id),
    e_tag: item.eTag ?? null,
    source_path: relativePath,
    metadata: safeSourceMetadata(metadata ?? item),
    target_key: key ?? null,
    destination_kind: metadata?.destination_kind ?? null,
    destination_project_id: metadata?.destination_project_id ?? null,
    destination_id: metadata?.destination_id ?? null,
    destination_folder_id: metadata?.destination_folder_id ?? null,
    mapped_folder_id: metadata?.mapped_folder_id ?? null,
    customer_id: customerId ?? null,
    status,
    reason: reason ?? null,
    sha256: sha256 ?? null,
    size_bytes: sizeBytes ?? null,
  };
}

function preservedDestination(record) {
  return {
    destination_kind: record?.destination_kind,
    destination_project_id: record?.destination_project_id,
    destination_id: record?.destination_id,
    destination_folder_id: record?.destination_folder_id,
    mapped_folder_id: record?.mapped_folder_id,
  };
}

function summarize(records) {
  const latest = new Map();
  for (const record of records) if (record.source_key && record.record_type === "source_item") latest.set(record.source_key, record);
  const counts = { successful: 0, failed: 0, skipped: 0, unresolved: 0 };
  for (const record of latest.values()) counts[record.status] += 1;
  return { total_items: latest.size, ...counts };
}

function itemSet(items, excludedRootId) {
  return new Map(items.filter((item) => !item.deleted && String(item.id) !== String(excludedRootId)).map((item) => [String(item.id), item]));
}

function descendantsOf(folderId, items) {
  const children = new Map();
  for (const item of items) {
    const parentId = item.parentReference?.id;
    if (!parentId) continue;
    const list = children.get(String(parentId)) ?? [];
    list.push(String(item.id));
    children.set(String(parentId), list);
  }
  const found = new Set([String(folderId)]);
  const stack = [String(folderId)];
  while (stack.length) {
    for (const child of children.get(stack.pop()) ?? []) {
      if (found.has(child)) continue;
      found.add(child);
      stack.push(child);
    }
  }
  return found;
}

export async function runDocumentImport(options) {
  const checkpoint = options.checkpoint;
  if (typeof checkpoint?.withExclusive === "function") {
    return checkpoint.withExclusive(() => runLockedDocumentImport(options));
  }
  return runLockedDocumentImport(options);
}

async function runLockedDocumentImport({
  mode,
  driveId,
  rootItemId,
  folderMappings = [],
  pilotItemId,
  pilotCustomerId,
  pilotExpectedFiles = 5,
  pilotExpectedFolders = 4,
  pilotExpectedBytes = 7147301,
  pilotApproved = false,
  bulkApproved = false,
  allowUnassignedQuarantineCopy = false,
  localAclConfirmed = false,
  source,
  destination,
  checkpoint,
  inventoryState = null,
}) {
  if (mode !== "pilot" && mode !== "bulk") throw new Error("Import mode must be pilot or bulk; default operation is preflight only.");
  if (!driveId || !rootItemId) throw new Error("A source drive and verified Kunden root item ID are required.");
  validateFolderMappings(folderMappings);
  if (mode === "pilot" && (!pilotApproved || String(pilotCustomerId) !== "6" || !pilotItemId)) {
    throw new Error("Pilot import requires explicit approval, one item ID, and customer ID 6.");
  }
  if (mode === "bulk" && !bulkApproved) {
    throw new Error("Bulk import requires explicit approval; a current drive/root/subtree-scoped reviewed pilot is checked after source reconciliation.");
  }
  if (mode === "bulk" && destination.kind !== "kratos-r2") {
    throw new Error("Bulk import is blocked unless the destination is authenticated Kratos storage; local staging is not a Kratos import.");
  }

  const destinationInfo = await destination.initialize();
  const localStore = destination.kind === "kratos-local";
  const requiresFolderBinding = localStore || destination.kind === "kratos-r2";
  const localBindings = checkpoint.records?.filter((record) => record.record_type === "local_destination_binding") ?? [];
  if (localBindings.some((record) => !localStore || record.destination_project_id !== destinationInfo?.projectId ||
      record.drive_id !== String(driveId) || record.root_item_id !== String(rootItemId))) {
    throw new Error("Checkpoint is bound to a different local import target or source root.");
  }
  if (localStore && (!Array.isArray(checkpoint.records) || !/^[a-f0-9]{64}$/.test(destinationInfo?.projectId ?? ""))) {
    throw new Error("Local import requires a checkpoint and a verified target identity.");
  }
  if (localStore && localBindings.length === 0 && checkpoint.records.length !== 0) {
    throw new Error("Local import requires a dedicated empty checkpoint for its first run.");
  }
  if (destinationInfo?.aclVerified === false && !localAclConfirmed) throw new Error("Windows staging ACL must be applied and explicitly confirmed before importing files.");
  await source.verifyCustomerRoot(driveId, rootItemId);

  let inventory;
  let inventoryOrigin = "full_snapshot";
  const savedInventory = inventoryState ? await inventoryState.load({ driveId: String(driveId), rootItemId: String(rootItemId) }) : null;
  if (savedInventory) {
    try {
      const delta = await source.changesSince(savedInventory.delta_link);
      if (!delta?.complete || !delta.deltaLink || !Array.isArray(delta.changes)) throw new Error("Complete scoped Graph delta changes required; import blocked.");
      inventory = applyInventoryChanges(savedInventory, { driveId: String(driveId), rootItemId: String(rootItemId), changes: delta.changes, deltaLink: delta.deltaLink });
      inventoryOrigin = "incremental_delta";
    } catch (error) {
      if (!isExpiredDeltaCursor(error)) throw error;
      inventoryOrigin = "expired_cursor_full_rescan";
    }
  }
  if (!inventory) {
    const snapshot = await source.snapshotDrive(driveId, rootItemId);
    if (!snapshot?.complete || !snapshot.deltaLink || !Array.isArray(snapshot.items)) throw new Error("Complete scoped Graph delta snapshot required; import blocked.");
    inventory = createInventorySnapshot({ driveId: String(driveId), rootItemId: String(rootItemId), items: snapshot.items, deltaLink: snapshot.deltaLink });
  }

  const treeItems = [];
  for await (const entry of source.walkRecursive({ driveId, rootItemId })) treeItems.push(entry);
  const deltaItems = itemSet(inventory.items, rootItemId);
  const treeIds = new Set(treeItems.map(({ item }) => String(item.id)));
  const duplicateTreeIds = treeItems.map(({ item }) => String(item.id)).filter((id, index, all) => all.indexOf(id) !== index);
  const deltaIds = new Set(deltaItems.keys());
  const missingFromTree = [...deltaIds].filter((id) => !treeIds.has(id));
  const missingFromDelta = [...treeIds].filter((id) => !deltaIds.has(id));
  const treeById = new Map(treeItems.map(({ item }) => [String(item.id), item]));
  const versionMismatches = [...deltaIds].filter((id) => itemFacetMismatch(deltaItems.get(id), treeById.get(id)));
  const shortcuts = treeItems.filter(({ item }) => item.remoteItem);
  if (missingFromTree.length || missingFromDelta.length || versionMismatches.length || duplicateTreeIds.length || shortcuts.length) {
    const unresolved = [];
    for (const id of new Set([...missingFromTree, ...missingFromDelta, ...versionMismatches, ...duplicateTreeIds])) {
      const item = deltaItems.get(id) ?? treeItems.find((entry) => String(entry.item.id) === id)?.item ?? { id, eTag: "inventory-mismatch" };
      const key = sourceCheckpointKey({ driveId, itemId: id, eTag: item.eTag ?? "inventory-mismatch" });
      const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "inventory_incomplete_or_changed", metadata: item });
      await checkpoint.append(record);
      unresolved.push(record);
    }
    for (const { item, relativePath } of shortcuts) {
      const key = sourceCheckpointKey({ driveId, itemId: item.id, eTag: item.eTag ?? "shortcut" });
      const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "shared_shortcut_not_followed", relativePath, metadata: item });
      await checkpoint.append(record);
      unresolved.push(record);
    }
    return { complete: false, run_complete: false, pilot_complete: false, migration_complete: false, blocked: true, reason: "Graph delta and recursive listing did not prove a complete stable Kunden inventory.", summary: summarize([...checkpoint.records]), unresolved_count: unresolved.length };
  }

  let reviewedPilot = null;
  if (mode === "bulk") {
    if (typeof checkpoint.getReviewedPilot !== "function") throw new Error("Bulk import requires a source-scoped reviewed pilot checkpoint; legacy review flags are not accepted.");
    reviewedPilot = checkpoint.getReviewedPilot({ driveId: String(driveId), rootItemId: String(rootItemId), destinationKind: "kratos-r2" });
    if (!reviewedPilot) throw new Error("Bulk import requires the latest successful, reviewed Kratos R2 pilot for this exact Graph drive and Kunden root.");
    const reviewedPilotRoot = treeItems.find(({ item }) => String(item.id) === String(reviewedPilot.pilot_folder_item_id))?.item;
    if (!reviewedPilotRoot || !itemIsDirectory(reviewedPilotRoot)) throw new Error("Reviewed pilot folder is absent from the current reconciled source tree.");
    const reviewedPilotMapping = resolveMapping(treeItems.find(({ item }) => String(item.id) === String(reviewedPilotRoot.id)).relativePath, folderMappings);
    if (Number(reviewedPilotMapping?.customerId) !== 6) throw new Error("Reviewed pilot folder no longer maps to customer ID 6.");
    const currentFingerprint = pilotSubtreeFingerprint({ driveId, rootItemId, pilotRoot: reviewedPilotRoot, treeItems, folderMappings, destination, destinationProjectId: destinationInfo?.projectId });
    if (currentFingerprint !== reviewedPilot.subtree_fingerprint) throw new Error("Reviewed pilot source subtree, mapping, destination, or project changed; a new successful pilot and explicit review are required before bulk import.");
    const pilotPrefix = normalizedSourcePath(treeItems.find(({ item }) => String(item.id) === String(reviewedPilotRoot.id)).relativePath);
    const pilotItems = treeItems.filter(({ item, relativePath }) => String(item.id) !== String(reviewedPilotRoot.id) && normalizedSourcePath(relativePath).startsWith(pilotPrefix + "/"));
    const pilotFiles = pilotItems.filter(({ item }) => Boolean(item.file));
    const pilotFolders = pilotItems.filter(({ item }) => itemIsDirectory(item));
    const pilotBytes = pilotFiles.reduce((sum, { item }) => sum + Number(item.size ?? 0), 0);
    if (pilotFiles.length !== reviewedPilot.expected_files || pilotFolders.length !== reviewedPilot.expected_folders || pilotBytes !== reviewedPilot.expected_bytes) throw new Error("Reviewed pilot file, folder, or byte scope differs from the current source subtree.");
  }

  let selected;
  let pilotComplete = false;
  if (mode === "pilot") {
    const pilotRoot = treeItems.find(({ item }) => String(item.id) === String(pilotItemId) && item.folder && !item.remoteItem);
    if (!pilotRoot) throw new Error("Pilot item ID must identify the selected customer folder inside Kunden.");
    const pilotMapping = resolveMapping(pilotRoot.relativePath, folderMappings);
    if (Number(pilotMapping?.customerId) !== 6 || String(pilotCustomerId) !== "6") throw new Error("The selected pilot folder must map to customer ID 6.");
    const pilotPrefix = normalizedSourcePath(pilotRoot.relativePath);
    selected = treeItems.filter(({ item, relativePath }) => String(item.id) !== String(pilotItemId) && normalizedSourcePath(relativePath).startsWith(pilotPrefix + "/"));
    const expectedFiles = selected.filter(({ item }) => Boolean(item.file)).length;
    const expectedFolders = selected.filter(({ item }) => itemIsDirectory(item)).length;
    if (expectedFiles !== pilotExpectedFiles || expectedFolders !== pilotExpectedFolders) {
      throw new Error("Pilot folder inventory does not match the reviewed expectation: expected " + pilotExpectedFiles + " files and " + pilotExpectedFolders + " folders.");
    }
    const expectedBytes = selected.filter(({ item }) => item.file).reduce((sum, { item }) => sum + Number(item.size ?? 0), 0);
    if (expectedBytes !== pilotExpectedBytes) throw new Error("Pilot folder byte total differs from its reviewed inventory expectation.");
  } else {
    selected = treeItems;
  }
  const sourcePaths = new Map(treeItems.map(({ item, relativePath }) => [String(item.id), relativePath]));
  const initialItems = [...deltaItems.values()];
  const descendantIds = descendantsOf(rootItemId, initialItems);
  const resultRecords = [];
  if (localStore && localBindings.length === 0) {
    await checkpoint.append({ record_type: "local_destination_binding", destination_kind: destination.kind, destination_project_id: destinationInfo.projectId, drive_id: String(driveId), root_item_id: String(rootItemId) });
  }

  for (const entry of selected) {
    const { item, relativePath, relativeSegments } = entry;
    const map = resolveMapping(relativePath, folderMappings);
    const customerId = map?.customerId == null ? null : Number(map.customerId);
    if (mode === "pilot" && customerId !== 6) throw new Error("The selected pilot item must map to customer ID 6.");

    if (item.remoteItem) {
      const key = sourceCheckpointKey({ driveId, itemId: item.id, eTag: item.eTag ?? "shortcut" });
      const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "shared_shortcut_not_followed", relativePath, metadata: item, customerId });
      await checkpoint.append(record);
      resultRecords.push(record);
      continue;
    }
    if (itemIsDirectory(item)) {
      const key = sourceCheckpointKey({ driveId, itemId: item.id, eTag: item.eTag ?? "folder" });
      const destinationKey = folderTargetKey({ driveId, relativeSegments, mapping: map, customerId });
      if (customerId == null && !allowUnassignedQuarantineCopy) {
        const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "unassigned_folder_inventory_only_no_copy; mapping review required", relativePath, metadata: item });
        await checkpoint.append(record);
        resultRecords.push(record);
        continue;
      }
      const mappingDepth = map ? normalizedSourcePath(map.relativePath).split("/").length : 0;
      try {
        const folder = await destination.ensureFolder(destinationKey, {
          customer_id: customerId,
          folder_id: map?.folderId ?? null,
          folder_segments: relativeSegments.slice(mappingDepth),
          source_path: relativePath,
          source_drive_id: String(driveId),
          source_item_id: String(item.id),
          source_version: item.eTag ?? "",
        });
        const status = customerId == null || folder.unresolved ? "unresolved" : "successful";
        const record = statusRecord({ driveId, item, sourceKey: key, status, reason: customerId == null ? "unassigned_folder_quarantined" : null, relativePath, targetKey: destinationKey, customerId, metadata: { ...item, destination_kind: folder.destinationKind ?? destination.kind, destination_id: folder.folderId ?? null } });
        await checkpoint.append(record);
        resultRecords.push(record);
      } catch (error) {
        const record = statusRecord({ driveId, item, sourceKey: key, status: "failed", reason: error?.code ?? "folder_create_failed", relativePath, targetKey: destinationKey, customerId, metadata: item });
        await checkpoint.append(record);
        resultRecords.push(record);
      }
      continue;
    }
    if (!item.file) {
      const key = sourceCheckpointKey({ driveId, itemId: item.id, eTag: item.eTag ?? "unsupported" });
      const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "unsupported_graph_item", relativePath, metadata: item, customerId });
      await checkpoint.append(record);
      resultRecords.push(record);
      continue;
    }
    if (!item.eTag) {
      const record = statusRecord({ driveId, item, sourceKey: sourceCheckpointKey({ driveId, itemId: item.id, eTag: "missing-eTag" }), status: "unresolved", reason: "source_version_missing", relativePath, metadata: item, customerId });
      await checkpoint.append(record);
      resultRecords.push(record);
      continue;
    }

    const key = sourceCheckpointKey({ driveId, itemId: item.id, eTag: item.eTag });
    if (customerId == null && !allowUnassignedQuarantineCopy) {
      const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "unassigned_file_inventory_only_no_copy; mapping review required", relativePath, metadata: item });
      await checkpoint.append(record);
      resultRecords.push(record);
      continue;
    }
    const destinationKey = targetKey({ driveId, item, relativeSegments, mapping: map, customerId });
    const previous = checkpoint.latestFor({ driveId, itemId: item.id, eTag: item.eTag });
    const folderSegments = map ? relativeSegments.slice(normalizedSourcePath(map.relativePath).split("/").length, -1) : [];
    const verificationContext = { driveId, item, customerId, baseFolderId: map?.folderId, folderSegments, relativePath };
    const priorBinding = preservedDestination(previous);
    if (previous?.destination_kind && (localStore || previous.destination_kind === "kratos-local") &&
        (previous.destination_kind !== destination.kind || previous.destination_project_id !== destinationInfo?.projectId)) {
      const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "checkpoint_destination_mismatch; target preserved", relativePath, targetKey: previous.target_key, customerId: previous.customer_id, metadata: { ...item, ...priorBinding }, sha256: previous.sha256, sizeBytes: previous.size_bytes });
      await checkpoint.append(record); resultRecords.push(record); continue;
    }
    if (previous && previous.target_key === destinationKey && ["successful", "skipped", "unresolved"].includes(previous.status) && previous.sha256) {
      if (localStore && itemFacetMismatch(previous.metadata, item)) {
        const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "resume_source_changed; target preserved", relativePath: previous.source_path, targetKey: destinationKey, customerId: previous.customer_id, metadata: { ...previous.metadata, ...priorBinding }, sha256: previous.sha256, sizeBytes: previous.size_bytes });
        await checkpoint.append(record); resultRecords.push(record); continue;
      }
      let found;
      try {
        found = await destination.checkTargetHash(destinationKey, { ...verificationContext, previous, expectedSha256: previous.sha256 });
      } catch (error) {
        if (!localStore) throw error;
        found = null;
      }
      if (requiresFolderBinding && customerId != null &&
          (Number(found?.customer_id) !== customerId || previous.destination_folder_id == null || previous.mapped_folder_id == null ||
           String(found?.folder_id) !== String(previous.destination_folder_id) || String(previous.mapped_folder_id) !== String(map?.folderId))) {
        const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "resume_customer_or_folder_mismatch; target preserved", relativePath, targetKey: destinationKey, customerId: previous.customer_id, metadata: { ...item, ...priorBinding }, sha256: previous.sha256, sizeBytes: previous.size_bytes });
        await checkpoint.append(record); resultRecords.push(record); continue;
      }
      if (found?.sha256 === previous.sha256 && found?.sizeBytes === previous.size_bytes) {
        const status = previous.status === "unresolved" ? "unresolved" : "skipped";
        const record = statusRecord({ driveId, item, sourceKey: key, status, reason: status === "unresolved" ? previous.reason : "already_staged_and_hash_verified", relativePath, targetKey: destinationKey, customerId, metadata: { ...item, ...priorBinding }, sha256: found.sha256, sizeBytes: found.sizeBytes });
        await checkpoint.append(record);
        resultRecords.push(record);
        continue;
      }
      const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "existing_target_hash_changed", relativePath, targetKey: destinationKey, customerId: previous.customer_id, metadata: { ...item, ...priorBinding }, sha256: previous.sha256, sizeBytes: previous.size_bytes });
      await checkpoint.append(record);
      resultRecords.push(record);
      continue;
    }
    if (previous?.sha256 && previous.target_key && previous.target_key !== destinationKey && (previous.destination_kind || previous.status === "successful" || previous.status === "skipped")) {
      const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "mapping_changed_after_success; old target preserved", relativePath, targetKey: previous.target_key, customerId: previous.customer_id, metadata: { ...item, ...priorBinding }, sha256: previous.sha256, sizeBytes: previous.size_bytes });
      await checkpoint.append(record);
      resultRecords.push(record);
      continue;
    }
    if (await destination.exists(destinationKey, { unassigned: customerId == null })) {
      const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "target_exists_without_matching_checkpoint; no overwrite", relativePath, targetKey: destinationKey, customerId, metadata: item });
      await checkpoint.append(record);
      resultRecords.push(record);
      continue;
    }
    if (requiresFolderBinding && customerId != null && !map?.folderId) {
      const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "mapped_customer_has_no_approved_Kratos_storage_folder", relativePath, targetKey: destinationKey, customerId, metadata: item });
      await checkpoint.append(record);
      resultRecords.push(record);
      continue;
    }

    let tempFile = null;
    let committedBinding = null;
    try {
      const before = await source.getItem(driveId, item.id);
      if (itemFacetMismatch(item, before)) {
        const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "source_changed_before_download", relativePath, targetKey: destinationKey, customerId, metadata: item });
        await checkpoint.append(record);
        resultRecords.push(record);
        continue;
      }
      const body = await source.downloadContent(driveId, item.id);
      tempFile = await destination.createTempStream(key, body);
      const sourceSha256 = tempFile.sha256;
      const sourceSizeBytes = tempFile.sizeBytes;
      if (!Number.isSafeInteger(Number(item.size)) || Number(item.size) !== sourceSizeBytes) {
        await destination.cleanupTemp(tempFile.filePath);
        tempFile = null;
        const record = statusRecord({ driveId, item, sourceKey: key, status: "failed", reason: "download_size_does_not_match_inventory", relativePath, targetKey: destinationKey, customerId, metadata: item, sha256: sourceSha256, sizeBytes: sourceSizeBytes });
        await checkpoint.append(record);
        resultRecords.push(record);
        continue;
      }
      const after = await source.getItem(driveId, item.id);
      if (itemFacetMismatch(item, after)) {
        await destination.cleanupTemp(tempFile.filePath);
        tempFile = null;
        const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "source_changed_during_download", relativePath, targetKey: destinationKey, customerId, metadata: item });
        await checkpoint.append(record);
        resultRecords.push(record);
        continue;
      }
      const committed = await destination.commitExclusive(tempFile.filePath, destinationKey, {
        drive_id: String(driveId),
        source_drive_id: String(driveId),
        source_item_id: String(item.id),
        source_version: item.eTag,
        source_path: relativePath,
        customer_id: customerId,
        folder_id: map?.folderId ?? null,
        file_name: item.name,
        mime_type: item.file?.mimeType ?? "application/octet-stream",
        folder_segments: folderSegments,
        relative_segments: relativeSegments,
        source_sha256: sourceSha256,
        source_created_at: item.createdDateTime ?? null,
        source_modified_at: item.lastModifiedDateTime ?? null,
      });
      if (committed.created || committed.duplicate) {
        committedBinding = { destination_kind: committed.destinationKind ?? destination.kind, destination_project_id: localStore ? destinationInfo.projectId : null, destination_id: committed.destinationId, destination_folder_id: committed.destinationFolderId, mapped_folder_id: map?.folderId, sha256: sourceSha256, sizeBytes: sourceSizeBytes };
      }
      await destination.cleanupTemp(tempFile.filePath);
      tempFile = null;
      if (!committed.created && !committed.duplicate) {
        const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "target_conflict; no overwrite", relativePath, targetKey: destinationKey, customerId, metadata: item });
        await checkpoint.append(record);
        resultRecords.push(record);
        continue;
      }
      const targetHash = await destination.checkTargetHash(destinationKey, { ...verificationContext, expectedSha256: sourceSha256, destinationId: committed.destinationId, destinationKind: committed.destinationKind ?? destination.kind });
      const associationMismatch = requiresFolderBinding && customerId != null &&
        (Number(targetHash?.customer_id) !== customerId || String(targetHash?.folder_id) !== String(committed.destinationFolderId));
      if (associationMismatch) {
        const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "target_customer_or_folder_mismatch; target preserved", relativePath, targetKey: destinationKey, customerId, metadata: { ...item, ...committedBinding }, sha256: sourceSha256, sizeBytes: sourceSizeBytes });
        await checkpoint.append(record);
        resultRecords.push(record);
        continue;
      }
      if (!targetHash || targetHash.sha256 !== sourceSha256 || targetHash.sizeBytes !== sourceSizeBytes || committed.sha256 !== sourceSha256 || committed.sizeBytes !== sourceSizeBytes || (targetHash.metadata_sha256 != null && targetHash.metadata_sha256 !== sourceSha256) || (targetHash.metadata_size_bytes != null && targetHash.metadata_size_bytes !== sourceSizeBytes)) {
        const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: "source_target_sha256_mismatch", relativePath, targetKey: destinationKey, customerId, metadata: { ...item, ...committedBinding }, sha256: sourceSha256, sizeBytes: sourceSizeBytes });
        await checkpoint.append(record);
        resultRecords.push(record);
        continue;
      }
      const isUnresolvedTarget = customerId == null || committed.destinationState === "unresolved";
      const status = isUnresolvedTarget ? "unresolved" : "successful";
      const record = statusRecord({ driveId, item, sourceKey: key, status, reason: customerId == null ? "unassigned_file_quarantined" : committed.destinationState === "unresolved" ? "Kratos returned unresolved storage state" : committed.duplicate ? "existing source version hash verified" : null, relativePath, targetKey: destinationKey, customerId, metadata: { ...item, ...committedBinding }, sha256: committed.sha256, sizeBytes: committed.sizeBytes });
      await checkpoint.append(record);
      resultRecords.push(record);
    } catch (error) {
      if (tempFile?.filePath) await destination.cleanupTemp(tempFile.filePath).catch(() => {});
      const record = statusRecord({ driveId, item, sourceKey: key, status: committedBinding ? "unresolved" : "failed", reason: error?.code ?? "transfer_error", relativePath, targetKey: destinationKey, customerId, metadata: { ...item, ...committedBinding }, sha256: committedBinding?.sha256, sizeBytes: committedBinding?.sizeBytes });
      await checkpoint.append(record);
      resultRecords.push(record);
    }
  }

  const changes = await source.changesSince(inventory.delta_link);
  if (!changes.complete || !changes.deltaLink || !Array.isArray(changes.changes)) throw new Error("Final Graph delta reconciliation was incomplete; no bulk completion can be reported.");
  const changedIds = new Set();
  for (const change of changes.changes) {
    if (descendantIds.has(String(change.id))) {
      changedIds.add(String(change.id));
      const nested = descendantsOf(change.id, initialItems);
      if (change.folder || change.deleted || nested.size > 1) for (const id of nested) changedIds.add(id);
    } else if (!change.deleted) {
      changedIds.add(String(change.id));
      const key = sourceCheckpointKey({ driveId, itemId: change.id, eTag: change.eTag ?? "added-after-snapshot" });
      const record = statusRecord({ driveId, item: change, sourceKey: key, status: "unresolved", reason: "source_added_after_snapshot; rerun required", relativePath: null, metadata: change });
      await checkpoint.append(record);
      resultRecords.push(record);
    }
  }
  for (const id of changedIds) {
    const before = initialItems.find((item) => String(item.id) === id);
    const changeRecord = changes.changes.find((value) => String(value.id) === id);
    const path = sourcePaths.get(id) ?? null;
    const item = before ?? changeRecord ?? { id, eTag: "changed" };
    const sourceVersion = before?.eTag ?? item.eTag ?? "changed";
    const key = sourceCheckpointKey({ driveId, itemId: id, eTag: sourceVersion });
    const previous = checkpoint.latestFor({ driveId, itemId: id, eTag: sourceVersion });
    const metadata = previous?.destination_id != null ? previous.metadata : changeRecord ?? item;
    const record = statusRecord({ driveId, item, sourceKey: key, status: "unresolved", reason: changeRecord?.deleted ? "source_deleted_after_snapshot; staged target preserved" : "source_changed_after_snapshot; staged target preserved", relativePath: path, targetKey: previous?.target_key ?? null, customerId: previous?.customer_id ?? null, metadata: { ...metadata, ...preservedDestination(previous) }, sha256: previous?.sha256, sizeBytes: previous?.size_bytes });
    await checkpoint.append(record);
    resultRecords.push(record);
  }

  if (changedIds.size === 0) {
    inventory = applyInventoryChanges(inventory, { driveId: String(driveId), rootItemId: String(rootItemId), changes: [], deltaLink: changes.deltaLink });
    if (inventoryState) await inventoryState.save(inventory);
    await checkpoint.append({ record_type: "source_delta", drive_id: String(driveId), root_item_id: String(rootItemId), delta_link: changes.deltaLink, status: "successful", inventory_origin: inventoryOrigin, item_count: inventory.items.length });
  } else {
    await checkpoint.append({ record_type: "source_delta", drive_id: String(driveId), root_item_id: String(rootItemId), status: "unresolved", reason: "source_changed_during_import; cursor not advanced", inventory_origin: inventoryOrigin });
  }

  if (mode === "pilot") {
    const pilotFiles = selected.filter(({ item }) => Boolean(item.file));
    const pilotFolders = selected.filter(({ item }) => itemIsDirectory(item));
    const fileRecords = pilotFiles.map(({ item }) => checkpoint.latestFor({ driveId, itemId: item.id, eTag: item.eTag }));
    const folderRecords = pilotFolders.map(({ item }) => checkpoint.latestFor({ driveId, itemId: item.id, eTag: item.eTag ?? "folder" }));
    const filesVerified = fileRecords.length === pilotExpectedFiles && fileRecords.every((record) => record && ["successful", "skipped"].includes(record.status) && /^[a-f0-9]{64}$/i.test(String(record.sha256 ?? "")));
    const foldersVerified = folderRecords.length === pilotExpectedFolders && folderRecords.every((record) => record && ["successful", "skipped"].includes(record.status));
    const bytesVerified = fileRecords.reduce((sum, record) => sum + Number(record?.size_bytes ?? 0), 0) === pilotExpectedBytes;
    const status = filesVerified && foldersVerified && bytesVerified && changedIds.size === 0 ? "successful" : "unresolved";
    const pilotRoot = treeItems.find(({ item }) => String(item.id) === String(pilotItemId))?.item;
    const pilotKey = sourceCheckpointKey({ driveId, itemId: pilotItemId, eTag: pilotRoot?.eTag ?? "pilot-folder" });
    const subtreeFingerprint = pilotRoot ? pilotSubtreeFingerprint({ driveId, rootItemId, pilotRoot, treeItems, folderMappings, destination, destinationProjectId: destinationInfo?.projectId }) : null;
    pilotComplete = status === "successful";
    await checkpoint.append({
      record_type: "pilot_complete",
      source_key: pilotKey,
      drive_id: String(driveId),
      root_item_id: String(rootItemId),
      pilot_folder_item_id: String(pilotItemId),
      pilot_folder_e_tag: pilotRoot?.eTag ?? null,
      subtree_fingerprint: subtreeFingerprint,
      customer_id: "6",
      destination_kind: destination.kind,
      expected_files: pilotExpectedFiles,
      verified_files: filesVerified ? fileRecords.length : 0,
      expected_folders: pilotExpectedFolders,
      verified_folders: foldersVerified ? folderRecords.length : 0,
      expected_bytes: pilotExpectedBytes,
      verified_bytes: bytesVerified ? pilotExpectedBytes : 0,
      status,
    });
  }

  const summary = summarize(resultRecords);
  const complete = changedIds.size === 0 && summary.failed === 0 && summary.unresolved === 0;
  return { complete, run_complete: complete, pilot_complete: mode === "pilot" && pilotComplete || mode === "bulk" && Boolean(reviewedPilot), migration_complete: false, blocked: false, mode, summary, unresolved_changes: changedIds.size, inventory_mode: inventoryOrigin, inventory_items: inventory.items.length };
}

export function summarizeImport(records) {
  return summarize(records);
}

export const importGates = { resolveMapping, targetKey, itemIsDirectory, validateFolderMappings, pilotSubtreeFingerprint };
