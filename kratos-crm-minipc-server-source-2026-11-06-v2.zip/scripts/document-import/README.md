# Kratos document import tooling

## Safety status

This is an isolated import utility. It has **not** been run against OneDrive, SharePoint, Kratos production, or a real customer file. No real credentials, downloads, or uploads were used while implementing or testing it.

The default command is a no-network preflight:

```powershell
node scripts/document-import/cli.mjs
```

It reports only whether required environment settings are present. It does not print their values, connect to Graph, create files, or change production.

## Microsoft device-code sign-in

`device-code-auth.mjs` implements single-tenant public-client device-code flow for Graph `Files.Read offline_access`. It does not accept or send a client secret. Access and refresh tokens remain in process memory, refresh tokens rotate in memory, and concurrent refreshes share one request. Nothing writes tokens to disk or logs them. During sign-in the CLI displays only Microsoft's verification URL and user code.

An Entra public client registration must already exist and be configured for the intended single tenant with the delegated `Files.Read` permission. Set these process environment variables:

- `KRATOS_ENTRA_TENANT_ID`: tenant GUID.
- `KRATOS_ENTRA_CLIENT_ID`: public client application GUID.

To perform a device-code login and read-only check of the configured source root, run:

```powershell
node scripts/document-import/cli.mjs --check-source-login
```

This performs only a Graph `GET` for the root item, then checks that its `webUrl` is exactly the verified HTTPS `Familienhelden2025-my.sharepoint.com/personal/office_familienhelden_at/Documents/Kunden` location (path percent encoding is normalized). It does not enumerate or download customer documents. The launcher prompts only for tenant and client GUIDs and supplies the already verified source drive/root item IDs:

```powershell
./scripts/document-import/start-device-login-check.ps1
```

For the gated synthetic pilot workflow, add `--device-login` to `--pilot`. All existing privacy, pilot, mapping, staging, and ACL checks still apply before the importer starts. A successful connection check alone does not authorize or start a document import. The no-argument command stays offline.

The `pilot` mode downloads only after all explicit gates are set. It requires an exact Graph drive ID, the item ID of the verified `Kunden` folder, a source-folder-to-customer mapping, a private staging directory, an approved pilot folder under customer ID 6, and both privacy and pilot approval environment flags. The pilot inventory is checked against five files, four child folders, and the reviewed total byte count before downloading. Every file is hash-verified and every directory is created before a pilot can be reviewed.

The command-line importer supports **local staging only**. Local staging success is not a Kratos import. Bulk mode is blocked until an authenticated Kratos storage session is available and a complete, reviewed customer-ID-6 pilot has succeeded in R2. The R2 adapter exists as an injected-session interface, but this standalone CLI does not mint or spoof Sites identity headers and currently has no approved session bridge.

## Data flow

1. Verify the configured Graph item is exactly the `Kunden` folder.
2. Read an initial Graph delta snapshot for that folder and follow every `@odata.nextLink` through the final `@odata.deltaLink`.
3. Recursively enumerate all child pages and compare source item IDs and versions with the delta inventory. Missing pages, shared shortcuts, or changed inventory block transfers.
4. Resolve customer ownership only through explicit exact source-folder mappings. Unmapped files and folders are recorded as `unresolved` inventory items without downloading their contents by default.
5. For each mapped file, compare its eTag and size before and after streaming its content to a private `.part` file while computing SHA-256.
6. Reconcile changes since the initial delta link. Changed or deleted source items become `unresolved`; any already-staged destination is preserved.
7. Create targets exclusively, never overwrite. Stream-read the target and compare its SHA-256 and byte count with the source. A conflicting target becomes `unresolved`.

The append-only `checkpoint.jsonl` is keyed by source drive ID, item ID, and eTag. A rerun reuses matching records only after checking the target bytes. The checkpoint also holds opaque Graph delta links and source metadata; treat it as sensitive and keep it inside the private staging root.

### Resume and delta limits

- If the final JSONL record is cut off without a newline, loading the checkpoint truncates only that incomplete tail. A valid final record without a newline is preserved and given a line boundary before the next append. Corruption in any complete line still stops the import.
- Source metadata written to the checkpoint is allowlisted; download URLs, web URLs, unrecognized Graph fields, and token-like properties are not persisted.
- The importer remains **restartable and idempotent per source version**. If `KRATOS_IMPORT_INVENTORY_STATE` is set to a private JSON state path inside the staging root, later invocations request changes from the saved root-scoped Graph delta cursor and merge partial item metadata into the persisted inventory. The importer still recursively lists the entire customer tree on every run and compares IDs, versions, names, sizes, and available parent references before any transfer.
- The inventory cursor and items are atomically replaced only after the recursive listing agrees and a final delta check finds no changes. If Graph rejects the cursor with HTTP 410, the importer performs a controlled full scoped snapshot and recursive reconciliation. Other state errors or scope mismatches fail closed. Without the optional state path, each run uses a full scoped delta snapshot.
- Changes found during a run are marked unresolved; the cursor is not advanced and another invocation is needed. Updates are imported as new immutable source versions. Deletions, moves, and renames update the next inventory, but the destination is not automatically deleted or renamed; prior objects remain for review.

Every report item uses one of four statuses: `successful`, `failed`, `skipped`, or `unresolved`. `complete` is true only when the inventory is reconciled and there are no failed or unresolved records.

## Configuration for a future approved local pilot

Set environment variables only; never pass a token on the command line:

- `GRAPH_ACCESS_TOKEN`: delegated Microsoft Graph read-only session token.
- Or use `KRATOS_ENTRA_TENANT_ID` and `KRATOS_ENTRA_CLIENT_ID` with `--device-login`; no client secret or persisted token is supported.
- `KRATOS_SOURCE_DRIVE_ID`: approved source drive.
- `KRATOS_SOURCE_ROOT_ITEM_ID`: exact item ID of the verified `Kunden` folder.
- `KRATOS_IMPORT_STAGING_DIR`: absolute local private folder.
- `KRATOS_IMPORT_CHECKPOINT`: absolute checkpoint path **inside** staging.
- `KRATOS_IMPORT_INVENTORY_STATE`: optional absolute inventory-state path **inside** staging. Its cursor is scoped to the configured Graph drive and `Kunden` root; do not share it across scopes.
- `KRATOS_IMPORT_FOLDER_MAP`: absolute JSON mapping file **inside** staging; shape: ```json
{"mappings":[{"relativePath":"<exact source folder>","customerId":6,"folderId":"<approved Kratos storage folder id>"}]}
```
- `KRATOS_PILOT_FOLDER_ITEM_ID`: exact source folder item ID for the pilot.
- `KRATOS_PILOT_CUSTOMER_ID`: `6`.
- `KRATOS_IMPORT_PRIVACY_APPROVED`: must be `YES` before any local file is staged.
- `KRATOS_IMPORT_PILOT_APPROVED`: must be `YES` before the pilot downloads.
- `KRATOS_IMPORT_ACL_CONFIRMED`: on Windows, set to `YES` only after applying and verifying the ACL below.

Before `--pilot` or `--review-pilot` reads the checkpoint, the CLI initializes the staging root, requires the checkpoint and mapping inputs to remain under it, and rejects symlink/junction paths. On Windows, `KRATOS_IMPORT_ACL_CONFIRMED=YES` records the operator's confirmation only; the program does not inspect or prove the Windows ACL. Reports expose `windows_acl_verified: false` and `acl_operator_confirmed` separately. Pilot review records are bound to the latest successful pilot for the exact drive, Kunden root, source version, complete subtree fingerprint, mapping, destination, and project. Older checkpoint records without this scope and fingerprint are not eligible for bulk approval and must be rerun and reviewed.

Import reports distinguish `run_complete`, `pilot_complete`, and `migration_complete`. A successful pilot can set the first two flags, but it never sets `migration_complete`; `complete` remains a compatibility alias for current-run completeness only.

Run a real pilot only after its source, local privacy target, and handling of the staged files have been explicitly approved:

```powershell
node scripts/document-import/cli.mjs --pilot
```

## Windows staging ACL

Use a new, dedicated staging directory. Before setting `KRATOS_IMPORT_ACL_CONFIRMED=YES`, apply and verify a private ACL for the current operator account. Example:

```powershell
$stage = $env:KRATOS_IMPORT_STAGING_DIR
icacls $stage /inheritance:r
icacls $stage /grant:r "$($env:USERNAME):(OI)(CI)F"
icacls $stage
```

The directory, source mapping, checkpoint, report, and staged documents may include customer-identifying metadata. Do not place them in a shared folder or sync them to OneDrive. On non-Windows systems, the tool sets mode `0700` on directories and `0600` on files.

## Kratos R2 adapter boundary

`KratosR2SessionDestination` requires an expected Sites project ID, an approved base URL, local private staging, and an injected authenticated session-header provider. It checks `/api/storage/status` before any write and requires project ID and R2 configuration to match. It refuses `oai-authenticated-user-*` headers and never follows redirects. Write requests carry the approved same-origin `Origin`.

Small files use the multipart endpoint up to its verified cap. Larger files use bounded 20 MiB parts and the server's resumable upload session, with source SHA-256 and Graph identity metadata. The adapter re-reads each completed Kratos file as a stream and hashes the returned bytes independently. It stores mapped files under the mapped customer folder, creates and verifies child folders, and leaves source records and target files untouched on conflicts.

Unassigned items are inventory-only by default. Physical quarantine copying requires a separate explicit policy and approval; it is not enabled by the standalone CLI.

## Local Kratos destination

`KratosLocalImportDestination` connects the importer to an explicitly opened local Kratos store. Use an isolated SQLite database, private object storage, a separate private staging directory and an approved base folder for each mapped customer. The standalone CLI retains its existing pilot and bulk gates.

The local destination checks the source identity, mapped customer and folder, byte count and SHA-256. Use a dedicated, initially empty checkpoint for each source and destination pair. Keep it private. Import and review use an exclusive `.lock` file next to the checkpoint. A competing process stops before loading or repairing it. A normal completion or handled error releases the lock.

A process crash can leave its lock file. Before recovering, check the recorded PID and start time and confirm the import has stopped. Move only the stale lock aside and retain the checkpoint. Use a separate inventory-state file for each checkpoint. Programmatic callers should use `runDocumentImport` directly. Wrap low-level checkpoint writes and reviews in `checkpoint.withExclusive`. A changed destination or a mismatched file needs review before a copy can be counted as verified.

The synthetic integration tests run without Graph or a Sites session. Run them from the project directory with the other importer tests.

```powershell
node --experimental-strip-types --test tests/document-import/*.test.mjs
```

## Read-only tools and source references

- Graph source adapter exposes GET-only `getItem`, folder-scoped delta, recursive children listing, and content download methods.
- Graph API pagination and delta reconciliation: [driveItem delta](https://learn.microsoft.com/graph/api/driveitem-delta).
- Content downloads redirect to a short-lived preauthenticated URL; the Graph bearer token is not needed on that URL: [download driveItem content](https://learn.microsoft.com/en-us/graph/api/driveitem-get-content?view=graph-rest-1.0).
- Throttled Graph calls honor `Retry-After` and use exponential backoff when the server omits it: [Graph throttling](https://learn.microsoft.com/graph/throttling).

No command in this folder changes or publishes the Kratos app. No command updates a Graph source item, deletes a source document, overwrites a committed staged file, or deletes a stored Kratos file. Failed/interrupted private `.part` transfer files are cleaned only within the staging tool's own temporary directory.
