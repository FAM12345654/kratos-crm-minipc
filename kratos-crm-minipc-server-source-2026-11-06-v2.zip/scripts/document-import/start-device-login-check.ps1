$ErrorActionPreference = 'Stop'

$tenantId = if ($env:KRATOS_ENTRA_TENANT_ID) { $env:KRATOS_ENTRA_TENANT_ID } else { '7c5e2462-8907-4f2b-9874-55edfd18f0b2' }
$clientId = if ($env:KRATOS_ENTRA_CLIENT_ID) { $env:KRATOS_ENTRA_CLIENT_ID } else { 'fc0ecac4-8bf2-47bb-9dab-7a17630d9bec' }
$guidPattern = '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
if ($tenantId -notmatch $guidPattern -or $clientId -notmatch $guidPattern) {
    throw 'Tenant ID and Client ID must be GUIDs.'
}
if (-not $env:KRATOS_SOURCE_DRIVE_ID) { $env:KRATOS_SOURCE_DRIVE_ID = 'b!bipgTrJF8ESWa_sc4UlJjqVjibBbbBdKo9Z9FXOXOnTtjzzCe4g0SrVHcnRBWKJ7' }
if (-not $env:KRATOS_SOURCE_ROOT_ITEM_ID) { $env:KRATOS_SOURCE_ROOT_ITEM_ID = '016K674QSIYPRS6G3BIZFK7GSQI72C7QKU' }

$env:KRATOS_ENTRA_TENANT_ID = $tenantId
$env:KRATOS_ENTRA_CLIENT_ID = $clientId
Remove-Variable tenantId, clientId

$cliPath = Join-Path $PSScriptRoot 'cli.mjs'
& node $cliPath --check-source-login
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}
