import { lstat, readFile } from "node:fs/promises";
import path from "node:path";
import { GraphReadOnlySource } from "./graph-source.mjs";
import { MemoryDeviceCodeCredential } from "./device-code-auth.mjs";
import { ImportCheckpoint } from "./checkpoint.mjs";
import { InventoryStateStore } from "./inventory-state.mjs";
import { LocalStagingDestination } from "./local-staging.mjs";
import { runDocumentImport } from "./importer.mjs";

const args = new Set(process.argv.slice(2));
const EXPECTED_KUNDEN_ROOT_WEB_URL = "https://Familienhelden2025-my.sharepoint.com/personal/office_familienhelden_at/Documents/Kunden";

function output(value) {
  process.stdout.write(JSON.stringify(value, null, 2) + "\n");
}

function isUnderRoot(root, candidate) {
  const relative = path.relative(path.resolve(root), path.resolve(candidate));
  return relative === "" || (!relative.startsWith(".." + path.sep) && relative !== ".." && !path.isAbsolute(relative));
}

async function assertNoSymlinkComponents(root, candidate) {
  if (!isUnderRoot(root, candidate)) throw new Error("Checkpoint and input files must remain inside the private staging root.");
  const relative = path.relative(path.resolve(root), path.resolve(candidate));
  let current = path.resolve(root);
  for (const segment of relative.split(path.sep).filter(Boolean)) {
    current = path.join(current, segment);
    try {
      const info = await lstat(current);
      if (info.isSymbolicLink()) throw new Error("Staging paths must not traverse symbolic links or junctions.");
    } catch (error) {
      if (error?.code === "ENOENT") break;
      throw error;
    }
  }
}

async function prepareCheckpointRead(stagingDirectory, checkpointPath) {
  if (!stagingDirectory || !path.isAbsolute(stagingDirectory) || !checkpointPath || !path.isAbsolute(checkpointPath)) {
    throw new Error("Set absolute private staging and checkpoint paths before reading import state.");
  }
  if (!isUnderRoot(stagingDirectory, checkpointPath)) throw new Error("Checkpoint must be under the private staging root before it can be loaded or reviewed.");
  const staging = new LocalStagingDestination(stagingDirectory);
  const info = await staging.initialize();
  if (!isUnderRoot(info.rootDirectory, checkpointPath)) throw new Error("Checkpoint resolved outside the verified staging root.");
  const aclOperatorConfirmed = process.env.KRATOS_IMPORT_ACL_CONFIRMED === "YES";
  if (process.platform === "win32" && !aclOperatorConfirmed) throw new Error("On Windows, apply and inspect the staging ACL, then set KRATOS_IMPORT_ACL_CONFIRMED=YES before loading the checkpoint. This flag records operator confirmation; it does not verify the ACL itself.");
  await assertNoSymlinkComponents(info.rootDirectory, checkpointPath);
  return { staging, rootDirectory: info.rootDirectory, aclVerifiedByRuntime: info.aclVerified, aclOperatorConfirmed };
}

function preflight() {
  output({
    mode: "preflight",
    network_access: false,
    source_credentials_present: Boolean(process.env.GRAPH_ACCESS_TOKEN || (process.env.KRATOS_ENTRA_TENANT_ID && process.env.KRATOS_ENTRA_CLIENT_ID)),
    entra_tenant_configured: Boolean(process.env.KRATOS_ENTRA_TENANT_ID),
    entra_public_client_configured: Boolean(process.env.KRATOS_ENTRA_CLIENT_ID),
    source_drive_configured: Boolean(process.env.KRATOS_SOURCE_DRIVE_ID),
    verified_kunden_root_configured: Boolean(process.env.KRATOS_SOURCE_ROOT_ITEM_ID),
    private_staging_configured: Boolean(process.env.KRATOS_IMPORT_STAGING_DIR),
    inventory_state_configured: Boolean(process.env.KRATOS_IMPORT_INVENTORY_STATE),
    privacy_target_approved: process.env.KRATOS_IMPORT_PRIVACY_APPROVED === "YES",
    production_modified: false,
    data_downloaded: false,
    note: "Default command is a no-network preflight. It does not read customer data or create target files.",
  });
}

async function main() {
  if (args.size === 0 || args.has("--dry-run") || args.has("--preflight")) {
    preflight();
    return;
  }
  if (args.has("--device-login") && !args.has("--pilot")) throw new Error("--device-login is supported only with --pilot; use --check-source-login for a read-only connection check.");
  if (args.has("--check-source-login")) {
    const tenantId = process.env.KRATOS_ENTRA_TENANT_ID;
    const clientId = process.env.KRATOS_ENTRA_CLIENT_ID;
    const driveId = process.env.KRATOS_SOURCE_DRIVE_ID;
    const rootItemId = process.env.KRATOS_SOURCE_ROOT_ITEM_ID;
    if (!tenantId || !clientId || !driveId || !rootItemId) throw new Error("--check-source-login requires Entra tenant/client GUIDs, a drive ID, and the verified Kunden root item ID.");
    const credential = new MemoryDeviceCodeCredential({ tenantId, clientId, onUserCode: ({ verificationUri, userCode }) => output({ mode: "device-login", verification_uri: verificationUri, user_code: userCode, note: "Enter this code only at the Microsoft verification page. No credentials or tokens are shown." }) });
    const source = new GraphReadOnlySource({ accessTokenProvider: () => credential.getAccessToken(), expectedRootWebUrl: EXPECTED_KUNDEN_ROOT_WEB_URL });
    await credential.signIn();
    await source.verifyCustomerRoot(driveId, rootItemId);
    output({ mode: "check-source-login", status: "successful", read_only: true, data_downloaded: false });
    return;
  }
  if (args.has("--review-pilot")) {
    const checkpointPath = process.env.KRATOS_IMPORT_CHECKPOINT;
    const driveId = process.env.KRATOS_SOURCE_DRIVE_ID;
    const rootItemId = process.env.KRATOS_SOURCE_ROOT_ITEM_ID;
    if (!driveId || !rootItemId) throw new Error("Pilot review requires the source drive and verified Kunden root IDs.");
    const gate = await prepareCheckpointRead(process.env.KRATOS_IMPORT_STAGING_DIR, checkpointPath);
    const checkpoint = new ImportCheckpoint(checkpointPath);
    await checkpoint.withExclusive(() => checkpoint.reviewPilot({
      driveId,
      rootItemId,
      pilotFolderItemId: process.env.KRATOS_PILOT_FOLDER_ITEM_ID,
      customerId: process.env.KRATOS_PILOT_CUSTOMER_ID,
      confirmReviewed: process.env.KRATOS_IMPORT_PILOT_REVIEWED === "YES",
    }));
    output({ mode: "review-pilot", status: "successful", customer_id: "6", destination_kind: "kratos-r2", checkpoint_private_path: true, windows_acl_verified: gate.aclVerifiedByRuntime, acl_operator_confirmed: gate.aclOperatorConfirmed });
    return;
  }
  if (args.has("--bulk")) {
    throw new Error("Bulk import is blocked in standalone mode: there is no supported authenticated Sites session bridge for Kratos storage. Do not pass or spoof oai-authenticated-user headers.");
  }
  if (!args.has("--pilot")) throw new Error("Select --dry-run or the explicitly gated --pilot flow. Bulk import is blocked.");
  if (process.env.KRATOS_IMPORT_PRIVACY_APPROVED !== "YES") throw new Error("Pilot is blocked until the local staging privacy target is explicitly approved.");
  if (process.env.KRATOS_IMPORT_PILOT_APPROVED !== "YES") throw new Error("Pilot is blocked until the pilot action is explicitly approved.");
  const accessToken = process.env.GRAPH_ACCESS_TOKEN;
  const driveId = process.env.KRATOS_SOURCE_DRIVE_ID;
  const rootItemId = process.env.KRATOS_SOURCE_ROOT_ITEM_ID;
  const folderMapFile = process.env.KRATOS_IMPORT_FOLDER_MAP;
  const stagingDirectory = process.env.KRATOS_IMPORT_STAGING_DIR;
  const checkpointPath = process.env.KRATOS_IMPORT_CHECKPOINT;
  const inventoryStatePath = process.env.KRATOS_IMPORT_INVENTORY_STATE;
  const useDeviceLogin = args.has("--device-login");
  if ((!accessToken && !useDeviceLogin) || !driveId || !rootItemId || !folderMapFile || !stagingDirectory || !checkpointPath) {
    throw new Error("Pilot requires Graph access token or --device-login, drive ID, verified Kunden root item ID, folder mapping file, private staging path, and checkpoint path.");
  }
  if (useDeviceLogin && (!process.env.KRATOS_ENTRA_TENANT_ID || !process.env.KRATOS_ENTRA_CLIENT_ID)) throw new Error("--device-login requires KRATOS_ENTRA_TENANT_ID and KRATOS_ENTRA_CLIENT_ID; no client secret is used.");
  for (const candidate of [folderMapFile, stagingDirectory, checkpointPath, ...(inventoryStatePath ? [inventoryStatePath] : [])]) if (!path.isAbsolute(candidate)) throw new Error("Mapping, staging, checkpoint, and configured inventory-state paths must be absolute.");
  if (!isUnderRoot(stagingDirectory, folderMapFile) || !isUnderRoot(stagingDirectory, checkpointPath) || (inventoryStatePath && !isUnderRoot(stagingDirectory, inventoryStatePath))) throw new Error("Folder map, checkpoint, and inventory state must be stored under the private staging root so one ACL protects imported metadata.");
  const gate = await prepareCheckpointRead(stagingDirectory, checkpointPath);
  await assertNoSymlinkComponents(gate.rootDirectory, folderMapFile);
  if (inventoryStatePath) await assertNoSymlinkComponents(gate.rootDirectory, inventoryStatePath);
  const mappingDoc = JSON.parse(await readFile(folderMapFile, "utf8"));
  if (!Array.isArray(mappingDoc.mappings)) throw new Error("Folder mapping file must contain a mappings array.");
  const checkpoint = new ImportCheckpoint(checkpointPath);
  const credential = useDeviceLogin ? new MemoryDeviceCodeCredential({
    tenantId: process.env.KRATOS_ENTRA_TENANT_ID,
    clientId: process.env.KRATOS_ENTRA_CLIENT_ID,
    onUserCode: ({ verificationUri, userCode }) => output({ mode: "device-login", verification_uri: verificationUri, user_code: userCode, note: "Enter this code only at the Microsoft verification page. No credentials or tokens are shown." }),
  }) : null;
  const source = new GraphReadOnlySource(credential
    ? { accessTokenProvider: () => credential.signIn(), expectedRootWebUrl: EXPECTED_KUNDEN_ROOT_WEB_URL }
    : { accessToken, expectedRootWebUrl: EXPECTED_KUNDEN_ROOT_WEB_URL });
  const destination = gate.staging;
  const inventoryState = inventoryStatePath ? new InventoryStateStore(inventoryStatePath) : null;
  const report = await runDocumentImport({
    mode: "pilot",
    driveId,
    rootItemId,
    folderMappings: mappingDoc.mappings,
    pilotItemId: process.env.KRATOS_PILOT_FOLDER_ITEM_ID,
    pilotCustomerId: process.env.KRATOS_PILOT_CUSTOMER_ID,
    pilotApproved: true,
    source,
    destination,
    checkpoint,
    inventoryState,
    localAclConfirmed: process.env.KRATOS_IMPORT_ACL_CONFIRMED === "YES",
  });
  output({ ...report, destination_kind: "local-staging", final_Kratos_storage: false, customer_names: "omitted", checkpoint_private_path: true, windows_acl_verified: gate.aclVerifiedByRuntime, acl_operator_confirmed: gate.aclOperatorConfirmed });
}

main().catch((error) => {
  process.stderr.write(JSON.stringify({ status: "blocked_or_failed", error_code: error?.code ?? "import_error", message: error?.message ?? "Import failed." }) + "\n");
  process.exitCode = 1;
});
