import { createHash } from "node:crypto";
import { appendFile, mkdir, readFile, chmod, lstat, truncate, open, realpath, unlink } from "node:fs/promises";
import path from "node:path";

export function sourceCheckpointKey({ driveId, itemId, eTag }) {
  if (!driveId || !itemId || !eTag) throw new Error("A checkpoint requires driveId, itemId, and eTag.");
  return createHash("sha256").update(String(driveId) + "\0" + String(itemId) + "\0" + String(eTag)).digest("hex");
}

export function safeSourceMetadata(item) {
  const metadata = {};
  const source = item ?? {};
  for (const key of ["id", "name", "eTag", "cTag", "size", "createdDateTime", "lastModifiedDateTime"]) {
    const value = source[key];
    if (value === null || ["string", "number", "boolean"].includes(typeof value)) metadata[key] = value;
  }
  if (source.file && typeof source.file === "object") {
    metadata.file = {};
    if (typeof source.file.mimeType === "string") metadata.file.mimeType = source.file.mimeType;
  }
  if (source.folder && typeof source.folder === "object") {
    metadata.folder = {};
    if (Number.isInteger(source.folder.childCount)) metadata.folder.childCount = source.folder.childCount;
  }
  if (source.deleted === true || (source.deleted && typeof source.deleted === "object")) metadata.deleted = true;
  if (source.remoteItem === true || (source.remoteItem && typeof source.remoteItem === "object")) metadata.remoteItem = true;
  if (source.parentReference && typeof source.parentReference === "object") {
    metadata.parentReference = {};
    for (const key of ["driveId", "id", "siteId"]) {
      const value = source.parentReference[key];
      if (typeof value === "string") metadata.parentReference[key] = value;
    }
    if (source.parentReference.sharepointIds && typeof source.parentReference.sharepointIds === "object") {
      metadata.parentReference.sharepointIds = {};
      for (const key of ["listId", "listItemId", "listItemUniqueId", "siteId", "webId"]) {
        const value = source.parentReference.sharepointIds[key];
        if (typeof value === "string") metadata.parentReference.sharepointIds[key] = value;
      }
    }
  }
  return metadata;
}

export class ImportCheckpoint {
  constructor(filePath) {
    if (!path.isAbsolute(filePath)) throw new Error("Checkpoint path must be absolute.");
    this.filePath = path.resolve(filePath);
    this.records = [];
    this.latestByKey = new Map();
    this.latestBySource = new Map();
  }

  async withExclusive(run) {
    const name = path.basename(this.filePath);
    if (/\.lock$/i.test(name)) throw new Error("The .lock suffix is reserved for checkpoint locks.");
    if (process.platform === "win32" && (/[:]/.test(name) || /[. ]$/.test(name))) {
      throw new Error("Checkpoint requires a canonical Windows filename.");
    }
    const parent = path.dirname(this.filePath);
    await mkdir(parent, { recursive: true, mode: 0o700 });
    let canonical = path.join(await realpath(parent), name);
    try {
      const info = await lstat(canonical);
      if (info.isSymbolicLink() || !info.isFile() || info.nlink !== 1) throw new Error("Checkpoint must be a regular file without links.");
      canonical = await realpath(canonical);
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
    }
    const lockPath = canonical + ".lock";
    let handle;
    try {
      handle = await open(lockPath, "wx", 0o600);
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
      throw Object.assign(new Error("Checkpoint is locked. Confirm the previous import has stopped before recovery."), { code: "checkpoint_locked" });
    }
    try {
      await handle.writeFile(JSON.stringify({ pid: process.pid, started_at: new Date().toISOString() }) + "\n");
      await this.#loadUnlocked();
      return await run(this);
    } finally {
      await handle.close();
      await unlink(lockPath);
    }
  }

  async load() {
    return this.withExclusive(() => this);
  }

  async #loadUnlocked() {
    this.records = [];
    this.latestByKey.clear();
    this.latestBySource.clear();
    await mkdir(path.dirname(this.filePath), { recursive: true, mode: 0o700 });
    try {
      const info = await lstat(this.filePath);
      if (info.isSymbolicLink() || !info.isFile() || info.nlink !== 1) throw new Error("Checkpoint must be a regular file without links.");
      const raw = await readFile(this.filePath, "utf8");
      const lines = raw.split("\n");
      const hasUnterminatedFinalLine = raw.length > 0 && !raw.endsWith("\n");
      let repairTrailingFragment = false;
      for (let index = 0; index < lines.length; index += 1) {
        const line = lines[index];
        if (!line) continue;
        try {
          const record = JSON.parse(line);
          this.#remember(record);
        } catch {
          if (index === lines.length - 1 && hasUnterminatedFinalLine) {
            repairTrailingFragment = true;
            break;
          }
          throw new Error("Checkpoint contains a corrupt non-final line; refusing to continue.");
        }
      }
      if (repairTrailingFragment) {
        const validPrefix = raw.slice(0, raw.lastIndexOf("\n") + 1);
        await truncate(this.filePath, Buffer.byteLength(validPrefix, "utf8"));
      } else if (hasUnterminatedFinalLine) {
        await appendFile(this.filePath, "\n", { encoding: "utf8", flag: "a" });
      }
      if (process.platform !== "win32") await chmod(this.filePath, 0o600);
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
    }
    return this;
  }

  #remember(record) {
    this.records.push(record);
    if (record.source_key) this.latestByKey.set(record.source_key, record);
    if (record.drive_id && record.item_id) this.latestBySource.set(record.drive_id + "\0" + record.item_id, record);
  }

  latestFor({ driveId, itemId, eTag }) {
    return this.latestByKey.get(sourceCheckpointKey({ driveId, itemId, eTag })) ?? null;
  }

  latestItem({ driveId, itemId }) {
    return this.latestBySource.get(String(driveId) + "\0" + String(itemId)) ?? null;
  }

  getReviewedPilot({ driveId, rootItemId, pilotFolderItemId, destinationKind = "kratos-r2" }) {
    if (!driveId || !rootItemId) return null;
    const completed = [...this.records].reverse().find((record) => record.record_type === "pilot_complete" &&
      String(record.drive_id) === String(driveId) && String(record.root_item_id) === String(rootItemId) &&
      (pilotFolderItemId == null || String(record.pilot_folder_item_id) === String(pilotFolderItemId)));
    if (!completed || completed.status !== "successful" || String(completed.customer_id) !== "6" ||
        completed.destination_kind !== destinationKind || !completed.source_key || !/^[a-f0-9]{64}$/i.test(String(completed.subtree_fingerprint ?? ""))) return null;
    const review = [...this.records].reverse().find((record) => record.record_type === "pilot_review" && record.status === "successful" &&
      String(record.drive_id) === String(driveId) && String(record.root_item_id) === String(rootItemId) &&
      String(record.pilot_folder_item_id) === String(completed.pilot_folder_item_id) &&
      record.destination_kind === destinationKind && record.reviewed_source_key === completed.source_key &&
      record.reviewed_subtree_fingerprint === completed.subtree_fingerprint);
    return review ? { ...completed, review } : null;
  }

  hasReviewedPilot(scope) { return Boolean(this.getReviewedPilot(scope)); }

  async reviewPilot({ driveId, rootItemId, pilotFolderItemId, customerId, confirmReviewed }) {
    if (!confirmReviewed || String(customerId) !== "6" || !driveId || !rootItemId) throw new Error("Pilot review requires explicit confirmation, scoped drive/root IDs, and customer ID 6.");
    const completed = [...this.records].reverse().find((record) => record.record_type === "pilot_complete" &&
      String(record.drive_id) === String(driveId) && String(record.root_item_id) === String(rootItemId) &&
      String(record.pilot_folder_item_id) === String(pilotFolderItemId));
    if (!completed) throw new Error("No fully verified Kratos R2 pilot for this customer folder exists to review.");
    if (completed.status !== "successful" || String(completed.customer_id) !== "6" || completed.destination_kind !== "kratos-r2" || !completed.source_key || !/^[a-f0-9]{64}$/i.test(String(completed.subtree_fingerprint ?? ""))) throw new Error("Latest pilot run for this scoped source is not a complete verified Kratos R2 pilot with a subtree fingerprint.");
    await this.append({ record_type: "pilot_review", drive_id: String(driveId), root_item_id: String(rootItemId), pilot_folder_item_id: String(pilotFolderItemId), customer_id: "6", destination_kind: "kratos-r2", status: "successful", source_key: completed.source_key, reviewed_source_key: completed.source_key, reviewed_subtree_fingerprint: completed.subtree_fingerprint });
  }

  async append(record) {
    const line = JSON.stringify({ recorded_at: new Date().toISOString(), ...record }) + "\n";
    await appendFile(this.filePath, line, { encoding: "utf8", mode: 0o600, flag: "a" });
    if (process.platform !== "win32") await chmod(this.filePath, 0o600);
    this.#remember(record);
  }
}
