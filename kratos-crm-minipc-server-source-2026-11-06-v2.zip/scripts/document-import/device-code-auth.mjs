const AUTHORITY = "https://login.microsoftonline.com";
const GRAPH_SCOPE = "Files.Read offline_access";
const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export class DeviceCodeAuthError extends Error {
  constructor(code, message = "Microsoft device-code authentication failed.") {
    super(message);
    this.name = "DeviceCodeAuthError";
    this.code = code;
  }
}

function safeOAuthError(body, fallback) {
  const known = new Set(["authorization_pending", "slow_down", "access_denied", "expired_token", "invalid_grant", "invalid_client", "invalid_scope", "temporarily_unavailable", "server_error"]);
  return known.has(body?.error) ? body.error : fallback;
}

function validateConfig({ tenantId, clientId, fetchImpl, requestTimeoutMs }) {
  if (!GUID.test(String(tenantId ?? "")) || !GUID.test(String(clientId ?? ""))) {
    throw new DeviceCodeAuthError("invalid_configuration", "A single-tenant Entra tenant ID and public client ID GUID are required.");
  }
  if (typeof fetchImpl !== "function" || !Number.isFinite(requestTimeoutMs) || requestTimeoutMs < 1000) {
    throw new DeviceCodeAuthError("invalid_configuration", "Invalid device-code HTTP configuration.");
  }
}

export class MemoryDeviceCodeCredential {
  #tenantId;
  #clientId;
  #fetch;
  #sleep;
  #onUserCode;
  #timeout;
  #refreshMarginMs;
  #accessToken = null;
  #refreshToken = null;
  #accessExpiresAt = 0;
  #refreshPromise = null;

  constructor({ tenantId, clientId, fetchImpl = fetch, sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)), onUserCode = () => {}, requestTimeoutMs = 15000, refreshMarginMs = 120000 } = {}) {
    validateConfig({ tenantId, clientId, fetchImpl, requestTimeoutMs });
    this.#tenantId = tenantId;
    this.#clientId = clientId;
    this.#fetch = fetchImpl;
    this.#sleep = sleep;
    this.#onUserCode = onUserCode;
    this.#timeout = requestTimeoutMs;
    this.#refreshMarginMs = refreshMarginMs;
  }

  get hasMemoryToken() {
    return Boolean(this.#accessToken || this.#refreshToken);
  }

  async getAccessToken() {
    if (this.#accessToken && Date.now() + this.#refreshMarginMs < this.#accessExpiresAt) return this.#accessToken;
    if (this.#refreshToken) return this.#refreshAccessToken();
    throw new DeviceCodeAuthError("not_authenticated", "Complete device-code sign-in before requesting a Graph token.");
  }

  async signIn() {
    if (this.#accessToken && Date.now() + this.#refreshMarginMs < this.#accessExpiresAt) return this.#accessToken;
    if (this.#refreshToken) return this.#refreshAccessToken();

    const endpoint = AUTHORITY + "/" + encodeURIComponent(this.#tenantId) + "/oauth2/v2.0/devicecode";
    const body = new URLSearchParams({ client_id: this.#clientId, scope: GRAPH_SCOPE });
    const response = await this.#post(endpoint, body, "device_code_request_failed");
    const challenge = await response.json().catch(() => null);
    if (!response.ok || !challenge || typeof challenge.device_code !== "string" || typeof challenge.user_code !== "string" || !Number.isFinite(Number(challenge.expires_in))) {
      throw new DeviceCodeAuthError(safeOAuthError(challenge, "device_code_request_failed"));
    }
    let verifyUrl;
    try { verifyUrl = new URL(challenge.verification_uri); } catch { throw new DeviceCodeAuthError("invalid_device_response"); }
    if (verifyUrl.protocol !== "https:" || verifyUrl.username || verifyUrl.password || (verifyUrl.port && verifyUrl.port !== "443") || !["microsoft.com", "microsoftonline.com"].some((host) => verifyUrl.hostname === host || verifyUrl.hostname.endsWith("." + host))) {
      throw new DeviceCodeAuthError("invalid_device_response");
    }
    this.#onUserCode({ verificationUri: verifyUrl.href, userCode: challenge.user_code });

    const expiresAt = Date.now() + Number(challenge.expires_in) * 1000;
    let intervalMs = Math.max(1000, Number(challenge.interval ?? 5) * 1000);
    const tokenEndpoint = AUTHORITY + "/" + encodeURIComponent(this.#tenantId) + "/oauth2/v2.0/token";
    while (Date.now() < expiresAt) {
      await this.#sleep(Math.min(intervalMs, Math.max(0, expiresAt - Date.now())));
      if (Date.now() >= expiresAt) break;
      const tokenResponse = await this.#post(tokenEndpoint, new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:device_code",
        client_id: this.#clientId,
        device_code: challenge.device_code,
      }), "token_request_failed");
      const tokenBody = await tokenResponse.json().catch(() => null);
      if (tokenResponse.ok) return this.#acceptTokens(tokenBody);
      const error = safeOAuthError(tokenBody, "token_request_failed");
      if (error === "authorization_pending") continue;
      if (error === "slow_down") { intervalMs += 5000; continue; }
      throw new DeviceCodeAuthError(error);
    }
    throw new DeviceCodeAuthError("expired_token", "Device-code sign-in expired before approval.");
  }

  async #refreshAccessToken() {
    if (this.#refreshPromise) return this.#refreshPromise;
    this.#refreshPromise = this.#performRefresh();
    try { return await this.#refreshPromise; } finally { this.#refreshPromise = null; }
  }

  async #performRefresh() {
    const endpoint = AUTHORITY + "/" + encodeURIComponent(this.#tenantId) + "/oauth2/v2.0/token";
    const response = await this.#post(endpoint, new URLSearchParams({
      grant_type: "refresh_token",
      client_id: this.#clientId,
      refresh_token: this.#refreshToken,
      scope: GRAPH_SCOPE,
    }), "refresh_failed");
    const body = await response.json().catch(() => null);
    if (!response.ok) {
      const code = safeOAuthError(body, "refresh_failed");
      if (code === "invalid_grant" || code === "access_denied") {
        this.#accessToken = null;
        this.#refreshToken = null;
        this.#accessExpiresAt = 0;
      }
      throw new DeviceCodeAuthError(code);
    }
    return this.#acceptTokens(body, true);
  }

  #acceptTokens(body, preserveRefreshToken = false) {
    if (!body || typeof body.access_token !== "string" || !body.access_token || !Number.isFinite(Number(body.expires_in)) || Number(body.expires_in) <= 0) throw new DeviceCodeAuthError("invalid_token_response");
    this.#accessToken = body.access_token;
    if (typeof body.refresh_token === "string" && body.refresh_token) this.#refreshToken = body.refresh_token;
    else if (!preserveRefreshToken) this.#refreshToken = null;
    this.#accessExpiresAt = Date.now() + Number(body.expires_in) * 1000;
    return this.#accessToken;
  }

  async #post(url, body, fallbackCode) {
    let response;
    try {
      response = await this.#fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
        body,
        redirect: "manual",
        signal: AbortSignal.timeout(this.#timeout),
      });
    } catch {
      throw new DeviceCodeAuthError(fallbackCode, "Microsoft identity endpoint request failed or timed out.");
    }
    if (response.status >= 300 && response.status < 400) {
      try { await response.body?.cancel?.(); } catch {}
      throw new DeviceCodeAuthError("identity_redirect_rejected");
    }
    return response;
  }
}

export const deviceCodeAuthConfig = { authority: AUTHORITY, scope: GRAPH_SCOPE };
