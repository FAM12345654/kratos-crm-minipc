import test from 'node:test';
import assert from 'node:assert/strict';
import {fetchChatFile,MAX_CHAT_FILE_BYTES} from '../lib/mcp-file-input.ts';

test('chat attachment input rejects arbitrary hosts before any network call', async()=>{
  for(const url of ['http://oaiusercontent.com/a','https://127.0.0.1/a','https://oaiusercontent.com.evil.invalid/a','https://user:secret@a.oaiusercontent.com/a','https://a.oaiusercontent.com:8443/a'])
    await assert.rejects(fetchChatFile({file_id:'file_qa',download_url:url}));
});
test('chat attachment preserves binary bytes with safe fetch options', async()=>{
  const original=globalThis.fetch;
  globalThis.fetch=async(_url,options)=>{assert.equal(options.redirect,'error');assert.equal(options.headers,undefined);return new Response(new Uint8Array([0,255,1,128]),{headers:{'content-length':'4'}});};
  try{const file=await fetchChatFile({file_id:'file_qa',download_url:'https://files.oaiusercontent.com/qa',file_name:'ü-test.bin'});assert.deepEqual(new Uint8Array(await file.arrayBuffer()),new Uint8Array([0,255,1,128]));assert.equal(file.name,'ü-test.bin');}finally{globalThis.fetch=original;}
});
test('chat attachment rejects an oversized response before buffering', async()=>{
  const original=globalThis.fetch;globalThis.fetch=async()=>new Response('qa',{headers:{'content-length':String(MAX_CHAT_FILE_BYTES+1)}});
  try{await assert.rejects(fetchChatFile({file_id:'file_qa',download_url:'https://files.oaiusercontent.com/qa'}),/20 MiB/);}finally{globalThis.fetch=original;}
});
