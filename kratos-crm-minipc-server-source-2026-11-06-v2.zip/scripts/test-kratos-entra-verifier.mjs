import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPair, exportJWK, createLocalJWKSet, SignJWT } from 'jose';
import { createKratosEntraJwtVerifier, createKratosRemoteEntraJwtVerifier } from '../lib/kratos-entra-verifier.ts';

const tenantId = '11111111-1111-4111-8111-111111111111';
const apiClientId = '22222222-2222-4222-8222-222222222222';
const clientId = '33333333-3333-4333-8333-333333333333';
const oid = '44444444-4444-4444-8444-444444444444';
const config = { tenantId, apiClientId, allowedClientIds: [clientId] };
const issuer = `https://login.microsoftonline.com/${tenantId}/v2.0`;
const { privateKey, publicKey } = await generateKeyPair('RS256');
const jwk = { ...await exportJWK(publicKey), kid: 'synthetic-entra-key', alg: 'RS256', use: 'sig' };
const verificationKey = createLocalJWKSet({ keys: [jwk] });
const verify = createKratosEntraJwtVerifier({ ...config, verificationKey });
const now = () => Math.floor(Date.now() / 1000);
async function sign(overrides = {}, header = { alg: 'RS256', typ: 'JWT', kid: jwk.kid }, key = privateKey) {
  return new SignJWT({ iss: issuer, aud: apiClientId, sub: 'synthetic-pairwise-subject', tid: tenantId, oid,
    ver: '2.0', azp: clientId, scp: 'kratos.read', iat: now(), nbf: now() - 1, exp: now() + 5400, ...overrides })
    .setProtectedHeader(header).sign(key);
}

test('Entra delegated access token maps tenant/object identity and only the internal read scope', async () => {
  assert.deepEqual(await verify(await sign({ scp: 'openid kratos.read unrelated.write' })), {
    subject: `${tenantId}:${oid}`, scopes: ['kratos:read'],
  });
  assert.deepEqual(await verify(await sign({ idtyp: 'user', sub: 'different-pairwise-subject' })), {
    subject: `${tenantId}:${oid}`, scopes: ['kratos:read'],
  });
});

test('rejects other tenant, issuer, audience, client, version and malformed identities', async () => {
  for (const claims of [{ tid: oid }, { iss: `https://login.microsoftonline.com/${oid}/v2.0` },
    { iss: 'https://login.microsoftonline.com/common/v2.0' }, { aud: clientId }, { aud: [apiClientId] },
    { azp: oid }, { azp: [clientId] }, { ver: '1.0' }, { oid: 'user@example.invalid' }, { sub: '' }]) {
    await assert.rejects(verify(await sign(claims)));
  }
});

test('rejects application-only, roles-only, ID-token-shaped and wrong-scope tokens', async () => {
  for (const claims of [{ idtyp: 'app' }, { idtyp: [] }, { scp: 'kratos:read' }, { scp: 'other.kratos.read' },
    { scp: ['kratos.read'] }, { scp: undefined, roles: ['kratos.read'] },
    { scp: undefined, aud: clientId, nonce: 'synthetic-id-token' }, { scp: '' }]) {
    await assert.rejects(verify(await sign(claims)));
  }
});

test('requires numeric time claims, enforces expiry/not-before and the two-hour ceiling', async () => {
  const issuedAt = now();
  for (const claims of [{ exp: now() - 1 }, { nbf: now() + 60 }, { iat: now() + 60 },
    { iat: issuedAt, exp: issuedAt + 7201 }, { iat: now() - 7300, exp: now() + 10 }, { nbf: undefined },
    { iat: undefined }, { exp: undefined }, { iat: '1' }, { exp: now() + 0.5 }, { nbf: now() + 6000 }]) {
    await assert.rejects(verify(await sign(claims)));
  }
});

test('rejects forged signatures, unsigned tokens and incompatible token headers', async () => {
  const other = await generateKeyPair('RS256');
  await assert.rejects(verify(await sign({}, undefined, other.privateKey)));
  await assert.rejects(verify('eyJhbGciOiJub25lIn0.eyJzdWIiOiJvd25lciJ9.'));
  await assert.rejects(verify(await sign({}, { alg: 'RS256', typ: 'at+jwt', kid: jwk.kid })));
  const ec = await generateKeyPair('ES256');
  await assert.rejects(verify(await sign({}, { alg: 'ES256', typ: 'JWT' }, ec.privateKey)));
});

test('configuration is bounded and cannot provide arbitrary tenant or key endpoints', () => {
  for (const override of [{ tenantId: 'common' }, { tenantId: 'https://evil.invalid' }, { apiClientId: '' },
    { allowedClientIds: [] }, { allowedClientIds: [apiClientId] }, { allowedClientIds: [clientId, clientId] },
    { allowedClientIds: Array(21).fill(clientId) }, { allowedClientIds: ['https://evil.invalid'] }]) {
    assert.throws(() => createKratosRemoteEntraJwtVerifier({ ...config, ...override }));
    assert.throws(() => createKratosEntraJwtVerifier({ ...config, ...override, verificationKey }));
  }
  assert.throws(() => createKratosEntraJwtVerifier({ ...config, verificationKey: undefined }));
});

test('remote verifier fetches only pinned tenant keys without redirects or bearer credentials', async () => {
  const previousFetch = globalThis.fetch;
  const requests = [];
  globalThis.fetch = async (url, options) => {
    requests.push({ url: String(url), options });
    return new Response(JSON.stringify({ keys: [jwk] }), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  try {
    const remote = createKratosRemoteEntraJwtVerifier(config);
    assert.deepEqual(await remote(await sign()), { subject: `${tenantId}:${oid}`, scopes: ['kratos:read'] });
    assert.equal(requests.length, 1);
    assert.equal(requests[0].url, `https://login.microsoftonline.com/${tenantId}/discovery/v2.0/keys`);
    assert.equal(requests[0].options.redirect, 'error');
    assert.equal(new Headers(requests[0].options.headers).has('authorization'), false);
  } finally { globalThis.fetch = previousFetch; }
});
