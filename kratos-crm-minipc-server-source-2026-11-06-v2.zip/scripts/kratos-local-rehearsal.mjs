import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, mkdtemp, readFile, readdir, realpath, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { generateKeyPair, SignJWT } from "jose";
import { runKratosProcessCheck, verifyProcessReport } from "./kratos-process-check.mjs";

const project = fileURLToPath(new URL("../", import.meta.url));
const origin = "https://kratos-rehearsal.invalid";
const issuer = "https://kratos-issuer.rehearsal.invalid";
const owner = "rehearsal-owner";
const customerId = 1;
const sample = Buffer.from([0, 0xff, 0x0d, 0x0a, 0x20]);

async function loadModules() {
  const bundle = await build({
    stdin: {
      contents: "export * from './integrations/kratos-local-server/server'; export * from './lib/kratos-local-backup';",
      resolveDir: project,
    },
    bundle: true, platform: "node", format: "esm", write: false, logLevel: "silent",
  });
  const encoded = Buffer.from(bundle.outputFiles[0].contents).toString("base64");
  return import("data:text/javascript;base64," + encoded);
}

async function seedDatabase(databasePath) {
  const database = new DatabaseSync(databasePath);
  try {
    const migrationDirectory = path.join(project, "drizzle");
    const migrations = (await readdir(migrationDirectory)).filter((name) => /^\d{4}_.*\.sql$/.test(name)).sort();
    assert.ok(migrations.length);
    for (const name of migrations) database.exec(await readFile(path.join(migrationDirectory, name), "utf8"));
    database.prepare("INSERT INTO customers(id,first_name,last_name,status,updated_by) VALUES (?,?,?,?,?)")
      .run(customerId, "Synthetic", "Rehearsal", "Kunde", owner);
  } finally { database.close(); }
}

async function rehearse() {
  if (process.argv.length !== 2) throw new Error("This rehearsal takes no arguments.");
  const { createKratosLocalServer, createKratosLocalBackup, restoreKratosLocalBackup } = await loadModules();
  const tempRoot = await realpath(os.tmpdir());
  const directory = await mkdtemp(path.join(tempRoot, "kratos-rehearsal-"));
  let app;
  try {
    const databasePath = path.join(directory, "rehearsal.sqlite");
    const documentRoot = path.join(directory, "documents");
    await mkdir(documentRoot, { mode: 0o700 });
    await seedDatabase(databasePath);
    const { privateKey, publicKey } = await generateKeyPair("RS256");
    const bearer = await new SignJWT({ scope: "kratos:read kratos:documents:write" }).setProtectedHeader({ alg: "RS256", typ: "at+jwt" })
      .setIssuer(issuer).setAudience(origin).setSubject(owner).setIssuedAt().setExpirationTime("2m").sign(privateKey);
    const localConfig = {
      resourceOrigin: origin, issuer, jwksUri: issuer + "/keys",
      allowedSubjects: [owner], verificationKey: async () => publicKey, port: 0,
    };
    app = await createKratosLocalServer({
      ...localConfig, databasePath,
      documentUploads: { root: documentRoot, allowedCustomerIds: [customerId], privateRootConfirmed: true },
    });
    const uploadAddress = await app.listen();
    const upload = () => fetch("http://127.0.0.1:" + uploadAddress.port + "/v1/documents/upload", {
      method: "POST", body: sample, signal: AbortSignal.timeout(5000), redirect: "error",
      headers: {
        authorization: "Bearer " + bearer, "content-type": "application/octet-stream",
        "x-kratos-customer-id": String(customerId), "x-kratos-file-name": "rehearsal.bin",
        "x-kratos-sha256": createHash("sha256").update(sample).digest("hex"),
        "idempotency-key": "synthetic-rehearsal",
      },
    });
    const first = await upload();
    assert.equal(first.status, 201);
    const { id: fileId } = await first.json();
    const retry = await upload();
    assert.equal(retry.status, 200);
    assert.equal((await retry.json()).id, fileId);
    await app.close();
    app = undefined;
    const backupDirectory = path.join(directory, "backup");
    const backup = await createKratosLocalBackup({ databasePath, documentRoot, destination: backupDirectory, privateTargetConfirmed: true });
    const restored = await restoreKratosLocalBackup({
      backupDirectory, destination: path.join(directory, "restored"), privateTargetConfirmed: true,
      expectedManifestSha256: backup.manifestSha256,
    });
    app = await createKratosLocalServer({
      ...localConfig, databasePath: restored.databasePath,
      documentDownloads: { root: restored.documentRoot, allowedCustomerIds: [customerId] },
    });
    const { port } = await app.listen();
    const base = "http://127.0.0.1:" + port;
    const report = await runKratosProcessCheck({ databasePath: restored.databasePath, gatewayUrl: base });
    assert.equal(report.status, "ok");
    assert.equal(verifyProcessReport(report), true);
    const response = await fetch(base + "/v1/documents/" + fileId, {
      headers: { authorization: "Bearer " + bearer }, signal: AbortSignal.timeout(5000), redirect: "error",
    });
    assert.equal(response.status, 200);
    assert.deepEqual(Buffer.from(await response.arrayBuffer()), sample);
    return { status: "ok", scope: "synthetic_rehearsal", run_id: report.run_id, upload_retry_verified: true, backup_files: backup.files, restored_download_bytes: sample.length };
  } finally {
    try { await app?.close(); }
    finally {
      assert.equal(path.dirname(await realpath(directory)), tempRoot);
      assert.ok(path.basename(directory).startsWith("kratos-rehearsal-"));
      await rm(directory, { recursive: true, force: true });
    }
  }
}

try { process.stdout.write(JSON.stringify(await rehearse()) + "\n"); }
catch {
  process.stderr.write('{"status":"failed","scope":"synthetic_rehearsal"}\n');
  process.exitCode = 1;
}
