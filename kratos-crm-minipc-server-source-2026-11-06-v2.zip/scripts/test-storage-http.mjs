import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const base=process.env.KRATOS_QA_URL || 'http://127.0.0.1:8787';
if(new URL(base).hostname!=='127.0.0.1') throw Error('This synthetic test only permits loopback.');
const headers={'oai-authenticated-user-id':'synthetic-storage-qa','oai-authenticated-user-email':'qa@example.invalid',origin:base};
const request=(route,init={})=>fetch(base+route,{...init,headers:{...headers,...init.headers}});
const unauth=await fetch(base+'/api/storage/files');assert.equal(unauth.status,401);
const folderResponse=await request('/api/storage/folders',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'QA ü Sonderzeichen',customer_id:1})});
assert.ok(folderResponse.ok,'Folder create');const folder=await folderResponse.json();const folderId=folder.folder_id??folder.folder?.id;assert.ok(folderId);
const bytes=new Uint8Array([0,255,1,127,128,9,13,10]);const sha=createHash('sha256').update(bytes).digest('hex');
async function upload(customer=1){const form=new FormData();form.set('file',new File([bytes],'QA ü.bin'));form.set('customer_id',String(customer));if(customer===1)form.set('folder_id',String(folderId));form.set('source_drive_id','synthetic-drive');form.set('source_item_id','synthetic-item');form.set('source_version','synthetic-v1');form.set('source_path','QA/ü.bin');form.set('source_sha256',sha);return request('/api/storage/files',{method:'POST',body:form});}
const response=await upload();assert.ok(response.ok,'Binary upload');const stored=await response.json();assert.equal(stored.sha256,sha);assert.ok(stored.file_id);
const download=await request('/api/storage/files/'+stored.file_id);assert.ok(download.ok);assert.match(download.headers.get('content-disposition'),/^attachment/);assert.equal(download.headers.get('x-content-type-options'),'nosniff');assert.match(download.headers.get('cache-control'),/no-store/);assert.deepEqual(new Uint8Array(await download.arrayBuffer()),bytes);
const repeated=await upload();assert.ok(repeated.ok);const duplicate=await repeated.json();assert.equal(duplicate.file_id,stored.file_id);assert.equal(duplicate.duplicate,true);
const conflict=await upload(2);assert.equal(conflict.ok,false,'Source identity must not change customer');
const metadata=await request('/api/storage/files/'+stored.file_id+'/metadata');const meta=await metadata.json();assert.equal('object_key' in meta,false);
const denied=await fetch(base+'/api/storage/files/'+stored.file_id);assert.equal(denied.status,401);
const zero=new FormData();zero.set('file',new File([],'QA empty.bin'));zero.set('customer_id','1');const emptyResponse=await request('/api/storage/files',{method:'POST',body:zero});assert.ok(emptyResponse.ok,'Zero byte upload');const empty=await emptyResponse.json();assert.equal(empty.size_bytes,0);assert.equal(empty.sha256,createHash('sha256').digest('hex'));
console.log(JSON.stringify({passed:true,checks:['private-auth','folders','binary-roundtrip','sha256','zero-bytes','source-idempotency','customer-conflict','private-metadata']}));
