# Kratos Mini-PC Server Source

Source bundle for the Kratos local read-only API gateway and the shared application code. It contains source and configuration files only: no customer database, document files, credentials, private keys, build output, or node_modules.

## Local synthetic rehearsal

Requirements: Windows x64/ARM64 as appropriate, Node.js 22.16 or newer, and pnpm 11.

    pnpm install --frozen-lockfile
    node scripts/kratos-local-rehearsal.mjs

The rehearsal uses temporary synthetic data and removes its temporary files. A successful result is only a local technical rehearsal; it does not establish Mini-PC installation, customer-data migration, Microsoft login, or external HTTPS access.

## Starting the API

node scripts/start-kratos-local.mjs requires an existing local SQLite database that matches the Kratos schema and a complete operator OAuth configuration. It binds only to 127.0.0.1; it does not create or migrate a database. Do not point it at a Cloudflare emulator database or production data. Do not enable LAN or Internet access from this bundle.

The existing Sites/Vinext UI still uses Cloudflare D1 and Sites identity. This package does not turn that UI into a standalone Windows CRM and is not a production installer.
