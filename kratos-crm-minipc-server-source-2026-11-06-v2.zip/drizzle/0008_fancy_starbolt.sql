ALTER TABLE `customer_contracts` ADD `policy_number` text;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `conclusion_date` text;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `conclusion_year` integer;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `main_due_date` text;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `duration_months` integer;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `notice_period_count` integer;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `notice_period_unit` text;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `next_eligible_termination_date` text;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `latest_notice_receipt_date` text;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `jurisdiction` text;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `verification_status` text DEFAULT 'unverified' NOT NULL;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `source_reference` integer REFERENCES customer_documents(id);--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `verified_by` text;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `verified_at` text;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `lifecycle` text DEFAULT 'unverified' NOT NULL;--> statement-breakpoint
ALTER TABLE `customer_contracts` ADD `replacement_contract_id` integer REFERENCES customer_contracts(id);--> statement-breakpoint
CREATE INDEX `customer_contracts_replacement_contract_idx` ON `customer_contracts` (`replacement_contract_id`);