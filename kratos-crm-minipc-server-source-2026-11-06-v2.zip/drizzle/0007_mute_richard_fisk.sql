CREATE TABLE `storage_audit_events` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`file_id` integer,
	`folder_id` integer,
	`action` text NOT NULL,
	`actor_email` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`file_id`) REFERENCES `storage_files`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`folder_id`) REFERENCES `storage_folders`(`id`) ON UPDATE no action ON DELETE restrict
);
--> statement-breakpoint
CREATE INDEX `storage_audit_file_idx` ON `storage_audit_events` (`file_id`,`id`);--> statement-breakpoint
CREATE INDEX `storage_audit_folder_idx` ON `storage_audit_events` (`folder_id`,`id`);--> statement-breakpoint
ALTER TABLE `storage_files` ADD `source_sha256` text;--> statement-breakpoint
ALTER TABLE `storage_files` ADD `source_created_at` text;--> statement-breakpoint
ALTER TABLE `storage_files` ADD `source_modified_at` text;