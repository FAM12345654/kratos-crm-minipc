CREATE TABLE `audit_events` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`customer_id` integer NOT NULL,
	`action` text NOT NULL,
	`changed_fields` text NOT NULL,
	`actor_email` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`first_name` text NOT NULL,
	`last_name` text NOT NULL,
	`phone` text,
	`email` text,
	`adviser` text,
	`status` text DEFAULT 'Kunde' NOT NULL,
	`folder_name` text,
	`internal_note` text,
	`last_contact_at` text,
	`next_follow_up_at` text,
	`next_follow_up_note` text,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_by` text DEFAULT 'system-import' NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `customers_name_phone_unique` ON `customers` (`first_name`,`last_name`,`phone`);--> statement-breakpoint
CREATE INDEX `customers_name_idx` ON `customers` (`last_name`,`first_name`);--> statement-breakpoint
CREATE INDEX `customers_phone_idx` ON `customers` (`phone`);