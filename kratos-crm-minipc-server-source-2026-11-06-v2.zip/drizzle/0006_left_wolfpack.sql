CREATE TABLE `storage_files` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`customer_id` integer,
	`folder_id` integer,
	`file_name` text NOT NULL,
	`object_key` text NOT NULL,
	`size_bytes` integer NOT NULL,
	`mime_type` text NOT NULL,
	`sha256` text,
	`source_drive_id` text,
	`source_item_id` text,
	`source_version` text,
	`source_path` text,
	`import_state` text DEFAULT 'pending' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`created_by` text NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`folder_id`) REFERENCES `storage_folders`(`id`) ON UPDATE no action ON DELETE restrict
);
--> statement-breakpoint
CREATE UNIQUE INDEX `storage_files_object_key_unique` ON `storage_files` (`object_key`);--> statement-breakpoint
CREATE UNIQUE INDEX `storage_files_source_version_unique` ON `storage_files` (`source_drive_id`,`source_item_id`,`source_version`);--> statement-breakpoint
CREATE INDEX `storage_files_customer_idx` ON `storage_files` (`customer_id`,`created_at`,`id`);--> statement-breakpoint
CREATE INDEX `storage_files_folder_idx` ON `storage_files` (`folder_id`,`created_at`,`id`);--> statement-breakpoint
CREATE INDEX `storage_files_state_idx` ON `storage_files` (`import_state`,`id`);--> statement-breakpoint
CREATE TABLE `storage_folders` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`customer_id` integer,
	`parent_folder_id` integer,
	`scope_key` text NOT NULL,
	`path_key` text NOT NULL,
	`name` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`created_by` text NOT NULL,
	FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`parent_folder_id`) REFERENCES `storage_folders`(`id`) ON UPDATE no action ON DELETE restrict
);
--> statement-breakpoint
CREATE UNIQUE INDEX `storage_folders_scope_path_unique` ON `storage_folders` (`scope_key`,`path_key`);--> statement-breakpoint
CREATE INDEX `storage_folders_parent_idx` ON `storage_folders` (`parent_folder_id`,`customer_id`);--> statement-breakpoint
CREATE INDEX `storage_folders_customer_idx` ON `storage_folders` (`customer_id`,`path_key`);--> statement-breakpoint
CREATE TABLE `storage_upload_parts` (
	`upload_id` text NOT NULL,
	`part_number` integer NOT NULL,
	`etag` text NOT NULL,
	`size_bytes` integer NOT NULL,
	`sha256` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`upload_id`) REFERENCES `storage_uploads`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `storage_upload_parts_upload_part_unique` ON `storage_upload_parts` (`upload_id`,`part_number`);--> statement-breakpoint
CREATE TABLE `storage_uploads` (
	`id` text PRIMARY KEY NOT NULL,
	`file_id` integer NOT NULL,
	`owner_email` text NOT NULL,
	`object_key` text NOT NULL,
	`r2_upload_id` text NOT NULL,
	`expected_size_bytes` integer NOT NULL,
	`status` text DEFAULT 'uploading' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`file_id`) REFERENCES `storage_files`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `storage_uploads_object_key_unique` ON `storage_uploads` (`object_key`);