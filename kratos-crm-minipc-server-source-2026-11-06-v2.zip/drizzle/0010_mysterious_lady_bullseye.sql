CREATE TABLE `kratos_case_events` (
	`owner_subject` text NOT NULL,
	`case_id` text NOT NULL,
	`event_id` text NOT NULL,
	`event_type` text NOT NULL,
	`payload_fingerprint` text NOT NULL,
	`actor_id` text NOT NULL,
	`applied_version` integer NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	PRIMARY KEY(`owner_subject`, `case_id`, `event_id`),
	FOREIGN KEY (`owner_subject`,`case_id`) REFERENCES `kratos_cases`(`owner_subject`,`case_id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `kratos_case_events_version_idx` ON `kratos_case_events` (`owner_subject`,`case_id`,`applied_version`);--> statement-breakpoint
CREATE TABLE `kratos_case_outbox` (
	`owner_subject` text NOT NULL,
	`case_id` text NOT NULL,
	`action_id` text NOT NULL,
	`action_type` text NOT NULL,
	`status` text DEFAULT 'pending_review' NOT NULL,
	`proposal_json` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	PRIMARY KEY(`owner_subject`, `action_id`),
	FOREIGN KEY (`owner_subject`,`case_id`) REFERENCES `kratos_cases`(`owner_subject`,`case_id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `kratos_case_outbox_case_idx` ON `kratos_case_outbox` (`owner_subject`,`case_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `kratos_cases` (
	`owner_subject` text NOT NULL,
	`case_id` text NOT NULL,
	`version` integer NOT NULL,
	`snapshot_json` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	PRIMARY KEY(`owner_subject`, `case_id`)
);
--> statement-breakpoint
CREATE INDEX `kratos_cases_owner_updated_idx` ON `kratos_cases` (`owner_subject`,`updated_at`,`case_id`);