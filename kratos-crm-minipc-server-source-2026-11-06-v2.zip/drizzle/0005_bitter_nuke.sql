CREATE TABLE `customer_contracts` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`customer_id` integer NOT NULL,
	`insurance_type` text NOT NULL,
	`provider` text,
	`status` text DEFAULT 'Ungeprüft' NOT NULL,
	`start_date` text,
	`end_date` text,
	`cancellation_deadline` text,
	`document_url` text,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_by` text NOT NULL,
	FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON UPDATE no action ON DELETE restrict
);
--> statement-breakpoint
CREATE INDEX `customer_contracts_customer_idx` ON `customer_contracts` (`customer_id`);--> statement-breakpoint
CREATE INDEX `customer_contracts_status_idx` ON `customer_contracts` (`status`);