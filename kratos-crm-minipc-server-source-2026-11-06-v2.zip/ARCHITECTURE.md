# Kratos – Architektur

## Ist
Sites/Vinext-Anwendung mit Cloudflare-D1-Bindung, bestehender privater Sites-Identität und MCP. Separater synthetischer Dev-Kontext. Gemeinsame Toolgeschäftslogik in lib/kratos-tool-service.ts. Dokumentenspeicher-/Multipart-Implementierung mit R2-Adapter, Graph-Nur-Lesen-Importer und privatem Checkpoint. Portabler Gateway mit OAuth-Tokenprüfung vorbereitet, kein externer Livezugang behauptet.

## Ziel
Athena ist der autorisierte Assistent, Kratos Daten-/Werkzeugdienst. Kunden-ID und Graph-Drive-/Item-ID verknüpfen Datensätze und Originale. Physische Kopien nur ins freigegebene Ziel, Originale bleiben unverändert. Vertragsdaten unterscheiden verifizierte Werte, Quelle und ungeklärte Angaben. Aktuelle/ehemalige Polizzen logisch trennen; Ablöse erst nach Nachweis.

Vorgänge bekommen stabile IDs, Zustände und idempotente Integrationsaktionen. Kein stiller Versand, keine pauschale Aufgabe allein bei Dokumenteingang. Risiken/Deckungslücken werden als überprüfbare Befunde mit Quellen zur fachlichen Prüfung erfasst, nicht als automatisch gesicherte Rechts-/Deckungsaussage.

Entwicklung auf Windows-Laptop. Mini-PC-Betriebssystem nach Hardwarecheck; Windows und Linux Desktop LTS prüfen. Adapter statt Cloudflare-Annahmen, reproduzierbare Laufzeit, minimale Dienstrechte, Secrets getrennt, Healthchecks und Wiederherstellungsprobe. Keine Produktionsunterbrechung oder Umstellung ohne konkreten Plan und Freigabe.

Lokaler Windows-/Node-Leseserver: ausschließlich Loopback mit nativer SQLite-readonly-Datei. Authentifizierung wahlweise bisheriges generisches JWT-Profil oder explizites Single-Tenant-Entra-v2-Profil. Entra trennt GUID-Audience (API) vom veröffentlichten HTTPS-Ressourcenscope und bindet Benutzer an tenant:oid. Der neue Modus ist synthetisch über HTTP getestet; Entra-Registrierungen, HTTPS-Proxy und echter Login bleiben offen. Worker/Sites-Produktion erhalten ihr bisheriges Profil.
