import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { spawnSync } from 'node:child_process';
import { mkdtemp, mkdir, readFile, readdir, writeFile, rm, access } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { createHash } from 'node:crypto';
const script = path.resolve('scripts/kratos-local-documents.mjs');
const runtime = path.resolve('.wrangler/kratos-local-documents');
async function bundleCount() { try { return (await readdir(runtime)).length; } catch (error) { if (error.code === 'ENOENT') return 0; throw error; } }
function run(args, env, cwd) {
 const clean = { ...process.env }; for (const key of Object.keys(clean)) if (key.startsWith('KRATOS_DOC_')) delete clean[key];
 return spawnSync(process.execPath, [script, ...args], { cwd, env: { ...clean, ...env }, encoding: 'utf8', timeout: 20000, windowsHide: true });
}
function complete(result) { assert.equal(result.status, 0, result.stderr); const output = JSON.parse(result.stdout); assert.equal(output.status, 'complete'); return output; }
function rejected(result) { assert.equal(result.status, 1); assert.equal(result.stdout, ''); assert.equal(result.stderr.trim(), '{"error":"Kratos local document operation failed."}'); }
async function fixture(runTest) {
 const dir = await mkdtemp(path.join(os.tmpdir(), 'kratos-doc-cli-test-')), databasePath = path.join(dir, 'synthetic.sqlite'), root = path.join(dir, 'documents');
 await mkdir(root); const db = new DatabaseSync(databasePath);
 for (const name of (await readdir('drizzle')).filter(x => /^\d{4}_.*\.sql$/.test(x)).sort()) db.exec((await readFile(path.join('drizzle', name), 'utf8')).replaceAll('--> statement-breakpoint', ''));
 db.prepare("INSERT INTO customers(id,first_name,last_name,authority_status,adviser,status,updated_by) VALUES (1,'Synthetic','CLI','Ungeprüft','synthetic','Kunde','synthetic')").run(); db.close();
 const env = { KRATOS_DOC_DB_PATH: databasePath, KRATOS_DOC_ROOT: root, KRATOS_DOC_OWNER_SUBJECT: 'synthetic-owner', KRATOS_DOC_ALLOWED_OWNER_SUBJECTS: '["synthetic-owner"]', KRATOS_DOC_ACTOR_ID: 'synthetic-actor', KRATOS_DOC_ALLOWED_CUSTOMER_IDS: '[1]', KRATOS_DOC_PRIVATE_ROOT_CONFIRMED: 'true', KRATOS_DOC_PRIVATE_TARGET_CONFIRMED: 'true' };
 try { await runTest({ dir, root, databasePath, env }); }
 finally { assert.equal(path.dirname(dir), path.resolve(os.tmpdir())); await rm(dir, { recursive: true, force: true }); }
}

test('operator CLI uploads and downloads exact binary bytes, lists IDs, and restores an actual verified backup', async () => fixture(async ({ dir, env }) => {
 const input = path.join(dir, 'sensitive-sentinel original ä.bin'), output = path.join(dir, 'download.bin'), payload = Buffer.from([0,255,10,13,27]);
 await writeFile(input, payload); const sha256 = createHash('sha256').update(payload).digest('hex');
 const uploadResult = run(['upload','--customer-id','1','--input',input,'--sha256',sha256], env, dir); const uploaded = complete(uploadResult);
 assert.equal(uploaded.sha256, sha256); assert.equal(uploadResult.stdout.includes('sensitive-sentinel'), false); assert.equal(uploadResult.stdout.includes(input), false);
 const listed = complete(run(['list','--customer-id','1'], env, dir)); assert.equal(listed.count, 1); assert.equal(listed.files[0].file_id, uploaded.file_id); assert.equal(Object.hasOwn(listed.files[0], 'file_name'), false);
 const downloaded = complete(run(['download','--file-id',String(uploaded.file_id),'--output',output], env, dir)); assert.equal(downloaded.verified, true); assert.deepEqual(await readFile(output), payload);
 const backupDir = path.join(dir, 'backup'), restoredDir = path.join(dir, 'restored');
 const backup = complete(run(['backup','--destination',backupDir], env, dir)); assert.equal(backup.files, 1); assert.match(backup.manifestSha256, /^[a-f0-9]{64}$/);
 const restored = complete(run(['restore','--backup',backupDir,'--destination',restoredDir,'--manifest-sha256',backup.manifestSha256], env, dir)); assert.equal(restored.verified, true);
 const restoredEnv = { ...env, KRATOS_DOC_DB_PATH: path.join(restoredDir, 'database.sqlite'), KRATOS_DOC_ROOT: path.join(restoredDir, 'documents') };
 const restoredOutput = path.join(dir, 'restored-download.bin'); complete(run(['download','--file-id',String(uploaded.file_id),'--output',restoredOutput], restoredEnv, dir)); assert.deepEqual(await readFile(restoredOutput), payload);
}));

test('CLI refuses absent or malformed operator config before creating bundles and hides supplied values', async () => fixture(async ({ dir, env }) => {
 const before = await bundleCount();
 for (const settings of [{}, { ...env, KRATOS_DOC_ALLOWED_CUSTOMER_IDS: 'sensitive-sentinel' }, { ...env, KRATOS_DOC_OWNER_SUBJECT: 'sensitive-sentinel' }, { ...env, KRATOS_DOC_PRIVATE_ROOT_CONFIRMED: 'false' }]) {
  const result = run(['list','--customer-id','1'], settings, dir); rejected(result); assert.equal(result.stderr.includes('sensitive-sentinel'), false);
 }
 assert.equal(await bundleCount(), before);
}));

test('CLI rejects unauthorized customers, unknown flags and overlapping backup destinations before bundle generation', async () => fixture(async ({ dir, root, env }) => {
 const before = await bundleCount();
 for (const args of [['list','--customer-id','2'], ['list','--customer-id','1','--sql','sensitive-sentinel'], ['backup','--destination',path.join(root, 'nested-backup')]]) rejected(run(args, env, dir));
 assert.equal(await bundleCount(), before); await assert.rejects(access(path.join(root, 'nested-backup')));
}));

test('CLI never overwrites existing download, backup or restore targets', async () => fixture(async ({ dir, env }) => {
 const target = path.join(dir, 'keep.bin'); await writeFile(target, 'keep');
 rejected(run(['download','--file-id','1','--output',target], env, dir));
 rejected(run(['backup','--destination',target], env, dir));
 rejected(run(['restore','--backup',dir,'--destination',target,'--manifest-sha256','0'.repeat(64)], env, dir));
 assert.equal(await readFile(target, 'utf8'), 'keep');
}));

test('wrong manifest proof and corrupted stored bytes produce no success or restored installation', async () => fixture(async ({ dir, root, databasePath, env }) => {
 const input = path.join(dir, 'input'); await writeFile(input, 'synthetic'); const uploaded = complete(run(['upload','--customer-id','1','--input',input], env, dir));
 const backupDir = path.join(dir, 'backup'); complete(run(['backup','--destination',backupDir], env, dir));
 const destination = path.join(dir, 'never-restored'); rejected(run(['restore','--backup',backupDir,'--destination',destination,'--manifest-sha256','0'.repeat(64)], env, dir)); await assert.rejects(access(destination));
 const db = new DatabaseSync(databasePath, { readOnly: true }); const row = db.prepare('SELECT object_key FROM storage_files WHERE id=?').get(uploaded.file_id); db.close();
 await writeFile(path.join(root, ...row.object_key.split('/')), 'corrupt');
 const output = path.join(dir, 'never-downloaded'); rejected(run(['download','--file-id',String(uploaded.file_id),'--output',output], env, dir)); await assert.rejects(access(output));
}));
