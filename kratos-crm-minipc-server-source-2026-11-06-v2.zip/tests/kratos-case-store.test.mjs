import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFile, mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { build } from "esbuild";

const bundle = await build({ entryPoints: [path.resolve("lib/kratos-case-store.ts")], bundle: true, platform: "node", format: "esm", write: false });
const storeModule = await import(`data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].contents).toString("base64")}`);
const { KratosCaseStore, SqliteCaseDatabase } = storeModule;
const caseId = "case_synthetic_01";

async function withDatabase(run) {
  const directory = await mkdtemp(path.join(os.tmpdir(), "kratos-case-store-"));
  const filePath = path.join(directory, "case-store.sqlite");
  let database = new DatabaseSync(filePath);
  try {
    const migration = await readFile(path.resolve("drizzle/0010_mysterious_lady_bullseye.sql"), "utf8");
    database.exec(migration.replaceAll("--> statement-breakpoint", ""));
    await run({ filePath, get database() { return database; }, reopen() { database.close(); database = new DatabaseSync(filePath); return database; } });
  } finally {
    try { database.close(); } catch { /* may already be closed */ }
    await rm(directory, { recursive: true, force: true });
  }
}

function makeStore(database, ownerSubject = "owner-a", allowedOwnerSubjects = ["owner-a", "owner-b"], todoistProjectId = "exact-project") {
  return new KratosCaseStore(new SqliteCaseDatabase(database), { ownerSubject, allowedOwnerSubjects, actorId: "synthetic-reviewer", todoistProjectId, now: () => "2026-11-05T20:00:00.000Z" });
}

function event(caseIdValue, eventId, type, fields = {}) {
  return { caseId: caseIdValue, eventId, actorId: "synthetic-reviewer", type, ...fields };
}

function completeCase(store, id = "case_outbox_01") {
  let row = store.createCase({ caseId: id, expectedScopeIds: ["scope-a"] });
  row = store.applyEvent({ caseId: id, expectedVersion: row.version, event: event(id, "assign", "customer_assignment_confirmed", { customerId: 7 }) });
  row = store.applyEvent({ caseId: id, expectedVersion: row.version, event: event(id, "doc-received", "document_received", { artifactId: "doc-1", attachmentPresent: true }) });
  row = store.applyEvent({ caseId: id, expectedVersion: row.version, event: event(id, "doc-reviewed", "artifact_reviewed", { artifactId: "doc-1", outcome: "accepted" }) });
  row = store.applyEvent({ caseId: id, expectedVersion: row.version, event: event(id, "reply-received", "insurer_response_received", { artifactId: "reply-1", attachmentPresent: true }) });
  row = store.applyEvent({ caseId: id, expectedVersion: row.version, event: event(id, "reply-reviewed", "insurer_response_reviewed", { artifactId: "reply-1", confirmation: "confirmed", scopeAssessments: [{ scopeId: "scope-a", outcome: "satisfied" }] }) });
  return row;
}

test("case, events, and version persist across reopen; same event replays and conflicting reuse fails", async () => {
  await withDatabase(async ({ database, reopen }) => {
    let store = makeStore(database);
    const created = store.createCase({ caseId, expectedScopeIds: ["scope-a"] });
    assert.equal(created.version, 1);
    const assignment = event(caseId, "assignment-1", "customer_assignment_confirmed", { customerId: 7 });
    const applied = store.applyEvent({ caseId, expectedVersion: 1, event: assignment });
    assert.equal(applied.version, 2);
    assert.equal(store.listEvents(caseId).length, 1);
    assert.equal(store.listOutbox(caseId).length, 0, "intake and ordinary case events create no outbox actions");

    store = makeStore(reopen());
    const restored = store.getCase(caseId);
    assert.equal(restored.version, 2);
    assert.equal(restored.snapshot.customerAssignment.customerId, 7);
    const replay = store.applyEvent({ caseId, expectedVersion: 1, event: assignment });
    assert.equal(replay.duplicate, true);
    assert.equal(replay.version, 2);
    assert.throws(() => store.applyEvent({ caseId, expectedVersion: 2, event: { ...assignment, customerId: 8 } }), { code: "event_id_conflict" });
    assert.equal(store.listEvents(caseId).length, 1);
    assert.match(store.listEvents(caseId)[0].payloadFingerprint, /^[a-f0-9]{64}$/);
  });
});

test("owner subject is injected and allowlisted; other owners cannot read or mutate the case", async () => {
  await withDatabase(async ({ database }) => {
    const ownerStore = makeStore(database, "owner-a");
    ownerStore.createCase({ caseId, expectedScopeIds: ["scope-a"] });
    const otherStore = makeStore(database, "owner-b");
    assert.equal(otherStore.getCase(caseId), null);
    assert.throws(() => otherStore.applyEvent({ caseId, expectedVersion: 1, event: event(caseId, "other-event", "customer_assignment_confirmed", { customerId: 7 }) }), { code: "case_not_found" });
    assert.throws(() => makeStore(database, "owner-c", ["owner-a", "owner-b"]), { code: "owner_not_allowed" });
  });
});

test("trusted actor binding and runtime event validation reject spoofed or malformed events before writes", async () => {
  await withDatabase(async ({ database }) => {
    const store = makeStore(database);
    store.createCase({ caseId, expectedScopeIds: ["scope-a"] });
    const assignment = store.applyEvent({ caseId, expectedVersion: 1, event: { ...event(caseId, "assign", "customer_assignment_confirmed", { customerId: 7 }), actorId: "forged-client" } });
    assert.equal(assignment.snapshot.customerAssignment.confirmedBy, "synthetic-reviewer");
    assert.equal(store.listEvents(caseId)[0].actorId, "synthetic-reviewer");
    assert.throws(() => store.applyEvent({ caseId, expectedVersion: 2, event: event(caseId, "unknown", "unknown_event", {}) }), { code: "invalid_event_type" });
    assert.throws(() => store.applyEvent({ caseId, expectedVersion: 2, event: event(caseId, "bad-boolean", "document_received", { artifactId: "doc-x", attachmentPresent: "true" }) }), { code: "invalid_event" });
    assert.throws(() => store.applyEvent({ caseId, expectedVersion: 2, event: event(caseId, "bad-confirmation", "insurer_response_reviewed", { artifactId: "reply-x", confirmation: ["confirmed"], scopeAssessments: [] }) }), { code: "invalid_event" });
    assert.throws(() => store.applyEvent({ caseId, expectedVersion: 2, event: event(caseId, "bad-outcome", "insurer_response_reviewed", { artifactId: "reply-x", confirmation: "confirmed", scopeAssessments: [{ scopeId: "scope-a", outcome: ["satisfied"] }] }) }), { code: "invalid_event" });
    assert.equal(store.getCase(caseId).version, 2);
    assert.equal(store.listEvents(caseId).length, 1);
  });
});

test("expected-version compare-and-swap permits only one update from the same version", async () => {
  await withDatabase(async ({ filePath, database }) => {
    const firstStore = makeStore(database);
    firstStore.createCase({ caseId, expectedScopeIds: ["scope-a"] });
    const secondDatabase = new DatabaseSync(filePath);
    const secondStore = makeStore(secondDatabase);
    try {
      const outcomes = await Promise.allSettled([
        Promise.resolve().then(() => firstStore.applyEvent({ caseId, expectedVersion: 1, event: event(caseId, "event-a", "customer_assignment_confirmed", { customerId: 7 }) })),
        Promise.resolve().then(() => secondStore.applyEvent({ caseId, expectedVersion: 1, event: event(caseId, "event-b", "customer_assignment_confirmed", { customerId: 8 }) })),
      ]);
      assert.equal(outcomes.filter((result) => result.status === "fulfilled").length, 1);
      assert.equal(outcomes.filter((result) => result.status === "rejected" && result.reason.code === "version_conflict").length, 1);
      assert.equal(firstStore.getCase(caseId).version, 2);
      assert.equal(firstStore.listEvents(caseId).length, 1);
    } finally { secondDatabase.close(); }
  });
});

test("reassignment after document evidence fails without changing snapshot or ledger", async () => {
  await withDatabase(async ({ database }) => {
    const store = makeStore(database);
    let row = store.createCase({ caseId, expectedScopeIds: ["scope-a"] });
    row = store.applyEvent({ caseId, expectedVersion: row.version, event: event(caseId, "assign", "customer_assignment_confirmed", { customerId: 7 }) });
    row = store.applyEvent({ caseId, expectedVersion: row.version, event: event(caseId, "document", "document_received", { artifactId: "doc-1", attachmentPresent: true }) });
    const eventCount = store.listEvents(caseId).length;
    assert.throws(() => store.applyEvent({ caseId, expectedVersion: row.version, event: event(caseId, "reassign", "customer_assignment_confirmed", { customerId: 8 }) }), { code: "customer_assignment_conflict" });
    const current = store.getCase(caseId);
    assert.equal(current.version, row.version);
    assert.equal(current.snapshot.customerAssignment.customerId, 7);
    assert.equal(store.listEvents(caseId).length, eventCount);
  });
});

test("outbox plan is derived only from a reviewed response and remains pending_review; intake never creates an action", async () => {
  await withDatabase(async ({ database }) => {
    const setupStore = makeStore(database, "owner-a", ["owner-a", "owner-b"], null);
    const row = completeCase(setupStore, "case_outbox_01");
    const store = makeStore(database);
    const result = store.applyEvent({
      caseId: "case_outbox_01",
      expectedVersion: row.version,
      event: event("case_outbox_01", "proposal-event", "insurer_response_reviewed", { artifactId: "reply-1", confirmation: "confirmed", scopeAssessments: [{ scopeId: "scope-a", outcome: "satisfied" }] }),
    });
    assert.equal(result.outboxActionId, "case_outbox_01:proposal-event");
    const actions = store.listOutbox("case_outbox_01");
    assert.equal(actions.length, 1);
    assert.equal(actions[0].status, "pending_review");
    assert.equal(actions[0].proposal.externalWritePerformed, false);
    assert.equal("sendPerformed" in actions[0].proposal, false);
    assert.equal(store.listOutbox("case_synthetic_01").length, 0);
    const replay = store.applyEvent({ caseId: "case_outbox_01", expectedVersion: row.version, event: event("case_outbox_01", "proposal-event", "insurer_response_reviewed", { artifactId: "reply-1", confirmation: "confirmed", scopeAssessments: [{ scopeId: "scope-a", outcome: "satisfied" }] }) });
    assert.equal(replay.duplicate, true);
    assert.equal(replay.outboxActionId, result.outboxActionId);
  });
});

test("a failing outbox insert rolls back event, snapshot CAS, and version", async () => {
  await withDatabase(async ({ database }) => {
    const setupStore = makeStore(database, "owner-a", ["owner-a", "owner-b"], null);
    const row = completeCase(setupStore, "case_outbox_01");
    const store = makeStore(database);
    database.exec("CREATE TRIGGER synthetic_outbox_failure BEFORE INSERT ON kratos_case_outbox BEGIN SELECT RAISE(ABORT, 'synthetic outbox failure'); END;");
    const eventValue = event("case_outbox_01", "atomic-outbox-event", "insurer_response_reviewed", { artifactId: "reply-1", confirmation: "confirmed", scopeAssessments: [{ scopeId: "scope-a", outcome: "satisfied" }] });
    assert.throws(() => store.applyEvent({ caseId: "case_outbox_01", expectedVersion: row.version, event: eventValue }), /synthetic outbox failure/);
    assert.equal(store.getCase("case_outbox_01").version, row.version);
    assert.equal(store.listEvents("case_outbox_01").some((entry) => entry.eventId === eventValue.eventId), false);
    assert.equal(store.listOutbox("case_outbox_01").length, 0);
    database.exec("DROP TRIGGER synthetic_outbox_failure;");
    const success = store.applyEvent({ caseId: "case_outbox_01", expectedVersion: row.version, event: eventValue });
    assert.equal(success.version, row.version + 1);
    assert.equal(store.listOutbox("case_outbox_01").length, 1);
  });
});

test("corrupt persisted snapshots are rejected instead of passed to workflow", async () => {
  await withDatabase(async ({ database }) => {
    const store = makeStore(database);
    store.createCase({ caseId, expectedScopeIds: ["scope-a"] });
    database.prepare("UPDATE kratos_cases SET snapshot_json=? WHERE owner_subject=? AND case_id=?").run("{bad-json", "owner-a", caseId);
    assert.throws(() => store.getCase(caseId), { code: "corrupt_snapshot" });
  });
});

test("persisted state must match the state derived from case evidence", async () => {
  await withDatabase(async ({ database }) => {
    const store = makeStore(database);
    store.createCase({ caseId, expectedScopeIds: ["scope-a"] });
    database.prepare("UPDATE kratos_cases SET snapshot_json=? WHERE owner_subject=? AND case_id=?").run(JSON.stringify({ ...store.getCase(caseId).snapshot, state: "complete" }), "owner-a", caseId);
    assert.throws(() => store.getCase(caseId), { code: "corrupt_snapshot" });
  });
});

test("persisted enum values reject arrays that stringify to valid states", async () => {
  await withDatabase(async ({ database }) => {
    const store = makeStore(database);
    let row = store.createCase({ caseId, expectedScopeIds: ["scope-a"] });
    row = store.applyEvent({ caseId, expectedVersion: row.version, event: event(caseId, "assign", "customer_assignment_confirmed", { customerId: 7 }) });
    row = store.applyEvent({ caseId, expectedVersion: row.version, event: event(caseId, "document", "document_received", { artifactId: "doc-1", attachmentPresent: true }) });
    const snapshot = { ...row.snapshot, state: "ready", artifacts: { ...row.snapshot.artifacts, "doc-1": { ...row.snapshot.artifacts["doc-1"], review: ["accepted"] } } };
    database.prepare("UPDATE kratos_cases SET snapshot_json=? WHERE owner_subject=? AND case_id=?").run(JSON.stringify(snapshot), "owner-a", caseId);
    assert.throws(() => store.getCase(caseId), { code: "corrupt_snapshot" });
  });
});
