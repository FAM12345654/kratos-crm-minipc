import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFile, readdir, mkdtemp, rm } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { build } from 'esbuild';

const bundle = await build({ entryPoints: [path.resolve('lib/kratos-case-api.ts')], bundle:true, platform:'node', format:'esm', write:false });
const {createKratosCaseApi} = await import(`data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].contents).toString('base64')}`);
const origin='https://cases.synthetic.invalid';
const id='case_synthetic_api';
const identities={owner:{subject:'owner-a',scopes:['kratos:read','kratos:cases:write']}, reader:{subject:'owner-a',scopes:['kratos:read']}, other:{subject:'owner-b',scopes:['kratos:read','kratos:cases:write']}, outsider:{subject:'outside',scopes:['kratos:read','kratos:cases:write']}};
async function fixture(run, overrides={}) {
 const directory=await mkdtemp(path.join(os.tmpdir(),'kratos-case-api-'));
 const file=path.join(directory,'synthetic.sqlite');
 const db=new DatabaseSync(file);
 try {
  db.exec('PRAGMA foreign_keys=ON');
  for(const migration of (await readdir('drizzle')).filter(name=>/^\d{4}_.*\.sql$/.test(name)).sort())db.exec((await readFile(path.join('drizzle',migration),'utf8')).replaceAll('--> statement-breakpoint',''));
  db.prepare('INSERT INTO customers(id,first_name,last_name,phone,email,authority_status,adviser,status,folder_name,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)').run(7,'Synthetic','Customer',null,null,'Ungeprüft','Synthetic','Kunde','Synthetic','synthetic');
  const config={database:db,resourceOrigin:origin,verifyAccessToken:async token=>identities[token]??null,allowedSubjects:['owner-a','owner-b'],enableWrites:true,canAccessCustomer:(_identity,customerId)=>customerId===7,todoistProjectId:'synthetic-project',...overrides};
  const api=createKratosCaseApi(config);
  await run({api,db,file,config});
 }finally{
  db.close();
  const resolved=path.resolve(directory);assert.equal(path.dirname(resolved),path.resolve(os.tmpdir()));assert.ok(path.basename(resolved).startsWith('kratos-case-api-'));
  await rm(resolved,{recursive:true,force:true});
 }
}
const req=(pathname,{method='POST',body,token='owner',headers={},raw}={})=>new Request(origin+pathname,{method,headers:{authorization:`Bearer ${token}`,...(method==='POST'?{'content-type':'application/json'}:{}),...headers},...(method==='POST'?{body:raw??JSON.stringify(body??{}),...(raw instanceof ReadableStream?{duplex:'half'}:{})}:{})});
async function create(api,body={caseId:id,expectedScopeIds:['policies']}){return api(req('/v1/cases',{body}));}
const eventReq=(event,expectedVersion=1,token='owner')=>req(`/v1/cases/${id}/events`,{token,body:{expectedVersion,event}});

test('explicit router creates and reads an owner case, replays initial creation, and binds audit actor',async()=>fixture(async({api,db})=>{
 assert.equal((await create(api)).status,201);
 assert.equal((await create(api)).status,200);
 const assigned=await api(eventReq({eventId:'assign-1',type:'customer_assignment_confirmed',customerId:7}));assert.equal(assigned.status,200);
 const row=await assigned.json();assert.equal(row.version,2);assert.equal(row.snapshot.customerAssignment.confirmedBy,'oauth:owner-a');
 assert.equal((await api(req(`/v1/cases/${id}`,{method:'GET'}))).status,200);
 const audit=await (await api(req(`/v1/cases/${id}/events`,{method:'GET'}))).json();assert.equal(audit.events[0].actorId,'oauth:owner-a');
 assert.equal(db.prepare('SELECT COUNT(*) AS n FROM kratos_case_events').get().n,1);
}));

test('authentication, owner boundaries, explicit write opt-in, scopes and Origin deny unauthorized operations',async()=>fixture(async({api,config})=>{
 assert.equal((await create(api)).status,201);
 for(const token of ['invalid','outsider','reader'])assert.ok([401,403].includes((await api(eventReq({eventId:'assign',type:'customer_assignment_confirmed',customerId:7},1,token))).status));
 assert.equal((await api(req(`/v1/cases/${id}`,{method:'GET',token:'other'}))).status,404);
 assert.equal((await api(req(`/v1/cases/${id}/events`,{method:'GET',token:'other'}))).status,404);
 assert.equal((await api(req('/v1/cases',{body:{caseId:'case_other',expectedScopeIds:['x']},headers:{origin:'https://other.invalid'}}))).status,403);
 const readonly=createKratosCaseApi({...config,enableWrites:false});assert.equal((await create(readonly,{caseId:'case_no_write',expectedScopeIds:['x']})).status,403);
 assert.equal((await readonly(req(`/v1/cases/${id}`,{method:'GET',token:'reader'}))).status,200);
}));

test('customer existence and trusted access are enforced for assignment and later reads',async()=>fixture(async({api,db,config})=>{
 await create(api);
 assert.equal((await api(eventReq({eventId:'bad',type:'customer_assignment_confirmed',customerId:999}))).status,404);
 assert.equal(db.prepare('SELECT COUNT(*) AS n FROM kratos_case_events').get().n,0);
 assert.equal((await api(eventReq({eventId:'assign',type:'customer_assignment_confirmed',customerId:7}))).status,200);
 const revoked=createKratosCaseApi({...config,canAccessCustomer:()=>false});
 for(const suffix of ['','/events','/plans'])assert.equal((await revoked(req(`/v1/cases/${id}${suffix}`,{method:'GET'}))).status,404);
 assert.equal((await revoked(eventReq({eventId:'doc',type:'document_received',artifactId:'doc-1',attachmentPresent:true},2))).status,404);
 const nonexistent=createKratosCaseApi({...config,canAccessCustomer:()=>true});
 await create(nonexistent,{caseId:'case_missing_customer',expectedScopeIds:['x']});
 assert.equal((await nonexistent(req('/v1/cases/case_missing_customer/events',{body:{expectedVersion:1,event:{eventId:'assign',type:'customer_assignment_confirmed',customerId:999}}}))).status,404);
}));

test('CAS rejects simultaneous stale events and retries are idempotent across a second SQLite connection',async()=>fixture(async({api,file,config,db})=>{
 await create(api);
 const second=new DatabaseSync(file);
 try{
 const otherApi=createKratosCaseApi({...config,database:second});
 const one={eventId:'first',type:'customer_assignment_confirmed',customerId:7},two={eventId:'second',type:'customer_assignment_confirmed',customerId:7};
 const results=await Promise.all([api(eventReq(one)),otherApi(eventReq(two))]);assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);
 const winner=results[0].status===200?one:two;
 const replay=await (await otherApi(eventReq(winner))).json();assert.equal(replay.duplicate,true);assert.equal(replay.version,2);
 assert.equal((await otherApi(eventReq({...winner,customerId:8},2))).status,404);
 const conflicting={...winner,type:'recipient_verified',recipientId:'synthetic-recipient'};delete conflicting.customerId;
 assert.equal((await otherApi(eventReq(conflicting,2))).status,409);
 assert.equal(db.prepare('SELECT COUNT(*) AS n FROM kratos_case_events').get().n,1);
 }finally{second.close();}
}));

test('strict arguments reject actor/owner injection, unknown types, invalid booleans and malformed bodies',async()=>fixture(async({api,db})=>{
 await create(api);
 for(const event of [{eventId:'x',type:'unknown'}, {eventId:'x',type:'customer_assignment_confirmed',customerId:7,actorId:'forged'},
  {eventId:'x',type:'document_received',artifactId:'doc',attachmentPresent:'true'}, {eventId:'x',type:'recipient_verified',recipientId:'synthetic',ownerSubject:'owner-b'}])assert.equal((await api(eventReq(event))).status,400);
 for(const body of [{caseId:'case_bad',expectedScopeIds:['x'],ownerSubject:'owner-b'},{caseId:'case_bad',expectedScopeIds:[]},{caseId:'../case',expectedScopeIds:['x']}])assert.equal((await create(api,body)).status,400);
 assert.equal((await api(req('/v1/cases',{raw:'{not-json'}))).status,400);
 assert.equal((await api(req('/v1/cases',{raw:'[]'}))).status,400);
 assert.equal(db.prepare('SELECT COUNT(*) AS n FROM kratos_case_events').get().n,0);
}));

test('body bounds use streamed bytes and malformed transport fails without writes',async()=>fixture(async({api,db})=>{
 const stream=new ReadableStream({start(controller){controller.enqueue(new TextEncoder().encode('x'.repeat(65537)));controller.close();}});
 assert.equal((await api(req('/v1/cases',{raw:stream}))).status,413);
 assert.equal((await api(req('/v1/cases',{headers:{'content-type':'text/plain'}}))).status,415);
 assert.equal((await api(new Request('https://other.invalid/v1/cases',{method:'POST'}))).status,421);
 assert.equal((await api(req('/v1/cases',{method:'DELETE'}))).status,405);
 assert.equal(db.prepare('SELECT COUNT(*) AS n FROM kratos_cases').get().n,0);
}));

test('response review produces only pending plans; intake itself never creates external tasks',async()=>fixture(async({api,db})=>{
 await create(api);
 const events=[
  {eventId:'assign',type:'customer_assignment_confirmed',customerId:7},
  {eventId:'response',type:'insurer_response_received',artifactId:'reply-1',attachmentPresent:true},
  {eventId:'full',type:'insurer_response_reviewed',artifactId:'reply-1',confirmation:'confirmed',scopeAssessments:[{scopeId:'policies',outcome:'satisfied'}]},
 ];
 for(let i=0;i<events.length;i++){
  const result=await api(eventReq(events[i],i+1));assert.equal(result.status,200, `event index ${i}`);
  if(i<2)assert.equal(db.prepare('SELECT COUNT(*) AS n FROM kratos_case_outbox').get().n,0);
 }
 const plans=await (await api(req(`/v1/cases/${id}/plans`,{method:'GET'}))).json();assert.equal(plans.externalWritePerformed,false);assert.equal(plans.plans.length,1);assert.equal(plans.plans[0].status,'pending_review');assert.equal(plans.plans[0].proposal.externalWritePerformed,false);
}));

test('unexpected database errors are generic and do not leak internal paths or SQL',async()=>fixture(async({api,db})=>{
 db.exec('DROP TABLE kratos_case_outbox');
 await create(api);
 const result=await api(req(`/v1/cases/${id}/plans`,{method:'GET'}));assert.equal(result.status,500);assert.deepEqual(await result.json(),{error:'case_operation_failed'});
}));

test('incomplete streamed request times out and never mutates the database',async()=>fixture(async({api,db})=>{
 let cancelled=false;
 const stream=new ReadableStream({start(controller){controller.enqueue(new TextEncoder().encode('{"caseId":'));},cancel(){cancelled=true;}});
 const result=await api(req('/v1/cases',{raw:stream}));
 assert.equal(result.status,408);assert.deepEqual(await result.json(),{error:'body_timeout'});
 assert.equal(cancelled,true);assert.equal(db.prepare('SELECT COUNT(*) AS n FROM kratos_cases').get().n,0);
}));
