import test from "node:test";
import assert from "node:assert/strict";
import {
  applyKratosCaseEvent,
  caseEventIdempotencyKey,
  createKratosCase,
  createPendingSendProposal,
  createTodoistPlanProposal,
  toKratosCaseId,
} from "../lib/kratos-case-workflow.ts";

const caseId = toKratosCaseId("case_synthetic_01");
const base = { caseId, actorId: "reviewer-1" };
const create = (options = {}) => createKratosCase({ caseId, expectedScopeIds: ["scope-a", "scope-b"], ...options });
const apply = (snapshot, event) => applyKratosCaseEvent(snapshot, { ...base, eventId: `event-${Math.random().toString(16).slice(2)}`, ...event });
const withConfirmedCustomer = (snapshot = create()) => apply(snapshot, { type: "customer_assignment_confirmed", eventId: "assign-1", customerId: 41 }).snapshot;
const receiveDocument = (snapshot, artifactId = "doc-1", attachmentPresent = true) => apply(snapshot, { type: "document_received", eventId: `receive-${artifactId}`, artifactId, attachmentPresent });
const acceptDocument = (snapshot, artifactId = "doc-1") => apply(snapshot, { type: "artifact_reviewed", eventId: `review-${artifactId}`, artifactId, outcome: "accepted" });
const receiveResponse = (snapshot, { artifactId = "reply-1", attachmentPresent = true } = {}) => apply(snapshot, { type: "insurer_response_received", eventId: `receive-${artifactId}`, artifactId, attachmentPresent });
const reviewResponse = (snapshot, { artifactId = "reply-1", confirmation = "confirmed", scopeAssessments = [] } = {}) => apply(snapshot, { type: "insurer_response_reviewed", eventId: `review-${artifactId}`, artifactId, confirmation, scopeAssessments });

test("ambiguous customer assignment remains review-needed and blocks ready state", () => {
  let snapshot = create({ assignmentStatus: "ambiguous" });
  assert.equal(snapshot.state, "needs_review");
  snapshot = receiveDocument(snapshot).snapshot;
  assert.equal(snapshot.state, "needs_review");
  assert.equal(snapshot.customerAssignment.status, "ambiguous");
});

test("document intake alone creates no Todoist proposal; confirmed and reviewed documents become ready", () => {
  const initial = create();
  const received = receiveDocument(initial).snapshot;
  assert.equal(received.state, "needs_review", "customer must be explicitly confirmed before handling");
  assert.deepEqual(createTodoistPlanProposal(received, "project-42"), { status: "not_created", reason: "insurer_response_not_confirmed" });

  const assigned = apply(received, { type: "customer_assignment_confirmed", eventId: "assign-1", customerId: 41 }).snapshot;
  assert.equal(assigned.state, "received", "received attachment is still awaiting review");
  const ready = acceptDocument(assigned).snapshot;
  assert.equal(ready.state, "ready");
  assert.deepEqual(createTodoistPlanProposal(ready, "project-42"), { status: "not_created", reason: "insurer_response_not_confirmed" });
  assert.equal(initial.artifacts["doc-1"], undefined, "state transitions must not mutate the input snapshot");
});

test("confirmed insurer response produces partial state and a plan using only the injected exact project ID", () => {
  let snapshot = withConfirmedCustomer();
  snapshot = receiveResponse(snapshot).snapshot;
  assert.equal(snapshot.state, "received");
  snapshot = reviewResponse(snapshot, { scopeAssessments: [{ scopeId: "scope-a", outcome: "satisfied" }, { scopeId: "scope-b", outcome: "outstanding" }] }).snapshot;
  assert.equal(snapshot.state, "partial");

  assert.deepEqual(createTodoistPlanProposal(snapshot), { status: "not_created", reason: "todoist_project_id_missing" });
  const proposal = createTodoistPlanProposal(snapshot, " exact-project-id ");
  assert.deepEqual(proposal, { status: "not_created", reason: "todoist_project_id_missing" });
  const plan = createTodoistPlanProposal(snapshot, "todoist-project-42");
  assert.equal(plan.status, "explicit-plan");
  assert.equal(plan.explicitPlan, true);
  assert.equal(plan.projectId, "todoist-project-42");
  assert.equal(plan.idempotencyKey, caseEventIdempotencyKey(caseId, "review-reply-1"));
  assert.deepEqual(plan.taskTemplates, [{ type: "insurer_response_follow_up", titleTemplate: "Rücklauf prüfen: fehlende Unterlagen", missingScopeIds: ["scope-b"] }]);
  assert.deepEqual(plan.requiredVerifiedDisplayFields, ["customerDisplayName", "insurerDisplayName", "lineOfBusinessDisplayName"]);
  assert.equal(plan.taskTitlesMaterialized, false);
  assert.equal(plan.externalWritePerformed, false);
  assert.equal("dueDate" in plan.taskTemplates[0], false);
});

test("all reviewed expected scopes satisfied yields complete state and a two-task explicit plan", () => {
  let snapshot = withConfirmedCustomer();
  snapshot = receiveResponse(snapshot).snapshot;
  snapshot = reviewResponse(snapshot, { scopeAssessments: [{ scopeId: "scope-a", outcome: "satisfied" }, { scopeId: "scope-b", outcome: "satisfied" }] }).snapshot;
  assert.equal(snapshot.state, "complete");
  const plan = createTodoistPlanProposal(snapshot, "project-exact");
  assert.equal(plan.status, "explicit-plan");
  assert.equal(plan.explicitPlan, true);
  assert.deepEqual(plan.taskTemplates, [
    { type: "confirmed_insurer_response", titleTemplate: "Rücklauf bestätigt" },
    { type: "contracts_review_and_consultation_prep", titleTemplate: "Verträge prüfen / Beratung vorbereiten" },
  ]);
  assert.equal(plan.taskTitlesMaterialized, false);
});

test("missing response attachment blocks confirmation and leaves the case for review", () => {
  let snapshot = withConfirmedCustomer();
  snapshot = receiveResponse(snapshot, { attachmentPresent: false }).snapshot;
  assert.equal(snapshot.state, "needs_review");
  assert.throws(() => reviewResponse(snapshot, { scopeAssessments: [{ scopeId: "scope-a", outcome: "satisfied" }] }), { code: "missing_attachment" });
  assert.equal(snapshot.insurerResponseReview, null);
  assert.deepEqual(createTodoistPlanProposal(snapshot, "project-exact"), { status: "not_created", reason: "insurer_response_not_confirmed" });
});

test("same event key and payload is idempotent; conflicting reuse is rejected", () => {
  const initial = create();
  const event = { ...base, eventId: "fixed-event", type: "customer_assignment_confirmed", customerId: 41 };
  const first = applyKratosCaseEvent(initial, event);
  const duplicate = applyKratosCaseEvent(first.snapshot, event);
  assert.equal(duplicate.duplicate, true);
  assert.equal(duplicate.snapshot, first.snapshot);
  assert.equal(duplicate.idempotencyKey, `${caseId}:fixed-event`);
  assert.throws(() => applyKratosCaseEvent(first.snapshot, { ...event, customerId: 42 }), { code: "idempotency_conflict" });
  assert.equal(initial.customerAssignment.status, "unconfirmed");
});

test("send proposals require confirmed customer, verified recipient, and reviewed signed valid authorization", () => {
  let snapshot = withConfirmedCustomer();
  snapshot = receiveDocument(snapshot).snapshot;
  snapshot = acceptDocument(snapshot).snapshot;
  snapshot = apply(snapshot, { type: "authorization_received", eventId: "authorization-received", artifactId: "poa-1", attachmentPresent: true }).snapshot;
  snapshot = apply(snapshot, { type: "authorization_reviewed", eventId: "authorization-reviewed", artifactId: "poa-1", validity: "valid", signed: true, authorizedRecipientId: "recipient-1" }).snapshot;
  assert.throws(() => createPendingSendProposal({ snapshot, proposalId: "proposal-unverified", recipientId: "recipient-1", authorizationArtifactId: "poa-1" }), { code: "recipient_not_verified" });

  snapshot = apply(snapshot, { type: "recipient_verified", eventId: "recipient-verified", recipientId: "recipient-1" }).snapshot;
  snapshot = apply(snapshot, { type: "recipient_verified", eventId: "recipient-2-verified", recipientId: "recipient-2" }).snapshot;
  assert.throws(() => createPendingSendProposal({ snapshot, proposalId: "proposal-wrong-recipient", recipientId: "recipient-2", authorizationArtifactId: "poa-1" }), { code: "valid_authorization_required" });
  const proposal = createPendingSendProposal({ snapshot, proposalId: "proposal-1", recipientId: "recipient-1", authorizationArtifactId: "poa-1" });
  assert.equal(proposal.status, "pending-proposal");
  assert.equal(proposal.sendPerformed, false);
  assert.equal(proposal.idempotencyKey, `${caseId}:proposal-1`);
});

test("inherited object keys cannot satisfy recipient, artifact, authorization, or idempotency lookups", () => {
  let snapshot = withConfirmedCustomer();
  snapshot = receiveDocument(snapshot).snapshot;
  snapshot = acceptDocument(snapshot).snapshot;
  snapshot = apply(snapshot, { type: "authorization_received", eventId: "prototype-auth-received", artifactId: "toString", attachmentPresent: true }).snapshot;
  snapshot = apply(snapshot, { type: "authorization_reviewed", eventId: "prototype-auth-reviewed", artifactId: "toString", validity: "valid", signed: true, authorizedRecipientId: "toString" }).snapshot;

  const inheritedRecipients = Object.create({ toString: { verifiedBy: "attacker", eventId: "inherited" }, constructor: { verifiedBy: "attacker", eventId: "inherited" } });
  const poisonedRecipientSnapshot = { ...snapshot, verifiedRecipientIds: inheritedRecipients };
  assert.throws(() => createPendingSendProposal({ snapshot: poisonedRecipientSnapshot, proposalId: "prototype-recipient", recipientId: "toString", authorizationArtifactId: "toString" }), { code: "recipient_not_verified" });
  assert.throws(() => createPendingSendProposal({ snapshot: poisonedRecipientSnapshot, proposalId: "prototype-constructor", recipientId: "constructor", authorizationArtifactId: "toString" }), { code: "recipient_not_verified" });

  const inheritedAuthorization = Object.create({ toString: { validity: "valid", signed: true, authorizedRecipientId: "toString" } });
  const poisonedAuthorizationSnapshot = { ...snapshot, verifiedRecipientIds: { toString: { verifiedBy: "reviewer", eventId: "verified" } }, authorizationReviews: inheritedAuthorization };
  assert.throws(() => createPendingSendProposal({ snapshot: poisonedAuthorizationSnapshot, proposalId: "prototype-authorization", recipientId: "toString", authorizationArtifactId: "toString" }), { code: "valid_authorization_required" });

  const inheritedArtifacts = Object.create({ __proto__: { artifactId: "__proto__", kind: "document" } });
  const poisonedArtifactSnapshot = { ...create(), artifacts: inheritedArtifacts };
  const artifactResult = apply(poisonedArtifactSnapshot, { type: "document_received", eventId: "artifact-prototype-key", artifactId: "__proto__", attachmentPresent: true });
  assert.equal(Object.hasOwn(artifactResult.snapshot.artifacts, "__proto__"), true);
  assert.equal(Object.getPrototypeOf(artifactResult.snapshot.artifacts), null);

  const inheritedEvents = Object.create({ [`${caseId}:inherited-event`]: "not-the-event-fingerprint" });
  const eventSnapshot = { ...create(), processedEvents: inheritedEvents };
  const eventResult = applyKratosCaseEvent(eventSnapshot, { ...base, eventId: "inherited-event", type: "customer_assignment_confirmed", customerId: 41 });
  assert.equal(eventResult.duplicate, false);
  assert.equal(eventResult.snapshot.customerAssignment.status, "confirmed");
});

test("risk findings force review and cannot be overridden by a confirmed response", () => {
  let snapshot = withConfirmedCustomer();
  snapshot = apply(snapshot, { type: "document_received", eventId: "risk-doc", artifactId: "doc-risk", attachmentPresent: true, riskFindings: ["identity_mismatch"] }).snapshot;
  assert.equal(snapshot.state, "needs_review");
  snapshot = receiveResponse(snapshot).snapshot;
  snapshot = reviewResponse(snapshot, { scopeAssessments: [{ scopeId: "scope-a", outcome: "satisfied" }, { scopeId: "scope-b", outcome: "satisfied" }] }).snapshot;
  assert.equal(snapshot.state, "needs_review");
});
