import test from "node:test";
import assert from "node:assert/strict";
import { createKratosGateway, KRATOS_GATEWAY_TOOLS, KRATOS_READ_SCOPE, MCP_PROTOCOL_VERSIONS } from "../lib/kratos-universal-gateway.ts";

const resourceOrigin = "https://kratos.example.test";
const issuer = "https://login.example.test/tenant/v2.0";
const identity = { subject: "user-1", scopes: [KRATOS_READ_SCOPE] };
const definitions = KRATOS_GATEWAY_TOOLS.map((name) => ({ name, description: `Read ${name}`, inputSchema: { type: "object", properties: {}, additionalProperties: false } }));

function makeGateway(overrides = {}) {
  const calls = [];
  const gateway = createKratosGateway({
    resourceOrigin,
    issuer,
    allowedSubjects: ["user-1"],
    tools: definitions,
    verifyAccessToken: async (token) => token === "valid" ? identity : null,
    executeTool: async (tool, args, caller) => { calls.push({ tool, args, caller }); return { tool, args }; },
    ...overrides,
  });
  return { gateway, calls };
}

function request(path, body, options = {}) {
  const headers = new Headers({ "content-type": "application/json", ...options.headers });
  if (options.token) headers.set("authorization", `Bearer ${options.token}`);
  if (options.origin) headers.set("origin", options.origin);
  return new Request(resourceOrigin + path, {
    method: options.method ?? "POST",
    headers,
    body: options.rawBody ?? JSON.stringify(body),
    ...(options.rawBody instanceof ReadableStream ? { duplex: "half" } : {}),
  });
}

async function json(response) { return response.json(); }

test("requires the injected JWT verifier and valid HTTPS origins", () => {
  assert.throws(() => createKratosGateway({ resourceOrigin, issuer, allowedSubjects: ["user-1"], tools: definitions, executeTool: () => null }), /verifier is required/);
  assert.throws(() => createKratosGateway({ resourceOrigin: "http://kratos.example.test", issuer, allowedSubjects: ["user-1"], tools: definitions, verifyAccessToken: () => identity, executeTool: () => null }), /HTTPS/);
  assert.throws(() => createKratosGateway({ resourceOrigin, issuer, allowedSubjects: [], tools: definitions, verifyAccessToken: () => identity, executeTool: () => null }), /subject/);
  assert.throws(() => createKratosGateway({ resourceOrigin, issuer, allowedSubjects: ["user-1"], tools: [{ name: "delete_customer", description: "write", inputSchema: {} }], verifyAccessToken: () => identity, executeTool: () => null }), /allowlist/);
});

test("MCP initialize negotiates every supported protocol version; ping and notifications work", async () => {
  const { gateway } = makeGateway();
  for (const version of MCP_PROTOCOL_VERSIONS) {
    const response = await gateway(request("/mcp", { jsonrpc: "2.0", id: 1, method: "initialize", params: { protocolVersion: version, capabilities: {}, clientInfo: { name: "test", version: "1" } } }, { token: "valid" }));
    assert.equal(response.status, 200);
    assert.equal((await json(response)).result.protocolVersion, version);
  }
  const ping = await gateway(request("/mcp", { jsonrpc: "2.0", id: "p", method: "ping" }, { token: "valid" }));
  assert.deepEqual((await json(ping)).result, {});
  const notification = await gateway(request("/mcp", { jsonrpc: "2.0", method: "notifications/initialized" }, { token: "valid" }));
  assert.equal(notification.status, 202);
  assert.equal(await notification.text(), "");
});

test("MCP list/call dispatch only allowlisted read tools with verified identity", async () => {
  const { gateway, calls } = makeGateway();
  const listed = await json(await gateway(request("/mcp", { jsonrpc: "2.0", id: 3, method: "tools/list" }, { token: "valid" })));
  assert.deepEqual(listed.result.tools.map((tool) => tool.name), KRATOS_GATEWAY_TOOLS);
  const called = await json(await gateway(request("/mcp", { jsonrpc: "2.0", id: 4, method: "tools/call", params: { name: "get_customer", arguments: { customer_id: 7 } } }, { token: "valid" })));
  assert.equal(called.result.structuredContent.tool, "get_customer");
  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0].caller, identity);
  const write = await json(await gateway(request("/mcp", { jsonrpc: "2.0", id: 5, method: "tools/call", params: { name: "delete_customer", arguments: {} } }, { token: "valid" })));
  assert.equal(write.error.code, -32602);
  assert.equal(calls.length, 1);
});

test("REST tool routes share executor, OpenAPI and OAuth protected resource metadata are available", async () => {
  const { gateway, calls } = makeGateway();
  const result = await json(await gateway(request("/v1/tools/search_customers", { query: "sample" }, { token: "valid" })));
  assert.equal(result.tool, "search_customers");
  assert.equal(calls.length, 1);
  const openapi = await json(await gateway(new Request(resourceOrigin + "/openapi.json")));
  assert.equal(openapi.openapi, "3.1.0");
  assert.equal(Object.keys(openapi.paths).length, KRATOS_GATEWAY_TOOLS.length);
  assert.equal(openapi.paths["/v1/tools/search_customers"].post.security[0].bearerAuth.length, 0);
  const metadata = await json(await gateway(new Request(resourceOrigin + "/.well-known/oauth-protected-resource")));
  assert.deepEqual(metadata.authorization_servers, [issuer]);
  assert.deepEqual(metadata.scopes_supported, [KRATOS_READ_SCOPE]);
});

test("unauthenticated requests return a protected-resource challenge; denied scope and subject block dispatch", async () => {
  const deniedScope = { subject: "user-1", scopes: [] };
  const deniedSubject = { subject: "other", scopes: [KRATOS_READ_SCOPE] };
  const verifyAccessToken = async (token) => token === "no-scope" ? deniedScope : token === "no-subject" ? deniedSubject : token === "valid" ? identity : null;
  const { gateway, calls } = makeGateway({ verifyAccessToken });
  const noAuth = await gateway(request("/v1/tools/get_customer", {}));
  assert.equal(noAuth.status, 401);
  assert.match(noAuth.headers.get("www-authenticate") ?? "", /oauth-protected-resource/);
  assert.equal((await json(noAuth)).error, "unauthorized");
  for (const token of ["no-scope", "no-subject"]) {
    const denied = await gateway(request("/v1/tools/get_customer", {}, { token }));
    assert.equal(denied.status, 403);
  }
  const invalidToken = await gateway(request("/v1/tools/get_customer", {}, { token: "bad" }));
  assert.equal(invalidToken.status, 401);
  assert.equal(calls.length, 0);
});

test("MCP initialize offers the latest supported version to an unknown client version", async () => {
  const { gateway, calls } = makeGateway();
  for (const protocolVersion of ["1900-01-01", "2099-12-31"]) {
    const response = await gateway(request("/mcp", { jsonrpc: "2.0", id: 1, method: "initialize", params: { protocolVersion } }, { token: "valid" }));
    assert.equal(response.status, 200);
    assert.equal((await json(response)).result.protocolVersion, MCP_PROTOCOL_VERSIONS[0]);
  }
  assert.equal(calls.length, 0);
});

test("origin checks, routes, methods, malformed initialization and protocol header mismatches fail closed", async () => {
  const { gateway, calls } = makeGateway();
  assert.equal((await gateway(request("/v1/tools/get_customer", {}, { token: "valid", origin: "https://attacker.example" }))).status, 403);
  assert.equal((await gateway(request("/v1/tools/delete_customer", {}, { token: "valid" }))).status, 404);
  assert.equal((await gateway(new Request("https://alternate.example.test/openapi.json"))).status, 421);
  assert.equal((await gateway(new Request(resourceOrigin + "/mcp", { method: "GET" }))).status, 405);
  const unsupportedHeader = await gateway(request("/mcp", { jsonrpc: "2.0", id: 1, method: "ping" }, { token: "valid", headers: { "mcp-protocol-version": "1900-01-01" } }));
  assert.equal(unsupportedHeader.status, 400);
  for (const protocolVersion of [undefined, null, 20251125, "", "invalid-version"]) {
    const invalidInitialize = await json(await gateway(request("/mcp", { jsonrpc: "2.0", id: 1, method: "initialize", params: { protocolVersion } }, { token: "valid" })));
    assert.equal(invalidInitialize.error.code, -32602);
  }
  for (const protocolVersion of [MCP_PROTOCOL_VERSIONS[1], "2099-12-31"]) {
    const mismatchedInitialize = await json(await gateway(request("/mcp", { jsonrpc: "2.0", id: 1, method: "initialize", params: { protocolVersion } }, { token: "valid", headers: { "mcp-protocol-version": MCP_PROTOCOL_VERSIONS[0] } })));
    assert.equal(mismatchedInitialize.error.code, -32602);
  }
  assert.equal(calls.length, 0);
});

test("body limit is enforced from streamed bytes and malformed JSON returns a generic error", async () => {
  const { gateway } = makeGateway({ bodyLimitBytes: 32 });
  const oversizedStream = new ReadableStream({
    start(controller) { controller.enqueue(new Uint8Array(20)); controller.enqueue(new Uint8Array(20)); controller.close(); },
  });
  const tooLarge = await gateway(request("/mcp", null, { token: "valid", rawBody: oversizedStream }));
  assert.equal(tooLarge.status, 413);
  const invalid = await gateway(request("/mcp", null, { token: "valid", rawBody: "{" }));
  assert.equal(invalid.status, 400);
  assert.equal((await json(invalid)).error.message, "Parse error");
});

test("tool exceptions do not leak details or create logs", async () => {
  const { gateway } = makeGateway({ executeTool: () => { throw new Error("secret customer contents"); } });
  const rest = await json(await gateway(request("/v1/tools/get_customer", {}, { token: "valid" })));
  assert.deepEqual(rest, { error: "tool_execution_failed" });
  const mcp = await json(await gateway(request("/mcp", { jsonrpc: "2.0", id: 8, method: "tools/call", params: { name: "get_customer", arguments: {} } }, { token: "valid" })));
  assert.equal(mcp.result.isError, true);
  assert.equal(JSON.stringify(mcp).includes("secret customer contents"), false);
});

test("business errors returned by a tool remain MCP isError results", async () => {
  const { gateway } = makeGateway({ executeTool: () => ({ isError: true, code: "not_found", detail: "synthetic" }) });
  const response = await json(await gateway(request("/mcp", { jsonrpc: "2.0", id: 9, method: "tools/call", params: { name: "get_customer", arguments: {} } }, { token: "valid" })));
  assert.equal(response.result.isError, true);
  assert.deepEqual(response.result.structuredContent, { isError: true, code: "not_found", detail: "synthetic" });
});

test("external OAuth scope changes metadata without weakening the internal authorization scope", async () => {
  const externalReadScope = resourceOrigin + "/kratos.read";
  const { gateway, calls } = makeGateway({ externalReadScope, verifyAccessToken: () => ({ subject: "user-1", scopes: [externalReadScope] }) });
  const denied = await gateway(request("/v1/tools/get_customer", {}, { token: "valid" }));
  assert.equal(denied.status, 403);
  assert.equal(calls.length, 0);
  for (const invalid of ["", 'read" injected="x', "scope one", "read\\scope", "read\nscope"]) assert.throws(() => makeGateway({ externalReadScope: invalid }), /external OAuth scope/);
});

test("fixed /mcp resource has scoped discovery and challenge without changing request origin", async () => {
  const resourceUrl = resourceOrigin + "/mcp";
  const { gateway } = makeGateway({ resourceUrl });
  const root = await json(await gateway(new Request(resourceOrigin + "/.well-known/oauth-protected-resource")));
  const scoped = await json(await gateway(new Request(resourceOrigin + "/.well-known/oauth-protected-resource/mcp")));
  assert.equal(scoped.resource, resourceUrl);
  assert.deepEqual(root, scoped);
  const denied = await gateway(request("/mcp", { jsonrpc: "2.0", id: 1, method: "ping" }));
  assert.equal(denied.status, 401);
  assert.ok(denied.headers.get("www-authenticate").includes(`resource_metadata="${resourceOrigin}/.well-known/oauth-protected-resource/mcp"`));
  assert.equal((await gateway(request("/mcp", { jsonrpc: "2.0", id: 1, method: "ping" }, { token: "valid" }))).status, 200);
  assert.equal((await gateway(new Request("https://evil.invalid/.well-known/oauth-protected-resource/mcp"))).status, 421);
  const { gateway: defaultGateway } = makeGateway();
  assert.equal((await defaultGateway(new Request(resourceOrigin + "/.well-known/oauth-protected-resource/mcp"))).status, 405);
  assert.equal((await json(await defaultGateway(new Request(resourceOrigin + "/.well-known/oauth-protected-resource")))).resource, resourceOrigin);
});

test("resource URL configuration accepts only exact origin or /mcp without URL normalization aliases", () => {
  makeGateway({ resourceUrl: resourceOrigin });
  for (const resourceUrl of [null, 42, "", resourceOrigin + "/", resourceOrigin + "/mcp/", resourceOrigin + "/MCP", resourceOrigin + "/%6dcp", resourceOrigin + "/x/../mcp", resourceOrigin + "/mcp?x=1", resourceOrigin + "/mcp#x", "https://evil.invalid/mcp", "https://user:secret@kratos.example.test/mcp", "https://KRATOS.example.test/mcp"]) {
    assert.throws(() => makeGateway({ resourceUrl }), /resourceUrl/);
  }
});
