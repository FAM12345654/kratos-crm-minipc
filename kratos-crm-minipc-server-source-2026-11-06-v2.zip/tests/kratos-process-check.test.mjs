import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { createServer } from 'node:http';
import { mkdtemp, mkdir, readFile, readdir, rm, writeFile, symlink } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { runKratosProcessCheck, verifyProcessReport, readVerifiedProcessReport } from '../scripts/kratos-process-check.mjs';

async function fixture(run) {
  const directory = await mkdtemp(path.join(os.tmpdir(), 'kratos-probe-'));
  const databasePath = path.join(directory, 'private-sentinel.sqlite');
  const reports = path.join(directory, 'reports'); await mkdir(reports);
  const db = new DatabaseSync(databasePath);
  db.exec('PRAGMA foreign_keys=ON; CREATE TABLE customers(id INTEGER PRIMARY KEY, private_note TEXT);');
  db.prepare('INSERT INTO customers VALUES (?,?)').run(1, 'sensitive-sentinel'); db.close();
  try { await run({ directory, databasePath, reports }); }
  finally {
    assert.equal(path.dirname(path.resolve(directory)), path.resolve(os.tmpdir()));
    assert.ok(path.basename(directory).startsWith('kratos-probe-'));
    await rm(directory, { recursive: true, force: true });
  }
}

async function endpoint(status, run) {
  const server = createServer((_request, response) => {
    response.writeHead(status, { 'www-authenticate': 'Bearer resource_metadata="https://synthetic.invalid/.well-known/oauth-protected-resource"' });
    response.end();
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  try { await run(`http://127.0.0.1:${server.address().port}`); }
  finally { await new Promise((resolve) => server.close(resolve)); }
}

test('technical run ID/checksum and local reports expose no data or paths and do not modify SQLite', async () => {
  await fixture(async ({ databasePath, reports }) => {
    const before = await readFile(databasePath);
    await endpoint(401, async (gatewayUrl) => {
      const report = await runKratosProcessCheck({ databasePath, gatewayUrl, reportDirectory: reports });
      assert.equal(report.status, 'ok'); assert.match(report.run_id, /^[a-f0-9-]{36}$/);
      assert.equal(verifyProcessReport(report), true);
      assert.equal(report.scope, 'technical_probe_only');
      const retained = await readVerifiedProcessReport(path.join(reports, 'latest.json'));
      assert.deepEqual(retained, report);
      assert.equal(JSON.stringify(report).includes('sensitive-sentinel'), false);
      assert.equal(JSON.stringify(report).includes(databasePath), false);
      assert.equal((await readdir(reports)).length, 2);
      assert.equal(verifyProcessReport({ ...report, status: 'failed' }), false);
      await assert.rejects(readVerifiedProcessReport(path.join(reports, 'latest.json'), { now: Date.now() + 3600000 }), { code: 'report_stale' });
      await assert.rejects(readVerifiedProcessReport(path.join(reports, 'latest.json'), { now: Date.now() - 3600000 }), { code: 'report_stale' });
    });
    assert.deepEqual(await readFile(databasePath), before);
  });
});

test('missing database fails without creating it and without disclosing its path', async () => {
  await fixture(async ({ directory }) => {
    const missing = path.join(directory, 'sensitive-sentinel-missing.sqlite');
    const report = await runKratosProcessCheck({ databasePath: missing });
    assert.equal(report.status, 'failed');
    assert.equal(report.checks[0].code, 'database_unavailable');
    assert.equal(JSON.stringify(report).includes('sensitive-sentinel'), false);
    assert.equal((await readdir(directory)).includes(path.basename(missing)), false);
  });
});

test('a gateway accepting an anonymous MCP request is reported failed, never healthy', async () => {
  await endpoint(200, async (gatewayUrl) => {
    const report = await runKratosProcessCheck({ gatewayUrl });
    assert.equal(report.status, 'failed');
    assert.equal(report.checks.find((row) => row.component === 'gateway').code, 'gateway_auth_boundary_failed');
  });
});

test('remote, credential-bearing and alternate localhost URL forms are rejected before probes', async () => {
  for (const gatewayUrl of ['https://127.0.0.1:8788', 'http://localhost:8788', 'http://127.0.0.1:8788/', 'http://user:secret@127.0.0.1:8788', 'http://example.invalid:8788']) {
    await assert.rejects(runKratosProcessCheck({ gatewayUrl }), { code: 'invalid_configuration' });
  }
  await assert.rejects(runKratosProcessCheck({}), { code: 'invalid_configuration' });
});

test('broken foreign keys fail integrity and altered reports fail checksum verification', async () => {
  await fixture(async ({ databasePath, reports }) => {
    const db = new DatabaseSync(databasePath);
    try { db.exec('PRAGMA foreign_keys=OFF; CREATE TABLE child(customer_id INTEGER REFERENCES customers(id)); INSERT INTO child VALUES (99);'); }
    finally { db.close(); }
    const report = await runKratosProcessCheck({ databasePath, reportDirectory: reports });
    assert.equal(report.checks[0].code, 'database_integrity_failed');
    const file = path.join(reports, 'latest.json');
    await writeFile(file, JSON.stringify({ ...report, status: 'ok' }));
    await assert.rejects(readVerifiedProcessReport(file), { code: 'report_integrity_failed' });
  });
});

test('report directory junctions are refused', async () => {
  await fixture(async ({ directory, databasePath, reports }) => {
    const alias = path.join(directory, 'alias');
    await symlink(reports, alias, process.platform === 'win32' ? 'junction' : 'dir');
    await assert.rejects(runKratosProcessCheck({ databasePath, reportDirectory: alias }), { code: 'unsafe_path' });
  });
});
