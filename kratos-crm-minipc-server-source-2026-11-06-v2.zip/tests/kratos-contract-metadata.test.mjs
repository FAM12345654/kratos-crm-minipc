import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import {
  isIsoCalendarDate,
  validateContractMetadata,
} from "../lib/kratos-contract-metadata.ts";

const evidence = { id: 201, customerId: 7 };
const base = {
  id: 10,
  customerId: 7,
  insuranceType: "Haushalt",
  provider: "Example Versicherung",
  policyNumber: "POL-123",
  conclusionDate: "2024-02-29",
  conclusionYear: 2024,
  mainDueDate: "2027-01-01",
  durationMonths: 36,
  noticePeriodCount: 3,
  noticePeriodUnit: "months",
  nextEligibleTerminationDate: "2027-01-01",
  latestNoticeReceiptDate: "2026-10-01",
  jurisdiction: "AT",
  verificationStatus: "verified",
  sourceReference: 201,
  verifiedFields: ["insuranceType", "provider", "policyNumber", "conclusionDate", "conclusionYear", "mainDueDate", "durationMonths", "noticePeriodCount", "noticePeriodUnit", "nextEligibleTerminationDate", "latestNoticeReceiptDate", "jurisdiction"],
  verifiedBy: "reviewer@example.invalid",
  verifiedAt: "2026-11-05T18:30:00.000Z",
  lifecycle: "current",
};
const validContext = { reviewConfirmed: true, sourceDocument: evidence };

test("calendar dates accept leap days and reject impossible or non-exact dates", () => {
  assert.equal(isIsoCalendarDate("2024-02-29"), true);
  assert.equal(isIsoCalendarDate("2023-02-29"), false);
  assert.equal(isIsoCalendarDate("2024-2-09"), false);
  assert.equal(isIsoCalendarDate("2024-03-01T00:00:00Z"), false);
});

test("legacy contract fields are primitive, bounded, and use the existing status enum while new metadata stays optional", () => {
  assert.deepEqual(validateContractMetadata({ insuranceType: "Haushalt", status: "Ungeprüft" }), { valid: true, errors: [] });
  for (const insuranceType of [null, true, [], {}, " ", "x".repeat(101)]) {
    assert.equal(validateContractMetadata({ insuranceType, status: "Aktiv" }).valid, false, `invalid insuranceType: ${String(insuranceType)}`);
  }
  for (const provider of [true, [], {}, "x".repeat(101)]) {
    assert.equal(validateContractMetadata({ insuranceType: "Haushalt", provider, status: "Aktiv" }).valid, false, `invalid provider: ${String(provider)}`);
  }
  assert.equal(validateContractMetadata({ insuranceType: "Haushalt", provider: null, status: "Aktiv" }).valid, true);
  for (const status of [null, true, [], {}, "Unbekannt"]) {
    assert.equal(validateContractMetadata({ insuranceType: "Haushalt", status }).valid, false, `invalid status: ${String(status)}`);
  }
  for (const status of ["Ungeprüft", "Antrag", "Aktiv", "Gekündigt", "Beendet"]) {
    assert.equal(validateContractMetadata({ insuranceType: "Haushalt", status }).valid, true);
  }
});

test("verified contract metadata requires explicit field review, actor, time, and a same-customer registered source", () => {
  assert.deepEqual(validateContractMetadata(base, validContext), { valid: true, errors: [] });
  assert.equal(validateContractMetadata(base).valid, false, "truthy source reference alone is not evidence review");
  assert.equal(validateContractMetadata(base, { ...validContext, reviewConfirmed: false }).valid, false);
  assert.equal(validateContractMetadata(base, { ...validContext, sourceDocument: { id: 201, customerId: 8 } }).valid, false);
  assert.equal(validateContractMetadata({ ...base, verifiedFields: ["insuranceType"] }, validContext).valid, false, "every populated field must be included in the explicit review scope");
});

test("main due date is stored as an independent fact without deriving termination dates", () => {
  const result = validateContractMetadata({ ...base, mainDueDate: "2026-01-15", nextEligibleTerminationDate: "2028-09-03" }, validContext);
  assert.equal(result.valid, true);
});

test("notice period count and unit must be paired, and conclusion year must match exact conclusion date", () => {
  assert.equal(validateContractMetadata({ ...base, noticePeriodUnit: null }, validContext).valid, false);
  assert.equal(validateContractMetadata({ ...base, conclusionYear: 2023 }, validContext).valid, false);
  assert.equal(validateContractMetadata({ ...base, conclusionDate: "2023-02-29", conclusionYear: 2023 }, validContext).valid, false);
});

test("former lifecycle requires a distinct verified replacement contract and its registered same-customer evidence", () => {
  const replacementContract = {
    id: 11,
    customerId: 7,
    verificationStatus: "verified",
    sourceReference: 202,
    verifiedFields: ["insuranceType", "policyNumber"],
    verifiedBy: "reviewer@example.invalid",
    verifiedAt: "2026-11-05T18:31:00.000Z",
  };
  const result = validateContractMetadata({ ...base, lifecycle: "former", replacementContractId: 11 }, {
    ...validContext,
    replacementContract,
    replacementSourceDocument: { id: 202, customerId: 7 },
  });
  assert.equal(result.valid, true, result.errors.join("; "));
  assert.equal(validateContractMetadata({ ...base, lifecycle: "former", replacementContractId: 10 }, validContext).valid, false, "self replacement is rejected");
  assert.equal(validateContractMetadata({ ...base, lifecycle: "former", replacementContractId: 11 }, { ...validContext, replacementContract: { ...replacementContract, verificationStatus: "unverified" } }).valid, false);
  assert.equal(validateContractMetadata({ ...base, lifecycle: "former", replacementContractId: 11 }, { ...validContext, replacementContract, replacementSourceDocument: { id: 202, customerId: 8 } }).valid, false);
});

test("generated additive migrations preserve existing fields and default existing lifecycle to unverified", async () => {
  const database = new DatabaseSync(":memory:");
  database.exec("PRAGMA foreign_keys=ON;");
  database.exec("CREATE TABLE customers(id INTEGER PRIMARY KEY);");
  database.exec("CREATE TABLE customer_documents(id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customers(id));");
  database.exec(`CREATE TABLE customer_contracts(
    id INTEGER PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    insurance_type TEXT NOT NULL,
    provider TEXT,
    status TEXT NOT NULL DEFAULT 'Ungeprüft',
    start_date TEXT,
    end_date TEXT,
    cancellation_deadline TEXT,
    document_url TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by TEXT NOT NULL
  );`);
  database.exec("INSERT INTO customers(id) VALUES (7);");
  database.exec("INSERT INTO customer_documents(id,customer_id) VALUES (201,7),(202,7);");
  database.exec("INSERT INTO customer_contracts(id,customer_id,insurance_type,provider,status,start_date,updated_by) VALUES (10,7,'Haushalt','Example Versicherung','Aktiv','2024-02-29','synthetic');");

  for (const name of ["0008_fancy_starbolt.sql", "0009_aromatic_rocket_racer.sql"]) {
    const sql = await readFile(path.resolve("drizzle", name), "utf8");
    database.exec(sql.replaceAll("--> statement-breakpoint", ""));
  }

  const contract = database.prepare("SELECT * FROM customer_contracts WHERE id=10").get();
  assert.equal(contract.provider, "Example Versicherung");
  assert.equal(contract.start_date, "2024-02-29");
  assert.equal(contract.lifecycle, "unverified");
  assert.equal(contract.verification_status, "unverified");
  assert.equal(contract.policy_number, null);
  assert.equal(contract.source_reference, null);
  database.prepare("INSERT INTO customer_contracts(id,customer_id,insurance_type,status,updated_by,source_reference) VALUES (11,7,'Kfz','Aktiv','synthetic',202)").run();
  assert.throws(() => database.prepare("INSERT INTO customer_contracts(id,customer_id,insurance_type,status,updated_by,source_reference) VALUES (12,7,'Kfz','Aktiv','synthetic',999)").run(), /FOREIGN KEY/);
  database.close();
});
