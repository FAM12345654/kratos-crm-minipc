import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {mkdtemp, readdir, rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const script=path.resolve('scripts/start-kratos-local.mjs');
async function rejectsStartup(overrides={}) {
 const dir=await mkdtemp(path.join(os.tmpdir(),'kratos-cli-preflight-'));
 const env={...process.env};
 for(const key of Object.keys(env))if(key.startsWith('KRATOS_LOCAL_'))delete env[key];
 Object.assign(env,overrides);
 try {
  const result=spawnSync(process.execPath,[script],{cwd:dir,env,encoding:'utf8',timeout:10000,windowsHide:true});
  assert.equal(result.status,1);assert.equal(result.stdout,'');
  const error=JSON.parse(result.stderr.trim());
  assert.equal(error.error,'Kratos local server failed to start. Check required local configuration.');
  assert.deepEqual(await readdir(dir),[],'Rejected config must not generate bundles or data files');
  assert.equal(result.stderr.includes('sensitive-sentinel'),false);
 }finally{
  const resolved=path.resolve(dir), root=path.resolve(os.tmpdir());
  assert.equal(path.dirname(resolved),root);assert.ok(path.basename(resolved).startsWith('kratos-cli-preflight-'));
  await rm(resolved,{recursive:true,force:true});
 }
}
test('CLI refuses missing configuration before creating runtime files or a listener',()=>rejectsStartup());
test('CLI refuses malformed subject JSON without leaking provided values',()=>rejectsStartup({KRATOS_LOCAL_DB_PATH:path.resolve('sensitive-sentinel.sqlite'),KRATOS_LOCAL_ALLOWED_SUBJECTS:'sensitive-sentinel-invalid-json'}));

const tenantId='11111111-1111-4111-8111-111111111111';
const apiClientId='22222222-2222-4222-8222-222222222222';
const clientId='33333333-3333-4333-8333-333333333333';
const entraBase={KRATOS_LOCAL_AUTH_MODE:'entra',KRATOS_LOCAL_DB_PATH:path.resolve('sensitive-sentinel.sqlite'),KRATOS_LOCAL_RESOURCE_ORIGIN:'https://synthetic.invalid',KRATOS_LOCAL_ALLOWED_SUBJECTS:JSON.stringify([tenantId+':44444444-4444-4444-8444-444444444444']),KRATOS_LOCAL_ENTRA_TENANT_ID:tenantId,KRATOS_LOCAL_ENTRA_API_CLIENT_ID:apiClientId,KRATOS_LOCAL_ENTRA_ALLOWED_CLIENT_IDS:JSON.stringify([clientId])};
test('CLI rejects unknown auth profiles before runtime files',()=>rejectsStartup({KRATOS_LOCAL_AUTH_MODE:'automatic'}));
test('CLI rejects missing, mixed or malformed Entra config before runtime files',async()=>{
 for(const overrides of [{KRATOS_LOCAL_ENTRA_API_CLIENT_ID:''},{KRATOS_LOCAL_OAUTH_ISSUER:'https://sensitive-sentinel.invalid'}, {KRATOS_LOCAL_ENTRA_ALLOWED_CLIENT_IDS:'not-json'}, {KRATOS_LOCAL_ENTRA_ALLOWED_CLIENT_IDS:JSON.stringify([apiClientId])}, {KRATOS_LOCAL_ALLOWED_SUBJECTS:JSON.stringify(['anyone@example.invalid'])}, {KRATOS_LOCAL_ENTRA_TENANT_ID:'common'}])await rejectsStartup({...entraBase,...overrides});
});
test('CLI generic profile rejects Entra settings instead of silently ignoring them',()=>rejectsStartup({...entraBase,KRATOS_LOCAL_AUTH_MODE:'generic',KRATOS_LOCAL_OAUTH_ISSUER:'https://issuer.invalid',KRATOS_LOCAL_OAUTH_JWKS_URI:'https://issuer.invalid/keys'}));

test('CLI rejects noncanonical or cross-origin resource URLs before runtime files',async()=>{
 for(const resourceUrl of ['',entraBase.KRATOS_LOCAL_RESOURCE_ORIGIN+'/',entraBase.KRATOS_LOCAL_RESOURCE_ORIGIN+'/mcp/',entraBase.KRATOS_LOCAL_RESOURCE_ORIGIN+'/%6dcp',entraBase.KRATOS_LOCAL_RESOURCE_ORIGIN+'/x/../mcp',entraBase.KRATOS_LOCAL_RESOURCE_ORIGIN+'/mcp?x=1',entraBase.KRATOS_LOCAL_RESOURCE_ORIGIN+'/mcp#x','https://evil.invalid/mcp'])await rejectsStartup({...entraBase,KRATOS_LOCAL_RESOURCE_URL:resourceUrl});
});

const genericBase={KRATOS_LOCAL_DB_PATH:path.resolve('sensitive-sentinel.sqlite'),KRATOS_LOCAL_RESOURCE_ORIGIN:'https://synthetic.invalid',KRATOS_LOCAL_ALLOWED_SUBJECTS:JSON.stringify(['synthetic-owner']),KRATOS_LOCAL_OAUTH_ISSUER:'https://issuer.invalid',KRATOS_LOCAL_OAUTH_JWKS_URI:'https://issuer.invalid/keys'};
test('CLI rejects disabled, partial and malformed case settings before runtime files',async()=>{
 for(const overrides of [{KRATOS_LOCAL_CASES_ENABLED:'yes'},{KRATOS_LOCAL_CASES_CUSTOMER_IDS:'[1]'},{KRATOS_LOCAL_CASES_ENABLED:'false',KRATOS_LOCAL_CASES_WRITES_ENABLED:'true'},{KRATOS_LOCAL_CASES_ENABLED:'true'},
  {KRATOS_LOCAL_CASES_ENABLED:'true',KRATOS_LOCAL_CASES_WRITES_ENABLED:'yes',KRATOS_LOCAL_CASES_CUSTOMER_IDS:'[1]'},
  {KRATOS_LOCAL_CASES_ENABLED:'true',KRATOS_LOCAL_CASES_WRITES_ENABLED:'true',KRATOS_LOCAL_CASES_CUSTOMER_IDS:'["1"]'},
  {KRATOS_LOCAL_CASES_ENABLED:'true',KRATOS_LOCAL_CASES_WRITES_ENABLED:'true',KRATOS_LOCAL_CASES_CUSTOMER_IDS:'[1,1]'}])await rejectsStartup({...genericBase,...overrides});
});
test('CLI does not enable the case API for the read-only Entra profile',()=>rejectsStartup({...entraBase,KRATOS_LOCAL_CASES_ENABLED:'true',KRATOS_LOCAL_CASES_WRITES_ENABLED:'true',KRATOS_LOCAL_CASES_CUSTOMER_IDS:'[1]'}));

test('CLI rejects missing and malformed opt-in document settings before runtime files', async () => {
 for (const overrides of [
  { KRATOS_LOCAL_DOCUMENTS_ENABLED: 'yes' },
  { KRATOS_LOCAL_DOCUMENTS_ROOT: path.resolve('sensitive-sentinel') },
  { KRATOS_LOCAL_DOCUMENTS_ENABLED: 'true', KRATOS_LOCAL_DOCUMENTS_ROOT: 'relative', KRATOS_LOCAL_DOCUMENTS_CUSTOMER_IDS: '[1]' },
  { KRATOS_LOCAL_DOCUMENTS_ENABLED: 'true', KRATOS_LOCAL_DOCUMENTS_ROOT: path.resolve('sensitive-sentinel'), KRATOS_LOCAL_DOCUMENTS_CUSTOMER_IDS: '[1,1]' },
 ]) await rejectsStartup({ ...genericBase, ...overrides });
});

test('CLI requires separate generic opt-in and private-root attestation for document uploads', async () => {
 const uploads = {
  KRATOS_LOCAL_DOCUMENT_UPLOADS_ENABLED: 'true',
  KRATOS_LOCAL_DOCUMENT_UPLOADS_ROOT: path.resolve('sensitive-sentinel'),
  KRATOS_LOCAL_DOCUMENT_UPLOADS_CUSTOMER_IDS: '[1]',
  KRATOS_LOCAL_DOCUMENT_UPLOADS_PRIVATE_ROOT_CONFIRMED: 'true',
 };
 await rejectsStartup({ ...entraBase, ...uploads });
 for (const overrides of [
  { KRATOS_LOCAL_DOCUMENT_UPLOADS_ENABLED: 'false' },
  { KRATOS_LOCAL_DOCUMENT_UPLOADS_PRIVATE_ROOT_CONFIRMED: 'false' },
  { KRATOS_LOCAL_DOCUMENT_UPLOADS_ROOT: 'relative' },
  { KRATOS_LOCAL_DOCUMENT_UPLOADS_CUSTOMER_IDS: '[1,1]' },
 ]) await rejectsStartup({ ...genericBase, ...uploads, ...overrides });
});
