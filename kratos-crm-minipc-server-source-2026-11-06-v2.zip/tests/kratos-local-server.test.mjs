import test, { after } from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { build } from "esbuild";
import { generateKeyPair, SignJWT } from "jose";
import { createHash } from "node:crypto";
import { mkdir, mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";

const bundle = await build({ entryPoints: [path.resolve("integrations/kratos-local-server/server.ts")], bundle: true, platform: "node", format: "esm", write: false });
const bundleDirectory = await mkdtemp(path.join(os.tmpdir(), "kratos-http-bundle-"));
const bundleFile = path.join(bundleDirectory, "server.mjs");
after(async () => {
  assert.equal(path.dirname(path.resolve(bundleDirectory)), path.resolve(os.tmpdir()));
  assert.ok(path.basename(bundleDirectory).startsWith("kratos-http-bundle-"));
  await rm(bundleDirectory, { recursive: true, force: true });
});
await (await import("node:fs/promises")).writeFile(bundleFile, bundle.outputFiles[0].contents);
const { createKratosLocalServer } = await import(pathToFileURL(bundleFile).href);
const origin = "https://kratos-resource.synthetic.invalid";
const issuer = "https://kratos-issuer.synthetic.invalid/";
const { privateKey, publicKey } = await generateKeyPair("RS256");
const entraTenant = "11111111-1111-4111-8111-111111111111";
const entraApi = "22222222-2222-4222-8222-222222222222";
const entraClient = "33333333-3333-4333-8333-333333333333";
const entraOwner = "44444444-4444-4444-8444-444444444444";
const documentBytes = Buffer.from([0, 255, 7, 10, 13]);

async function entraToken(overrides = {}) {
  const now = Math.floor(Date.now() / 1000);
  return new SignJWT({ iss: `https://login.microsoftonline.com/${entraTenant}/v2.0`, aud: entraApi,
    tid: entraTenant, oid: entraOwner, sub: "synthetic-subject", ver: "2.0", azp: entraClient,
    scp: "kratos.read", iat: now, nbf: now - 1, exp: now + 5400, ...overrides })
    .setProtectedHeader({ alg: "RS256", typ: "JWT", kid: "synthetic-key" }).sign(privateKey);
}

async function token(claims = {}) {
  const now = Math.floor(Date.now() / 1000);
  return new SignJWT({ iss: issuer, aud: origin, sub: "synthetic-owner", scope: "kratos:read", ...claims })
    .setProtectedHeader({ alg: "RS256", typ: "at+jwt", kid: "synthetic-key" })
    .setIssuedAt(now).setExpirationTime(now + 300).sign(privateKey);
}

async function withServer(run, overrides = {}) {
  const directory = await mkdtemp(path.join(os.tmpdir(), "kratos-local-http-"));
  const databasePath = path.join(directory, "synthetic.sqlite");
  const writer = new DatabaseSync(databasePath);
  try {
    writer.exec("PRAGMA foreign_keys=ON");
    const migrationNames = (await readdir(path.resolve("drizzle"))).filter((name) => /^\d{4}_.*\.sql$/.test(name)).sort();
    for (const name of migrationNames) writer.exec((await readFile(path.resolve("drizzle", name), "utf8")).replaceAll("--> statement-breakpoint", ""));
    writer.prepare("INSERT INTO customers(id,first_name,last_name,phone,email,authority_status,adviser,status,folder_name,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)")
      .run(1, "Ada", "Lovelace", "+1 555 0100", "ada@example.invalid", "Vorhanden", "Morgan", "Kunde", "Ada Lovelace", "synthetic");
    writer.prepare("INSERT INTO customers(id,first_name,last_name,phone,email,authority_status,adviser,status,folder_name,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)")
      .run(2, "Grace", "Hopper", "+1 555 0200", "grace@example.invalid", "Ungeprüft", "Morgan", "Kunde", "Grace Hopper", "synthetic");
    writer.prepare("INSERT INTO storage_files(id,customer_id,file_name,object_key,size_bytes,mime_type,sha256,import_state,created_by,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)")
      .run(501, 1, "synthetic.pdf", "synthetic/opaque-key", 12, "application/pdf", "a".repeat(64), "stored", "synthetic", "2026-11-05T12:00:00.000Z");
    const effectiveOverrides = { ...overrides };
    const objectRoot = path.join(directory, "objects");
    if (overrides.documentDownloads === true) {
      const root = objectRoot;
      await mkdir(path.join(root, "local"), { recursive: true });
      const insert = writer.prepare("INSERT INTO storage_files(id,customer_id,file_name,object_key,size_bytes,mime_type,sha256,import_state,created_by,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)");
      for (const [id, customerId, bytes, storedBytes, size] of [
        [601, 1, documentBytes, documentBytes, documentBytes.length],
        [602, 2, documentBytes, documentBytes, documentBytes.length],
        [603, 1, documentBytes, Buffer.alloc(documentBytes.length), documentBytes.length],
        [604, 1, Buffer.alloc(0), Buffer.alloc(0), 0],
        [605, 1, documentBytes, documentBytes, 20 * 1024 * 1024 + 1],
        [606, 1, documentBytes, Buffer.concat([documentBytes, Buffer.alloc(1)]), documentBytes.length],
      ]) {
        const key = "local/" + id.toString(16).padStart(32, "0") + ".bin";
        await writeFile(path.join(root, key), storedBytes);
        insert.run(id, customerId, "synthetic-Übersicht.pdf", key, size, "application/pdf", createHash("sha256").update(bytes).digest("hex"), "stored", "synthetic", "2026-11-05T12:00:00.000Z");
      }
      effectiveOverrides.documentDownloads = { root, allowedCustomerIds: [1] };
    }
    if (overrides.documentUploads === true) {
      await mkdir(objectRoot, { recursive: true });
      effectiveOverrides.documentUploads = { root: objectRoot, allowedCustomerIds: [1], privateRootConfirmed: true };
    }
    writer.close();
    const app = await createKratosLocalServer({
      databasePath, resourceOrigin: origin, issuer, jwksUri: issuer + "keys", allowedSubjects: ["synthetic-owner"], port: 0,
      verificationKey: async (header) => header.kid === "synthetic-key" ? publicKey : null,
      requestDeadlineMs: 10_000, responseDeadlineMs: 5_000, ...effectiveOverrides,
    });
    const address = await app.listen();
    try { await run({ databasePath, objectRoot, app, address, base: `http://${address.address}:${address.port}` }); }
    finally { await app.close(); }
  } finally {
    try { writer.close(); } catch { /* closed before server startup */ }
    await rm(directory, { recursive: true, force: true });
  }
}

async function request(base, pathname, { method = "POST", body = {}, bearer, headers = {} } = {}) {
  return fetch(base + pathname, {
    method,
    headers: { ...(method === "POST" ? { "content-type": "application/json" } : {}), ...(bearer ? { authorization: `Bearer ${bearer}` } : {}), ...headers },
    ...(method === "POST" ? { body: typeof body === "string" ? body : JSON.stringify(body) } : {}),
  });
}

function upload(base, bearer, bytes = documentBytes, overrides = {}) {
  return fetch(base + "/v1/documents/upload", {
    method: "POST", body: bytes,
    headers: {
      ...(bearer ? { authorization: `Bearer ${bearer}` } : {}),
      "content-type": "application/octet-stream", "x-kratos-customer-id": "1",
      "x-kratos-file-name": encodeURIComponent("synthetic-Übersicht.bin"),
      "x-kratos-sha256": createHash("sha256").update(bytes).digest("hex"),
      "idempotency-key": "synthetic-upload", ...overrides,
    },
  });
}

test("opt-in upload verifies bytes, binds customer, and safely replays a subject-specific idempotency key", async () => {
  await withServer(async ({ base, databasePath, objectRoot }) => {
    const signed = await token({ scope: "kratos:documents:write" });
    const first = await upload(base, signed);
    assert.equal(first.status, 201);
    const result = await first.json();
    assert.equal(result.duplicate, false);
    assert.equal(result.size_bytes, documentBytes.length);
    assert.equal(result.sha256, createHash("sha256").update(documentBytes).digest("hex"));
    const again = await upload(base, signed);
    assert.equal(again.status, 200);
    assert.deepEqual(await again.json(), { ...result, duplicate: true });
    assert.equal((await upload(base, signed, Buffer.from("different"))).status, 409);
    assert.equal((await upload(base, signed, documentBytes, { "x-kratos-file-name": "another-name.bin" })).status, 409);
    const retrieved = await request(base, `/v1/documents/${result.id}`, { method: "GET", bearer: await token() });
    assert.equal(retrieved.status, 200);
    assert.deepEqual(Buffer.from(await retrieved.arrayBuffer()), documentBytes);
    const other = await upload(base, await token({ scope: "kratos:documents:write", sub: "synthetic-second-owner" }));
    assert.equal(other.status, 201);
    const second = await other.json();
    assert.notEqual(second.id, result.id);
    const database = new DatabaseSync(databasePath, { readOnly: true });
    try {
      const row = database.prepare("SELECT customer_id,file_name,object_key FROM storage_files WHERE id=?").get(result.id);
      assert.equal(row.customer_id, 1);
      assert.equal(row.file_name, "synthetic-Übersicht.bin");
      assert.deepEqual(await readFile(path.join(objectRoot, row.object_key)), documentBytes);
      assert.equal(database.prepare("SELECT count(*) AS n FROM storage_audit_events WHERE file_id=?").get(result.id).n, 1);
    } finally { database.close(); }
  }, { documentUploads: true, documentDownloads: true, allowedSubjects: ["synthetic-owner", "synthetic-second-owner"] });
});

test("uploads stay disabled by default and reject denied, corrupt, and oversized input before writing", async () => {
  const signed = await token({ scope: "kratos:documents:write" });
  await withServer(async ({ base }) => {
    assert.equal((await upload(base, signed)).status, 404);
  });
  await withServer(async ({ base, address, databasePath, objectRoot }) => {
    assert.equal((await upload(base)).status, 401);
    assert.equal((await upload(base, await token())).status, 403);
    assert.equal((await upload(base, await token({ scope: "kratos:documents:write", sub: "unknown-owner" }))).status, 403);
    assert.equal((await upload(base, signed, documentBytes, { origin: "https://untrusted.invalid" })).status, 403);
    assert.equal((await upload(base, signed, documentBytes, { "x-kratos-customer-id": "2" })).status, 404);
    assert.equal((await upload(base, signed, documentBytes, { "x-kratos-file-name": "..%2Fsecret.bin" })).status, 400);
    assert.equal((await upload(base, signed, documentBytes, { "x-kratos-sha256": "a".repeat(64) })).status, 422);
    // Verify the early rejection with headers only. Sending an oversized body
    // concurrently with the rejection can reset the socket before fetch reads it.
    const oversized = await rawRequest(address.port, [
      "POST /v1/documents/upload HTTP/1.1", `Host: 127.0.0.1:${address.port}`,
      `Authorization: Bearer ${signed}`, "Content-Type: application/octet-stream",
      "Content-Length: 1048577", "X-Kratos-Customer-Id: 1", "X-Kratos-File-Name: large.bin",
      "X-Kratos-Sha256: " + "a".repeat(64), "Idempotency-Key: oversize", "Connection: close", "", "",
    ].join("\r\n"));
    assert.match(oversized, /^HTTP\/1\.1 413 /);
    assert.deepEqual(await readdir(objectRoot), []);
    const database = new DatabaseSync(databasePath, { readOnly: true });
    try { assert.equal(database.prepare("SELECT count(*) AS n FROM storage_files").get().n, 1); }
    finally { database.close(); }
  }, { documentUploads: true });
});

test("timed-out upload cannot write after delayed JWT verification resumes", async () => {
  let releaseKey;
  const delayedKey = new Promise((resolve) => { releaseKey = resolve; });
  let resolverEntered = false;
  await withServer(async ({ base, databasePath, objectRoot }) => {
    try {
      const response = await upload(base, await token({ scope: "kratos:documents:write" }));
      assert.equal(response.status, 504);
      assert.equal(resolverEntered, true);
    } finally { releaseKey(publicKey); }
    await new Promise((resolve) => setTimeout(resolve, 100));
    assert.deepEqual(await readdir(objectRoot), []);
    const database = new DatabaseSync(databasePath, { readOnly: true });
    try { assert.equal(database.prepare("SELECT count(*) AS n FROM storage_files").get().n, 1); }
    finally { database.close(); }
  }, { documentUploads: true, responseDeadlineMs: 50, verificationKey: async () => { resolverEntered = true; return delayedKey; } });
});

test("local downloads require explicit opt-in", async () => {
  await withServer(async ({ base }) => {
    const response = await request(base, "/v1/documents/501", { method: "GET", bearer: await token() });
    assert.equal(response.status, 404);
    assert.deepEqual(await response.json(), { error: "not_found" });
  });
});

test("opt-in downloads verify JWT, customer ACL, byte count and checksum before responding", async () => {
  await withServer(async ({ base }) => {
    const bearer = await token();
    const get = (id, settings) => request(base, "/v1/documents/" + id, { method: "GET", bearer, ...settings });
    const missingAuth = await get(601, { bearer: undefined });
    assert.equal(missingAuth.status, 401);
    assert.match(missingAuth.headers.get("www-authenticate"), /^Bearer /);
    assert.equal((await get(601, { bearer: "invalid" })).status, 401);
    assert.equal((await get(601, { bearer: await token({ sub: "foreign-owner" }) })).status, 403);
    assert.equal((await get(601, { bearer: await token({ scope: "other:read" }) })).status, 403);
    assert.equal((await get(601, { headers: { origin: "https://foreign.invalid" } })).status, 403);
    assert.equal((await get(601, { headers: { "sec-fetch-site": "cross-site" } })).status, 403);
    assert.equal((await get(601, { method: "HEAD" })).status, 405);
    for (const id of [602, 603, 606, 999, "01", "9007199254740992"]) {
      const denied = await get(id);
      assert.equal(denied.status, 404);
      assert.deepEqual(await denied.json(), { error: "not_found" });
    }
    assert.equal((await get(605)).status, 413);
    const bytes = await get(601, { headers: { origin } });
    assert.equal(bytes.status, 200);
    assert.equal(bytes.headers.get("cache-control"), "no-store");
    assert.equal(bytes.headers.get("content-type"), "application/octet-stream");
    assert.equal(bytes.headers.get("x-content-type-options"), "nosniff");
    assert.equal(bytes.headers.get("content-disposition"), 'attachment; filename="kratos-document-601.bin"');
    assert.deepEqual(Buffer.from(await bytes.arrayBuffer()), documentBytes);
    const metadata = await request(base, "/v1/tools/get_stored_customer_file", { bearer, body: { file_id: 601 } });
    assert.equal(metadata.status, 200);
    const file = await metadata.json();
    assert.equal(file.local_download_path_template, "/v1/documents/{id}");
    assert.equal(file.download_path, undefined);
    assert.equal(file.gateway_download_available, undefined);
    const empty = await get(604);
    assert.equal(empty.status, 200);
    assert.equal((await empty.arrayBuffer()).byteLength, 0);
  }, { documentDownloads: true });
});

test("opt-in downloads also accept the established Entra read-only identity", async () => {
  const entra = { tenantId: entraTenant, apiClientId: entraApi, allowedClientIds: [entraClient] };
  await withServer(async ({ base }) => {
    const response = await request(base, "/v1/documents/601", { method: "GET", bearer: await entraToken() });
    assert.equal(response.status, 200);
    assert.deepEqual(Buffer.from(await response.arrayBuffer()), documentBytes);
  }, { documentDownloads: true, entra, issuer: undefined, jwksUri: undefined, allowedSubjects: [entraTenant + ":" + entraOwner] });
});

function rawRequest(port, raw) {
  return new Promise((resolve, reject) => {
    const socket = net.connect(port, "127.0.0.1", () => socket.write(raw));
    const chunks = [];
    socket.on("data", (chunk) => chunks.push(chunk));
    socket.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    socket.on("error", reject);
    socket.setTimeout(3000, () => socket.destroy(new Error("raw request timed out")));
  });
}

function slowBodyRequest(port) {
  return new Promise((resolve, reject) => {
    const socket = net.connect(port, "127.0.0.1", () => {
      socket.write(`POST /v1/tools/get_customer HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nContent-Type: application/json\r\nAuthorization: Bearer ${"x".repeat(32)}\r\nContent-Length: 100\r\nConnection: close\r\n\r\n{"customer_id":`);
    });
    const chunks = [];
    socket.on("data", (chunk) => chunks.push(chunk));
    socket.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    socket.on("error", reject);
    setTimeout(() => socket.destroy(), 2000).unref();
  });
}

test("real loopback HTTP gateway verifies JWTs and serves customer search/details and gateway metadata", async () => {
  await withServer(async ({ base, address }) => {
    assert.equal(address.address, "127.0.0.1");
    const valid = await token();
    const search = await request(base, "/v1/tools/search_customers", { bearer: valid, body: { query: "Ada Lovelace", limit: 10, offset: 0 } });
    assert.equal(search.status, 200);
    const result = await search.json();
    assert.equal(result.total_count, 1);
    assert.deepEqual(result.customers[0].matched_by, ["name"]);
    const details = await request(base, "/v1/tools/get_customer", { bearer: valid, body: { customer_id: 1, fields: ["first_name", "phone", "email"] } });
    assert.deepEqual(await details.json(), { id: 1, first_name: "Ada", phone: "+1 555 0100", email: "ada@example.invalid" });
    const metadata = await request(base, "/.well-known/oauth-protected-resource", { method: "GET" });
    assert.equal(metadata.status, 200);
    assert.equal((await metadata.json()).resource, origin);
    const openapi = await request(base, "/openapi.json", { method: "GET" });
    assert.equal(openapi.status, 200);
    assert.ok((await openapi.json()).paths["/v1/tools/get_customer"]);
  });
});

test("wrong or missing bearer, subject, audience, and origin fail closed", async () => {
  await withServer(async ({ base }) => {
    assert.equal((await request(base, "/v1/tools/get_customer", { body: { customer_id: 1 } })).status, 401);
    assert.equal((await request(base, "/v1/tools/get_customer", { bearer: "not-a-jwt", body: { customer_id: 1 } })).status, 401);
    assert.equal((await request(base, "/v1/tools/get_customer", { bearer: await token({ sub: "another-owner" }), body: { customer_id: 1 } })).status, 403);
    assert.equal((await request(base, "/v1/tools/get_customer", { bearer: await token({ aud: "https://wrong.synthetic.invalid" }), body: { customer_id: 1 } })).status, 401);
    assert.equal((await request(base, "/v1/tools/get_customer", { bearer: await token(), body: { customer_id: 1 }, headers: { origin: "https://evil.synthetic.invalid" } })).status, 403);
  });
});

test("request body and parser errors are bounded and generic; unknown tools and writes stay unavailable", async () => {
  await withServer(async ({ base, databasePath }) => {
    const valid = await token();
    const oversized = await request(base, "/v1/tools/get_customer", { bearer: valid, body: "x".repeat(65 * 1024), headers: { "content-type": "application/json" } });
    assert.equal(oversized.status, 413);
    assert.deepEqual(await oversized.json(), { error: "body_too_large" });
    const malformed = await request(base, "/v1/tools/get_customer", { bearer: valid, body: "private-customer-name: {broken" });
    assert.equal(malformed.status, 400);
    assert.equal((await malformed.text()).includes("private-customer-name"), false);
    assert.equal((await request(base, "/v1/tools/create_customer", { bearer: valid, body: { first_name: "Injected", last_name: "Write" } })).status, 404);
    assert.equal((await request(base, "/v1/tools/get_customer/extra", { bearer: valid, body: { customer_id: 1 } })).status, 404);
    const check = new DatabaseSync(databasePath, { readOnly: true });
    assert.equal(check.prepare("SELECT count(*) AS count FROM customers WHERE first_name='Injected'").get().count, 0);
    check.close();
    const download = await request(base, "/v1/tools/get_stored_customer_file", { bearer: valid, body: { file_id: 501 } });
    const fileMetadata = await download.json();
    assert.equal(download.status, 200);
    assert.equal("download_path" in fileMetadata, false);
    assert.equal(fileMetadata.gateway_download_available, false);
  });
});

test("Host header is pinned to the actual loopback port and duplicate Host is rejected", async () => {
  await withServer(async ({ address }) => {
    const wrongHost = await rawRequest(address.port, "GET /.well-known/oauth-protected-resource HTTP/1.1\r\nHost: evil.invalid\r\nConnection: close\r\n\r\n");
    assert.match(wrongHost, /HTTP\/1\.1 421/);
    const duplicateHostResponse = await rawRequest(address.port, `GET /.well-known/oauth-protected-resource HTTP/1.1\r\nHost: 127.0.0.1:${address.port}\r\nHost: evil.invalid\r\nConnection: close\r\n\r\n`);
    assert.match(duplicateHostResponse, /HTTP\/1\.1 (400|421)/);
  });
});

test("absolute request-body deadline returns 408 and never dispatches an incomplete request", async () => {
  await withServer(async ({ address }) => {
    const response = await slowBodyRequest(address.port);
    assert.match(response, /HTTP\/1\.1 408/);
    assert.match(response, /request_timeout/);
  }, { requestDeadlineMs: 150 });
});

test("shutdown closes stalled loopback clients within a bounded interval before releasing SQLite", async () => {
  await withServer(async ({ app, address }) => {
    const socket = net.connect(address.port, "127.0.0.1");
    await new Promise((resolve, reject) => { socket.once("connect", resolve); socket.once("error", reject); });
    socket.write(`POST /v1/tools/get_customer HTTP/1.1\r\nHost: 127.0.0.1:${address.port}\r\nContent-Type: application/json\r\nContent-Length: 100\r\nConnection: keep-alive\r\n\r\n{"customer_id":`);
    await new Promise((resolve) => setTimeout(resolve, 30));
    const started = Date.now();
    await app.close();
    assert.ok(Date.now() - started < 1500);
    socket.destroy();
  }, { requestDeadlineMs: 10_000 });
});

test("bind failure closes its SQLite handle and reports a generic error", async () => {
  await withServer(async ({ databasePath, address }) => {
    const blocked = await createKratosLocalServer({
      databasePath, resourceOrigin: origin, issuer, jwksUri: issuer + "keys", allowedSubjects: ["synthetic-owner"], port: address.port,
      verificationKey: async (header) => header.kid === "synthetic-key" ? publicKey : null,
    });
    await assert.rejects(blocked.listen(), /could not be started/);
    await blocked.close();
    const reopened = await createKratosLocalServer({
      databasePath, resourceOrigin: origin, issuer, jwksUri: issuer + "keys", allowedSubjects: ["synthetic-owner"], port: 0,
      verificationKey: async (header) => header.kid === "synthetic-key" ? publicKey : null,
    });
    await reopened.listen();
    await reopened.close();
  });
});

test("origin-form only; forwarded headers do not change the configured resource origin; close releases loopback listener", async () => {
  await withServer(async ({ base, app, address }) => {
    const valid = await token();
    const forwarded = await request(base, "/v1/tools/get_customer", { bearer: valid, body: { customer_id: 1, fields: ["id"] }, headers: { "x-forwarded-host": "evil.invalid", forwarded: "host=evil.invalid" } });
    assert.equal(forwarded.status, 200);
    const absolute = await rawRequest(address.port, `POST http://evil.invalid/v1/tools/get_customer HTTP/1.1\r\nHost: 127.0.0.1:${address.port}\r\nContent-Length: 2\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n{}`);
    assert.match(absolute, /HTTP\/1\.1 400/);
    await app.close();
    await assert.rejects(fetch(base + "/.well-known/oauth-protected-resource"));
  });
});

test("chunked requests enforce the 64 KiB byte boundary without Content-Length", async () => {
  await withServer(async ({ address }) => {
    const valid=await token();
    const payload=JSON.stringify({customer_id:1,fields:["status"]});
    for(const size of [65536,65537]){
      const body=payload+" ".repeat(size-Buffer.byteLength(payload));
      const chunks=[];
      for(let offset=0;offset<body.length;offset+=2048){const part=body.slice(offset,offset+2048);chunks.push(Buffer.byteLength(part).toString(16)+"\r\n"+part+"\r\n");}
      const raw=`POST /v1/tools/get_customer HTTP/1.1\r\nHost: 127.0.0.1:${address.port}\r\nContent-Type: application/json\r\nAuthorization: Bearer ${valid}\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n`+chunks.join("")+"0\r\n\r\n";
      const response=await rawRequest(address.port,raw);
      assert.match(response,size===65536?/^HTTP\/1\.1 200 /:/^HTTP\/1\.1 413 /);
      const responseBody=response.split("\r\n\r\n").slice(1).join("\r\n\r\n");
      assert.deepEqual(JSON.parse(responseBody),size===65536?{id:1,status:"Kunde"}:{error:"body_too_large"});
    }
  });
});

test("explicit Entra profile verifies delegated tokens over HTTP and publishes the HTTPS resource scope", async () => {
  await withServer(async ({ base }) => {
    const valid = await entraToken();
    const result = await request(base, "/v1/tools/get_customer", { bearer: valid, body: { customer_id: 1, fields: ["status"] } });
    assert.equal(result.status, 200);
    assert.deepEqual(await result.json(), { id: 1, status: "Kunde" });
    const metadata = await (await request(base, "/.well-known/oauth-protected-resource", { method: "GET" })).json();
    assert.deepEqual(metadata.scopes_supported, [origin + "/kratos.read"]);
    assert.deepEqual(metadata.authorization_servers, [`https://login.microsoftonline.com/${entraTenant}/v2.0`]);
    const unauth = await request(base, "/v1/tools/get_customer");
    assert.equal(unauth.status, 401);
    assert.ok(unauth.headers.get("www-authenticate").includes(`scope="${origin}/kratos.read"`));
    const listed = await (await request(base, "/mcp", { bearer: valid, body: { jsonrpc: "2.0", id: 1, method: "tools/list" } })).json();
    for (const tool of listed.result.tools) assert.deepEqual(tool.securitySchemes, [{ type: "oauth2", scopes: [origin + "/kratos.read"] }]);
    const openapi = await (await request(base, "/openapi.json", { method: "GET" })).json();
    assert.deepEqual(openapi.paths["/v1/tools/get_customer"].post["x-kratos-required-oauth-scopes"], [origin + "/kratos.read"]);
    for (const [claims, status] of [[{ oid: entraClient }, 403], [{ azp: entraOwner }, 401], [{ aud: "00000003-0000-0000-c000-000000000000" }, 401], [{ idtyp: "app" }, 401], [{ scp: undefined, roles: ["kratos.read"] }, 401]]) {
      const rejected = await request(base, "/v1/tools/get_customer", { bearer: await entraToken(claims), body: { customer_id: 1 } });
      assert.equal(rejected.status, status);
    }
    assert.equal((await request(base, "/v1/tools/get_customer", { bearer: await token(), body: { customer_id: 1 } })).status, 401);
  }, { issuer: undefined, jwksUri: undefined, entra: { tenantId: entraTenant, apiClientId: entraApi, allowedClientIds: [entraClient] }, allowedSubjects: [`${entraTenant}:${entraOwner}`] });
});

test("Entra configuration and subject errors are rejected before opening a database", async () => {
  const common = { databasePath: path.resolve("missing-synthetic-database.sqlite"), resourceOrigin: origin, entra: { tenantId: entraTenant, apiClientId: entraApi, allowedClientIds: [entraClient] }, allowedSubjects: [`${entraTenant}:${entraOwner}`] };
  await assert.rejects(createKratosLocalServer({ ...common, issuer }), /cannot be combined/);
  await assert.rejects(createKratosLocalServer({ ...common, allowedSubjects: ["anyone@example.invalid"] }), /tenant:object/);
  await assert.rejects(createKratosLocalServer({ ...common, entra: { ...common.entra, tenantId: "common" } }), /Explicit Entra/);
});

test("generic /mcp resource requires its exact audience and rejects the origin audience", async () => {
  await withServer(async ({ base }) => {
    const oldAudience = await request(base, "/v1/tools/get_customer", { bearer: await token(), body: { customer_id: 1, fields: ["status"] } });
    assert.equal(oldAudience.status, 401);
    const accepted = await request(base, "/v1/tools/get_customer", { bearer: await token({ aud: origin + "/mcp" }), body: { customer_id: 1, fields: ["status"] } });
    assert.equal(accepted.status, 200);
    assert.deepEqual(await accepted.json(), { id: 1, status: "Kunde" });
    const metadata = await (await request(base, "/.well-known/oauth-protected-resource/mcp", { method: "GET" })).json();
    assert.equal(metadata.resource, origin + "/mcp");
  }, { resourceUrl: origin + "/mcp" });
});

test("Entra /mcp resource publishes path-bound scopes while keeping API GUID audience", async () => {
  await withServer(async ({ base }) => {
    const valid = await entraToken();
    const resourceUrl = origin + "/mcp";
    const scope = resourceUrl + "/kratos.read";
    const metadata = await (await request(base, "/.well-known/oauth-protected-resource/mcp", { method: "GET" })).json();
    assert.equal(metadata.resource, resourceUrl);
    assert.deepEqual(metadata.scopes_supported, [scope]);
    const root = await (await request(base, "/.well-known/oauth-protected-resource", { method: "GET" })).json();
    assert.deepEqual(root, metadata);
    const unauth = await request(base, "/mcp", { body: { jsonrpc: "2.0", id: 1, method: "ping" } });
    assert.equal(unauth.status, 401);
    assert.ok(unauth.headers.get("www-authenticate").includes(`resource_metadata="${origin}/.well-known/oauth-protected-resource/mcp"`));
    assert.ok(unauth.headers.get("www-authenticate").includes(`scope="${scope}"`));
    const listed = await (await request(base, "/mcp", { bearer: valid, body: { jsonrpc: "2.0", id: 1, method: "tools/list" } })).json();
    for (const tool of listed.result.tools) assert.deepEqual(tool.securitySchemes, [{ type: "oauth2", scopes: [scope] }]);
    const openapi = await (await request(base, "/openapi.json", { method: "GET" })).json();
    assert.deepEqual(openapi.paths["/v1/tools/get_customer"].post["x-kratos-required-oauth-scopes"], [scope]);
    assert.equal((await request(base, "/v1/tools/get_customer", { bearer: valid, body: { customer_id: 1 } })).status, 200);
    assert.equal((await request(base, "/v1/tools/get_customer", { bearer: await entraToken({ aud: resourceUrl }), body: { customer_id: 1 } })).status, 401);
  }, { resourceUrl: origin + "/mcp", issuer: undefined, jwksUri: undefined, entra: { tenantId: entraTenant, apiClientId: entraApi, allowedClientIds: [entraClient] }, allowedSubjects: [`${entraTenant}:${entraOwner}`] });
});

test("invalid resource URLs fail before the database is opened", async () => {
  for (const resourceUrl of [null, "", origin + "/", origin + "/mcp/", origin + "/%6dcp", origin + "/x/../mcp", origin + "/mcp?x=1", origin + "/mcp#x", "https://evil.invalid/mcp"]) {
    await assert.rejects(createKratosLocalServer({ databasePath: path.resolve("missing-synthetic-database.sqlite"), resourceOrigin: origin, resourceUrl, issuer, jwksUri: issuer + "keys", allowedSubjects: ["synthetic-owner"] }), /resourceUrl/);
  }
});

test("case HTTP routes remain disabled by default even with a write-scoped token", async () => {
  await withServer(async ({ base, databasePath }) => {
    const writeToken = await token({ scope: "kratos:read kratos:cases:write" });
    assert.equal((await request(base, "/v1/cases", { bearer: writeToken, body: { caseId: "case_disabled", expectedScopeIds: ["policy"] } })).status, 404);
    const check = new DatabaseSync(databasePath, { readOnly: true });
    try { assert.equal(check.prepare("SELECT COUNT(*) AS n FROM kratos_cases").get().n, 0); } finally { check.close(); }
  });
});

test("case request that receives HTTP 504 cannot write after delayed JWT verification", async () => {
  let releaseKey;
  const delayedKey = new Promise((resolve) => { releaseKey = resolve; });
  let resolverEntered = false;
  await withServer(async ({ base, databasePath }) => {
    const writeToken = await token({ scope: "kratos:read kratos:cases:write" });
    try {
      const pending = request(base, "/v1/cases", { bearer: writeToken, body: { caseId: "case_after_deadline", expectedScopeIds: ["policy"] } });
      const result = await pending;
      assert.equal(result.status, 504);
      assert.deepEqual(await result.json(), { error: "gateway_timeout" });
      assert.equal(resolverEntered, true);
    } finally {
      releaseKey(publicKey);
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
    const check = new DatabaseSync(databasePath, { readOnly: true });
    try { assert.equal(check.prepare("SELECT COUNT(*) AS n FROM kratos_cases").get().n, 0); }
    finally { check.close(); }
  }, {
    responseDeadlineMs: 50,
    verificationKey: async () => { resolverEntered = true; return delayedKey; },
    caseApi: { enableWrites: true, allowedCustomerIds: [1] },
  });
});

test("explicit generic case profile serves signed create, assignment, retry and owner-scoped reads over HTTP", async () => {
  await withServer(async ({ base, databasePath, app }) => {
    const writeToken = await token({ scope: "kratos:read kratos:cases:write" });
    const pathname = "/v1/cases/case_http_synthetic";
    const createBody = { caseId: "case_http_synthetic", expectedScopeIds: ["policy"] };
    assert.equal((await request(base, "/v1/cases", { bearer: await token(), body: createBody })).status, 403);
    assert.equal((await request(base, "/v1/cases", { bearer: writeToken, body: createBody })).status, 201);
    const assignment = { expectedVersion: 1, event: { eventId: "assign", type: "customer_assignment_confirmed", customerId: 1 } };
    assert.equal((await request(base, pathname + "/events", { bearer: writeToken, body: assignment })).status, 200);
    const retried = await (await request(base, pathname + "/events", { bearer: writeToken, body: assignment })).json();
    assert.equal(retried.duplicate, true);
    assert.equal(retried.version, 2);
    assert.equal((await request(base, pathname + "/events", { bearer: writeToken, body: { expectedVersion: 1, event: { eventId: "next", type: "recipient_verified", recipientId: "synthetic-recipient" } } })).status, 409);
    const read = await request(base, pathname, { method: "GET", bearer: await token() });
    assert.equal(read.status, 200);
    assert.equal((await read.json()).snapshot.customerAssignment.customerId, 1);
    const audit = await (await request(base, pathname + "/events", { method: "GET", bearer: await token() })).json();
    assert.equal(audit.events[0].actorId, "oauth:synthetic-owner");
    assert.equal((await request(base, pathname, { method: "GET", bearer: await token({ sub: "unknown-owner" }) })).status, 403);
    assert.equal((await request(base, "/v1/cases", { bearer: writeToken, body: { caseId: "case_other_customer", expectedScopeIds: ["policy"] } })).status, 201);
    for (const customerId of [2, 999]) assert.equal((await request(base, "/v1/cases/case_other_customer/events", { bearer: writeToken, body: { expectedVersion: 1, event: { eventId: "bad-" + customerId, type: "customer_assignment_confirmed", customerId } } })).status, 404);
    await app.close();
    const check = new DatabaseSync(databasePath);
    try {
      assert.equal(check.prepare("SELECT COUNT(*) AS n FROM kratos_case_events").get().n, 1);
      check.exec("BEGIN EXCLUSIVE; ROLLBACK");
    } finally { check.close(); }
  }, { caseApi: { enableWrites: true, allowedCustomerIds: [1, 999] } });
});

test("read-only case profile rejects mutation; bind failure releases both database connections", async () => {
  await withServer(async ({ base, address, databasePath }) => {
    const writeToken = await token({ scope: "kratos:read kratos:cases:write" });
    assert.equal((await request(base, "/v1/cases", { bearer: writeToken, body: { caseId: "case_no_writes", expectedScopeIds: ["x"] } })).status, 403);
    const blocked = await createKratosLocalServer({ databasePath, resourceOrigin: origin, issuer, jwksUri: issuer + "keys", allowedSubjects: ["synthetic-owner"], port: address.port, verificationKey: async () => publicKey, caseApi: { enableWrites: true, allowedCustomerIds: [1] } });
    await assert.rejects(blocked.listen(), /could not be started/);
    await blocked.close();
    const check = new DatabaseSync(databasePath);
    try { check.exec("BEGIN EXCLUSIVE; ROLLBACK"); } finally { check.close(); }
  }, { caseApi: { enableWrites: false, allowedCustomerIds: [1] } });
});

test("invalid case profiles are rejected before database access and Entra case access is not enabled", async () => {
  const common = { databasePath: path.resolve("missing-synthetic-database.sqlite"), resourceOrigin: origin, issuer, jwksUri: issuer + "keys", allowedSubjects: ["synthetic-owner"] };
  for (const caseApi of [null, {}, { enableWrites: "true", allowedCustomerIds: [1] }, { enableWrites: true, allowedCustomerIds: [] }, { enableWrites: true, allowedCustomerIds: ["1"] }, { enableWrites: true, allowedCustomerIds: [1, 1] }]) await assert.rejects(createKratosLocalServer({ ...common, caseApi }), /case profile/);
  await assert.rejects(createKratosLocalServer({ ...common, issuer: undefined, jwksUri: undefined, entra: { tenantId: entraTenant, apiClientId: entraApi, allowedClientIds: [entraClient] }, allowedSubjects: [`${entraTenant}:${entraOwner}`], caseApi: { enableWrites: false, allowedCustomerIds: [1] } }), /case profile/);
});

test("case startup rejects a missing operator migration without creating tables or retaining database handles", async () => {
  await withServer(async ({ databasePath }) => {
    const setup = new DatabaseSync(databasePath);
    try { setup.exec("DROP TABLE kratos_case_outbox"); } finally { setup.close(); }
    await assert.rejects(createKratosLocalServer({ databasePath, resourceOrigin: origin, issuer, jwksUri: issuer + "keys", allowedSubjects: ["synthetic-owner"], verificationKey: async () => publicKey, caseApi: { enableWrites: true, allowedCustomerIds: [1] } }), /could not initialize/);
    const check = new DatabaseSync(databasePath);
    try {
      assert.equal(check.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE name='kratos_case_outbox'").get().n, 0);
      check.exec("BEGIN EXCLUSIVE; ROLLBACK");
    } finally { check.close(); }
  });
});
