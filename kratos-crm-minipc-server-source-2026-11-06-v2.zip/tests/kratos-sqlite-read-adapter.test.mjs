import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { build } from "esbuild";
import { mkdtemp, readFile, readdir, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";

async function loadBundle(entryPoint) {
  const result = await build({ entryPoints: [path.resolve(entryPoint)], bundle: true, platform: "node", format: "esm", write: false });
  return import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].contents).toString("base64")}`);
}

const [adapterModule, toolModule] = await Promise.all([
  loadBundle("lib/kratos-sqlite-read-adapter.ts"),
  loadBundle("lib/kratos-tool-service.ts"),
]);
const { KratosSqliteReadAdapter } = adapterModule;
const { runKratosTool } = toolModule;

async function withDatabase(run) {
  const directory = await mkdtemp(path.join(os.tmpdir(), "kratos-readonly-sqlite-"));
  const databasePath = path.join(directory, "synthetic.sqlite");
  const writer = new DatabaseSync(databasePath);
  try {
    writer.exec("PRAGMA foreign_keys=ON");
    const migrationNames = (await readdir(path.resolve("drizzle"))).filter((name) => /^\d{4}_.*\.sql$/.test(name)).sort();
    for (const name of migrationNames) {
      const migration = await readFile(path.resolve("drizzle", name), "utf8");
      writer.exec(migration.replaceAll("--> statement-breakpoint", ""));
    }
    writer.prepare("INSERT INTO customers(id,first_name,last_name,phone,email,birthday,authority_status,adviser,status,folder_name,folder_url,internal_note,next_follow_up_at,next_follow_up_note,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
      .run(1, "Ada", "Lovelace", "+1 (555) 0100", "ada@example.invalid", "1815-12-10", "Vorhanden", "Morgan", "Kunde", "Ada Lovelace", null, "synthetic note", "2026-11-20", "synthetic follow up", "synthetic");
    writer.prepare("INSERT INTO customers(id,first_name,last_name,phone,email,authority_status,adviser,status,folder_name,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)")
      .run(2, "Grace", "Hopper", "+1 (555) 0200", "grace@example.invalid", "Ungeprüft", "Morgan", "Kunde", "Grace Hopper", "synthetic");
    writer.prepare("INSERT INTO customers(id,first_name,last_name,phone,email,authority_status,adviser,status,folder_name,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)")
      .run(3, "Alan", "Turing", "+1 (555) 0300", "alan@example.invalid", "Ungeprüft", "Casey", "Privat", "Alan Turing", "synthetic");
    writer.close();
    await run({ databasePath });
  } finally {
    try { writer.close(); } catch { /* closed before reader tests */ }
    await rm(directory, { recursive: true, force: true });
  }
}

test("existing Kratos customer tools read a native SQLite file with exact fields, phone/name search, and pagination", async () => {
  await withDatabase(async ({ databasePath }) => {
    const adapter = await KratosSqliteReadAdapter.open(databasePath);
    try {
      const bindings = adapter.bindings();
      const nameResult = await runKratosTool("search_customers", { query: "Ada Lovelace", limit: 10, offset: 0 }, "synthetic-reader", bindings);
      assert.equal(nameResult.total_count, 1);
      assert.deepEqual(nameResult.customers[0].matched_by, ["name"]);
      assert.deepEqual([nameResult.customers[0].id, nameResult.customers[0].first_name, nameResult.customers[0].last_name], [1, "Ada", "Lovelace"]);

      const phoneResult = await runKratosTool("search_customers", { query: "+1 (555) 0100" }, "synthetic-reader", bindings);
      assert.equal(phoneResult.total_count, 1);
      assert.deepEqual(phoneResult.customers[0].matched_by, ["phone"]);

      const firstPage = await runKratosTool("search_customers", { query: "Kunde", limit: 1, offset: 0 }, "synthetic-reader", bindings);
      const secondPage = await runKratosTool("search_customers", { query: "Kunde", limit: 1, offset: 1 }, "synthetic-reader", bindings);
      assert.equal(firstPage.total_count, 2);
      assert.equal(firstPage.has_more, true);
      assert.equal(firstPage.next_offset, 1);
      assert.equal(secondPage.offset, 1);
      assert.equal(secondPage.customers.length, 1);
      assert.notEqual(firstPage.customers[0].id, secondPage.customers[0].id);

      const details = await runKratosTool("get_customer", { customer_id: 1, fields: ["first_name", "phone", "next_follow_up_at", "next_follow_up_note"] }, "synthetic-reader", bindings);
      assert.deepEqual(details, { id: 1, first_name: "Ada", phone: "+1 (555) 0100", next_follow_up_at: "2026-11-20", next_follow_up_note: "synthetic follow up" });
    } finally { adapter.close(); }
  });
});

test("tool parameters remain bound data and never become SQL syntax", async () => {
  await withDatabase(async ({ databasePath }) => {
    const adapter = await KratosSqliteReadAdapter.open(databasePath);
    try {
      const result = await runKratosTool("search_customers", { query: "%' OR 1=1 --", limit: 25, offset: 0 }, "synthetic-reader", adapter.bindings());
      assert.equal(result.total_count, 0);
      assert.equal(result.customers.length, 0);
      assert.throws(() => adapter.DB.prepare("SELECT id FROM customers; DELETE FROM customers"), { code: "untrusted_query" });
      assert.throws(() => adapter.DB.prepare("SELECT missing_column FROM customers"), { code: "query_rejected" });
      assert.throws(() => adapter.DB.prepare("SELECT id FROM customers").bind({ arbitrary: "value" }), { code: "invalid_bind_value" });
    } finally { adapter.close(); }
  });
});

test("writes are denied at both tool-facade and native read-only boundaries; database remains unchanged", async () => {
  await withDatabase(async ({ databasePath }) => {
    const before = new DatabaseSync(databasePath, { readOnly: true });
    const beforeCount = before.prepare("SELECT count(*) AS count FROM customers").get().count;
    assert.throws(() => before.exec("UPDATE customers SET status='Privat' WHERE id=1"), /readonly|read-only/i);
    before.close();

    const adapter = await KratosSqliteReadAdapter.open(databasePath);
    try {
      await assert.rejects(runKratosTool("create_customer", { first_name: "Synthetic", last_name: "Write Attempt" }, "synthetic-reader", adapter.bindings()), { code: "untrusted_query" });
      assert.throws(() => adapter.DB.batch([]), { code: "read_only_operation" });
      assert.throws(() => adapter.DB.exec("DELETE FROM customers"), { code: "read_only_operation" });
      assert.throws(() => adapter.DB.run("DELETE FROM customers"), { code: "read_only_operation" });
      assert.throws(() => adapter.DB.dump(), { code: "read_only_operation" });
      assert.throws(() => adapter.DB.raw(), { code: "read_only_operation" });
      assert.throws(() => adapter.DB.prepare("SELECT id FROM customers").run(), { code: "read_only_operation" });
    } finally { adapter.close(); }

    const after = new DatabaseSync(databasePath, { readOnly: true });
    assert.equal(after.prepare("SELECT count(*) AS count FROM customers").get().count, beforeCount);
    assert.equal(after.prepare("SELECT count(*) AS count FROM customers WHERE first_name='Synthetic'").get().count, 0);
    after.close();
  });
});

test("missing database paths fail without creating a file and errors do not disclose paths or SQL", async () => {
  const directory = await mkdtemp(path.join(os.tmpdir(), "kratos-missing-db-"));
  const missingPath = path.join(directory, "private-customer-database.sqlite");
  try {
    await assert.rejects(KratosSqliteReadAdapter.open(missingPath), (error) => {
      assert.equal(error.code, "database_unavailable");
      assert.equal(error.message.includes(missingPath), false);
      return true;
    });
    const { access } = await import("node:fs/promises");
    await assert.rejects(access(missingPath));
  } finally { await rm(directory, { recursive: true, force: true }); }
});


test("bound statement views keep independent parameter sets", async () => {
  await withDatabase(async ({ databasePath }) => {
    const adapter = await KratosSqliteReadAdapter.open(databasePath);
    try {
      const statement = adapter.DB.prepare("SELECT id FROM customers WHERE id=?");
      const first = statement.bind(1), second = statement.bind(2);
      assert.equal(await first.first("id"), 1);
      assert.equal(await second.first("id"), 2);
      assert.equal(await first.first("id"), 1);
    } finally { adapter.close(); }
  });
});

test("German name case and decomposed umlauts resolve consistently without merging ambiguous candidates", async () => {
  await withDatabase(async ({ databasePath }) => {
    const writer = new DatabaseSync(databasePath);
    try {
      const insert = writer.prepare("INSERT INTO customers(id,first_name,last_name,email,adviser,status,updated_by) VALUES (?,?,?,?,?,?,?)");
      insert.run(4, "JÜRGEN", "MÜLLER", "synthetic-4@example.invalid", "Private Adviser", "Kunde", "synthetic");
      insert.run(5, "Ju\u0308rgen", "Mu\u0308ller", "synthetic-5@example.invalid", "Another Adviser", "Kunde", "synthetic");
      insert.run(6, "Jürgen", "Different", "synthetic-6@example.invalid", "Müller", "Kunde", "synthetic");
    } finally { writer.close(); }
    const adapter = await KratosSqliteReadAdapter.open(databasePath);
    try {
      for (const query of ["jürgen müller", "JÜRGEN MÜLLER", "ju\u0308rgen mu\u0308ller", "Müller Jürgen"]) {
        const result = await runKratosTool("search_customers", { query }, "synthetic-reader", adapter.bindings());
        assert.equal(result.total_count, 2);
        assert.deepEqual(new Set(result.customers.map((row) => row.id)), new Set([4, 5]));
        for (const customer of result.customers) {
          assert.deepEqual(customer.matched_by, ["name"]);
          assert.equal(Object.hasOwn(customer, "email"), false);
          assert.equal(Object.hasOwn(customer, "phone"), false);
          assert.equal(Object.hasOwn(customer, "internal_note"), false);
        }
      }
      const single = await runKratosTool("search_customers", { query: "müller", limit: 1, offset: 0 }, "synthetic-reader", adapter.bindings());
      assert.equal(single.total_count, 3);
      assert.equal(single.has_more, true);
      const exactEmail = await runKratosTool("search_customers", { query: "SYNTHETIC-4@EXAMPLE.INVALID" }, "synthetic-reader", adapter.bindings());
      assert.deepEqual(exactEmail.customers.map((row) => row.id), [4]);
    } finally { adapter.close(); }
  });
});
