import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { build } from 'esbuild';
import { mkdtemp, mkdir, readFile, readdir, writeFile, rm, symlink } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const bundleDir = await mkdtemp(path.join(os.tmpdir(), 'kratos-store-bundle-'));
after(async () => { assert.equal(path.dirname(bundleDir), path.resolve(os.tmpdir())); await rm(bundleDir, { recursive: true, force: true }); });
const bundle = await build({ entryPoints: ['lib/kratos-local-document-store.ts'], bundle: true, platform: 'node', format: 'esm', write: false });
await writeFile(path.join(bundleDir, 'store.mjs'), bundle.outputFiles[0].contents);
const { KratosLocalDocumentStore } = await import(pathToFileURL(path.join(bundleDir, 'store.mjs')).href);
const digest = value => createHash('sha256').update(value).digest('hex');
async function* bytes(value) { for (let offset = 0; offset < value.length; offset += 8191) yield value.subarray(offset, offset + 8191); }
async function fixture(run, overrides = {}) {
 const dir = await mkdtemp(path.join(os.tmpdir(), 'kratos-store-test-'));
 const databasePath = path.join(dir, 'test.sqlite'), root = path.join(dir, 'documents');
 await mkdir(root); const db = new DatabaseSync(databasePath);
 const migrations = (await readdir('drizzle')).filter(x => /^\d{4}_.*\.sql$/.test(x)).sort();
 for (const name of migrations) db.exec((await readFile(path.join('drizzle', name), 'utf8')).replaceAll('--> statement-breakpoint', ''));
 for (const id of [1,2]) db.prepare("INSERT INTO customers(id,first_name,last_name,authority_status,adviser,status,updated_by) VALUES (?,?,?,'Ungeprüft','synthetic','Kunde','synthetic')").run(id, 'Synthetic', String(id));
 db.close();
 const config = { databasePath, root, ownerSubject: 'synthetic-owner', allowedOwnerSubjects: ['synthetic-owner'], actorId: 'synthetic-actor', allowedCustomerIds: [1], privateRootConfirmed: true, ...overrides };
 let store;
 try { store = await KratosLocalDocumentStore.open(config); await run({ dir, config, store, databasePath, root }); }
 finally { if (store) { try { store.close(); } catch {} } assert.equal(path.dirname(dir), path.resolve(os.tmpdir())); await rm(dir, { recursive: true, force: true }); }
}

test('local bytes, original special names, hierarchy, customer linkage and hashes survive reopening', async () => fixture(async ({ store, config }) => {
 const parent = store.createFolder(1, 'Beratung ä & 2026'); const folder = store.createFolder(1, 'Anträge #1', parent);
 assert.equal(store.createFolder(1, 'Anträge #1', parent), folder);
 const payload = Buffer.alloc(21 * 1024 * 1024 + 13, 193); payload[42] = 0;
 const uploaded = await store.upload({ customerId: 1, folderId: folder, fileName: 'Polizze ä #.docx', expectedSize: payload.length, expectedSha256: digest(payload) }, bytes(payload));
 assert.equal(uploaded.duplicate, false); assert.equal(uploaded.file.sha256, digest(payload));
 assert.equal(store.list(1, { folderId: folder, query: '.docx' }).length, 1);
 assert.equal(store.list(1, { folderId: parent }).length, 0);
 store.close(); const reopened = await KratosLocalDocumentStore.open(config);
 try { const download = await reopened.read(uploaded.file.id); const chunks = []; for await (const chunk of download.bytes) chunks.push(chunk); assert.deepEqual(Buffer.concat(chunks), payload); }
 finally { reopened.close(); }
}));

test('zero bytes and arbitrary binary types are supported', async () => fixture(async ({ store }) => {
 const out = await store.upload({ customerId: 1, fileName: 'empty.zip', mimeType: 'application/zip', expectedSize: 0 }, bytes(Buffer.alloc(0)));
 assert.equal(out.file.sha256, digest('')); const read = await store.read(out.file.id); let size = 0; for await (const chunk of read.bytes) size += chunk.length; assert.equal(size, 0);
}));

test('source retries verify real target bytes; conflicting customer/name/hash cannot be reassigned', async () => fixture(async ({ store, root }) => {
 const value = Buffer.from('synthetic source'); const source = { driveId: 'drive', itemId: 'item', version: 'v1', path: 'Kunden/Synthetic/file', sha256: digest(value) };
 const input = { customerId: 1, fileName: 'file.bin', expectedSize: value.length, source };
 const first = await store.upload(input, bytes(value)); const retry = await store.upload(input, bytes(value));
 assert.equal(retry.duplicate, true); assert.equal(retry.file.id, first.file.id); assert.equal(store.list(1).length, 1);
 assert.equal((await readdir(path.join(root, 'local'))).length, 1, 'successful retry must not produce another physical object');
 await assert.rejects(store.upload({ ...input, fileName: 'changed.bin' }, bytes(value)), e => e.code === 'source_conflict');
 await assert.rejects(store.upload({ ...input, source: { ...source, modifiedAt: '2026-11-05T12:00:00Z' } }, bytes(value)), e => e.code === 'source_conflict');
 await writeFile(path.join(root, ...first.file.object_key.split('/')), 'corruption');
 await assert.rejects(store.upload(input, bytes(value)), e => e.code === 'integrity_mismatch');
 await assert.rejects(store.read(first.file.id), e => e.code === 'integrity_mismatch');
}));

test('access checks reject other customers, cross-customer folders and unassigned files', async () => fixture(async ({ store, databasePath }) => {
 const db = new DatabaseSync(databasePath); db.prepare("INSERT INTO storage_folders(id,customer_id,scope_key,path_key,name,created_by) VALUES (99,2,'customer:2','foreign','foreign','synthetic')").run(); db.close();
 assert.throws(() => store.list(2), e => e.code === 'storage_access_denied');
 assert.throws(() => store.list(null), e => e.code === 'storage_access_denied');
 await assert.rejects(store.upload({ customerId: 1, folderId: 99, fileName: 'x', expectedSize: 0 }, bytes(Buffer.alloc(0))), e => e.code === 'folder_customer_mismatch');
}));

test('failed size/hash uploads never become visible records and names cannot escape storage', async () => fixture(async ({ store, root }) => {
 for (const fileName of ['../escape', 'bad\\name', '.', '']) await assert.rejects(store.upload({ customerId: 1, fileName, expectedSize: 0 }, bytes(Buffer.alloc(0))));
 await assert.rejects(store.upload({ customerId: 1, fileName: 'short', expectedSize: 5 }, bytes(Buffer.from('a'))));
 await assert.rejects(store.upload({ customerId: 1, fileName: 'long', expectedSize: 0 }, bytes(Buffer.from('a'))));
 await assert.rejects(store.upload({ customerId: 1, fileName: 'hash', expectedSize: 1, expectedSha256: '0'.repeat(64) }, bytes(Buffer.from('a'))));
 assert.equal(store.list(1).length, 0); assert.equal((await readdir(root)).join(','), 'local');
}));

test('trusted-owner mismatch and missing private-root attestation fail before filesystem effects', async () => {
 for (const override of [{ ownerSubject: 'other' }, { privateRootConfirmed: false }]) await assert.rejects(KratosLocalDocumentStore.open({ databasePath: path.resolve('does-not-exist.sqlite'), root: path.resolve('no-root'), ownerSubject: 'owner', allowedOwnerSubjects: ['owner'], actorId: 'actor', allowedCustomerIds: [1], privateRootConfirmed: true, ...override }), e => e.code === 'storage_access_denied');
});

test('existing junction paths are rejected instead of following them', async () => fixture(async ({ dir, config }) => {
 const real = path.join(dir, 'other'), link = path.join(dir, 'junction'); await mkdir(real); await symlink(real, link, process.platform === 'win32' ? 'junction' : 'dir');
 await assert.rejects(KratosLocalDocumentStore.open({ ...config, root: link }), e => e.code === 'unsafe_local_path');
}));

test('metadata and audit writes roll back together on audit failure', async () => fixture(async ({ store, databasePath }) => {
 const db = new DatabaseSync(databasePath); db.exec("CREATE TRIGGER synthetic_block_audit BEFORE INSERT ON storage_audit_events BEGIN SELECT RAISE(ABORT,'synthetic failure'); END"); db.close();
 await assert.rejects(store.upload({ customerId: 1, fileName: 'rollback.bin', expectedSize: 1 }, bytes(Buffer.from('x'))), e => e.code === 'metadata_failed');
 assert.equal(store.list(1).length, 0);
}));
