import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { build } from 'esbuild';
import { mkdtemp, mkdir, readFile, readdir, writeFile, rm, access } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { pathToFileURL } from 'node:url';
const dirBundle = await mkdtemp(path.join(os.tmpdir(), 'kratos-backup-bundle-'));
after(async () => { assert.equal(path.dirname(dirBundle), path.resolve(os.tmpdir())); await rm(dirBundle, { recursive: true, force: true }); });
const result = await build({ stdin: { contents: "export * from './lib/kratos-local-backup'; export * from './lib/kratos-local-document-store';", resolveDir: process.cwd() }, bundle: true, platform: 'node', format: 'esm', write: false });
await writeFile(path.join(dirBundle, 'modules.mjs'), result.outputFiles[0].contents);
const { createKratosLocalBackup, restoreKratosLocalBackup, KratosLocalDocumentStore } = await import(pathToFileURL(path.join(dirBundle, 'modules.mjs')).href);
async function* stream(value) { yield value; }
async function fixture(run) {
 const dir = await mkdtemp(path.join(os.tmpdir(), 'kratos-backup-test-')), root = path.join(dir, 'documents'), databasePath = path.join(dir, 'source.sqlite');
 await mkdir(root); const db = new DatabaseSync(databasePath);
 for (const name of (await readdir('drizzle')).filter(x => /^\d{4}_.*\.sql$/.test(x)).sort()) db.exec((await readFile(path.join('drizzle', name), 'utf8')).replaceAll('--> statement-breakpoint', ''));
 db.prepare("INSERT INTO customers(id,first_name,last_name,authority_status,adviser,status,updated_by) VALUES (1,'Synthetic','Backup','Ungeprüft','synthetic','Kunde','synthetic')").run(); db.close();
 const config = { databasePath, root, ownerSubject: 'owner', allowedOwnerSubjects: ['owner'], actorId: 'actor', allowedCustomerIds: [1], privateRootConfirmed: true };
 const store = await KratosLocalDocumentStore.open(config);
 try { await run({ dir, root, databasePath, store, config, backupOptions: { databasePath, documentRoot: root, destination: path.join(dir, 'backup'), privateTargetConfirmed: true } }); }
 finally { store.close(); assert.equal(path.dirname(dir), path.resolve(os.tmpdir())); await rm(dir, { recursive: true, force: true }); }
}

test('native SQLite backup and immutable file snapshot restore together into a new installation', async () => fixture(async ({ store, backupOptions, dir, config }) => {
 const value = Buffer.from([0,255,13,10,44]); const file = await store.upload({ customerId: 1, fileName: 'synthetic.odd', expectedSize: value.length }, stream(value));
 const backup = await createKratosLocalBackup(backupOptions); assert.equal(backup.files, 1); assert.equal(backup.bytes, value.length); assert.equal(backup.unreferencedObjectCount, 0);
 // A later live write is excluded from the coherent snapshot and remains untouched.
 await store.upload({ customerId: 1, fileName: 'later.bin', expectedSize: 0 }, stream(Buffer.alloc(0)));
 const restored = await restoreKratosLocalBackup({ backupDirectory: backupOptions.destination, destination: path.join(dir, 'restored'), privateTargetConfirmed: true, expectedManifestSha256: backup.manifestSha256 });
 const reopened = await KratosLocalDocumentStore.open({ ...config, databasePath: restored.databasePath, root: restored.documentRoot });
 try { assert.equal(reopened.list(1).length, 1); const read = await reopened.read(file.file.id); const chunks = []; for await (const chunk of read.bytes) chunks.push(chunk); assert.deepEqual(Buffer.concat(chunks), value); }
 finally { reopened.close(); }
 assert.equal(store.list(1).length, 2);
}));

test('corrupt source objects block backup success; incomplete backups have no success manifest', async () => fixture(async ({ store, root, backupOptions }) => {
 const out = await store.upload({ customerId: 1, fileName: 'x', expectedSize: 1 }, stream(Buffer.from('x')));
 await writeFile(path.join(root, ...out.file.object_key.split('/')), 'corrupt');
 await assert.rejects(createKratosLocalBackup(backupOptions), e => e.code === 'backup_integrity_mismatch');
 await assert.rejects(access(path.join(backupOptions.destination, 'manifest.json')));
}));

test('changed manifest and damaged backup objects are rejected before creating restore target', async () => fixture(async ({ store, backupOptions, dir }) => {
 const out = await store.upload({ customerId: 1, fileName: 'x', expectedSize: 1 }, stream(Buffer.from('x'))); const backup = await createKratosLocalBackup(backupOptions);
 const destination = path.join(dir, 'never-created');
 await assert.rejects(restoreKratosLocalBackup({ backupDirectory: backupOptions.destination, destination, privateTargetConfirmed: true, expectedManifestSha256: '0'.repeat(64) }), e => e.code === 'backup_manifest_identity_mismatch');
 await writeFile(path.join(backupOptions.destination, 'documents', ...out.file.object_key.split('/')), 'damaged');
 await assert.rejects(restoreKratosLocalBackup({ backupDirectory: backupOptions.destination, destination, privateTargetConfirmed: true, expectedManifestSha256: backup.manifestSha256 }), e => e.code === 'backup_integrity_mismatch');
 await assert.rejects(access(destination));
}));

test('existing backup/restore destinations are never replaced and live sources remain intact', async () => fixture(async ({ backupOptions, dir }) => {
 await mkdir(backupOptions.destination); await writeFile(path.join(backupOptions.destination, 'keep'), 'original');
 await assert.rejects(createKratosLocalBackup(backupOptions), e => e.code === 'backup_target_exists_or_unavailable');
 assert.equal(await readFile(path.join(backupOptions.destination, 'keep'), 'utf8'), 'original');
 const alternate = { ...backupOptions, destination: path.join(dir, 'backup2') }; const backup = await createKratosLocalBackup(alternate);
 await assert.rejects(restoreKratosLocalBackup({ backupDirectory: alternate.destination, destination: backupOptions.destination, privateTargetConfirmed: true, expectedManifestSha256: backup.manifestSha256 }), e => e.code === 'backup_target_exists_or_unavailable');
 assert.equal(await readFile(path.join(backupOptions.destination, 'keep'), 'utf8'), 'original');
}));

test('unreferenced interrupted-upload objects are counted separately and never silently claimed as backed up', async () => fixture(async ({ store, backupOptions }) => {
 await assert.rejects(store.upload({ customerId: 1, fileName: 'interrupted', expectedSize: 2 }, stream(Buffer.from('x'))));
 const backup = await createKratosLocalBackup(backupOptions); assert.equal(backup.files, 0); assert.equal(backup.unreferencedObjectCount, 1);
}));

test('backup cannot target the live document tree or use an unattested target', async () => fixture(async ({ backupOptions, root }) => {
 await assert.rejects(createKratosLocalBackup({ ...backupOptions, destination: path.join(root, 'backup') }), e => e.code === 'backup_target_overlaps_source');
 await assert.rejects(createKratosLocalBackup({ ...backupOptions, privateTargetConfirmed: false }), e => e.code === 'backup_access_denied');
}));
