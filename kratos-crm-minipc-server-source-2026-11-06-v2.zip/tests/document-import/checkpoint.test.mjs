import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { ImportCheckpoint, safeSourceMetadata } from "../../scripts/document-import/checkpoint.mjs";

async function withCheckpoint(run) {
  const directory = await mkdtemp(path.join(os.tmpdir(), "kratos-checkpoint-test-"));
  const filePath = path.join(directory, "checkpoint.jsonl");
  try { await run(filePath); }
  finally { await rm(directory, { recursive: true, force: true }); }
}

test("a corrupt unterminated tail is truncated before the next append", async () => {
  await withCheckpoint(async (filePath) => {
    const valid = JSON.stringify({ record_type: "source_item", item_id: "one" }) + "\n";
    await writeFile(filePath, valid + '{"record_type":"partial', "utf8");
    const checkpoint = await new ImportCheckpoint(filePath).load();
    assert.equal(checkpoint.records.length, 1);
    await checkpoint.append({ record_type: "source_item", item_id: "two" });

    const resumed = await new ImportCheckpoint(filePath).load();
    assert.deepEqual(resumed.records.map((record) => record.item_id), ["one", "two"]);
    assert.ok((await readFile(filePath, "utf8")).endsWith("\n"));
  });
});

test("a valid unterminated final record receives a line boundary before appending", async () => {
  await withCheckpoint(async (filePath) => {
    await writeFile(filePath, JSON.stringify({ record_type: "source_item", item_id: "one" }), "utf8");
    const checkpoint = await new ImportCheckpoint(filePath).load();
    await checkpoint.append({ record_type: "source_item", item_id: "two" });

    const resumed = await new ImportCheckpoint(filePath).load();
    assert.deepEqual(resumed.records.map((record) => record.item_id), ["one", "two"]);
  });
});

test("corrupt complete lines fail closed without modifying the checkpoint", async () => {
  await withCheckpoint(async (filePath) => {
    const raw = '{"record_type":"source_item"}\n{bad}\n';
    await writeFile(filePath, raw, "utf8");
    await assert.rejects(new ImportCheckpoint(filePath).load(), /corrupt non-final line/);
    assert.equal(await readFile(filePath, "utf8"), raw);
  });
});

test("a second importer stops before checkpoint loading and then reloads the committed records", async () => {
  await withCheckpoint(async (filePath) => {
    const first = new ImportCheckpoint(filePath);
    const second = new ImportCheckpoint(filePath);
    await first.withExclusive(async () => {
      await first.append({ record_type: "source_item", item_id: "first" });
      await assert.rejects(second.withExclusive(() => assert.fail("competing import started")), { code: "checkpoint_locked" });
      await assert.rejects(second.load(), { code: "checkpoint_locked" });
      await assert.rejects(new ImportCheckpoint(filePath + ".lock").load(), /reserved/);
      assert.equal(second.records.length, 0);
    });
    await second.withExclusive(async () => {
      assert.deepEqual(second.records.map((record) => record.item_id), ["first"]);
      await second.append({ record_type: "source_item", item_id: "second" });
    });
    await first.withExclusive(() => assert.deepEqual(first.records.map((record) => record.item_id), ["first", "second"]));
  });
});

test("stale locks fail closed and an exception releases only the acquired lock", async () => {
  await withCheckpoint(async (filePath) => {
    const lockPath = filePath + ".lock";
    const abandoned = '{"pid":123,"started_at":"2026-01-01T00:00:00Z"}\n';
    await writeFile(lockPath, abandoned, "utf8");
    await assert.rejects(new ImportCheckpoint(filePath).withExclusive(() => assert.fail("stale lock ignored")), { code: "checkpoint_locked" });
    assert.equal(await readFile(lockPath, "utf8"), abandoned);

    const another = new ImportCheckpoint(filePath + ".other");
    await assert.rejects(another.withExclusive(() => { throw new Error("interrupted"); }), /interrupted/);
    await another.withExclusive(() => {});
  });
});

test("checkpoint source metadata uses a small allowlist", () => {
  const metadata = safeSourceMetadata({
    id: "item-1",
    name: "policy.pdf",
    eTag: "etag-1",
    size: 42,
    webUrl: "https://example.invalid/private",
    "@microsoft.graph.downloadUrl": "https://example.invalid/token",
    accessToken: "secret",
    file: { mimeType: "application/pdf", hashes: { quickXorHash: "sensitive-unknown" }, downloadUrl: "https://example.invalid/token" },
    parentReference: { driveId: "drive-1", id: "parent-1", webUrl: "https://example.invalid/private" },
  });
  assert.deepEqual(metadata, {
    id: "item-1",
    name: "policy.pdf",
    eTag: "etag-1",
    size: 42,
    file: { mimeType: "application/pdf" },
    parentReference: { driveId: "drive-1", id: "parent-1" },
  });
});

test("pilot review is bound to latest drive/root/source version and subtree fingerprint", async () => {
  await withCheckpoint(async (filePath) => {
    const checkpoint = await new ImportCheckpoint(filePath).load();
    const complete = {
      record_type: "pilot_complete", source_key: "pilot-v1", drive_id: "drive-a", root_item_id: "root-a",
      pilot_folder_item_id: "pilot", customer_id: "6", destination_kind: "kratos-r2", status: "successful",
      subtree_fingerprint: "a".repeat(64), expected_files: 5, expected_folders: 4, expected_bytes: 100,
    };
    await checkpoint.append(complete);
    await checkpoint.reviewPilot({ driveId: "drive-a", rootItemId: "root-a", pilotFolderItemId: "pilot", customerId: 6, confirmReviewed: true });
    assert.equal(checkpoint.hasReviewedPilot({ driveId: "drive-a", rootItemId: "root-a", destinationKind: "kratos-r2" }), true);
    assert.equal(checkpoint.hasReviewedPilot({ driveId: "drive-b", rootItemId: "root-a", destinationKind: "kratos-r2" }), false);

    await checkpoint.append({ ...complete, source_key: "pilot-v2", subtree_fingerprint: "b".repeat(64), status: "unresolved" });
    assert.equal(checkpoint.hasReviewedPilot({ driveId: "drive-a", rootItemId: "root-a", destinationKind: "kratos-r2" }), false, "an older success/review cannot authorize after the latest pilot source changes or fails");
    await assert.rejects(checkpoint.reviewPilot({ driveId: "drive-a", rootItemId: "root-a", pilotFolderItemId: "pilot", customerId: 6, confirmReviewed: true }), /Latest pilot run/);
  });
});
