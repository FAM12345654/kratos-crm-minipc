import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import {
  applyInventoryChanges,
  createInventorySnapshot,
  InventoryStateError,
  InventoryStateStore,
  isExpiredDeltaCursor,
} from "../../scripts/document-import/inventory-state.mjs";

const driveId = "synthetic-drive";
const rootItemId = "kunden-root";
const cursor = (token) => `https://graph.microsoft.com/v1.0/drives/${driveId}/items/${rootItemId}/delta?token=${token}`;
const file = (id, name, parentId, eTag = "v1") => ({ id, name, eTag, size: 12, file: { mimeType: "application/pdf" }, parentReference: { driveId, id: parentId } });

async function withDirectory(run) {
  const directory = await mkdtemp(path.join(os.tmpdir(), "kratos-inventory-state-"));
  try { await run(directory); }
  finally { await rm(directory, { recursive: true, force: true }); }
}

test("full snapshot uses the last occurrence of duplicate IDs and strips unknown metadata", () => {
  const state = createInventorySnapshot({ driveId, rootItemId, deltaLink: cursor("full"), items: [
    { id: "folder-a", name: "Old name", eTag: "f1", folder: {}, parentReference: { driveId, id: rootItemId } },
    file("doc-1", "Old.pdf", "folder-a", "v1"),
    { id: "folder-a", name: "New name", eTag: "f2", folder: {}, parentReference: { driveId, id: rootItemId }, webUrl: "https://private.invalid/" },
    file("doc-1", "New.pdf", "folder-a", "v2"),
  ] });
  assert.deepEqual(state.items.map(({ id }) => id), ["doc-1", "folder-a"]);
  assert.equal(state.items.find(({ id }) => id === "folder-a").name, "New name");
  assert.equal(state.items.find(({ id }) => id === "doc-1").name, "New.pdf");
  assert.equal("webUrl" in state.items.find(({ id }) => id === "folder-a"), false);
});

test("full snapshot tombstones remove the item and descendants recursively", () => {
  const state = createInventorySnapshot({ driveId, rootItemId, deltaLink: cursor("full"), items: [
    { id: "folder-a", name: "A", eTag: "f1", folder: {}, parentReference: { driveId, id: rootItemId } },
    { id: "folder-b", name: "B", eTag: "f1", folder: {}, parentReference: { driveId, id: "folder-a" } },
    file("doc-1", "One.pdf", "folder-b"),
    { id: "folder-a", deleted: {} },
  ] });
  assert.deepEqual(state.items, []);
});

test("incremental delta merges partial metadata, records a move, and removes deleted subtrees", () => {
  const original = createInventorySnapshot({ driveId, rootItemId, deltaLink: cursor("one"), items: [
    { id: "folder-a", name: "A", eTag: "f1", folder: {}, parentReference: { driveId, id: rootItemId } },
    { id: "folder-b", name: "B", eTag: "f1", folder: {}, parentReference: { driveId, id: rootItemId } },
    { id: "folder-child", name: "Child", eTag: "fc1", folder: {}, parentReference: { driveId, id: "folder-a" } },
    file("doc-1", "Policy.pdf", "folder-child", "v1"),
    file("doc-2", "Old.pdf", "folder-child", "v1"),
  ] });
  const moved = applyInventoryChanges(original, {
    driveId,
    rootItemId,
    deltaLink: cursor("two"),
    changes: [
      { id: "folder-child", deleted: {} },
      { id: "doc-1", eTag: "v2", parentReference: { id: "folder-b" } },
    ],
  });
  const doc = moved.items.find(({ id }) => id === "doc-1");
  assert.equal(doc.name, "Policy.pdf", "partial update retains previous name");
  assert.equal(doc.eTag, "v2");
  assert.equal(doc.parentReference.id, "folder-b", "parentReference merge reflects the move");
  assert.equal(moved.items.some(({ id }) => id === "folder-child"), false);
  assert.equal(moved.items.some(({ id }) => id === "doc-1"), true, "a moved item remains outside the deleted subtree");
  assert.equal(moved.items.some(({ id }) => id === "doc-2"), false, "folder tombstone recursively removes descendants");
  assert.equal(moved.delta_link, cursor("two"));
});

test("an item moved outside the scoped root is removed from inventory", () => {
  const original = createInventorySnapshot({ driveId, rootItemId, deltaLink: cursor("one"), items: [
    { id: "folder-a", name: "A", eTag: "f1", folder: {}, parentReference: { driveId, id: rootItemId } },
    file("doc-1", "Policy.pdf", "folder-a", "v1"),
  ] });
  const next = applyInventoryChanges(original, {
    driveId,
    rootItemId,
    deltaLink: cursor("two"),
    changes: [{ id: "doc-1", eTag: "v2", parentReference: { id: "outside-folder" } }],
  });
  assert.equal(next.items.some(({ id }) => id === "doc-1"), false);
  assert.equal(next.items.some(({ id }) => id === "folder-a"), true);
});

test("cursor and persisted scope are exact and fail closed", async () => {
  await withDirectory(async (directory) => {
    const store = new InventoryStateStore(path.join(directory, "inventory.json"));
    const state = createInventorySnapshot({ driveId, rootItemId, deltaLink: cursor("safe"), items: [file("doc-1", "Policy.pdf", rootItemId)] });
    await store.save(state);
    assert.equal((await store.load({ driveId, rootItemId })).items.length, 1);
    await assert.rejects(store.load({ driveId: "another-drive", rootItemId }), { code: "scope_mismatch" });
    assert.throws(() => createInventorySnapshot({ driveId, rootItemId, deltaLink: cursor("safe").replace("/items/kunden-root/", "/items/other-root/"), items: [] }), { code: "invalid_delta_cursor" });
    assert.throws(() => createInventorySnapshot({ driveId, rootItemId, deltaLink: "https://attacker.invalid/delta", items: [] }), { code: "invalid_delta_cursor" });
  });
});

test("state updates are atomic and malformed state does not silently become a rescan", async () => {
  await withDirectory(async (directory) => {
    const filePath = path.join(directory, "inventory.json");
    const store = new InventoryStateStore(filePath);
    const first = createInventorySnapshot({ driveId, rootItemId, deltaLink: cursor("first"), items: [file("doc-1", "Policy.pdf", rootItemId)] });
    await store.save(first);
    const second = applyInventoryChanges(first, { driveId, rootItemId, deltaLink: cursor("second"), changes: [{ id: "doc-1", eTag: "v2" }] });
    await store.save(second);
    const serialized = JSON.parse(await readFile(filePath, "utf8"));
    assert.equal(serialized.delta_link, cursor("second"));
    assert.equal(serialized.items[0].name, "Policy.pdf");
    assert.deepEqual((await readdir(directory)).sort(), ["inventory.json"]);
    await writeFile(filePath, "{bad json", "utf8");
    await assert.rejects(store.load({ driveId, rootItemId }), { code: "invalid_inventory_state" });
  });
});

test("expired delta cursor is identifiable for a controlled full rescan", () => {
  assert.equal(isExpiredDeltaCursor({ code: "graph_http_410" }), true);
  assert.equal(isExpiredDeltaCursor({ code: "network_error" }), false);
  assert.ok(new InventoryStateError("synthetic", "synthetic error") instanceof Error);
});
