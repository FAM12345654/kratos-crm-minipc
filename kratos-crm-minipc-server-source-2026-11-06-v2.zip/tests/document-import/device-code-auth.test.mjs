import test from "node:test";
import assert from "node:assert/strict";
import { MemoryDeviceCodeCredential, deviceCodeAuthConfig } from "../../scripts/document-import/device-code-auth.mjs";

const tenantId = "11111111-1111-4111-8111-111111111111";
const clientId = "22222222-2222-4222-8222-222222222222";
const response = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
const challenge = { device_code: "SECRET_DEVICE_CODE_FIXTURE", user_code: "ABCD-EFGH", verification_uri: "https://microsoft.com/devicelogin", expires_in: 600, interval: 1 };

test("device-code login uses only Files.Read and offline_access; callback receives only verification URL and user code", async () => {
  const requests = [], shown = [], waits = [];
  const fetchImpl = async (url, options) => {
    requests.push({ url: String(url), body: new URLSearchParams(options.body), headers: options.headers });
    return requests.length === 1 ? response(challenge) : requests.length === 2 ? response({ error: "authorization_pending" }, 400) : response({ access_token: "ACCESS_FIXTURE", refresh_token: "REFRESH_FIXTURE", expires_in: 3600 });
  };
  const credential = new MemoryDeviceCodeCredential({ tenantId, clientId, fetchImpl, sleep: async (ms) => waits.push(ms), onUserCode: (value) => shown.push(value) });
  assert.equal(await credential.signIn(), "ACCESS_FIXTURE");
  assert.deepEqual(shown, [{ verificationUri: challenge.verification_uri, userCode: challenge.user_code }]);
  assert.equal(JSON.stringify(shown).includes("SECRET_DEVICE_CODE_FIXTURE"), false);
  assert.equal(requests[0].body.get("scope"), "Files.Read offline_access");
  assert.equal(requests[0].body.has("client_secret"), false);
  assert.equal(requests[1].body.get("device_code"), challenge.device_code);
  assert.deepEqual(waits, [1000, 1000]);
  assert.equal(deviceCodeAuthConfig.scope, "Files.Read offline_access");
});

test("slow_down lengthens the polling interval and access_denied is handled", async () => {
  const waits = [];
  let calls = 0;
  const credential = new MemoryDeviceCodeCredential({ tenantId, clientId, sleep: async (ms) => waits.push(ms), fetchImpl: async () => ++calls === 1 ? response(challenge) : calls === 2 ? response({ error: "slow_down" }, 400) : response({ error: "access_denied" }, 400) });
  await assert.rejects(credential.signIn(), { code: "access_denied" });
  assert.deepEqual(waits, [1000, 6000]);
});

test("explicit access denial stops polling immediately", async () => {
  let calls = 0;
  const credential = new MemoryDeviceCodeCredential({ tenantId, clientId, sleep: async () => {}, fetchImpl: async () => ++calls === 1 ? response(challenge) : response({ error: "access_denied" }, 400) });
  await assert.rejects(credential.signIn(), { code: "access_denied" });
  assert.equal(calls, 2);
});

test("refreshes in memory, rotates refresh token, and deduplicates concurrent requests", async () => {
  const bodies = [];
  let now = Date.now;
  Date.now = () => now();
  let tokenCalls = 0;
  const credential = new MemoryDeviceCodeCredential({ tenantId, clientId, refreshMarginMs: 0, fetchImpl: async (_url, options) => {
    const body = new URLSearchParams(options.body);
    bodies.push(body);
    if (bodies.length === 1) return response(challenge);
    if (body.get("grant_type").includes("device_code")) return response({ access_token: "ACCESS_OLD", refresh_token: "REFRESH_OLD", expires_in: 0.001 });
    tokenCalls++;
    await new Promise((resolve) => setTimeout(resolve, 5));
    return response({ access_token: "ACCESS_NEW", refresh_token: "REFRESH_NEW", expires_in: 3600 });
  }, sleep: async () => {} });
  try {
    await credential.signIn();
    await new Promise((resolve) => setTimeout(resolve, 5));
    const tokens = await Promise.all([credential.getAccessToken(), credential.getAccessToken(), credential.getAccessToken()]);
    assert.deepEqual(tokens, ["ACCESS_NEW", "ACCESS_NEW", "ACCESS_NEW"]);
    assert.equal(tokenCalls, 1);
    const refreshRequest = bodies.at(-1);
    assert.equal(refreshRequest.get("grant_type"), "refresh_token");
    assert.equal(refreshRequest.get("refresh_token"), "REFRESH_OLD");
    assert.equal(refreshRequest.get("scope"), "Files.Read offline_access");
  } finally { Date.now = now; }
});

test("configuration errors, invalid verification URL, request timeout, and expiry fail closed", async () => {
  assert.throws(() => new MemoryDeviceCodeCredential({ tenantId: "common", clientId }), { code: "invalid_configuration" });
  const invalidUrl = new MemoryDeviceCodeCredential({ tenantId, clientId, fetchImpl: async () => response({ ...challenge, verification_uri: "https://attacker.invalid/" }) });
  await assert.rejects(invalidUrl.signIn(), { code: "invalid_device_response" });
  const timeout = new MemoryDeviceCodeCredential({ tenantId, clientId, fetchImpl: async () => { throw new Error("synthetic timeout"); } });
  await assert.rejects(timeout.signIn(), { code: "device_code_request_failed" });
  const expired = new MemoryDeviceCodeCredential({ tenantId, clientId, fetchImpl: async () => response({ ...challenge, expires_in: 1 }), sleep: async (ms) => new Promise((resolve) => setTimeout(resolve, ms)) });
  await assert.rejects(expired.signIn(), { code: "expired_token" });
});
