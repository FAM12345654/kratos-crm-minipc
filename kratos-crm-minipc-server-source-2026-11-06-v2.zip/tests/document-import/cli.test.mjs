import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import os from "node:os";
import path from "node:path";
import { ImportCheckpoint } from "../../scripts/document-import/checkpoint.mjs";

const execFileAsync = promisify(execFile);
const cliPath = path.resolve("scripts/document-import/cli.mjs");

test("pilot review rejects a checkpoint outside private staging before reading or repairing it", async () => {
  const directory = await mkdtemp(path.join(os.tmpdir(), "kratos-cli-gate-"));
  const staging = path.join(directory, "private-stage");
  const checkpoint = path.join(directory, "outside-checkpoint.jsonl");
  const original = "{\"record_type\":\"pilot_complete\"}\n{broken";
  try {
    await writeFile(checkpoint, original, "utf8");
    await assert.rejects(execFileAsync(process.execPath, [cliPath, "--review-pilot"], {
      env: {
        ...process.env,
        KRATOS_IMPORT_STAGING_DIR: staging,
        KRATOS_IMPORT_CHECKPOINT: checkpoint,
        KRATOS_SOURCE_DRIVE_ID: "synthetic-drive",
        KRATOS_SOURCE_ROOT_ITEM_ID: "synthetic-root",
        KRATOS_PILOT_FOLDER_ITEM_ID: "synthetic-pilot",
        KRATOS_PILOT_CUSTOMER_ID: "6",
        KRATOS_IMPORT_PILOT_REVIEWED: "YES",
        KRATOS_IMPORT_ACL_CONFIRMED: "YES",
      },
    }), (error) => /under the private staging root/.test(String(error.stderr)));
    assert.equal(await readFile(checkpoint, "utf8"), original, "the out-of-root checkpoint was not loaded or repaired");
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("a pilot review in a second process cannot repair an active import checkpoint", async () => {
  const root = path.resolve(os.tmpdir());
  const staging = await mkdtemp(path.join(root, "kratos-cli-lock-"));
  const file = path.join(staging, "checkpoint.jsonl");
  const partial = '{"record_type":"unfinished';
  try {
    await new ImportCheckpoint(file).withExclusive(async () => {
      await writeFile(file, partial, "utf8");
      await assert.rejects(execFileAsync(process.execPath, [cliPath, "--review-pilot"], {
        timeout: 10000,
        env: {
          ...process.env,
          KRATOS_IMPORT_STAGING_DIR: staging,
          KRATOS_IMPORT_CHECKPOINT: file,
          KRATOS_SOURCE_DRIVE_ID: "synthetic-drive",
          KRATOS_SOURCE_ROOT_ITEM_ID: "synthetic-root",
          KRATOS_IMPORT_ACL_CONFIRMED: "YES",
        },
      }), (error) => JSON.parse(error.stderr).error_code === "checkpoint_locked");
      assert.equal(await readFile(file, "utf8"), partial);
    });
    await new ImportCheckpoint(file).load();
    assert.equal(await readFile(file, "utf8"), "");
  } finally {
    assert.equal(path.dirname(staging), root);
    assert.ok(path.basename(staging).startsWith("kratos-cli-lock-"));
    await rm(staging, { recursive: true, force: true });
  }
});
