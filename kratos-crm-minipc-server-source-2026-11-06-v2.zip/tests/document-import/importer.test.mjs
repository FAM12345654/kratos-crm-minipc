import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { Readable } from "node:stream";
import { importGates, runDocumentImport } from "../../scripts/document-import/importer.mjs";

const digest = (b) => createHash("sha256").update(b).digest("hex");

function fixtureSource() {
  const items = [
    { id: "pilot", name: "synthetic", eTag: "v1", folder: {}, parentReference: { id: "kunden" } },
    { id: "other-folder", name: "Other", eTag: "v1", folder: {}, parentReference: { id: "kunden" } },
    ...["a", "b", "c", "d"].map((id) => ({ id: `folder-${id}`, name: `Folder ${id}`, eTag: "v1", folder: {}, parentReference: { id: "pilot" } })),
    ...["one", "two", "three", "four", "five"].map((id, i) => ({ id: `file-${id}`, name: `${id}.txt`, eTag: "v1", size: [2, 3, 5, 7, 11][i], file: { mimeType: "text/plain" }, parentReference: { id: i < 2 ? "pilot" : `folder-${["a", "b", "c"][i - 2]}` } })),
    { id: "other-file", name: "private.txt", eTag: "v1", size: 13, file: { mimeType: "text/plain" }, parentReference: { id: "other-folder" } },
  ];
  const content = new Map(items.filter((x) => x.file).map((x) => [x.id, Buffer.alloc(x.size, x.id.charCodeAt(5))]));
  let downloads = 0;
  return {
    items,
    get downloads() { return downloads; },
    async verifyCustomerRoot() { return { id: "kunden", name: "Kunden", folder: {} }; },
    async snapshotDrive(driveId, rootItemId) { return { complete: true, deltaLink: `https://graph.microsoft.com/v1.0/drives/${driveId}/items/${rootItemId}/delta?token=synthetic-v1`, items }; },
    async *walkRecursive() {
      const paths = new Map([["pilot", ["synthetic"]], ["folder-a", ["synthetic", "Folder a"]], ["folder-b", ["synthetic", "Folder b"]], ["folder-c", ["synthetic", "Folder c"]], ["folder-d", ["synthetic", "Folder d"]]]);
      for (const item of items) {
        if (item.id === "pilot") yield { item, relativePath: "synthetic", relativeSegments: ["synthetic"] };
        else if (item.id === "other-folder") yield { item, relativePath: "Other", relativeSegments: ["Other"] };
        else if (item.id === "other-file") yield { item, relativePath: "Other/private.txt", relativeSegments: ["Other", "private.txt"] };
        else if (item.folder) yield { item, relativePath: paths.get(item.id).join("/"), relativeSegments: paths.get(item.id) };
        else {
          const parent = paths.get(item.parentReference.id) ?? ["synthetic"];
          yield { item, relativePath: [...parent, item.name].join("/"), relativeSegments: [...parent, item.name] };
        }
      }
    },
    async getItem(_d, id) { return items.find((x) => x.id === id); },
    async downloadContent(_d, id) { downloads++; return Readable.from([content.get(id)]); },
    async changesSince(deltaLink) { const next = new URL(deltaLink); next.searchParams.set("token", "synthetic-v2"); return { complete: true, deltaLink: next.href, changes: [] }; },
  };
}

function fakeDestination() {
  const objects = new Map();
  const folders = new Set();
  const temp = new Map();
  return {
    kind: "local-staging", aclVerified: true,
    async initialize() { return { aclVerified: true, projectId: this.projectId }; },
    async ensureFolder(key) { folders.add(key); return { created: true, folderId: key }; },
    async createTempStream(key, stream) {
      const chunks = [];
      for await (const c of stream) chunks.push(Buffer.from(c));
      const bytes = Buffer.concat(chunks), filePath = `temp:${key}`;
      temp.set(filePath, bytes);
      return { filePath, sha256: digest(bytes), sizeBytes: bytes.length };
    },
    async cleanupTemp(path) { temp.delete(path); },
    async exists(key) { return objects.has(key); },
    async commitExclusive(path, key, metadata = {}) {
      if (objects.has(key)) return { created: false };
      const bytes = temp.get(path);
      objects.set(key, { sha256: digest(bytes), sizeBytes: bytes.length, bytes: Buffer.from(bytes), customer_id: metadata.customer_id, folder_id: metadata.folder_id });
      return { created: true, sha256: digest(bytes), sizeBytes: bytes.length, destinationFolderId: metadata.folder_id };
    },
    async checkTargetHash(key, context = {}) { return objects.get(key) ?? (context.previous?.target_key ? objects.get(context.previous.target_key) : null); },
    objects, folders,
  };
}

function memoryCheckpoint() {
  const records = [];
  return {
    records,
    async append(record) { records.push(record); },
    latestFor({ itemId, eTag }) { return [...records].reverse().find((r) => r.record_type === "source_item" && r.item_id === String(itemId) && r.e_tag === eTag); },
    hasReviewedPilot() { return false; },
    getReviewedPilot() { return null; },
  };
}

test("pilot imports full synthetic subtree, hashes targets, and resumes idempotently", async () => {
  const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
  const args = { mode: "pilot", driveId: "synthetic-drive", rootItemId: "kunden", folderMappings: [{ relativePath: "synthetic", customerId: 6, folderId: "customer-6" }], pilotItemId: "pilot", pilotCustomerId: 6, pilotApproved: true, pilotExpectedFiles: 5, pilotExpectedFolders: 4, pilotExpectedBytes: 28, source, destination, checkpoint };
  const first = await runDocumentImport(args);
  assert.equal(first.complete, true, JSON.stringify({ summary: first.summary, records: checkpoint.records.map((r) => [r.item_id, r.status, r.reason]) }));
  assert.equal(first.run_complete, true);
  assert.equal(first.pilot_complete, true);
  assert.equal(first.migration_complete, false);
  assert.equal(source.downloads, 5);
  assert.equal(destination.objects.size, 5);
  assert.equal(destination.folders.size, 4);
  assert.ok(checkpoint.records.some((r) => r.record_type === "pilot_complete" && r.destination_kind === "local-staging"), "local staging is recorded distinctly and cannot satisfy the R2 review gate");
  const second = await runDocumentImport(args);
  assert.equal(source.downloads, 5, "verified checkpoint rerun must not download again");
  assert.equal(second.summary.skipped, 5);
});

test("optional inventory state reuses scoped delta cursor but still reconciles the full tree before each transfer", async () => {
  const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
  const baseSnapshot = source.snapshotDrive.bind(source), baseWalk = source.walkRecursive.bind(source), baseChanges = source.changesSince.bind(source);
  let snapshots = 0, walks = 0, changes = 0;
  source.snapshotDrive = async (...args) => { snapshots++; return baseSnapshot(...args); };
  source.walkRecursive = async function* (...args) { walks++; yield* baseWalk(...args); };
  source.changesSince = async (...args) => { changes++; return baseChanges(...args); };
  const inventoryState = {
    state: null,
    async load(scope) {
      if (!this.state) return null;
      assert.deepEqual(scope, { driveId: "synthetic-drive", rootItemId: "kunden" });
      return structuredClone(this.state);
    },
    async save(value) { this.state = structuredClone(value); },
  };
  const args = { mode: "pilot", driveId: "synthetic-drive", rootItemId: "kunden", folderMappings: [{ relativePath: "synthetic", customerId: 6, folderId: "customer-6" }], pilotItemId: "pilot", pilotCustomerId: 6, pilotApproved: true, pilotExpectedFiles: 5, pilotExpectedFolders: 4, pilotExpectedBytes: 28, source, destination, checkpoint, inventoryState };
  const first = await runDocumentImport(args);
  assert.equal(first.inventory_mode, "full_snapshot");
  assert.ok(inventoryState.state?.delta_link);
  const second = await runDocumentImport(args);
  assert.equal(second.inventory_mode, "incremental_delta");
  assert.equal(snapshots, 1, "a valid saved cursor avoids a new full delta snapshot");
  assert.equal(walks, 2, "each run still recursively reconciles the whole tree");
  assert.equal(changes, 3, "initial final check, then incremental page and final check");
});

test("expired saved cursor triggers controlled full snapshot and recursive reconciliation", async () => {
  const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
  const baseSnapshot = source.snapshotDrive.bind(source), baseWalk = source.walkRecursive.bind(source), baseChanges = source.changesSince.bind(source);
  let snapshots = 0, walks = 0, changes = 0;
  source.snapshotDrive = async (...args) => { snapshots++; return baseSnapshot(...args); };
  source.walkRecursive = async function* (...args) { walks++; yield* baseWalk(...args); };
  source.changesSince = async (...args) => {
    changes++;
    if (changes === 1) throw Object.assign(new Error("synthetic expired cursor"), { code: "graph_http_410" });
    return baseChanges(...args);
  };
  const inventoryState = {
    state: { schema_version: 1, drive_id: "synthetic-drive", root_item_id: "kunden", delta_link: "https://graph.microsoft.com/v1.0/drives/synthetic-drive/items/kunden/delta?token=expired", items: [] },
    async load() { return structuredClone(this.state); },
    async save(value) { this.state = structuredClone(value); },
  };
  const result = await runDocumentImport({ mode: "pilot", driveId: "synthetic-drive", rootItemId: "kunden", folderMappings: [{ relativePath: "synthetic", customerId: 6, folderId: "customer-6" }], pilotItemId: "pilot", pilotCustomerId: 6, pilotApproved: true, pilotExpectedFiles: 5, pilotExpectedFolders: 4, pilotExpectedBytes: 28, source, destination, checkpoint, inventoryState });
  assert.equal(result.inventory_mode, "expired_cursor_full_rescan");
  assert.equal(snapshots, 1);
  assert.equal(walks, 1);
  assert.equal(destination.objects.size, 5);
  assert.ok(inventoryState.state.items.length > 0);
});

test("inventory and recursive-list mismatch blocks transfers", async () => {
  const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
  const baseWalk = source.walkRecursive.bind(source);
  source.walkRecursive = async function* (...args) {
    for await (const entry of baseWalk(...args)) {
      yield entry.item.id === "file-one" ? { ...entry, item: { ...entry.item, eTag: "newer-version" } } : entry;
    }
  };
  const result = await runDocumentImport({ mode: "pilot", driveId: "synthetic-drive", rootItemId: "kunden", folderMappings: [{ relativePath: "synthetic", customerId: 6, folderId: "customer-6" }], pilotItemId: "pilot", pilotCustomerId: 6, pilotApproved: true, pilotExpectedFiles: 5, pilotExpectedFolders: 4, pilotExpectedBytes: 28, source, destination, checkpoint });
  assert.equal(result.blocked, true);
  assert.equal(source.downloads, 0);
  assert.equal(destination.objects.size, 0);
});

test("delta/tree facet mismatches block before download", async (t) => {
  const cases = [
    ["file-kind", "file-one", (item) => ({ ...item, file: undefined, folder: {} })],
    ["folder-kind", "folder-a", (item) => ({ ...item, folder: undefined, file: { mimeType: "application/octet-stream" } })],
    ["remote-item", "file-one", (item) => ({ ...item, remoteItem: { id: "remote-1" } })],
    ["cTag-version", "file-one", (item) => ({ ...item, cTag: "different-content-tag" })],
    ["missing-parent", "file-one", (item) => ({ ...item, parentReference: {} })],
    ["size", "file-one", (item) => ({ ...item, size: item.size + 1 })],
  ];
  for (const [name, id, mutate] of cases) await t.test(name, async () => {
    const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
    const walk = source.walkRecursive.bind(source);
    source.walkRecursive = async function* (...args) {
      for await (const entry of walk(...args)) yield entry.item.id === id ? { ...entry, item: mutate(entry.item) } : entry;
    };
    const result = await runDocumentImport({ mode: "pilot", driveId: "synthetic-drive", rootItemId: "kunden", folderMappings: [{ relativePath: "synthetic", customerId: 6, folderId: "customer-6" }], pilotItemId: "pilot", pilotCustomerId: 6, pilotApproved: true, pilotExpectedFiles: 5, pilotExpectedFolders: 4, pilotExpectedBytes: 28, source, destination, checkpoint });
    assert.equal(result.blocked, true);
    assert.equal(source.downloads, 0);
    assert.equal(destination.objects.size, 0);
  });
});

test("actual downloaded byte count must match source inventory before destination commit", async () => {
  const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
  const originalDownload = source.downloadContent.bind(source);
  source.downloadContent = async (drive, id) => {
    const content = await originalDownload(drive, id);
    if (id !== "file-one") return content;
    const chunks = [];
    for await (const chunk of content) chunks.push(Buffer.from(chunk));
    return Readable.from([Buffer.concat(chunks).subarray(1)]);
  };
  const result = await runDocumentImport({ mode: "pilot", driveId: "synthetic-drive", rootItemId: "kunden", folderMappings: [{ relativePath: "synthetic", customerId: 6, folderId: "customer-6" }], pilotItemId: "pilot", pilotCustomerId: 6, pilotApproved: true, pilotExpectedFiles: 5, pilotExpectedFolders: 4, pilotExpectedBytes: 28, source, destination, checkpoint });
  assert.equal(result.summary.failed, 1);
  assert.ok(checkpoint.records.some((record) => record.reason === "download_size_does_not_match_inventory"));
  assert.equal(destination.objects.size, 4);
});

test("unmapped files and folders stay inventory-only and are never downloaded", async () => {
  const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
  destination.kind = "kratos-r2";
  destination.projectId = "synthetic-project";
  const folderMappings = [{ relativePath: "synthetic", customerId: 6, folderId: "customer-6" }];
  const treeItems = [];
  for await (const entry of source.walkRecursive({ driveId: "d", rootItemId: "kunden" })) treeItems.push(entry);
  const pilotRoot = treeItems.find(({ item }) => item.id === "pilot").item;
  const subtreeFingerprint = importGates.pilotSubtreeFingerprint({ driveId: "d", rootItemId: "kunden", pilotRoot, treeItems, folderMappings, destination, destinationProjectId: destination.projectId });
  checkpoint.getReviewedPilot = () => ({ pilot_folder_item_id: "pilot", subtree_fingerprint: subtreeFingerprint, expected_files: 5, expected_folders: 4, expected_bytes: 28 });
  const result = await runDocumentImport({ mode: "bulk", bulkApproved: true, driveId: "d", rootItemId: "kunden", folderMappings, source, destination, checkpoint });
  assert.equal(source.downloads, 5, "only the reviewed, mapped pilot subtree is transferred; unassigned sibling is never downloaded");
  assert.equal(result.complete, false);
  assert.ok(checkpoint.records.some((r) => r.reason?.includes("inventory_only_no_copy")));
  assert.equal(destination.objects.size, 5);
  assert.equal(result.migration_complete, false);
});

test("bulk gate rejects a changed nested pilot version or mapping before any transfer", async (t) => {
  for (const change of ["source-version", "mapping"]) {
    await t.test(change, async () => {
      const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
      destination.kind = "kratos-r2";
      destination.projectId = "synthetic-project";
      const approvedMappings = [{ relativePath: "synthetic", customerId: 6, folderId: "customer-6" }];
      const approvedTree = [];
      for await (const entry of source.walkRecursive({ driveId: "d", rootItemId: "kunden" })) approvedTree.push(entry);
      const approvedRoot = approvedTree.find(({ item }) => item.id === "pilot").item;
      const reviewedFingerprint = importGates.pilotSubtreeFingerprint({ driveId: "d", rootItemId: "kunden", pilotRoot: approvedRoot, treeItems: approvedTree, folderMappings: approvedMappings, destination, destinationProjectId: destination.projectId });
      checkpoint.getReviewedPilot = () => ({ pilot_folder_item_id: "pilot", subtree_fingerprint: reviewedFingerprint, expected_files: 5, expected_folders: 4, expected_bytes: 28 });
      let currentMappings = approvedMappings;
      if (change === "source-version") source.items.find((item) => item.id === "file-one").eTag = "v2";
      else currentMappings = [{ relativePath: "synthetic", customerId: 6, folderId: "customer-6-moved" }];
      await assert.rejects(runDocumentImport({ mode: "bulk", bulkApproved: true, driveId: "d", rootItemId: "kunden", folderMappings: currentMappings, source, destination, checkpoint }), /subtree, mapping, destination, or project changed/);
      assert.equal(source.downloads, 0);
      assert.equal(destination.objects.size, 0);
    });
  }
});

test("local staging cannot be used for bulk even with approval", async () => {
  await assert.rejects(runDocumentImport({ mode: "bulk", bulkApproved: true, driveId: "d", rootItemId: "kunden", source: fixtureSource(), destination: fakeDestination(), checkpoint: { hasReviewedPilot: () => true } }), /authenticated Kratos storage/);
});

test("conflicting normalized customer-folder mappings stop before destination setup or source access", async () => {
  const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
  let initialized = 0, rootVerified = 0;
  const initialize = destination.initialize.bind(destination), verifyRoot = source.verifyCustomerRoot.bind(source);
  destination.initialize = async () => { initialized++; return initialize(); };
  source.verifyCustomerRoot = async (...args) => { rootVerified++; return verifyRoot(...args); };
  await assert.rejects(runDocumentImport({
    mode: "pilot",
    driveId: "synthetic-drive",
    rootItemId: "kunden",
    folderMappings: [
      { relativePath: "synthetic/", customerId: 6, folderId: "customer-6" },
      { relativePath: "synthetic\\", customerId: 7, folderId: "customer-7" },
    ],
    pilotItemId: "pilot",
    pilotCustomerId: 6,
    pilotApproved: true,
    source,
    destination,
    checkpoint,
  }), { code: "mapping_conflict" });
  assert.equal(initialized, 0);
  assert.equal(rootVerified, 0);
  assert.equal(source.downloads, 0);
});

test("target conflicts are left untouched", async () => {
  const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
  const id = digest(Buffer.from("file-one")).slice(0, 10);
  const version = digest(Buffer.from("v1")).slice(0, 10);
  const key = `customers/6/one--${id}-${version}.txt`;
  const original = { sha256: "old", sizeBytes: 3, bytes: Buffer.from("original") };
  destination.objects.set(key, original);
  const result = await runDocumentImport({ mode: "pilot", driveId: "synthetic-drive", rootItemId: "kunden", folderMappings: [{ relativePath: "synthetic", customerId: 6, folderId: "customer-6" }], pilotItemId: "pilot", pilotCustomerId: 6, pilotApproved: true, pilotExpectedFiles: 5, pilotExpectedFolders: 4, pilotExpectedBytes: 28, source, destination, checkpoint });
  assert.equal(destination.objects.get(key), original);
  assert.equal(result.complete, false);
  assert.ok(checkpoint.records.some((r) => r.reason === "target_exists_without_matching_checkpoint; no overwrite"));
});

test("source name/parent changes during transfer are not committed even with unchanged eTag and bytes", async (t) => {
  for (const phase of ['before', 'after']) await t.test(phase, async () => {
    const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
    const original = source.getItem.bind(source); let reads = 0;
    source.getItem = async (...args) => {
      const item = await original(...args);
      if (item.id !== 'file-one') return item;
      reads++;
      return reads === (phase === 'before' ? 1 : 2) ? { ...item, name: 'moved.txt', parentReference: { id: 'other-folder' } } : item;
    };
    await runDocumentImport({ mode: 'pilot', driveId: 'synthetic-drive', rootItemId: 'kunden', folderMappings: [{ relativePath: 'synthetic', customerId: 6, folderId: 'customer-6' }], pilotItemId: 'pilot', pilotCustomerId: 6, pilotApproved: true, pilotExpectedFiles: 5, pilotExpectedFolders: 4, pilotExpectedBytes: 28, source, destination, checkpoint });
    assert.equal(checkpoint.records.some((record) => record.item_id === 'file-one' && record.reason === `source_changed_${phase === 'after' ? 'during' : 'before'}_download`), true);
    assert.equal(destination.objects.size, 4);
    assert.equal(source.downloads, phase === 'before' ? 4 : 5);
  });
});

test("Kratos resume rechecks customer and approved folder association instead of trusting identical bytes", async (t) => {
  for (const mismatch of ['customer', 'folder', 'base-mapping', 'legacy-checkpoint']) await t.test(mismatch, async () => {
    const source = fixtureSource(), destination = fakeDestination(), checkpoint = memoryCheckpoint();
    destination.kind = 'kratos-r2';
    const commit = destination.commitExclusive.bind(destination);
    destination.commitExclusive = async (file, key, metadata) => {
      assert.equal(metadata.source_drive_id, 'synthetic-drive', 'Importer provides the actual destination source identity contract');
      return commit(file, key, metadata);
    };
    const args = { mode: 'pilot', driveId: 'synthetic-drive', rootItemId: 'kunden', folderMappings: [{ relativePath: 'synthetic', customerId: 6, folderId: 'customer-6' }], pilotItemId: 'pilot', pilotCustomerId: 6, pilotApproved: true, pilotExpectedFiles: 5, pilotExpectedFolders: 4, pilotExpectedBytes: 28, source, destination, checkpoint };
    await runDocumentImport(args);
    assert.equal(source.downloads, 5);
    await runDocumentImport(args);
    assert.equal(source.downloads, 5, 'Valid fully bound checkpoint resumes without download');
    if (mismatch === 'customer' || mismatch === 'folder') for (const object of destination.objects.values()) object[mismatch === 'customer' ? 'customer_id' : 'folder_id'] = mismatch === 'customer' ? 99 : 'other-folder';
    if (mismatch === 'base-mapping') args.folderMappings[0].folderId = 'new-approved-base';
    if (mismatch === 'legacy-checkpoint') for (const record of checkpoint.records) { delete record.destination_folder_id; delete record.mapped_folder_id; }
    const before = checkpoint.records.length;
    await runDocumentImport(args);
    const failures = checkpoint.records.slice(before).filter((record) => record.reason?.startsWith('resume_customer_or_folder_mismatch'));
    assert.equal(failures.length, 5);
    assert.equal(source.downloads, 5, 'Association conflicts preserve targets and perform no extra copy');
    assert.equal(destination.objects.size, 5);
  });
});
