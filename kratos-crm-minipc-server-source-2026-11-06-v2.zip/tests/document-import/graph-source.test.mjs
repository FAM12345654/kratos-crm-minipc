import test from "node:test";
import assert from "node:assert/strict";
import { GraphReadOnlySource, matchesExpectedRootWebUrl } from "../../scripts/document-import/graph-source.mjs";

const graph = "https://graph.microsoft.com/v1.0";
const json = (body, status = 200, headers = {}) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", ...headers } });

test("scoped delta follows pages and requires final delta link", async () => {
  const requested = [];
  const source = new GraphReadOnlySource({ accessToken: "synthetic", fetchImpl: async (url) => {
    requested.push(String(url));
    return requested.length === 1
      ? json({ value: [{ id: "a" }], "@odata.nextLink": `${graph}/next` })
      : json({ value: [{ id: "b" }], "@odata.deltaLink": `${graph}/delta-token` });
  } });
  const result = await source.snapshotDrive("drive", "kunden");
  assert.equal(result.complete, true);
  assert.deepEqual(result.items.map((item) => item.id), ["a", "b"]);
  assert.equal(requested.length, 2);
});

test("Graph pagination rejects links outside the approved host", async () => {
  const source = new GraphReadOnlySource({ accessToken: "synthetic", fetchImpl: async () => json({ value: [], "@odata.nextLink": "https://attacker.invalid/steal" }) });
  await assert.rejects(source.snapshotDrive("drive", "kunden"), { code: "unsafe_graph_url" });
});

test("recursive listing follows nested and paginated children", async () => {
  const source = new GraphReadOnlySource({ accessToken: "synthetic", fetchImpl: async (url) => {
    const u = new URL(url);
    if (u.searchParams.has("page")) return json({ value: [{ id: "x", name: "Datei.txt", file: {} }] });
    if (u.pathname.endsWith("/root/children")) return json({ value: [{ id: "f", name: "Ordner", folder: {} }], "@odata.nextLink": `${graph}/drives/d/items/root/children?page=2` });
    if (u.pathname.endsWith("/f/children")) return json({ value: [{ id: "y", name: "innen.txt", file: {} }] });
    throw new Error("Unexpected synthetic request");
  } });
  const entries = [];
  for await (const entry of source.walkRecursive({ driveId: "d", rootItemId: "root" })) entries.push([entry.item.id, entry.relativePath]);
  assert.deepEqual(entries, [["f", "Ordner"], ["x", "Datei.txt"], ["y", "Ordner/innen.txt"]]);
});

test("Retry-After is honored without capping", async () => {
  const waits = [];
  let calls = 0;
  const source = new GraphReadOnlySource({ accessToken: "synthetic", maxAttempts: 2, sleep: async (ms) => waits.push(ms), fetchImpl: async () => ++calls === 1 ? json({}, 429, { "retry-after": "86400" }) : json({ value: [], "@odata.deltaLink": `${graph}/delta` }) });
  await source.snapshotDrive("d", "root");
  assert.deepEqual(waits, [86400000]);
});

test("content redirects never forward Graph authorization and reject non-443 URLs", async () => {
  const calls = [];
  const source = new GraphReadOnlySource({ accessToken: "synthetic-secret", fetchImpl: async (url, options) => {
    calls.push({ url: String(url), headers: options.headers });
    if (calls.length === 1) return new Response(null, { status: 302, headers: { location: "https://files.sharepoint.com/download?sig=synthetic" } });
    return new Response("ok", { status: 200 });
  } });
  const body = await source.downloadContent("d", "i");
  let text = "";
  for await (const chunk of body) text += chunk;
  assert.equal(text, "ok");
  assert.equal(calls[0].headers.Authorization, "Bearer synthetic-secret");
  assert.equal(calls[1].headers?.Authorization, undefined);

  const unsafe = new GraphReadOnlySource({ accessToken: "synthetic", fetchImpl: async () => new Response(null, { status: 302, headers: { location: "https://files.sharepoint.com:444/file" } }) });
  await assert.rejects(unsafe.downloadContent("d", "i"), { code: "unsafe_download_url" });
});

test("Graph requests resolve the in-memory token provider for each request", async () => {
  const tokens = ["TOKEN_ONE", "TOKEN_TWO"], seen = [];
  const source = new GraphReadOnlySource({ accessTokenProvider: async () => tokens.shift(), fetchImpl: async (_url, options) => {
    seen.push(options.headers.Authorization);
    return json({ id: "i", name: "Kunden", folder: {} });
  } });
  await source.getItem("d", "i");
  await source.getItem("d", "i");
  assert.deepEqual(seen, ["Bearer TOKEN_ONE", "Bearer TOKEN_TWO"]);
});

test("verified Kunden webUrl requires the exact HTTPS host and decoded path", () => {
  const expected = "https://Familienhelden2025-my.sharepoint.com/personal/office_familienhelden_at/Documents/Kunden";
  assert.equal(matchesExpectedRootWebUrl(expected, expected), true);
  assert.equal(matchesExpectedRootWebUrl(expected.replace("/Kunden", "/Kunden%20Kopie"), expected), false);
  assert.equal(matchesExpectedRootWebUrl(expected.replace("https://", "http://"), expected), false);
  assert.equal(matchesExpectedRootWebUrl(expected.replace("Familienhelden2025", "attacker"), expected), false);
  assert.equal(matchesExpectedRootWebUrl(expected + "?download=1", expected), false);
});
