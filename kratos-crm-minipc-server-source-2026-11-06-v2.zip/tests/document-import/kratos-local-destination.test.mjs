import test from "node:test";
import assert from "node:assert/strict";
import { backup, DatabaseSync } from "node:sqlite";
import { createHash } from "node:crypto";
import { mkdtemp, mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { Readable } from "node:stream";
import { build } from "esbuild";
import { ImportCheckpoint } from "../../scripts/document-import/checkpoint.mjs";
import { KratosLocalImportDestination } from "../../scripts/document-import/kratos-local-destination.mjs";
import { runDocumentImport } from "../../scripts/document-import/importer.mjs";

const built = await build({ entryPoints: ["lib/kratos-local-document-store.ts"], bundle: true, platform: "node", format: "esm", write: false });
const { KratosLocalDocumentStore } = await import("data:text/javascript;base64," + Buffer.from(built.outputFiles[0].contents).toString("base64"));
const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");

async function fixture(run) {
  const temp = await mkdtemp(path.join(tmpdir(), "kratos-local-import-"));
  const databasePath = path.join(temp, "synthetic.sqlite");
  const root = path.join(temp, "objects");
  const stagingDirectory = path.join(temp, "private-staging");
  await mkdir(root);
  const db = new DatabaseSync(databasePath);
  let store;
  try {
    for (const file of (await readdir("drizzle")).filter((name) => /^\d{4}_.*\.sql$/.test(name)).sort()) {
      db.exec(await readFile(path.join("drizzle", file), "utf8"));
    }
    db.exec("INSERT INTO customers(id,first_name,last_name) VALUES (6,'Synthetic','Pilot'), (7,'Synthetic','Other')");
    const options = { databasePath, root, ownerSubject: "synthetic-owner", allowedOwnerSubjects: ["synthetic-owner"], actorId: "synthetic-owner", allowedCustomerIds: [6, 7], privateRootConfirmed: true };
    store = await KratosLocalDocumentStore.open(options);
    const baseFolderId = store.createFolder(6, "Kundenmappe");
    const otherFolderId = store.createFolder(7, "Andere Kundenmappe");
    const payload = Buffer.from([0, 255, 17, 89]);
    const folder = { id: "pilot", name: "Testkunde", eTag: "v1", folder: {}, parentReference: { id: "kunden" } };
    const nested = { id: "nested", name: "Verträge", eTag: "v1", folder: {}, parentReference: { id: "pilot" } };
    const file = { id: "file", name: "Vertrag Ä #1.pdf", eTag: "v1", size: payload.length, file: { mimeType: "application/pdf" }, parentReference: { id: "nested" } };
    const items = [folder, nested, file];
    const source = {
      downloads: 0,
      async verifyCustomerRoot() {},
      async snapshotDrive() { return { items, complete: true, deltaLink: "https://graph.microsoft.com/v1.0/drives/synthetic/items/kunden/delta?token=initial" }; },
      async *walkRecursive() {
        for (const [index, item] of items.entries()) {
          const relativeSegments = items.slice(0, index + 1).map((part) => part.name);
          yield { item, relativeSegments, relativePath: relativeSegments.join("/") };
        }
      },
      async getItem(_driveId, itemId) { return items.find((item) => item.id === itemId); },
      async downloadContent() { this.downloads++; return Readable.from([payload]); },
      async changesSince(deltaLink) { return { changes: [], complete: true, deltaLink }; },
    };
    const checkpointPath = path.join(temp, "checkpoint.jsonl");
    const destination = new KratosLocalImportDestination({ store, stagingDirectory });
    const args = {
      mode: "pilot", driveId: "synthetic", rootItemId: "kunden", pilotItemId: "pilot", pilotCustomerId: 6,
      pilotApproved: true, pilotExpectedFiles: 1, pilotExpectedFolders: 1, pilotExpectedBytes: payload.length,
      folderMappings: [{ relativePath: folder.name, customerId: 6, folderId: baseFolderId }], localAclConfirmed: true,
      source, destination, checkpoint: await new ImportCheckpoint(checkpointPath).load(),
    };
    await run({ db, root, store, args, baseFolderId, otherFolderId, source, payload, checkpointPath, stagingDirectory, options, temp });
  } finally {
    store?.close();
    db.close();
    if (path.dirname(temp) === tmpdir() && path.basename(temp).startsWith("kratos-local-import-")) {
      await rm(temp, { recursive: true, force: true });
    }
  }
}

test("local pilot writes SQLite and exact object bytes and resumes with a reopened checkpoint", () => fixture(async ({ db, root, args, store, baseFolderId, source, payload, checkpointPath, stagingDirectory }) => {
  const first = await runDocumentImport(args);
  assert.equal(first.pilot_complete, true);
  assert.equal(first.migration_complete, false);
  const [stored] = store.list(6);
  const folder = db.prepare("SELECT name,parent_folder_id FROM storage_folders WHERE id=?").get(stored.folder_id);
  assert.equal(folder.name, "Verträge");
  assert.equal(folder.parent_folder_id, baseFolderId);
  assert.equal(stored.file_name, "Vertrag Ä #1.pdf");
  assert.equal(stored.sha256, digest(payload));
  assert.deepEqual(await readFile(path.join(root, stored.object_key)), payload);
  assert.equal(db.prepare("SELECT source_drive_id, source_item_id, source_version, source_path FROM storage_files WHERE id=?").get(stored.id).source_path, "Testkunde/Verträge/Vertrag Ä #1.pdf");
  args.checkpoint = await new ImportCheckpoint(checkpointPath).load();
  args.destination = new KratosLocalImportDestination({ store, stagingDirectory });
  assert.equal((await runDocumentImport(args)).pilot_complete, true);
  assert.equal(source.downloads, 1);
  assert.equal(store.list(6).length, 1);
  assert.deepEqual(await readdir(path.join(stagingDirectory, ".temporary")), []);
  await assert.rejects(runDocumentImport({ ...args, mode: "bulk", bulkApproved: true }), /Bulk import is blocked/);
}));

test("local pilot reports corruption on every retry and keeps its original target binding", () => fixture(async ({ root, store, args, source }) => {
  assert.equal((await runDocumentImport(args)).pilot_complete, true);
  const [file] = store.list(6);
  await writeFile(path.join(root, file.object_key), Buffer.alloc(file.size_bytes, 0));
  for (let attempt = 0; attempt < 2; attempt++) {
    assert.equal((await runDocumentImport(args)).pilot_complete, false);
    const record = args.checkpoint.latestFor({ driveId: "synthetic", itemId: "file", eTag: "v1" });
    assert.equal(record.status, "unresolved");
    assert.equal(record.destination_id, file.id);
    assert.equal(record.destination_folder_id, file.folder_id);
    assert.equal(record.sha256, file.sha256);
  }
  assert.equal(source.downloads, 1);
  assert.equal(store.list(6).length, 1);
}));

test("foreign mapped base folders are rejected without creating any object", () => fixture(async ({ args, otherFolderId, store }) => {
  args.folderMappings[0].folderId = otherFolderId;
  assert.equal((await runDocumentImport(args)).pilot_complete, false);
  assert.deepEqual(store.list(6), []);
  assert.deepEqual(store.list(7), []);
}));

test("checkpoint pins the physical store before writing folders or files", () => fixture(async ({ args, source, db, options, temp, checkpointPath, stagingDirectory }) => {
  assert.equal((await runDocumentImport(args)).pilot_complete, true);
  args.checkpoint = await new ImportCheckpoint(checkpointPath).load();
  const databasePath = path.join(temp, "switched.sqlite");
  const root = path.join(temp, "switched-objects");
  await mkdir(root);
  await backup(db, databasePath);
  const switchedStore = await KratosLocalDocumentStore.open({ ...options, databasePath, root });
  const originalVerify = source.verifyCustomerRoot;
  let sourceReads = 0;
  source.verifyCustomerRoot = async () => { sourceReads++; };
  try {
    const switched = new KratosLocalImportDestination({ store: switchedStore, stagingDirectory });
    await assert.rejects(runDocumentImport({ ...args, destination: switched }), /Checkpoint is bound/);
    await assert.rejects(runDocumentImport({ ...args, destination: { kind: "kratos-r2", async initialize() {} } }), /Checkpoint is bound/);
    assert.equal(sourceReads, 0);
    assert.equal(source.downloads, 1);
    assert.deepEqual(await readdir(path.join(root, "local")), []);
  } finally {
    switchedStore.close();
    source.verifyCustomerRoot = originalVerify;
  }
  assert.equal((await runDocumentImport(args)).pilot_complete, true);
}));

test("an interrupted stream can retry without producing duplicate objects or leaving a partial file", () => fixture(async ({ args, source, store, stagingDirectory }) => {
  const download = source.downloadContent.bind(source);
  source.downloadContent = async () => Readable.from((async function* () {
    yield Buffer.from([0, 255]);
    throw new Error("synthetic interruption");
  })());
  assert.equal((await runDocumentImport(args)).pilot_complete, false);
  assert.deepEqual(store.list(6), []);
  assert.deepEqual(await readdir(path.join(stagingDirectory, ".temporary")), []);
  source.downloadContent = download;
  assert.equal((await runDocumentImport(args)).pilot_complete, true);
  assert.equal(source.downloads, 1);
  assert.equal(store.list(6).length, 1);
}));

test("a changed cTag with the same eTag cannot silently reuse a checkpoint", () => fixture(async ({ args, source }) => {
  assert.equal((await runDocumentImport(args)).pilot_complete, true);
  const file = await source.getItem("synthetic", "file");
  file.cTag = "different-content-tag";
  for (let attempt = 0; attempt < 2; attempt++) {
    assert.equal((await runDocumentImport(args)).pilot_complete, false);
    const record = args.checkpoint.latestFor({ driveId: "synthetic", itemId: "file", eTag: "v1" });
    assert.equal(record.reason, "resume_source_changed; target preserved");
  }
  assert.equal(source.downloads, 1);
}));
