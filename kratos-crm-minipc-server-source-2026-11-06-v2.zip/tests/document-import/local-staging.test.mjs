import test from "node:test";
import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, readdir, rm, symlink, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { Readable } from "node:stream";
import { LocalStagingDestination, streamToFileAndHash } from "../../scripts/document-import/local-staging.mjs";

test("interrupted staging removes its partial file and leaves existing files intact", async () => {
  const root = path.resolve(os.tmpdir());
  const directory = await mkdtemp(path.join(root, "kratos-staging-test-"));
  try {
    const destination = new LocalStagingDestination(directory);
    await destination.initialize();
    const interrupted = new Error("synthetic source interruption");
    const stream = Readable.from((async function* () {
      yield Buffer.from("partial bytes");
      throw interrupted;
    })());
    await assert.rejects(destination.createTempStream("synthetic-key", stream), interrupted);
    assert.deepEqual(await readdir(destination.temporaryDirectory), []);

    const existing = path.join(destination.temporaryDirectory, "existing.part");
    await writeFile(existing, "original");
    await assert.rejects(streamToFileAndHash(Readable.from([Buffer.from("replacement")]), existing), { code: "EEXIST" });
    assert.equal(await readFile(existing, "utf8"), "original");
  } finally {
    assert.equal(path.dirname(path.resolve(directory)), root);
    assert.ok(path.basename(directory).startsWith("kratos-staging-test-"));
    await rm(directory, { recursive: true, force: true });
  }
});

test("staging rejects an ancestor junction before creating directories through it", async () => {
  const root = path.resolve(os.tmpdir());
  const directory = await mkdtemp(path.join(root, "kratos-staging-test-"));
  try {
    const target = path.join(directory, "target");
    const junction = path.join(directory, "junction");
    await mkdir(target);
    await symlink(target, junction, process.platform === "win32" ? "junction" : "dir");
    await assert.rejects(new LocalStagingDestination(path.join(junction, "new-stage")).initialize(), /symbolic link or junction/);
    assert.deepEqual(await readdir(target), []);
  } finally {
    assert.equal(path.dirname(path.resolve(directory)), root);
    assert.ok(path.basename(directory).startsWith("kratos-staging-test-"));
    await rm(directory, { recursive: true, force: true });
  }
});
