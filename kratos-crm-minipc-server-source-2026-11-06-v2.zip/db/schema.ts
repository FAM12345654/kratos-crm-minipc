import { sql } from "drizzle-orm";
import { foreignKey, index, integer, primaryKey, sqliteTable, text, uniqueIndex, type AnySQLiteColumn } from "drizzle-orm/sqlite-core";

export const customers = sqliteTable("customers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  phone: text("phone"),
  email: text("email"),
  birthday: text("birthday"),
  authorityStatus: text("authority_status").notNull().default("Ungeprüft"),
  adviser: text("adviser"),
  status: text("status").notNull().default("Kunde"),
  folderName: text("folder_name"),
  folderUrl: text("folder_url"),
  internalNote: text("internal_note"),
  lastContactAt: text("last_contact_at"),
  nextFollowUpAt: text("next_follow_up_at"),
  nextFollowUpNote: text("next_follow_up_note"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedBy: text("updated_by").notNull().default("system-import"),
}, (table) => ({
  namePhoneUnique: uniqueIndex("customers_name_phone_unique").on(table.firstName, table.lastName, table.phone),
  nameIndex: index("customers_name_idx").on(table.lastName, table.firstName),
  phoneIndex: index("customers_phone_idx").on(table.phone),
}));

export const auditEvents = sqliteTable("audit_events", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id").notNull(),
  action: text("action").notNull(),
  changedFields: text("changed_fields").notNull(),
  actorEmail: text("actor_email").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const customerDocuments = sqliteTable("customer_documents", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id").references(() => customers.id, { onDelete: "cascade" }),
  category: text("category").notNull(),
  fileName: text("file_name").notNull(),
  fileUrl: text("file_url").notNull(),
  source: text("source").notNull().default("OneDrive"),
  registeredAt: text("registered_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  registeredBy: text("registered_by").notNull(),
}, table => ({ fileUnique: uniqueIndex("customer_documents_file_unique").on(table.customerId, table.fileUrl), customerIndex: index("customer_documents_customer_idx").on(table.customerId, table.category) }));

export const customerContracts = sqliteTable("customer_contracts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id").notNull().references(() => customers.id, { onDelete: "restrict" }),
  insuranceType: text("insurance_type").notNull(),
  provider: text("provider"),
  status: text("status").notNull().default("Ungeprüft"),
  startDate: text("start_date"),
  endDate: text("end_date"),
  cancellationDeadline: text("cancellation_deadline"),
  documentUrl: text("document_url"),
  policyNumber: text("policy_number"),
  conclusionDate: text("conclusion_date"),
  conclusionYear: integer("conclusion_year"),
  mainDueDate: text("main_due_date"),
  durationMonths: integer("duration_months"),
  noticePeriodCount: integer("notice_period_count"),
  noticePeriodUnit: text("notice_period_unit", { enum: ["days", "weeks", "months", "years"] }),
  nextEligibleTerminationDate: text("next_eligible_termination_date"),
  latestNoticeReceiptDate: text("latest_notice_receipt_date"),
  jurisdiction: text("jurisdiction"),
  verificationStatus: text("verification_status", { enum: ["unverified", "verified", "review_required"] }).notNull().default("unverified"),
  // Current evidence records point to the customer document registry; the row itself does not attest that its contents were reviewed.
  sourceReference: integer("source_reference").references(() => customerDocuments.id, { onDelete: "restrict" }),
  // JSON array of explicit field names reviewed by verifiedBy at verifiedAt.
  verifiedFields: text("verified_fields"),
  verifiedBy: text("verified_by"),
  verifiedAt: text("verified_at"),
  lifecycle: text("lifecycle", { enum: ["current", "former", "unverified"] }).notNull().default("unverified"),
  replacementContractId: integer("replacement_contract_id").references((): AnySQLiteColumn => customerContracts.id, { onDelete: "restrict" }),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedBy: text("updated_by").notNull(),
}, table => ({
  customerIndex: index("customer_contracts_customer_idx").on(table.customerId),
  statusIndex: index("customer_contracts_status_idx").on(table.status),
  replacementContractIndex: index("customer_contracts_replacement_contract_idx").on(table.replacementContractId),
}));

export const storageFolders = sqliteTable("storage_folders", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id").references(() => customers.id, { onDelete: "restrict" }),
  parentFolderId: integer("parent_folder_id").references((): AnySQLiteColumn => storageFolders.id, { onDelete: "restrict" }),
  scopeKey: text("scope_key").notNull(),
  pathKey: text("path_key").notNull(),
  name: text("name").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  createdBy: text("created_by").notNull(),
}, table => ({
  pathUnique: uniqueIndex("storage_folders_scope_path_unique").on(table.scopeKey, table.pathKey),
  parentIndex: index("storage_folders_parent_idx").on(table.parentFolderId, table.customerId),
  customerIndex: index("storage_folders_customer_idx").on(table.customerId, table.pathKey),
}));

export const storageFiles = sqliteTable("storage_files", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id").references(() => customers.id, { onDelete: "restrict" }),
  folderId: integer("folder_id").references(() => storageFolders.id, { onDelete: "restrict" }),
  fileName: text("file_name").notNull(),
  objectKey: text("object_key").notNull().unique(),
  sizeBytes: integer("size_bytes").notNull(),
  mimeType: text("mime_type").notNull(),
  sha256: text("sha256"),
  sourceSha256: text("source_sha256"),
  sourceDriveId: text("source_drive_id"),
  sourceItemId: text("source_item_id"),
  sourceVersion: text("source_version"),
  sourcePath: text("source_path"),
  sourceCreatedAt: text("source_created_at"),
  sourceModifiedAt: text("source_modified_at"),
  importState: text("import_state").notNull().default("pending"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  createdBy: text("created_by").notNull(),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, table => ({
  sourceVersionUnique: uniqueIndex("storage_files_source_version_unique").on(table.sourceDriveId, table.sourceItemId, table.sourceVersion),
  customerIndex: index("storage_files_customer_idx").on(table.customerId, table.createdAt, table.id),
  folderIndex: index("storage_files_folder_idx").on(table.folderId, table.createdAt, table.id),
  stateIndex: index("storage_files_state_idx").on(table.importState, table.id),
}));

export const storageUploads = sqliteTable("storage_uploads", {
  id: text("id").primaryKey(),
  fileId: integer("file_id").notNull().references(() => storageFiles.id, { onDelete: "cascade" }),
  ownerEmail: text("owner_email").notNull(),
  objectKey: text("object_key").notNull().unique(),
  r2UploadId: text("r2_upload_id").notNull(),
  expectedSizeBytes: integer("expected_size_bytes").notNull(),
  status: text("status").notNull().default("uploading"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const storageUploadParts = sqliteTable("storage_upload_parts", {
  uploadId: text("upload_id").notNull().references(() => storageUploads.id, { onDelete: "cascade" }),
  partNumber: integer("part_number").notNull(),
  etag: text("etag").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  sha256: text("sha256").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, table => ({
  uploadPartUnique: uniqueIndex("storage_upload_parts_upload_part_unique").on(table.uploadId, table.partNumber),
}));

export const storageAuditEvents = sqliteTable("storage_audit_events", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  fileId: integer("file_id").references(() => storageFiles.id, { onDelete: "restrict" }),
  folderId: integer("folder_id").references(() => storageFolders.id, { onDelete: "restrict" }),
  action: text("action").notNull(),
  actorEmail: text("actor_email").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, table => ({
  fileIndex: index("storage_audit_file_idx").on(table.fileId, table.id),
  folderIndex: index("storage_audit_folder_idx").on(table.folderId, table.id),
}));

export const kratosCases = sqliteTable("kratos_cases", {
  ownerSubject: text("owner_subject").notNull(),
  caseId: text("case_id").notNull(),
  version: integer("version").notNull(),
  snapshotJson: text("snapshot_json").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => ({
  pk: primaryKey({ columns: [table.ownerSubject, table.caseId] }),
  versionCheckIndex: index("kratos_cases_owner_updated_idx").on(table.ownerSubject, table.updatedAt, table.caseId),
}));

export const kratosCaseEvents = sqliteTable("kratos_case_events", {
  ownerSubject: text("owner_subject").notNull(),
  caseId: text("case_id").notNull(),
  eventId: text("event_id").notNull(),
  eventType: text("event_type").notNull(),
  payloadFingerprint: text("payload_fingerprint").notNull(),
  actorId: text("actor_id").notNull(),
  appliedVersion: integer("applied_version").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => ({
  pk: primaryKey({ columns: [table.ownerSubject, table.caseId, table.eventId] }),
  caseFk: foreignKey({ columns: [table.ownerSubject, table.caseId], foreignColumns: [kratosCases.ownerSubject, kratosCases.caseId], name: "kratos_case_events_case_fk" }).onDelete("cascade"),
  versionIndex: index("kratos_case_events_version_idx").on(table.ownerSubject, table.caseId, table.appliedVersion),
}));

export const kratosCaseOutbox = sqliteTable("kratos_case_outbox", {
  ownerSubject: text("owner_subject").notNull(),
  caseId: text("case_id").notNull(),
  actionId: text("action_id").notNull(),
  actionType: text("action_type").notNull(),
  status: text("status", { enum: ["pending_review"] }).notNull().default("pending_review"),
  proposalJson: text("proposal_json").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => ({
  pk: primaryKey({ columns: [table.ownerSubject, table.actionId] }),
  caseFk: foreignKey({ columns: [table.ownerSubject, table.caseId], foreignColumns: [kratosCases.ownerSubject, kratosCases.caseId], name: "kratos_case_outbox_case_fk" }).onDelete("cascade"),
  caseIndex: index("kratos_case_outbox_case_idx").on(table.ownerSubject, table.caseId, table.createdAt),
}));
