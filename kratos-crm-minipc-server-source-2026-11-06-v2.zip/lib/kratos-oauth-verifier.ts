import { createRemoteJWKSet, customFetch, jwtVerify, type JWTVerifyGetKey } from "jose";

export type KratosAccessIdentity = { subject: string; scopes: string[] };
type VerificationConfig = {
  issuer: string;
  audience: string;
  /** Supply only trusted public signing keys; never derive this from token claims. */
  verificationKey: JWTVerifyGetKey;
};

function trustedHttps(value: string): URL {
  const url = new URL(value);
  if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash || (url.port && url.port !== "443")) {
    throw new Error("OAuth configuration requires a pinned HTTPS URL without credentials, query or fragment.");
  }
  return url;
}

/** Verifies access tokens, never issues tokens or grants access by email alone. */
export function createKratosJwtVerifier(config: VerificationConfig) {
  trustedHttps(config.issuer);
  trustedHttps(config.audience);
  if (typeof config.verificationKey !== "function") throw new Error("Trusted signing keys required.");
  return async (token: string): Promise<KratosAccessIdentity> => {
    if (typeof token !== "string" || token.length > 16384) throw new Error("Invalid access token.");
    const { payload } = await jwtVerify(token, config.verificationKey, {
      issuer: config.issuer,
      audience: config.audience,
      algorithms: ["RS256", "ES256"],
      typ: "at+jwt",
      requiredClaims: ["iss", "aud", "sub", "iat", "exp"],
      maxTokenAge: "1h",
      clockTolerance: 0,
    });
    if (typeof payload.sub !== "string" || !payload.sub.trim() || payload.sub.length > 255 ||
      typeof payload.iat !== "number" || typeof payload.exp !== "number" ||
      payload.exp <= payload.iat || payload.exp - payload.iat > 3600 ||
      typeof payload.scope !== "string" || payload.scope.length > 2048) {
      throw new Error("Invalid access token claims.");
    }
    return { subject: payload.sub, scopes: payload.scope.split(/\s+/).filter(Boolean) };
  };
}

/** The issuer/JWKS URL are administrator configuration, never user input. */
export function createKratosRemoteJwtVerifier(config: { issuer: string; audience: string; jwksUri: string }) {
  const jwks = trustedHttps(config.jwksUri);
  const verificationKey = createRemoteJWKSet(jwks, {
    timeoutDuration: 5000,
    cooldownDuration: 30000,
    cacheMaxAge: 300000,
    [customFetch]: (url, options) => fetch(url, { ...options, redirect: "error" }),
  });
  return createKratosJwtVerifier({ ...config, verificationKey });
}
