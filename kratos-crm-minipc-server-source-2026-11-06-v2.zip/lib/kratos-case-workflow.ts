/**
 * Pure, side-effect-free workflow state for customer document intake and insurer responses.
 * This module does not contact Kratos, Todoist, insurers, or storage services.
 */

declare const caseIdBrand: unique symbol;
export type KratosCaseId = string & { readonly [caseIdBrand]: true };

export type CaseWorkflowState = "received" | "needs_review" | "ready" | "partial" | "complete";
export type CustomerAssignment =
  | { status: "unconfirmed" }
  | { status: "ambiguous" }
  | { status: "confirmed"; customerId: number; confirmedBy: string; eventId: string };
export type RiskFinding = "identity_mismatch" | "signature_unclear" | "scope_unclear" | "recipient_unclear" | "attachment_unreadable" | "other_review_required";
export type CaseArtifactKind = "document" | "insurer_response" | "authorization";
export type CaseArtifact = {
  artifactId: string;
  kind: CaseArtifactKind;
  attachmentPresent: boolean;
  receivedEventId: string;
  review: "pending" | "accepted" | "needs_review";
  riskFindings: RiskFinding[];
};
export type ScopeAssessment = { scopeId: string; outcome: "satisfied" | "outstanding" | "unclear" };
export type InsurerResponseReview = {
  artifactId: string;
  eventId: string;
  reviewedBy: string;
  confirmation: "confirmed" | "unconfirmed" | "needs_review";
  scopeAssessments: ScopeAssessment[];
  riskFindings: RiskFinding[];
};

export type KratosCaseSnapshot = {
  caseId: KratosCaseId;
  state: CaseWorkflowState;
  customerAssignment: CustomerAssignment;
  expectedScopeIds: string[];
  artifacts: Record<string, CaseArtifact>;
  insurerResponseReview: InsurerResponseReview | null;
  verifiedRecipientIds: Record<string, { verifiedBy: string; eventId: string }>;
  authorizationReviews: Record<string, {
    artifactId: string;
    reviewedBy: string;
    validity: "valid" | "invalid" | "needs_review";
    signed: boolean;
    authorizedRecipientId: string;
    eventId: string;
  }>;
  /** Idempotency fingerprints contain event metadata only, never document contents. */
  processedEvents: Record<string, string>;
  eventOrder: string[];
};

type CaseEventBase = { caseId: KratosCaseId; eventId: string; actorId: string };
export type KratosCaseEvent =
  | (CaseEventBase & { type: "customer_assignment_confirmed"; customerId: number })
  | (CaseEventBase & { type: "document_received"; artifactId: string; attachmentPresent: boolean; riskFindings?: RiskFinding[] })
  | (CaseEventBase & { type: "insurer_response_received"; artifactId: string; attachmentPresent: boolean; riskFindings?: RiskFinding[] })
  | (CaseEventBase & { type: "authorization_received"; artifactId: string; attachmentPresent: boolean; riskFindings?: RiskFinding[] })
  | (CaseEventBase & { type: "artifact_reviewed"; artifactId: string; outcome: "accepted" | "needs_review"; riskFindings?: RiskFinding[] })
  | (CaseEventBase & { type: "insurer_response_reviewed"; artifactId: string; confirmation: "confirmed" | "unconfirmed" | "needs_review"; scopeAssessments: ScopeAssessment[]; riskFindings?: RiskFinding[] })
  | (CaseEventBase & { type: "recipient_verified"; recipientId: string })
  | (CaseEventBase & { type: "authorization_reviewed"; artifactId: string; validity: "valid" | "invalid" | "needs_review"; signed: boolean; authorizedRecipientId: string });

export type ApplyCaseEventResult = { snapshot: KratosCaseSnapshot; duplicate: boolean; idempotencyKey: string };

export class KratosCaseWorkflowError extends Error {
  readonly code: string;
  constructor(code: string, message: string) { super(message); this.name = "KratosCaseWorkflowError"; this.code = code; }
}

const RISK_FINDINGS = new Set<RiskFinding>([
  "identity_mismatch", "signature_unclear", "scope_unclear", "recipient_unclear", "attachment_unreadable", "other_review_required",
]);

function hasOwnKey<T>(record: Record<string, T>, key: string): boolean {
  return Object.hasOwn(record, key);
}

function copyOwnRecord<T>(record: Record<string, T>): Record<string, T> {
  const copy = Object.create(null) as Record<string, T>;
  for (const [key, value] of Object.entries(record)) copy[key] = value;
  return copy;
}

export function toKratosCaseId(value: string): KratosCaseId {
  if (typeof value !== "string" || !/^[A-Za-z0-9][A-Za-z0-9_-]{2,79}$/.test(value)) {
    throw new KratosCaseWorkflowError("invalid_case_id", "Case ID must be a stable opaque identifier of 3 to 80 characters.");
  }
  return value as KratosCaseId;
}

function requireText(value: unknown, field: string): asserts value is string {
  if (typeof value !== "string" || value.length === 0 || value.trim() !== value) {
    throw new KratosCaseWorkflowError("invalid_event", `${field} must be a non-empty exact identifier.`);
  }
}

function requireCustomerId(value: unknown): asserts value is number {
  if (!Number.isSafeInteger(value) || Number(value) < 1) throw new KratosCaseWorkflowError("invalid_customer_id", "Customer ID must be a positive integer.");
}

function validateFindings(findings: RiskFinding[] = []): RiskFinding[] {
  if (!Array.isArray(findings) || findings.some((finding) => !RISK_FINDINGS.has(finding))) {
    throw new KratosCaseWorkflowError("invalid_risk_finding", "Risk findings must use the explicit review code list.");
  }
  return [...new Set(findings)];
}

export function createKratosCase(input: {
  caseId: string | KratosCaseId;
  expectedScopeIds: string[];
  assignmentStatus?: "unconfirmed" | "ambiguous";
}): KratosCaseSnapshot {
  const caseId = toKratosCaseId(input.caseId);
  if (!Array.isArray(input.expectedScopeIds) || input.expectedScopeIds.length === 0 || input.expectedScopeIds.some((scope) => typeof scope !== "string" || !scope.trim() || scope.trim() !== scope) || new Set(input.expectedScopeIds).size !== input.expectedScopeIds.length) {
    throw new KratosCaseWorkflowError("invalid_expected_scopes", "At least one unique exact expected scope ID is required.");
  }
  const assignmentStatus = input.assignmentStatus ?? "unconfirmed";
  if (assignmentStatus !== "unconfirmed" && assignmentStatus !== "ambiguous") throw new KratosCaseWorkflowError("invalid_assignment", "Initial customer assignment must remain unconfirmed or ambiguous.");
  return {
    caseId,
    state: assignmentStatus === "ambiguous" ? "needs_review" : "received",
    customerAssignment: assignmentStatus === "ambiguous" ? { status: "ambiguous" } : { status: "unconfirmed" },
    expectedScopeIds: [...input.expectedScopeIds],
    artifacts: Object.create(null) as Record<string, CaseArtifact>,
    insurerResponseReview: null,
    verifiedRecipientIds: Object.create(null) as Record<string, { verifiedBy: string; eventId: string }>,
    authorizationReviews: Object.create(null) as KratosCaseSnapshot["authorizationReviews"],
    processedEvents: Object.create(null) as Record<string, string>,
    eventOrder: [],
  };
}

export function caseEventIdempotencyKey(caseId: KratosCaseId | string, eventId: string): string {
  requireText(eventId, "eventId");
  return `${toKratosCaseId(caseId)}:${eventId}`;
}

function stableValue(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableValue).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableValue(record[key])}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}

function hasRisk(snapshot: KratosCaseSnapshot): boolean {
  return Object.values(snapshot.artifacts).some((artifact) => artifact.riskFindings.length > 0 || !artifact.attachmentPresent || artifact.review === "needs_review") ||
    Boolean(snapshot.insurerResponseReview?.riskFindings.length) || snapshot.insurerResponseReview?.confirmation === "needs_review";
}

export function currentKratosCaseState(snapshot: KratosCaseSnapshot): CaseWorkflowState {
  const hasArtifacts = Object.keys(snapshot.artifacts).length > 0;
  if (snapshot.customerAssignment.status === "ambiguous" || hasRisk(snapshot)) return "needs_review";
  if (snapshot.customerAssignment.status !== "confirmed") return hasArtifacts ? "needs_review" : "received";
  if (Object.values(snapshot.artifacts).some((artifact) => artifact.review === "pending")) return "received";

  const response = snapshot.insurerResponseReview;
  if (response) {
    if (response.confirmation !== "confirmed") return "needs_review";
    if (response.scopeAssessments.some((assessment) => assessment.outcome === "unclear")) return "needs_review";
    const covered = new Map(response.scopeAssessments.map((assessment) => [assessment.scopeId, assessment.outcome]));
    return snapshot.expectedScopeIds.every((scopeId) => covered.get(scopeId) === "satisfied") ? "complete" : "partial";
  }
  return hasArtifacts ? "ready" : "received";
}

function validateEvent(snapshot: KratosCaseSnapshot, event: KratosCaseEvent): void {
  if (!event || typeof event !== "object" || !event.type) throw new KratosCaseWorkflowError("invalid_event", "A typed case event is required.");
  if (event.caseId !== snapshot.caseId) throw new KratosCaseWorkflowError("case_id_mismatch", "Event case ID does not match the target case.");
  requireText(event.eventId, "eventId");
  requireText(event.actorId, "actorId");
}

export function applyKratosCaseEvent(snapshot: KratosCaseSnapshot, event: KratosCaseEvent): ApplyCaseEventResult {
  validateEvent(snapshot, event);
  const idempotencyKey = caseEventIdempotencyKey(snapshot.caseId, event.eventId);
  const fingerprint = stableValue(event);
  if (hasOwnKey(snapshot.processedEvents, idempotencyKey)) {
    const prior = snapshot.processedEvents[idempotencyKey];
    if (prior !== fingerprint) throw new KratosCaseWorkflowError("idempotency_conflict", "The same case event key was reused with different event content.");
    return { snapshot, duplicate: true, idempotencyKey };
  }

  const next: KratosCaseSnapshot = {
    ...snapshot,
    artifacts: copyOwnRecord(snapshot.artifacts),
    verifiedRecipientIds: copyOwnRecord(snapshot.verifiedRecipientIds),
    authorizationReviews: copyOwnRecord(snapshot.authorizationReviews),
    processedEvents: copyOwnRecord(snapshot.processedEvents),
    eventOrder: [...snapshot.eventOrder, idempotencyKey],
  };
  for (const artifact of Object.values(next.artifacts)) artifact.riskFindings = [...artifact.riskFindings];
  next.processedEvents[idempotencyKey] = fingerprint;

  switch (event.type) {
    case "customer_assignment_confirmed": {
      requireCustomerId(event.customerId);
      if (snapshot.customerAssignment.status === "confirmed" && snapshot.customerAssignment.customerId !== event.customerId) {
        throw new KratosCaseWorkflowError("customer_assignment_conflict", "A confirmed customer assignment cannot be silently replaced.");
      }
      next.customerAssignment = { status: "confirmed", customerId: event.customerId, confirmedBy: event.actorId, eventId: event.eventId };
      break;
    }
    case "document_received":
    case "insurer_response_received":
    case "authorization_received": {
      requireText(event.artifactId, "artifactId");
      if (hasOwnKey(next.artifacts, event.artifactId)) throw new KratosCaseWorkflowError("artifact_conflict", "Artifact ID already exists in this case.");
      const findings = validateFindings(event.riskFindings);
      next.artifacts[event.artifactId] = {
        artifactId: event.artifactId,
        kind: event.type === "document_received" ? "document" : event.type === "insurer_response_received" ? "insurer_response" : "authorization",
        attachmentPresent: event.attachmentPresent === true,
        receivedEventId: event.eventId,
        review: findings.length || event.attachmentPresent !== true ? "needs_review" : "pending",
        riskFindings: findings,
      };
      break;
    }
    case "artifact_reviewed": {
      const artifact = hasOwnKey(next.artifacts, event.artifactId) ? next.artifacts[event.artifactId] : undefined;
      if (!artifact || artifact.kind !== "document") throw new KratosCaseWorkflowError("artifact_not_found", "Only a received document artifact can be reviewed with this event.");
      const findings = validateFindings(event.riskFindings);
      artifact.review = event.outcome === "accepted" && !findings.length && artifact.attachmentPresent ? "accepted" : "needs_review";
      artifact.riskFindings = [...new Set([...artifact.riskFindings, ...findings])];
      break;
    }
    case "insurer_response_reviewed": {
      const artifact = hasOwnKey(next.artifacts, event.artifactId) ? next.artifacts[event.artifactId] : undefined;
      if (!artifact || artifact.kind !== "insurer_response") throw new KratosCaseWorkflowError("artifact_not_found", "Insurer response must be received before it can be reviewed.");
      const findings = validateFindings(event.riskFindings);
      const seenScopes = new Set<string>();
      for (const assessment of event.scopeAssessments) {
        requireText(assessment.scopeId, "scopeId");
        if (!snapshot.expectedScopeIds.includes(assessment.scopeId) || seenScopes.has(assessment.scopeId)) {
          throw new KratosCaseWorkflowError("invalid_scope_assessment", "Scope assessments must uniquely reference expected scopes.");
        }
        seenScopes.add(assessment.scopeId);
      }
      if (event.confirmation === "confirmed" && !artifact.attachmentPresent) throw new KratosCaseWorkflowError("missing_attachment", "An insurer response without its attachment cannot be confirmed.");
      artifact.review = event.confirmation === "confirmed" && findings.length === 0 && artifact.attachmentPresent ? "accepted" : "needs_review";
      artifact.riskFindings = [...new Set([...artifact.riskFindings, ...findings])];
      next.insurerResponseReview = {
        artifactId: event.artifactId,
        eventId: event.eventId,
        reviewedBy: event.actorId,
        confirmation: findings.length ? "needs_review" : event.confirmation,
        scopeAssessments: event.scopeAssessments.map((item) => ({ ...item })),
        riskFindings: findings,
      };
      break;
    }
    case "recipient_verified": {
      requireText(event.recipientId, "recipientId");
      next.verifiedRecipientIds[event.recipientId] = { verifiedBy: event.actorId, eventId: event.eventId };
      break;
    }
    case "authorization_reviewed": {
      const artifact = hasOwnKey(next.artifacts, event.artifactId) ? next.artifacts[event.artifactId] : undefined;
      if (!artifact || artifact.kind !== "authorization") throw new KratosCaseWorkflowError("artifact_not_found", "A received authorization artifact is required before review.");
      requireText(event.authorizedRecipientId, "authorizedRecipientId");
      if (event.validity === "valid" && (!event.signed || !artifact.attachmentPresent)) throw new KratosCaseWorkflowError("authorization_evidence_required", "A valid authorization requires a present signed artifact confirmed by review.");
      next.authorizationReviews[event.artifactId] = {
        artifactId: event.artifactId,
        reviewedBy: event.actorId,
        validity: event.validity,
        signed: event.signed,
        authorizedRecipientId: event.authorizedRecipientId,
        eventId: event.eventId,
      };
      artifact.review = event.validity === "valid" && event.signed && artifact.attachmentPresent ? "accepted" : "needs_review";
      break;
    }
  }

  next.state = currentKratosCaseState(next);
  return { snapshot: next, duplicate: false, idempotencyKey };
}

export type TodoistPlanProposal = {
  status: "explicit-plan";
  explicitPlan: true;
  caseId: KratosCaseId;
  projectId: string;
  idempotencyKey: string;
  /** Templates are not ready-to-create Todoist tasks until verified display names are supplied downstream. */
  taskTemplates: Array<{ type: "insurer_response_follow_up" | "contracts_review_and_consultation_prep" | "confirmed_insurer_response"; titleTemplate: string; missingScopeIds?: string[] }>;
  requiredVerifiedDisplayFields: ["customerDisplayName", "insurerDisplayName", "lineOfBusinessDisplayName"];
  taskTitlesMaterialized: false;
  externalWritePerformed: false;
};

export type TodoistPlanResult = { status: "not_created"; reason: "insurer_response_not_confirmed" | "todoist_project_id_missing" | "case_needs_review" } | TodoistPlanProposal;

/** Returns a plan only. It never calls Todoist or calculates due dates. */
export function createTodoistPlanProposal(snapshot: KratosCaseSnapshot, exactProjectId?: string | null): TodoistPlanResult {
  const review = snapshot.insurerResponseReview;
  if (!review || review.confirmation !== "confirmed" || !hasOwnKey(snapshot.artifacts, review.artifactId) || snapshot.artifacts[review.artifactId]?.review !== "accepted") {
    return { status: "not_created", reason: "insurer_response_not_confirmed" };
  }
  if (snapshot.state !== "partial" && snapshot.state !== "complete") return { status: "not_created", reason: "case_needs_review" };
  if (typeof exactProjectId !== "string" || exactProjectId.length === 0 || exactProjectId.trim() !== exactProjectId) {
    return { status: "not_created", reason: "todoist_project_id_missing" };
  }
  const outcomes = new Map(review.scopeAssessments.map((assessment) => [assessment.scopeId, assessment.outcome]));
  const missingScopeIds = snapshot.expectedScopeIds.filter((scopeId) => outcomes.get(scopeId) !== "satisfied");
  const taskTemplates: TodoistPlanProposal["taskTemplates"] = snapshot.state === "complete"
    ? [
      { type: "confirmed_insurer_response", titleTemplate: "Rücklauf bestätigt" },
      { type: "contracts_review_and_consultation_prep", titleTemplate: "Verträge prüfen / Beratung vorbereiten" },
    ]
    : [{ type: "insurer_response_follow_up", titleTemplate: "Rücklauf prüfen: fehlende Unterlagen", missingScopeIds }];
  return {
    status: "explicit-plan",
    explicitPlan: true,
    caseId: snapshot.caseId,
    projectId: exactProjectId,
    idempotencyKey: caseEventIdempotencyKey(snapshot.caseId, review.eventId),
    taskTemplates,
    requiredVerifiedDisplayFields: ["customerDisplayName", "insurerDisplayName", "lineOfBusinessDisplayName"],
    taskTitlesMaterialized: false,
    externalWritePerformed: false,
  };
}

export type PendingSendProposal = {
  status: "pending-proposal";
  caseId: KratosCaseId;
  proposalId: string;
  recipientId: string;
  authorizationArtifactId: string;
  idempotencyKey: string;
  sendPerformed: false;
};

/** Creates a reviewable send proposal only; this module never sends correspondence. */
export function createPendingSendProposal(input: {
  snapshot: KratosCaseSnapshot;
  proposalId: string;
  recipientId: string;
  authorizationArtifactId: string;
}): PendingSendProposal {
  const { snapshot } = input;
  requireText(input.proposalId, "proposalId");
  requireText(input.recipientId, "recipientId");
  requireText(input.authorizationArtifactId, "authorizationArtifactId");
  if (snapshot.customerAssignment.status !== "confirmed") throw new KratosCaseWorkflowError("customer_assignment_required", "A confirmed customer assignment is required before proposing correspondence.");
  if (!hasOwnKey(snapshot.verifiedRecipientIds, input.recipientId)) throw new KratosCaseWorkflowError("recipient_not_verified", "A specifically verified recipient is required before proposing correspondence.");
  const authorization = hasOwnKey(snapshot.authorizationReviews, input.authorizationArtifactId) ? snapshot.authorizationReviews[input.authorizationArtifactId] : undefined;
  if (!authorization || authorization.validity !== "valid" || !authorization.signed || authorization.authorizedRecipientId !== input.recipientId) {
    throw new KratosCaseWorkflowError("valid_authorization_required", "A reviewed, signed, valid authorization for this exact recipient is required.");
  }
  if (snapshot.state === "needs_review" || snapshot.state === "received") throw new KratosCaseWorkflowError("case_review_required", "The case must be ready or have a reviewed insurer response before correspondence is proposed.");
  return {
    status: "pending-proposal",
    caseId: snapshot.caseId,
    proposalId: input.proposalId,
    recipientId: input.recipientId,
    authorizationArtifactId: input.authorizationArtifactId,
    idempotencyKey: caseEventIdempotencyKey(snapshot.caseId, input.proposalId),
    sendPerformed: false,
  };
}
