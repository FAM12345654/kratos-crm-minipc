import { createHash } from "node:crypto";
import { open } from "node:fs/promises";
import path from "node:path";
import { assertKratosLocalPath, localObjectPath } from "./kratos-local-document-store";

export const MAX_LOCAL_DOCUMENT_BYTES = 20 * 1024 * 1024;

/** This endpoint shares the gateway's existing read-only SQLite connection. */
export async function openKratosLocalDocumentReader(database: D1Database, root: string, allowedCustomerIds: readonly number[]) {
  await assertKratosLocalPath(root, "directory");
  await assertKratosLocalPath(path.join(root, "local"), "directory");
  const customers = new Set(allowedCustomerIds);
  const findFile = database.prepare(
    "SELECT f.customer_id, f.folder_id, f.object_key, f.size_bytes, f.sha256 FROM storage_files f JOIN customers c ON c.id=f.customer_id WHERE f.id=? AND f.import_state='stored'",
  );
  const findFolder = database.prepare("SELECT parent_folder_id FROM storage_folders WHERE id=? AND customer_id=?");

  return async function readDocument(fileId: number, signal: AbortSignal): Promise<Buffer | null | "too_large"> {
    signal.throwIfAborted();
    const file = await findFile.bind(fileId).first<{ customer_id: number; folder_id: number | null; object_key: string; size_bytes: number; sha256: string }>();
    if (!file || !customers.has(file.customer_id) || !Number.isSafeInteger(file.size_bytes) || file.size_bytes < 0 || !/^[a-f0-9]{64}$/.test(file.sha256)) return null;
    const visited = new Set<number>();
    let folderId = file.folder_id;
    while (folderId !== null) {
      signal.throwIfAborted();
      if (!Number.isSafeInteger(folderId) || folderId < 1 || visited.has(folderId) || visited.size >= 1000) return null;
      visited.add(folderId);
      const folder = await findFolder.bind(folderId, file.customer_id).first<{ parent_folder_id: number | null }>();
      if (!folder) return null;
      folderId = folder.parent_folder_id;
    }

    const target = localObjectPath(root, file.object_key);
    if (file.size_bytes > MAX_LOCAL_DOCUMENT_BYTES) return "too_large";
    signal.throwIfAborted();
    await assertKratosLocalPath(target, "file");
    signal.throwIfAborted();
    const handle = await open(target, "r");
    try {
      const before = await handle.stat();
      if (!before.isFile() || before.nlink !== 1 || before.size !== file.size_bytes) return null;
      signal.throwIfAborted();
      const bytes = Buffer.allocUnsafe(file.size_bytes);
      let offset = 0;
      while (offset < bytes.length) {
        signal.throwIfAborted();
        const { bytesRead } = await handle.read(bytes, offset, Math.min(1024 * 1024, bytes.length - offset), offset);
        if (bytesRead === 0) return null;
        offset += bytesRead;
      }
      const end = await handle.read(Buffer.alloc(1), 0, 1, offset);
      const after = await handle.stat();
      signal.throwIfAborted();
      if (end.bytesRead !== 0 || after.size !== before.size || after.mtimeMs !== before.mtimeMs ||
          after.nlink !== 1 || createHash("sha256").update(bytes).digest("hex") !== file.sha256) return null;
      return bytes;
    } finally {
      await handle.close();
    }
  };
}
