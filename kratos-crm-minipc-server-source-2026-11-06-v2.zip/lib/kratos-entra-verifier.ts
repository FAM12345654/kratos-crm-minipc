import { createRemoteJWKSet, customFetch, jwtVerify, type JWTVerifyGetKey } from "jose";
import type { KratosAccessIdentity } from "./kratos-oauth-verifier";

export type KratosEntraConfiguration = {
  tenantId: string;
  apiClientId: string;
  /** Explicit delegated OAuth clients; the API registration is not a login client. */
  allowedClientIds: string[];
};

const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const MAX_TOKEN_SECONDS = 7200;

function configuration(config: KratosEntraConfiguration) {
  if (!config || !GUID.test(config.tenantId) || !GUID.test(config.apiClientId) ||
      !Array.isArray(config.allowedClientIds) || config.allowedClientIds.length < 1 || config.allowedClientIds.length > 20 ||
      config.allowedClientIds.some((id) => typeof id !== "string" || !GUID.test(id) || id === config.apiClientId) ||
      new Set(config.allowedClientIds).size !== config.allowedClientIds.length) {
    throw new Error("Explicit Entra tenant, separate API and delegated client IDs are required.");
  }
  return {
    tenantId: config.tenantId,
    apiClientId: config.apiClientId,
    allowedClientIds: new Set(config.allowedClientIds),
    issuer: `https://login.microsoftonline.com/${config.tenantId}/v2.0`,
    jwksUri: `https://login.microsoftonline.com/${config.tenantId}/discovery/v2.0/keys`,
  };
}

/** Separate, single-tenant Entra v2 delegated-token profile; no token issuance or user grant. */
export function createKratosEntraJwtVerifier(config: KratosEntraConfiguration & { verificationKey: JWTVerifyGetKey }) {
  const pinned = configuration(config);
  if (typeof config.verificationKey !== "function") throw new Error("Trusted signing keys are required.");
  return async (token: string): Promise<KratosAccessIdentity> => {
    if (typeof token !== "string" || !token || token.length > 16384) throw new Error("Invalid Entra access token.");
    const { payload } = await jwtVerify(token, config.verificationKey, {
      issuer: pinned.issuer,
      audience: pinned.apiClientId,
      algorithms: ["RS256"],
      typ: "JWT",
      requiredClaims: ["iss", "aud", "sub", "iat", "nbf", "exp", "tid", "oid", "ver", "azp", "scp"],
      maxTokenAge: "2h",
      clockTolerance: 0,
    });
    // Entra normally issues 60–90 minute tokens. Two hours is a local ceiling,
    // not a tenant policy change; longer-lived/CAE tokens intentionally fail closed.
    if (payload.ver !== "2.0" || payload.tid !== pinned.tenantId || payload.aud !== pinned.apiClientId ||
        typeof payload.oid !== "string" || !GUID.test(payload.oid) ||
        typeof payload.sub !== "string" || !payload.sub.trim() || payload.sub.length > 255 ||
        typeof payload.azp !== "string" || !pinned.allowedClientIds.has(payload.azp) ||
        (payload.idtyp !== undefined && payload.idtyp !== "user") ||
        typeof payload.scp !== "string" || payload.scp.length > 2048 || !payload.scp.split(/\s+/).includes("kratos.read") ||
        !Number.isSafeInteger(payload.iat) || !Number.isSafeInteger(payload.nbf) || !Number.isSafeInteger(payload.exp) ||
        payload.exp! <= payload.iat! || payload.exp! <= payload.nbf! || payload.exp! - payload.iat! > MAX_TOKEN_SECONDS) {
      throw new Error("Invalid Entra access token claims.");
    }
    return { subject: `${pinned.tenantId}:${payload.oid}`, scopes: ["kratos:read"] };
  };
}

/** Tenant/key locations are derived only from validated administrator configuration. */
export function createKratosRemoteEntraJwtVerifier(config: KratosEntraConfiguration) {
  const pinned = configuration(config);
  const verificationKey = createRemoteJWKSet(new URL(pinned.jwksUri), {
    timeoutDuration: 5000,
    cooldownDuration: 30000,
    cacheMaxAge: 300000,
    [customFetch]: (url, options) => fetch(url, { ...options, redirect: "error" }),
  });
  return createKratosEntraJwtVerifier({ ...config, verificationKey });
}
