import { KratosCaseStore, KratosCaseStoreError, SqliteCaseDatabase, type NodeSqliteDatabase, type StoredKratosCase } from "./kratos-case-store";
import { KratosCaseWorkflowError, toKratosCaseId, type KratosCaseEvent } from "./kratos-case-workflow";
import type { KratosAccessTokenVerifier, KratosVerifiedIdentity } from "./kratos-universal-gateway";

export type KratosCaseApiConfig = {
  /** Already-open trusted SQLite connection; migrations and path selection are operator work. */
  database: NodeSqliteDatabase;
  resourceOrigin: string;
  verifyAccessToken: KratosAccessTokenVerifier;
  allowedSubjects: readonly string[];
  /** Explicitly opt in. Existing readonly gateway/verifiers do not gain this scope. */
  enableWrites?: boolean;
  /** Trusted customer authorization; invoked again for assigned-case reads and writes. */
  canAccessCustomer: (identity: KratosVerifiedIdentity, customerId: number) => boolean | Promise<boolean>;
  todoistProjectId?: string;
};

const BODY_LIMIT = 64 * 1024;
const RESPONSE_LIMIT = 1024 * 1024;
const EVENT_FIELDS: Record<string, string[]> = {
  customer_assignment_confirmed: ["customerId"],
  document_received: ["artifactId", "attachmentPresent", "riskFindings"],
  insurer_response_received: ["artifactId", "attachmentPresent", "riskFindings"],
  authorization_received: ["artifactId", "attachmentPresent", "riskFindings"],
  artifact_reviewed: ["artifactId", "outcome", "riskFindings"],
  insurer_response_reviewed: ["artifactId", "confirmation", "scopeAssessments", "riskFindings"],
  recipient_verified: ["recipientId"],
  authorization_reviewed: ["artifactId", "validity", "signed", "authorizedRecipientId"],
};

class ApiError extends Error { constructor(readonly status: number, readonly code: string) { super(code); } }
function record(value: unknown): value is Record<string, unknown> { return value !== null && typeof value === "object" && !Array.isArray(value); }
function exactKeys(value: Record<string, unknown>, allowed: string[]): boolean { return Object.keys(value).every((key) => allowed.includes(key)); }
function requireActive(request: Request): void { if (request.signal.aborted) throw new ApiError(408, "request_cancelled"); }
function response(status: number, value: unknown): Response {
  let body = JSON.stringify(value);
  if (Buffer.byteLength(body) > RESPONSE_LIMIT) { status = 413; body = '{"error":"response_too_large"}'; }
  return new Response(body, { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...(status === 401 ? { "www-authenticate": 'Bearer scope="kratos:read"' } : {}) } });
}

async function boundedBody(request: Request): Promise<Record<string, unknown>> {
  requireActive(request);
  if (request.headers.get("content-type")?.split(";")[0].trim().toLowerCase() !== "application/json") throw new ApiError(415, "unsupported_media_type");
  const reader = request.body?.getReader();
  if (!reader) throw new ApiError(400, "invalid_json");
  const chunks: Uint8Array[] = [];
  let bytes = 0;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let onAbort: (() => void) | undefined;
  const collect = async () => {
    for (;;) {
      const part = await reader.read();
      if (part.done) break;
      bytes += part.value.byteLength;
      if (bytes > BODY_LIMIT) throw new ApiError(413, "body_too_large");
      chunks.push(part.value);
    }
    let parsed: unknown;
    try { parsed = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(chunks))); }
    catch { throw new ApiError(400, "invalid_json"); }
    if (!record(parsed)) throw new ApiError(400, "invalid_arguments");
    return parsed;
  };
  try {
    return await Promise.race([
      collect(),
      new Promise<never>((_resolve, reject) => { timer = setTimeout(() => reject(new ApiError(408, "body_timeout")), 5000); }),
      new Promise<never>((_resolve, reject) => {
        onAbort = () => { void reader.cancel().catch(() => {}); reject(new ApiError(408, "request_cancelled")); };
        request.signal.addEventListener("abort", onAbort, { once: true });
        if (request.signal.aborted) onAbort();
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
    if (onAbort) request.signal.removeEventListener("abort", onAbort);
    void reader.cancel().catch(() => {});
  }
}

/** Opt-in case router with no external action executor. */
export function createKratosCaseApi(config: KratosCaseApiConfig): (request: Request) => Promise<Response> {
  let origin: URL;
  try { origin = new URL(config.resourceOrigin); } catch { throw new Error("Canonical HTTPS origin required."); }
  if (origin.protocol !== "https:" || config.resourceOrigin !== origin.origin || origin.username || origin.password) throw new Error("Canonical HTTPS origin required.");
  if (typeof config.verifyAccessToken !== "function" || typeof config.canAccessCustomer !== "function" || !config.database ||
      !Array.isArray(config.allowedSubjects) || config.allowedSubjects.length < 1 || config.allowedSubjects.length > 20 ||
      config.allowedSubjects.some((subject) => typeof subject !== "string" || !subject || subject.trim() !== subject || subject.length > 249) ||
      (config.enableWrites !== undefined && typeof config.enableWrites !== "boolean")) throw new Error("Explicit trusted case API configuration required.");
  const allowed = new Set(config.allowedSubjects);
  const caseDatabase = new SqliteCaseDatabase(config.database);
  const canAccess = async (request: Request, identity: KratosVerifiedIdentity, customerId: number) => {
    requireActive(request);
    if (!Number.isSafeInteger(customerId) || customerId < 1) throw new ApiError(404, "not_found");
    const granted = await config.canAccessCustomer(identity, customerId);
    requireActive(request);
    if (granted !== true || !config.database.prepare("SELECT id FROM customers WHERE id=?").get(customerId)) throw new ApiError(404, "not_found");
  };
  const allowCase = async (request: Request, identity: KratosVerifiedIdentity, row: StoredKratosCase | null) => {
    requireActive(request);
    if (!row) throw new ApiError(404, "not_found");
    if (row.snapshot.customerAssignment.status === "confirmed") await canAccess(request, identity, row.snapshot.customerAssignment.customerId);
    requireActive(request);
    return row;
  };
  return async (request) => {
    try {
      requireActive(request);
      const url = new URL(request.url);
      if (url.origin !== config.resourceOrigin) throw new ApiError(421, "misdirected_request");
      if (url.search || url.hash || !/^\/v1\/cases(?:\/[A-Za-z0-9][A-Za-z0-9_-]{2,79}(?:\/(?:events|plans))?)?$/.test(url.pathname)) throw new ApiError(404, "not_found");
      if (request.method !== "GET" && request.method !== "POST") throw new ApiError(405, "method_not_allowed");
      const requestOrigin = request.headers.get("origin");
      if (requestOrigin !== null && requestOrigin !== config.resourceOrigin) throw new ApiError(403, "origin_not_allowed");
      const bearer = /^Bearer\s+([^\s]+)$/i.exec(request.headers.get("authorization") ?? "");
      let identity: KratosVerifiedIdentity | null = null;
      try { if (bearer) identity = await config.verifyAccessToken(bearer[1]); } catch { /* generic unauthorized */ }
      requireActive(request);
      if (!identity) throw new ApiError(401, "unauthorized");
      if (!allowed.has(identity.subject) || !Array.isArray(identity.scopes) || !identity.scopes.includes("kratos:read")) throw new ApiError(403, "access_denied");
      const write = request.method === "POST";
      if (write && (config.enableWrites !== true || !identity.scopes.includes("kratos:cases:write"))) throw new ApiError(403, "write_not_allowed");
      const store = new KratosCaseStore(caseDatabase, { ownerSubject: identity.subject, allowedOwnerSubjects: [...allowed], actorId: `oauth:${identity.subject}`, todoistProjectId: config.todoistProjectId });
      if (url.pathname === "/v1/cases") {
        if (!write) throw new ApiError(405, "method_not_allowed");
        const body = await boundedBody(request);
        requireActive(request);
        if (!exactKeys(body, ["caseId", "expectedScopeIds", "assignmentStatus"]) || typeof body.caseId !== "string" || !Array.isArray(body.expectedScopeIds) ||
            body.expectedScopeIds.length > 100 || body.expectedScopeIds.some((scope) => typeof scope !== "string" || scope.length > 255) ||
            (body.assignmentStatus !== undefined && body.assignmentStatus !== "unconfirmed" && body.assignmentStatus !== "ambiguous")) throw new ApiError(400, "invalid_arguments");
        const id = toKratosCaseId(body.caseId);
        const prior = store.getCase(id);
        if (prior) {
          if (prior.version === 1 && prior.snapshot.customerAssignment.status === (body.assignmentStatus ?? "unconfirmed") && JSON.stringify(prior.snapshot.expectedScopeIds) === JSON.stringify(body.expectedScopeIds)) return response(200, { ...prior, duplicate: true });
          throw new ApiError(409, "case_exists");
        }
        requireActive(request);
        return response(201, { ...store.createCase({ caseId: id, expectedScopeIds: body.expectedScopeIds as string[], assignmentStatus: body.assignmentStatus as "unconfirmed" | "ambiguous" | undefined }), duplicate: false });
      }
      const [, , , caseId, suffix] = url.pathname.split("/");
      const current = await allowCase(request, identity, store.getCase(caseId));
      requireActive(request);
      if (!write) {
        if (suffix === "events") return response(200, { events: store.listEvents(caseId) });
        if (suffix === "plans") return response(200, { plans: store.listOutbox(caseId), externalWritePerformed: false });
        return response(200, current);
      }
      if (suffix !== "events") throw new ApiError(405, "method_not_allowed");
      const body = await boundedBody(request);
      requireActive(request);
      if (!exactKeys(body, ["expectedVersion", "event"]) || !Number.isSafeInteger(body.expectedVersion) || Number(body.expectedVersion) < 1 || !record(body.event) ||
          typeof body.event.type !== "string" || !Object.hasOwn(EVENT_FIELDS, body.event.type) ||
          !exactKeys(body.event, ["eventId", "type", ...EVENT_FIELDS[body.event.type]])) throw new ApiError(400, "invalid_arguments");
      if (body.event.type === "customer_assignment_confirmed") {
        if (!Number.isSafeInteger(body.event.customerId) || Number(body.event.customerId) < 1) throw new ApiError(400, "invalid_arguments");
        await canAccess(request, identity, Number(body.event.customerId));
      }
      if (body.event.type === "insurer_response_reviewed" && Array.isArray(body.event.scopeAssessments) && body.event.scopeAssessments.some((assessment) => !record(assessment) || !exactKeys(assessment, ["scopeId", "outcome"]))) throw new ApiError(400, "invalid_arguments");
      const event = { ...body.event, caseId, actorId: `oauth:${identity.subject}` } as unknown as KratosCaseEvent;
      requireActive(request);
      return response(200, store.applyEvent({ caseId, expectedVersion: Number(body.expectedVersion), event }));
    } catch (error) {
      if (error instanceof ApiError) return response(error.status, { error: error.code });
      if (error instanceof KratosCaseStoreError || error instanceof KratosCaseWorkflowError) {
        const code = error.code;
        if (["case_exists", "version_conflict", "event_id_conflict", "outbox_conflict", "customer_assignment_conflict", "artifact_conflict"].includes(code)) return response(409, { error: code });
        if (code === "case_not_found") return response(404, { error: "not_found" });
        if (error instanceof KratosCaseWorkflowError || code.startsWith("invalid_") || code === "case_id_mismatch") return response(400, { error: "invalid_arguments" });
      }
      return response(500, { error: "case_operation_failed" });
    }
  };
}
