import { createHash, randomUUID } from "node:crypto";
import { lstat, mkdir, open, realpath, unlink } from "node:fs/promises";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

export class KratosLocalDocumentError extends Error {
  constructor(readonly code: string) { super(code); this.name = "KratosLocalDocumentError"; }
}
function fail(code: string): never { throw new KratosLocalDocumentError(code); }
export const LOCAL_OBJECT_KEY = /^local\/[a-f0-9]{32}\.bin$/;
export type LocalFile = { id: number; customer_id: number | null; folder_id: number | null; file_name: string; object_key: string; size_bytes: number; mime_type: string; sha256: string; import_state: string };
export type LocalSource = { driveId: string; itemId: string; version: string; path: string; sha256: string; createdAt?: string; modifiedAt?: string };
export type LocalDocumentOptions = {
  databasePath: string; root: string;
  /** Trusted authenticated configuration, not values accepted in individual requests. */
  ownerSubject: string; allowedOwnerSubjects: readonly string[]; actorId: string;
  allowedCustomerIds: readonly number[]; allowUnassigned?: boolean;
  /** Operator attestation only; this does not claim programmatic Windows ACL verification. */
  privateRootConfirmed: boolean;
};

/** Reject symlinks/junctions in every existing path component. Local ACLs must prevent replacement races. */
export async function assertKratosLocalPath(target: string, kind: "file" | "directory"): Promise<void> {
  if (typeof target !== "string" || !path.isAbsolute(target) || target.startsWith("\\\\") || target.includes("\0")) fail("invalid_local_path");
  const resolved = path.resolve(target);
  let current = path.parse(resolved).root;
  const pieces = resolved.slice(current.length).split(path.sep).filter(Boolean);
  if (!pieces.length && kind === "file") fail("unsafe_local_path");
  for (let index = 0; index < pieces.length; index++) {
    current = path.join(current, pieces[index]);
    const stat = await lstat(current).catch(() => fail("local_path_unavailable"));
    if (stat.isSymbolicLink() || (index < pieces.length - 1 && !stat.isDirectory())) fail("unsafe_local_path");
    if (index === pieces.length - 1 && (kind === "directory" ? !stat.isDirectory() : !stat.isFile() || stat.nlink !== 1)) fail("unsafe_local_path");
  }
}

export function localObjectPath(root: string, key: string): string {
  if (!LOCAL_OBJECT_KEY.test(key)) fail("invalid_object_key");
  const target = path.resolve(root, ...key.split("/"));
  if (!target.startsWith(path.resolve(root) + path.sep)) fail("invalid_object_key");
  return target;
}

export async function hashKratosLocalFile(file: string, maxBytes = Infinity, assertActive?: () => void): Promise<{ sha256: string; size: number }> {
  assertActive?.();
  await assertKratosLocalPath(file, "file");
  const handle = await open(file, "r");
  try {
    const before = await handle.stat();
    if (!before.isFile() || before.nlink !== 1 || before.size > maxBytes) fail("unsafe_local_path");
    const hash = createHash("sha256"); let size = 0;
    const chunk = Buffer.allocUnsafe(1024 * 1024);
    for (;;) {
      assertActive?.();
      const { bytesRead } = await handle.read(chunk, 0, Math.min(chunk.length, maxBytes - size + 1), size);
      if (!bytesRead) break;
      size += bytesRead;
      if (size > maxBytes) fail("object_changed");
      hash.update(chunk.subarray(0, bytesRead));
    }
    const after = await handle.stat();
    if (size !== before.size || after.size !== before.size || after.mtimeMs !== before.mtimeMs) fail("object_changed");
    return { sha256: hash.digest("hex"), size };
  } finally { await handle.close(); }
}

function name(value: unknown): asserts value is string {
  if (typeof value !== "string" || !value.trim() || value.length > 255 || /[\\/\u0000-\u001f\u007f]/.test(value) || value === "." || value === "..") fail("invalid_name");
}
function sourceMetadata(source?: LocalSource): void {
  if (!source) return;
  for (const value of [source.driveId, source.itemId, source.version]) if (typeof value !== "string" || !value || value.length > 500) fail("invalid_source");
  if (!/^[a-f0-9]{64}$/.test(source.sha256) || typeof source.path !== "string" || !source.path || source.path.length > 1500 || source.path.includes("\\") || source.path.split("/").some((part) => !part || part === "." || part === ".." || /[\u0000-\u001f\u007f]/.test(part))) fail("invalid_source");
  for (const value of [source.createdAt, source.modifiedAt]) if (value !== undefined && (typeof value !== "string" || !Number.isFinite(Date.parse(value)))) fail("invalid_source");
}

/** Local binary backend using the existing Kratos metadata schema. No migration, seed or delete API. */
export class KratosLocalDocumentStore {
  private constructor(private readonly options: LocalDocumentOptions, private readonly database: DatabaseSync) {}
  static async open(options: LocalDocumentOptions): Promise<KratosLocalDocumentStore> {
    if (!options || options.privateRootConfirmed !== true || typeof options.ownerSubject !== "string" || !options.ownerSubject || !Array.isArray(options.allowedOwnerSubjects) || !options.allowedOwnerSubjects.includes(options.ownerSubject) || typeof options.actorId !== "string" || !options.actorId || !Array.isArray(options.allowedCustomerIds) || options.allowedCustomerIds.some((id) => !Number.isSafeInteger(id) || id < 1)) fail("storage_access_denied");
    await assertKratosLocalPath(options.root, "directory");
    await assertKratosLocalPath(options.databasePath, "file");
    const root = path.resolve(options.root);
    try { await mkdir(path.join(root, "local"), { mode: 0o700 }); } catch (error) { if ((error as NodeJS.ErrnoException).code !== "EEXIST") fail("storage_unavailable"); }
    await assertKratosLocalPath(path.join(root, "local"), "directory");
    const database = new DatabaseSync(options.databasePath);
    try {
      database.exec("PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000");
      database.prepare("SELECT id,source_sha256,source_created_at,source_modified_at FROM storage_files LIMIT 0").all();
      database.prepare("SELECT id FROM storage_folders LIMIT 0").all();
      database.prepare("SELECT id FROM storage_audit_events LIMIT 0").all();
      return new KratosLocalDocumentStore({ ...options, root, allowedCustomerIds: [...options.allowedCustomerIds], allowedOwnerSubjects: [...options.allowedOwnerSubjects] }, database);
    } catch { database.close(); fail("storage_schema_unavailable"); }
  }
  close(): void { this.database.close(); }
  private customer(id: number | null): void {
    if (id === null) { if (this.options.allowUnassigned !== true) fail("storage_access_denied"); return; }
    if (!Number.isSafeInteger(id) || id < 1 || !this.options.allowedCustomerIds.includes(id)) fail("storage_access_denied");
    if (!this.database.prepare("SELECT id FROM customers WHERE id=?").get(id)) fail("customer_unavailable");
  }
  private folder(customerId: number | null, folderId: number | null): void {
    this.customer(customerId);
    if (folderId === null) return;
    if (!Number.isSafeInteger(folderId) || folderId < 1) fail("invalid_folder");
    const visited = new Set<number>(); let current: number | null = folderId;
    while (current !== null) {
      if (!Number.isSafeInteger(current) || visited.has(current) || visited.size >= 1000) fail("invalid_folder_hierarchy");
      visited.add(current);
      const row = this.database.prepare("SELECT customer_id,parent_folder_id FROM storage_folders WHERE id=?").get(current);
      if (!row || row.customer_id !== customerId) fail("folder_customer_mismatch");
      current = row.parent_folder_id as number | null;
    }
  }
  private audit(action: string, fileId: number | null, folderId: number | null): void {
    this.database.prepare("INSERT INTO storage_audit_events(file_id,folder_id,action,actor_email) VALUES (?,?,?,?)").run(fileId, folderId, action, this.options.actorId);
  }
  async importIdentity(): Promise<string> {
    const locations = [[this.options.databasePath, "file"], [path.join(this.options.root, "local"), "directory"]] as const;
    const identity = [];
    for (const [location, kind] of locations) {
      await assertKratosLocalPath(location, kind);
      const canonical = await realpath(location);
      const info = await lstat(canonical, { bigint: true });
      identity.push([process.platform === "win32" ? canonical.toLowerCase() : canonical, String(info.dev), String(info.ino), String(info.birthtimeNs)]);
    }
    return createHash("sha256").update(JSON.stringify(identity)).digest("hex");
  }

  resolveImportFolder(customerId: number, baseFolderId: number, segments: string[], create = false): number | null {
    if (!Number.isSafeInteger(baseFolderId) || baseFolderId < 1) fail("invalid_folder");
    this.folder(customerId, baseFolderId);
    let parent = baseFolderId;
    for (const segment of segments) {
      name(segment);
      if (create) {
        parent = this.createFolder(customerId, segment, parent);
      } else {
        const row = this.database.prepare("SELECT id FROM storage_folders WHERE customer_id=? AND parent_folder_id=? AND name=? LIMIT 2").all(customerId, parent, segment);
        if (row.length !== 1) return null;
        parent = Number(row[0].id);
      }
    }
    return parent;
  }

  async verifyImportedFile(fileId: number, customerId: number, folderId: number, fileName: string, source: LocalSource, expectedSize: number): Promise<LocalFile | null> {
    this.folder(customerId, folderId);
    sourceMetadata(source);
    const row = this.database.prepare("SELECT * FROM storage_files WHERE id=? AND customer_id=? AND folder_id=? AND file_name=? AND source_drive_id=? AND source_item_id=? AND source_version=? AND source_path=? AND source_sha256=? AND size_bytes=? AND sha256=? AND import_state='stored'")
      .get(fileId, customerId, folderId, fileName, source.driveId, source.itemId, source.version, source.path, source.sha256, expectedSize, source.sha256);
    if (!row) return null;
    const file = { ...row } as LocalFile;
    const hash = await hashKratosLocalFile(localObjectPath(this.options.root, file.object_key));
    return hash.size === expectedSize && hash.sha256 === source.sha256 ? file : null;
  }
  createFolder(customerId: number | null, folderName: string, parentFolderId: number | null = null): number {
    name(folderName); this.folder(customerId, parentFolderId);
    const parent = parentFolderId === null ? null : this.database.prepare("SELECT path_key FROM storage_folders WHERE id=?").get(parentFolderId);
    const pathKey = parent ? `${parent.path_key}/${folderName}` : folderName;
    if (pathKey.length > 1500) fail("invalid_folder");
    const scopeKey = customerId === null ? "unassigned" : `customer:${customerId}`;
    const existing = this.database.prepare("SELECT id,parent_folder_id,customer_id,name FROM storage_folders WHERE scope_key=? AND path_key=?").get(scopeKey, pathKey);
    if (existing) { if (existing.customer_id !== customerId || existing.parent_folder_id !== parentFolderId || existing.name !== folderName) fail("folder_conflict"); return Number(existing.id); }
    this.database.exec("BEGIN IMMEDIATE");
    try {
      const result = this.database.prepare("INSERT INTO storage_folders(customer_id,parent_folder_id,scope_key,path_key,name,created_by) VALUES (?,?,?,?,?,?)").run(customerId, parentFolderId, scopeKey, pathKey, folderName, this.options.actorId);
      const id = Number(result.lastInsertRowid); this.audit("local_folder_created", null, id); this.database.exec("COMMIT"); return id;
    } catch { this.database.exec("ROLLBACK"); fail("folder_conflict"); }
  }
  list(customerId: number | null, options: { folderId?: number | null; query?: string; limit?: number; offset?: number } = {}): LocalFile[] {
    this.customer(customerId);
    const limit = options.limit ?? 25, offset = options.offset ?? 0;
    if (!Number.isInteger(limit) || limit < 1 || limit > 100 || !Number.isInteger(offset) || offset < 0 || offset > 100000 || (options.query !== undefined && (typeof options.query !== "string" || options.query.length > 255))) fail("invalid_list");
    if (options.folderId !== undefined) this.folder(customerId, options.folderId);
    const rows = this.database.prepare("SELECT id,customer_id,folder_id,file_name,object_key,size_bytes,mime_type,sha256,import_state FROM storage_files WHERE customer_id IS ? AND import_state='stored' AND object_key GLOB 'local/*' AND (?=0 OR folder_id IS ?) AND instr(lower(file_name),lower(?))>0 ORDER BY id LIMIT ? OFFSET ?").all(customerId, options.folderId === undefined ? 0 : 1, options.folderId ?? null, options.query ?? "", limit, offset);
    return rows.map((row) => ({ ...row }) as LocalFile);
  }
  async upload(input: { customerId: number | null; folderId?: number | null; fileName: string; mimeType?: string; expectedSize: number; expectedSha256?: string; source?: LocalSource }, bytes: AsyncIterable<Uint8Array>, assertActive?: () => void): Promise<{ file: LocalFile; duplicate: boolean }> {
    assertActive?.();
    this.folder(input.customerId, input.folderId ?? null); name(input.fileName); sourceMetadata(input.source);
    if (!Number.isSafeInteger(input.expectedSize) || input.expectedSize < 0 || (input.expectedSha256 !== undefined && !/^[a-f0-9]{64}$/.test(input.expectedSha256)) || !bytes || typeof bytes[Symbol.asyncIterator] !== "function") fail("invalid_upload");
    const mime = input.mimeType ?? "application/octet-stream";
    if (typeof mime !== "string" || mime.length > 255 || !/^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/i.test(mime)) fail("invalid_mime");
    const source = input.source;
    const prior = source && this.database.prepare("SELECT * FROM storage_files WHERE source_drive_id=? AND source_item_id=? AND source_version=?").get(source.driveId, source.itemId, source.version);
    if (prior) {
      if (prior.customer_id !== input.customerId || prior.folder_id !== (input.folderId ?? null) || prior.file_name !== input.fileName || prior.mime_type !== mime || prior.size_bytes !== input.expectedSize || prior.sha256 !== source!.sha256 || prior.source_path !== source!.path || prior.source_created_at !== (source!.createdAt ?? null) || prior.source_modified_at !== (source!.modifiedAt ?? null) || prior.import_state !== "stored" || !LOCAL_OBJECT_KEY.test(String(prior.object_key))) fail("source_conflict");
      const incoming = createHash("sha256"); let length = 0;
      for await (const chunk of bytes) { if (!(chunk instanceof Uint8Array) || length + chunk.byteLength > input.expectedSize) fail("size_mismatch"); incoming.update(chunk); length += chunk.byteLength; }
      const checksum = incoming.digest("hex");
      if (length !== input.expectedSize || checksum !== prior.sha256 || (input.expectedSha256 && checksum !== input.expectedSha256)) fail("integrity_mismatch");
      const existing = await hashKratosLocalFile(localObjectPath(this.options.root, String(prior.object_key)), input.expectedSize, assertActive);
      if (existing.sha256 !== checksum || existing.size !== length) fail("integrity_mismatch");
      return { file: { ...prior } as LocalFile, duplicate: true };
    }
    await assertKratosLocalPath(path.join(this.options.root, "local"), "directory");
    const key = `local/${randomUUID().replaceAll("-", "")}.bin`, target = localObjectPath(this.options.root, key);
    assertActive?.();
    const file = await open(target, "wx", 0o600);
    let retained = false;
    try {
      const result = await this.writeUpload(input, bytes, file, key, target, assertActive);
      retained = !result.duplicate;
      return result;
    } finally {
      if (!retained && assertActive) await unlink(target).catch(() => {});
    }
  }
  private async writeUpload(input: Parameters<KratosLocalDocumentStore["upload"]>[0], bytes: AsyncIterable<Uint8Array>, file: Awaited<ReturnType<typeof open>>, key: string, target: string, assertActive?: () => void): Promise<{ file: LocalFile; duplicate: boolean }> {
    const mime = input.mimeType ?? "application/octet-stream";
    let size = 0; const hash = createHash("sha256");
    try {
      for await (const chunk of bytes) {
        assertActive?.();
        if (!(chunk instanceof Uint8Array) || size + chunk.byteLength > input.expectedSize) fail("size_mismatch");
        let written = 0;
        while (written < chunk.byteLength) { const result = await file.write(chunk, written, chunk.byteLength - written); if (!result.bytesWritten) fail("write_failed"); written += result.bytesWritten; }
        hash.update(chunk); size += chunk.byteLength;
      }
      await file.sync();
    } catch (error) { if (error instanceof KratosLocalDocumentError) throw error; fail("upload_failed"); }
    finally { await file.close(); }
    const sha256 = hash.digest("hex");
    if (size !== input.expectedSize || (input.expectedSha256 && input.expectedSha256 !== sha256) || (input.source && input.source.sha256 !== sha256)) fail("integrity_mismatch");
    const verified = await hashKratosLocalFile(target, size, assertActive);
    if (verified.sha256 !== sha256 || verified.size !== size) fail("integrity_mismatch");
    assertActive?.();
    this.database.exec("BEGIN IMMEDIATE");
    let result: { file: LocalFile; duplicate: boolean };
    try {
      this.folder(input.customerId, input.folderId ?? null);
      const source = input.source;
      const previous = source && this.database.prepare("SELECT * FROM storage_files WHERE source_drive_id=? AND source_item_id=? AND source_version=?").get(source.driveId, source.itemId, source.version);
      if (previous) {
        if (previous.customer_id !== input.customerId || previous.folder_id !== (input.folderId ?? null) || previous.file_name !== input.fileName || previous.mime_type !== mime || previous.size_bytes !== size || previous.sha256 !== sha256 || previous.source_path !== source!.path || previous.source_created_at !== (source!.createdAt ?? null) || previous.source_modified_at !== (source!.modifiedAt ?? null) || previous.import_state !== "stored" || !LOCAL_OBJECT_KEY.test(String(previous.object_key))) fail("source_conflict");
        result = { file: { ...previous } as LocalFile, duplicate: true };
      } else {
        const inserted = this.database.prepare("INSERT INTO storage_files(customer_id,folder_id,file_name,object_key,size_bytes,mime_type,sha256,source_sha256,source_drive_id,source_item_id,source_version,source_path,source_created_at,source_modified_at,import_state,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'stored',?)").run(input.customerId, input.folderId ?? null, input.fileName, key, size, mime, sha256, source?.sha256 ?? null, source?.driveId ?? null, source?.itemId ?? null, source?.version ?? null, source?.path ?? null, source?.createdAt ?? null, source?.modifiedAt ?? null, this.options.actorId);
        const id = Number(inserted.lastInsertRowid); this.audit("local_upload_verified", id, input.folderId ?? null);
        result = { file: { ...this.database.prepare("SELECT * FROM storage_files WHERE id=?").get(id) } as LocalFile, duplicate: false };
      }
      assertActive?.();
      this.database.exec("COMMIT");
    } catch (error) { this.database.exec("ROLLBACK"); if (error instanceof KratosLocalDocumentError) throw error; assertActive?.(); fail("metadata_failed"); }
    // A retry is only successful if the original immutable target still matches, not merely its metadata.
    if (result.duplicate) {
      const previous = await hashKratosLocalFile(localObjectPath(this.options.root, result.file.object_key), size, assertActive);
      if (previous.sha256 !== sha256 || previous.size !== size) fail("integrity_mismatch");
    }
    return result;
  }
  async read(fileId: number): Promise<{ file: LocalFile; bytes: AsyncGenerator<Uint8Array> }> {
    if (!Number.isSafeInteger(fileId) || fileId < 1) fail("invalid_file_id");
    const row = this.database.prepare("SELECT * FROM storage_files WHERE id=? AND import_state='stored'").get(fileId);
    if (!row) fail("file_unavailable");
    this.folder(row.customer_id as number | null, row.folder_id as number | null);
    const metadata = { ...row } as LocalFile;
    const target = localObjectPath(this.options.root, metadata.object_key);
    const verified = await hashKratosLocalFile(target);
    if (verified.size !== metadata.size_bytes || verified.sha256 !== metadata.sha256) fail("integrity_mismatch");
    this.audit("local_download_verified", fileId, metadata.folder_id);
    async function* stream() {
      await assertKratosLocalPath(target, "file"); const handle = await open(target, "r");
      try {
        const hash = createHash("sha256"); let position = 0;
        for (;;) { const chunk = Buffer.allocUnsafe(1024 * 1024); const part = await handle.read(chunk, 0, chunk.length, position); if (!part.bytesRead) break; const value = chunk.subarray(0, part.bytesRead); position += part.bytesRead; hash.update(value); yield value; }
        if (position !== metadata.size_bytes || hash.digest("hex") !== metadata.sha256) fail("integrity_mismatch");
      } finally { await handle.close(); }
    }
    return { file: metadata, bytes: stream() };
  }
}
