import { createHash } from "node:crypto";

export const MAX_SINGLE_UPLOAD_BYTES = 20 * 1024 * 1024;
export const STORAGE_PART_SIZE_BYTES = 20 * 1024 * 1024;
export const MIN_MULTIPART_PART_BYTES = 5 * 1024 * 1024;
export const MAX_MULTIPART_PARTS = 10_000;
export const MAX_MULTIPART_UPLOAD_BYTES = STORAGE_PART_SIZE_BYTES * MAX_MULTIPART_PARTS;

export function hasSameOrigin(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (!origin || origin === "null") return false;
  try { return new URL(origin).origin === new URL(request.url).origin; }
  catch { return false; }
}

export type StorageFileFilters = {
  customerId?: number | null;
  folderId?: number | null;
  query?: string;
  limit?: number;
  offset?: number;
};

export type StoredFileMetadata = {
  id: number;
  customer_id: number | null;
  folder_id: number | null;
  file_name: string;
  size_bytes: number;
  mime_type: string;
  sha256: string | null;
  source_path: string | null;
  import_state: string;
  created_at: string;
};

export type StorageUploadMetadata = {
  customerId?: number | null;
  folderId?: number | null;
  sourceDriveId?: string | null;
  sourceItemId?: string | null;
  sourceVersion?: string | null;
  sourcePath?: string | null;
  sourceCreatedAt?: string | null;
  sourceModifiedAt?: string | null;
  sourceSha256?: string | null;
};

export type StoredFileResult = {
  file_id: number;
  import_state: string;
  size_bytes: number;
  sha256: string | null;
  duplicate: boolean;
};

export class StorageConflictError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "StorageConflictError";
  }
}

export function safeFileName(value: string): string | null {
  if (!value || value.trim().length === 0 || value.length > 255 || /[\\/\u0000-\u001f\u007f]/.test(value) || value === "." || value === "..") return null;
  return value;
}

export function safeSourcePath(value: string | null | undefined): string | null | undefined {
  if (value === undefined || value === null || value.trim() === "") return value;
  const segments = value.split("/");
  if (value.length > 1500 || value.startsWith("/") || value.endsWith("/") || value.includes("\\") || segments.some((part) => !part || part === "." || part === ".." || /[\u0000-\u001f\u007f]/.test(part))) return undefined;
  return value;
}

export function validMimeType(value: string): string {
  const type = value.trim().toLowerCase();
  return /^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/.test(type) ? type.slice(0, 255) : "application/octet-stream";
}

export function validateSourceIdentity(metadata: StorageUploadMetadata): string | null {
  const hasAny = Boolean(metadata.sourceDriveId || metadata.sourceItemId || metadata.sourceVersion);
  const hasAll = Boolean(metadata.sourceDriveId && metadata.sourceItemId && metadata.sourceVersion);
  if (hasAny && !hasAll) return "Quellversion benötigt drive_id, item_id und version gemeinsam.";
  if (hasAll && !metadata.sourceSha256) return "Quellversion benötigt einen vorab berechneten source_sha256.";
  for (const value of [metadata.sourceDriveId, metadata.sourceItemId, metadata.sourceVersion]) {
    if (value && value.length > 500) return "Quellmetadaten überschreiten die zulässige Länge.";
  }
  if (metadata.sourcePath !== undefined && metadata.sourcePath !== null && safeSourcePath(metadata.sourcePath) === undefined) return "Quellpfad muss relativ sein und darf keine Aufwärtssegmente enthalten.";
  if (metadata.sourceSha256 && !/^[a-f0-9]{64}$/i.test(metadata.sourceSha256)) return "Quell-SHA-256 muss aus 64 Hex-Zeichen bestehen.";
  for (const value of [metadata.sourceCreatedAt, metadata.sourceModifiedAt]) {
    if (value && (value.length > 50 || !Number.isFinite(Date.parse(value)))) return "Quellzeitstempel muss ein gültiger ISO-Zeitpunkt sein.";
  }
  return null;
}

export async function listStoredFiles(db: D1Database, filters: StorageFileFilters = {}) {
  const limit = filters.limit ?? 25;
  const offset = filters.offset ?? 0;
  if (!Number.isInteger(limit) || limit < 1 || limit > 100 || !Number.isInteger(offset) || offset < 0 || offset > 100_000) throw new Error("Ungültige Dateiliste-Paginierung.");

  const clauses: string[] = [];
  const bindings: (string | number)[] = [];
  if (Object.hasOwn(filters, "customerId")) {
    if (filters.customerId === null) clauses.push("customer_id IS NULL");
    else { clauses.push("customer_id=?"); bindings.push(Number(filters.customerId)); }
  }
  if (Object.hasOwn(filters, "folderId")) {
    if (filters.folderId === null) clauses.push("folder_id IS NULL");
    else { clauses.push("folder_id=?"); bindings.push(Number(filters.folderId)); }
  }
  const query = filters.query?.trim() ?? "";
  if (query) {
    const like = "%" + query.replace(/[\\%_]/g, "\\$&") + "%";
    clauses.push("(file_name LIKE ? ESCAPE '\\' OR source_path LIKE ? ESCAPE '\\')");
    bindings.push(like, like);
  }
  const where = clauses.length ? " WHERE " + clauses.join(" AND ") : "";
  const count = await db.prepare("SELECT count(*) AS total FROM storage_files" + where).bind(...bindings).first<{ total: number }>();
  const rows = await db.prepare("SELECT id,customer_id,folder_id,file_name,size_bytes,mime_type,sha256,source_path,import_state,created_at FROM storage_files" + where + " ORDER BY created_at DESC,id DESC LIMIT ? OFFSET ?")
    .bind(...bindings, limit, offset).all<StoredFileMetadata>();
  const total = count?.total ?? 0;
  const hasMore = offset + rows.results.length < total;
  return {
    files: rows.results,
    total_count: total,
    offset,
    has_more: hasMore,
    next_offset: hasMore ? offset + rows.results.length : null,
  };
}

export async function getStoredFileMetadata(db: D1Database, id: number): Promise<StoredFileMetadata | null> {
  if (!Number.isInteger(id) || id < 1) return null;
  return await db.prepare("SELECT id,customer_id,folder_id,file_name,size_bytes,mime_type,sha256,source_path,import_state,created_at FROM storage_files WHERE id=?")
    .bind(id).first<StoredFileMetadata>();
}

export async function getStoredFileObjectKey(db: D1Database, id: number): Promise<string | null> {
  if (!Number.isInteger(id) || id < 1) return null;
  const row = await db.prepare("SELECT object_key FROM storage_files WHERE id=? AND import_state IN ('stored','unresolved')").bind(id).first<{ object_key: string }>();
  return row?.object_key ?? null;
}

export async function listStorageFolders(db: D1Database, filters: { customerId?: number | null; parentFolderId?: number | null; query?: string; limit?: number; offset?: number } = {}) {
  const limit = filters.limit ?? 50;
  const offset = filters.offset ?? 0;
  if (!Number.isInteger(limit) || limit < 1 || limit > 100 || !Number.isInteger(offset) || offset < 0 || offset > 100_000) throw new Error("Ungültige Ordnerlisten-Paginierung.");
  const clauses: string[] = [];
  const bindings: (string | number)[] = [];
  if (Object.hasOwn(filters, "customerId")) {
    if (filters.customerId === null) clauses.push("customer_id IS NULL");
    else { clauses.push("customer_id=?"); bindings.push(Number(filters.customerId)); }
  }
  if (Object.hasOwn(filters, "parentFolderId")) {
    if (filters.parentFolderId === null) clauses.push("parent_folder_id IS NULL");
    else { clauses.push("parent_folder_id=?"); bindings.push(Number(filters.parentFolderId)); }
  }
  const query = filters.query?.trim() ?? "";
  if (query) { clauses.push("name LIKE ? ESCAPE '\\'"); bindings.push("%" + query.replace(/[\\%_]/g, "\\$&") + "%"); }
  const where = clauses.length ? " WHERE " + clauses.join(" AND ") : "";
  const count = await db.prepare("SELECT count(*) AS total FROM storage_folders" + where).bind(...bindings).first<{ total: number }>();
  const rows = await db.prepare("SELECT id,name,parent_folder_id,customer_id,created_at FROM storage_folders" + where + " ORDER BY name COLLATE NOCASE,id LIMIT ? OFFSET ?")
    .bind(...bindings, limit, offset).all();
  const total = count?.total ?? 0;
  const hasMore = offset + rows.results.length < total;
  return { folders: rows.results, total_count: total, offset, has_more: hasMore, next_offset: hasMore ? offset + rows.results.length : null };
}

export async function createStorageFolder(db: D1Database, args: { name: unknown; customerId?: unknown; parentFolderId?: unknown }, actor: string) {
  const name = typeof args.name === "string" ? args.name : "";
  if (!name || name.trim().length === 0 || name.length > 200 || /[\\/\\\u0000-\u001f\u007f]/.test(name) || name === "." || name === "..") return { error: "Ungültiger Ordnername." } as const;
  let customerId: number | null = args.customerId === undefined || args.customerId === null ? null : Number(args.customerId);
  if (customerId !== null && (!Number.isInteger(customerId) || customerId < 1)) return { error: "Ungültige Kunden-ID." } as const;
  const parentId = args.parentFolderId === undefined || args.parentFolderId === null ? null : Number(args.parentFolderId);
  if (parentId !== null && (!Number.isInteger(parentId) || parentId < 1)) return { error: "Ungültige übergeordnete Ordner-ID." } as const;
  if (customerId !== null) {
    const customer = await db.prepare("SELECT id FROM customers WHERE id=?").bind(customerId).first();
    if (!customer) return { error: "Kunde nicht gefunden." } as const;
  }
  let parentPath = "";
  let scopeKey = customerId === null ? "unresolved" : "customer:" + customerId;
  if (parentId !== null) {
    const parent = await db.prepare("SELECT id,customer_id,scope_key,path_key FROM storage_folders WHERE id=?").bind(parentId).first<{ id: number; customer_id: number | null; scope_key: string; path_key: string }>();
    if (!parent) return { error: "Übergeordneter Ordner nicht gefunden." } as const;
    if (customerId !== null && customerId !== parent.customer_id) return { error: "Ordner und Kunde gehören zu unterschiedlichen Ablagebereichen." } as const;
    customerId = parent.customer_id;
    scopeKey = parent.scope_key;
    parentPath = parent.path_key;
  }
  const normalizedName = name.normalize("NFC").toLocaleLowerCase("de-DE");
  const pathKey = parentPath ? parentPath + "/" + normalizedName : normalizedName;
  const now = new Date().toISOString();
  const created = await db.prepare("INSERT INTO storage_folders (customer_id,parent_folder_id,scope_key,path_key,name,created_at,created_by) VALUES (?,?,?,?,?,?,?) ON CONFLICT(scope_key,path_key) DO NOTHING")
    .bind(customerId, parentId, scopeKey, pathKey, name, now, actor).run();
  const folder = await db.prepare("SELECT id,name,parent_folder_id,customer_id,created_at FROM storage_folders WHERE scope_key=? AND path_key=?").bind(scopeKey, pathKey).first();
  if (folder && created.meta.changes > 0) await recordStorageAudit(db, { folderId: Number(folder.id), action: "folder_create", actor });
  if (folder && created.meta.changes === 0 && folder.name !== name) return { error: "Ordnername kollidiert nach Unicode-/Großschreibungs-Normalisierung mit einem vorhandenen Ordner." } as const;
  return folder ? { folder, created: created.meta.changes > 0 } : { error: "Ordner konnte nicht angelegt werden." } as const;
}

async function resolveFileContext(db: D1Database, metadata: StorageUploadMetadata) {
  let customerId = metadata.customerId === undefined ? null : metadata.customerId;
  const folderId = metadata.folderId === undefined ? null : metadata.folderId;
  if (customerId !== null && (!Number.isInteger(customerId) || customerId < 1)) return { error: "Ungültige Kunden-ID." } as const;
  if (folderId !== null && (!Number.isInteger(folderId) || folderId < 1)) return { error: "Ungültige Ordner-ID." } as const;
  if (customerId !== null) {
    const customer = await db.prepare("SELECT id FROM customers WHERE id=?").bind(customerId).first();
    if (!customer) return { error: "Kunde nicht gefunden." } as const;
  }
  if (folderId !== null) {
    const folder = await db.prepare("SELECT id,customer_id FROM storage_folders WHERE id=?").bind(folderId).first<{ id: number; customer_id: number | null }>();
    if (!folder) return { error: "Ablageordner nicht gefunden." } as const;
    if (customerId !== null && customerId !== folder.customer_id) return { error: "Ordner und Kunde gehören zu unterschiedlichen Ablagebereichen." } as const;
    customerId = folder.customer_id;
  }
  return { customerId, folderId } as const;
}

async function findDuplicate(db: D1Database, metadata: StorageUploadMetadata) {
  if (!metadata.sourceDriveId || !metadata.sourceItemId || !metadata.sourceVersion) return null;
  return await db.prepare("SELECT id,object_key,file_name,size_bytes,sha256,source_sha256,source_path,import_state,customer_id,folder_id FROM storage_files WHERE source_drive_id=? AND source_item_id=? AND source_version=?")
    .bind(metadata.sourceDriveId, metadata.sourceItemId, metadata.sourceVersion).first<{ id: number; object_key: string; file_name: string; size_bytes: number; sha256: string | null; source_sha256: string | null; source_path: string | null; import_state: string; customer_id: number | null; folder_id: number | null }>();
}

export async function storeUploadedFile(db: D1Database, bucket: R2Bucket, file: File, metadata: StorageUploadMetadata, actor: string): Promise<StoredFileResult> {
  const fileName = safeFileName(file.name);
  if (!fileName) throw new Error("Ungültiger Dateiname.");
  if (!Number.isInteger(file.size) || file.size < 0 || file.size > MAX_SINGLE_UPLOAD_BYTES) throw new Error("Einzeluploads sind auf 20 MiB begrenzt.");
  const sourceError = validateSourceIdentity(metadata);
  if (sourceError) throw new Error(sourceError);
  const context = await resolveFileContext(db, metadata);
  if ("error" in context) throw new Error(context.error);
  const duplicate = await findDuplicate(db, metadata);
  if (duplicate) {
    const sameMetadata = duplicate.file_name === fileName &&
      duplicate.size_bytes === file.size &&
      duplicate.customer_id === context.customerId &&
      duplicate.folder_id === context.folderId &&
      duplicate.source_path === (safeSourcePath(metadata.sourcePath) ?? null) &&
      duplicate.source_sha256 === (metadata.sourceSha256?.toLowerCase() ?? null);
    if (!sameMetadata) throw new StorageConflictError("Diese Quellversion ist bereits mit abweichender Zuordnung, Dateigröße oder Prüfsumme registriert.");
    if (duplicate.import_state !== "stored" && duplicate.import_state !== "unresolved") throw new StorageConflictError("Diese Quellversion hat einen unvollständigen oder fehlgeschlagenen Import; Status zuerst prüfen.");
    return { file_id: duplicate.id, import_state: duplicate.import_state, size_bytes: duplicate.size_bytes, sha256: duplicate.sha256, duplicate: true };
  }

  const objectKey = "kratos/private/" + crypto.randomUUID();
  const now = new Date().toISOString();
  let insert: D1Result[];
  try {
    insert = await db.batch([
      db.prepare("INSERT INTO storage_files (customer_id,folder_id,file_name,object_key,size_bytes,mime_type,sha256,source_sha256,source_drive_id,source_item_id,source_version,source_path,source_created_at,source_modified_at,import_state,created_at,created_by,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .bind(context.customerId, context.folderId, fileName, objectKey, file.size, validMimeType(file.type), null, metadata.sourceSha256?.toLowerCase() ?? null, metadata.sourceDriveId ?? null, metadata.sourceItemId ?? null, metadata.sourceVersion ?? null, safeSourcePath(metadata.sourcePath) ?? null, metadata.sourceCreatedAt ?? null, metadata.sourceModifiedAt ?? null, "pending", now, actor, now),
      db.prepare("INSERT INTO storage_audit_events (file_id,action,actor_email) SELECT last_insert_rowid(),'upload_started',?").bind(actor),
    ]);
  } catch {
    const racedDuplicate = await findDuplicate(db, metadata);
    if (racedDuplicate) {
      const sameMetadata = racedDuplicate.file_name === fileName &&
        racedDuplicate.size_bytes === file.size &&
        racedDuplicate.customer_id === context.customerId &&
        racedDuplicate.folder_id === context.folderId &&
        racedDuplicate.source_path === (safeSourcePath(metadata.sourcePath) ?? null) &&
        racedDuplicate.source_sha256 === (metadata.sourceSha256?.toLowerCase() ?? null);
      if (!sameMetadata) throw new StorageConflictError("Diese Quellversion ist bereits mit abweichender Zuordnung, Dateigröße oder Prüfsumme registriert.");
      if (racedDuplicate.import_state !== "stored" && racedDuplicate.import_state !== "unresolved") throw new StorageConflictError("Diese Quellversion hat einen unvollständigen oder fehlgeschlagenen Import; Status zuerst prüfen.");
      return { file_id: racedDuplicate.id, import_state: racedDuplicate.import_state, size_bytes: racedDuplicate.size_bytes, sha256: racedDuplicate.sha256, duplicate: true };
    }
    throw new Error("Dateimetadaten konnten nicht angelegt werden.");
  }
  const fileId = Number(insert[0].meta.last_row_id);
  const hash = createHash("sha256");
  let sizeBytes = 0;
  const body = file.stream().pipeThrough(new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) {
      sizeBytes += chunk.byteLength;
      if (sizeBytes > MAX_SINGLE_UPLOAD_BYTES) throw new Error("Einzeluploads sind auf 20 MiB begrenzt.");
      hash.update(chunk);
      controller.enqueue(chunk);
    },
  }));
  try {
    const fixed = new FixedLengthStream(file.size);
    const streaming = body.pipeTo(fixed.writable);
    await bucket.put(objectKey, fixed.readable, {
      httpMetadata: { contentType: "application/octet-stream", cacheControl: "private, no-store" },
      customMetadata: { fileId: String(fileId) },
    });
    await streaming;
    if (sizeBytes !== file.size) throw new Error("Dateigröße stimmt nach dem Upload nicht überein.");
    const incomingSha256 = hash.digest("hex");
    if (metadata.sourceSha256 && metadata.sourceSha256.toLowerCase() !== incomingSha256) throw new Error("Dateiinhalt stimmt nicht mit dem Quell-SHA-256 überein.");
    const storedObject = await bucket.get(objectKey);
    if (!storedObject || !("body" in storedObject) || !storedObject.body) throw new Error("Gespeichertes Objekt konnte nicht unabhängig gelesen werden.");
    const targetHash = await hashReadableStream(storedObject.body, MAX_SINGLE_UPLOAD_BYTES);
    if (targetHash.sizeBytes !== sizeBytes || targetHash.sha256 !== incomingSha256) throw new Error("Gespeicherte Datei weicht vom Uploadinhalt ab.");
    const sha256 = targetHash.sha256;
    const importState = context.customerId === null ? "unresolved" : "stored";
    await db.batch([
      db.prepare("UPDATE storage_files SET sha256=?,source_sha256=?,import_state=?,updated_at=? WHERE id=?").bind(sha256, metadata.sourceSha256?.toLowerCase() ?? incomingSha256, importState, new Date().toISOString(), fileId),
      db.prepare("INSERT INTO storage_audit_events (file_id,action,actor_email) VALUES (?,?,?)").bind(fileId, "file_verified", actor),
    ]);
    return { file_id: fileId, import_state: importState, size_bytes: sizeBytes, sha256, duplicate: false };
  } catch {
    await db.batch([
      db.prepare("UPDATE storage_files SET import_state='failed',updated_at=? WHERE id=?").bind(new Date().toISOString(), fileId),
      db.prepare("INSERT INTO storage_audit_events (file_id,action,actor_email) VALUES (?,?,?)").bind(fileId, "upload_failed", actor),
    ]).catch(() => undefined);
    throw new Error("Datei konnte nicht sicher gespeichert werden; Importstatus prüfen, bevor erneut hochgeladen wird.");
  }
}

export async function recordStorageAudit(db: D1Database, args: { fileId?: number | null; folderId?: number | null; action: string; actor: string }) {
  await db.prepare("INSERT INTO storage_audit_events (file_id,folder_id,action,actor_email) VALUES (?,?,?,?)")
    .bind(args.fileId ?? null, args.folderId ?? null, args.action, args.actor).run();
}

export async function hashReadableStream(stream: ReadableStream<Uint8Array>, maxBytes = Number.MAX_SAFE_INTEGER) {
  const hash = createHash("sha256");
  const reader = stream.getReader();
  let sizeBytes = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      sizeBytes += value.byteLength;
      if (sizeBytes > maxBytes) throw new Error("Stream überschreitet die erlaubte Größe.");
      hash.update(value);
    }
  } finally {
    reader.releaseLock();
  }
  return { sizeBytes, sha256: hash.digest("hex") };
}

export async function getStorageUploadSession(db: D1Database, id: string, ownerEmail: string) {
  const upload = await db.prepare("SELECT id,file_id,expected_size_bytes,status FROM storage_uploads WHERE id=? AND owner_email=?").bind(id, ownerEmail)
    .first<{ id: string; file_id: number; expected_size_bytes: number; status: string }>();
  if (!upload) return null;
  const parts = await db.prepare("SELECT part_number,etag,size_bytes,sha256 FROM storage_upload_parts WHERE upload_id=? ORDER BY part_number").bind(id).all<{ part_number: number; etag: string; size_bytes: number; sha256: string }>();
  const file = await getStoredFileMetadata(db, upload.file_id);
  return { upload_id: upload.id, file_id: upload.file_id, status: upload.status, expected_size_bytes: upload.expected_size_bytes, part_size_bytes: STORAGE_PART_SIZE_BYTES, max_parts: MAX_MULTIPART_PARTS, parts: parts.results, ...(file ? { file } : {}) };
}

export async function createStorageUploadSession(db: D1Database, bucket: R2Bucket, args: { fileName: string; mimeType: string; expectedSizeBytes: number; metadata: StorageUploadMetadata; actor: string }) {
  const fileName = safeFileName(args.fileName);
  if (!fileName) throw new Error("Ungültiger Dateiname.");
  if (!Number.isInteger(args.expectedSizeBytes) || args.expectedSizeBytes <= MAX_SINGLE_UPLOAD_BYTES || args.expectedSizeBytes > MAX_MULTIPART_UPLOAD_BYTES) throw new Error("Resumierbare Uploads benötigen mehr als 20 MiB und unterstützen höchstens 10.000 Teile zu je 20 MiB.");
  const sourceError = validateSourceIdentity(args.metadata);
  if (sourceError) throw new Error(sourceError);
  if (!args.metadata.sourceSha256) throw new Error("Resumierbare Uploads benötigen source_sha256 zur unabhängigen Zielprüfung.");
  const context = await resolveFileContext(db, args.metadata);
  if ("error" in context) throw new Error(context.error);
  const sourcePath = safeSourcePath(args.metadata.sourcePath) ?? null;
  const sourceSha256 = args.metadata.sourceSha256.toLowerCase();
  const existing = await findDuplicate(db, args.metadata);
  if (existing) {
    const same = existing.file_name === fileName && existing.size_bytes === args.expectedSizeBytes &&
      existing.customer_id === context.customerId && existing.folder_id === context.folderId &&
      existing.source_path === sourcePath && existing.source_sha256 === sourceSha256;
    if (!same) throw new StorageConflictError("Diese Quellversion ist bereits mit abweichender Zuordnung, Dateigröße oder Prüfsumme registriert.");
    if (existing.import_state === "stored" || existing.import_state === "unresolved") return { file_id: existing.id, import_state: existing.import_state, size_bytes: existing.size_bytes, sha256: existing.sha256, duplicate: true, upload_id: null };
    const active = await db.prepare("SELECT id,owner_email,status FROM storage_uploads WHERE file_id=? ORDER BY created_at DESC LIMIT 1").bind(existing.id)
      .first<{ id: string; owner_email: string; status: string }>();
    if (active?.status === "uploading" && active.owner_email === args.actor) return { file_id: existing.id, import_state: existing.import_state, size_bytes: existing.size_bytes, sha256: existing.sha256, duplicate: true, upload_id: active.id, resumed: true };
    throw new StorageConflictError("Diese Quellversion hat einen unvollständigen oder fehlgeschlagenen Import; Status zuerst prüfen.");
  }
  const uploadId = crypto.randomUUID();
  const objectKey = "kratos/private/" + crypto.randomUUID();
  const now = new Date().toISOString();
  const multipart = await bucket.createMultipartUpload(objectKey, {
    httpMetadata: { contentType: "application/octet-stream", cacheControl: "private, no-store" },
    customMetadata: { uploadId },
  });
  try {
    await db.batch([
      db.prepare("INSERT INTO storage_files (customer_id,folder_id,file_name,object_key,size_bytes,mime_type,sha256,source_sha256,source_drive_id,source_item_id,source_version,source_path,source_created_at,source_modified_at,import_state,created_at,created_by,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .bind(context.customerId, context.folderId, fileName, objectKey, args.expectedSizeBytes, validMimeType(args.mimeType), null, sourceSha256, args.metadata.sourceDriveId ?? null, args.metadata.sourceItemId ?? null, args.metadata.sourceVersion ?? null, sourcePath, args.metadata.sourceCreatedAt ?? null, args.metadata.sourceModifiedAt ?? null, "pending", now, args.actor, now),
      db.prepare("INSERT INTO storage_audit_events (file_id,action,actor_email) SELECT last_insert_rowid(),'multipart_upload_started',?").bind(args.actor),
      db.prepare("INSERT INTO storage_uploads (id,file_id,owner_email,object_key,r2_upload_id,expected_size_bytes,status,created_at,updated_at) SELECT ?,id,?,?,?,?,?,?,? FROM storage_files WHERE object_key=?")
        .bind(uploadId, args.actor, objectKey, multipart.uploadId, args.expectedSizeBytes, "uploading", now, now, objectKey),
    ]);
    const file = await db.prepare("SELECT id FROM storage_files WHERE object_key=?").bind(objectKey).first<{ id: number }>();
    if (!file) throw new Error("Uploadmetadaten konnten nicht gespeichert werden.");
    return { upload_id: uploadId, file_id: file.id, part_size_bytes: STORAGE_PART_SIZE_BYTES, max_parts: MAX_MULTIPART_PARTS, duplicate: false, resumed: false };
  } catch {
    await multipart.abort().catch(() => undefined);
    const raced = await findDuplicate(db, args.metadata);
    if (raced) {
      const same = raced.file_name === fileName && raced.size_bytes === args.expectedSizeBytes && raced.customer_id === context.customerId &&
        raced.folder_id === context.folderId && raced.source_path === sourcePath && raced.source_sha256 === sourceSha256;
      if (!same) throw new StorageConflictError("Diese Quellversion ist bereits mit abweichender Zuordnung, Dateigröße oder Prüfsumme registriert.");
      if (raced.import_state === "stored" || raced.import_state === "unresolved") return { file_id: raced.id, import_state: raced.import_state, size_bytes: raced.size_bytes, sha256: raced.sha256, duplicate: true, upload_id: null };
    }
    throw new Error("Upload konnte nicht gestartet werden.");
  }
}

function hashAndLimitStream(stream: ReadableStream<Uint8Array>, maxBytes: number) {
  const hash = createHash("sha256");
  let sizeBytes = 0;
  let resolveSummary: (value: { sizeBytes: number; sha256: string }) => void = () => undefined;
  const summary = new Promise<{ sizeBytes: number; sha256: string }>((resolve) => { resolveSummary = resolve; });
  const limited = stream.pipeThrough(new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) {
      sizeBytes += chunk.byteLength;
      if (sizeBytes > maxBytes) throw new Error("Uploadpart überschreitet 20 MiB.");
      hash.update(chunk);
      controller.enqueue(chunk);
    },
    flush() { resolveSummary({ sizeBytes, sha256: hash.digest("hex") }); },
  }));
  return { stream: limited, summary };
}

export async function uploadStoragePart(db: D1Database, bucket: R2Bucket, uploadId: string, partNumber: number, ownerEmail: string, expectedPartSize: number, body: ReadableStream<Uint8Array> | null) {
  if (!body) throw new Error("Dateiinhalt fehlt.");
  if (!Number.isInteger(partNumber) || partNumber < 1 || partNumber > MAX_MULTIPART_PARTS) throw new Error("Part-Nummer muss 1 bis 10000 sein.");
  if (!Number.isInteger(expectedPartSize) || expectedPartSize < 1 || expectedPartSize > STORAGE_PART_SIZE_BYTES) throw new Error("Uploadpart-Größe muss 1 Byte bis 20 MiB sein.");
  const session = await db.prepare("SELECT id,file_id,object_key,r2_upload_id,status FROM storage_uploads WHERE id=? AND owner_email=?").bind(uploadId, ownerEmail)
    .first<{ id: string; file_id: number; object_key: string; r2_upload_id: string; status: string }>();
  if (!session) throw new StorageConflictError("Upload-Session nicht gefunden.");
  if (session.status !== "uploading") throw new StorageConflictError("Upload-Session nimmt keine weiteren Parts an.");
  const existing = await db.prepare("SELECT etag,size_bytes,sha256 FROM storage_upload_parts WHERE upload_id=? AND part_number=?").bind(uploadId, partNumber)
    .first<{ etag: string; size_bytes: number; sha256: string }>();
  if (existing) {
    const summary = await hashReadableStream(body, STORAGE_PART_SIZE_BYTES);
    if (summary.sizeBytes === expectedPartSize && summary.sizeBytes === existing.size_bytes && summary.sha256 === existing.sha256) {
      return { part_number: partNumber, etag: existing.etag, size_bytes: existing.size_bytes, sha256: existing.sha256, duplicate: true };
    }
    throw new StorageConflictError("Part-Nummer wurde bereits mit anderem Inhalt bestätigt.");
  }
  const measured = hashAndLimitStream(body, STORAGE_PART_SIZE_BYTES);
  let uploaded: R2UploadedPart;
  let summary: { sizeBytes: number; sha256: string };
  let streaming: Promise<void> | undefined;
  try {
    const fixed = new FixedLengthStream(expectedPartSize);
    streaming = measured.stream.pipeTo(fixed.writable);
    const upload = bucket.resumeMultipartUpload(session.object_key, session.r2_upload_id).uploadPart(partNumber, fixed.readable);
    [uploaded] = await Promise.all([upload, streaming]);
    summary = await measured.summary;
  } catch {
    if (streaming) await Promise.allSettled([streaming]);
    throw new Error("Uploadpart konnte nicht gespeichert werden; vorhandenen Sessionstatus prüfen.");
  }
  if (summary.sizeBytes !== expectedPartSize) throw new Error("Uploadpart-Größe stimmt nicht mit Content-Length überein.");
  if (summary.sizeBytes < 1) throw new Error("Leere Uploadparts sind nicht zulässig.");
  try {
    await db.prepare("INSERT INTO storage_upload_parts (upload_id,part_number,etag,size_bytes,sha256) VALUES (?,?,?,?,?)")
      .bind(uploadId, partNumber, uploaded.etag, summary.sizeBytes, summary.sha256).run();
  } catch {
    const raced = await db.prepare("SELECT etag,size_bytes,sha256 FROM storage_upload_parts WHERE upload_id=? AND part_number=?").bind(uploadId, partNumber)
      .first<{ etag: string; size_bytes: number; sha256: string }>();
    if (raced && raced.etag === uploaded.etag && raced.size_bytes === summary.sizeBytes && raced.sha256 === summary.sha256) {
      return { part_number: partNumber, etag: raced.etag, size_bytes: raced.size_bytes, sha256: raced.sha256, duplicate: true };
    }
    throw new StorageConflictError("Partnummer wurde parallel mit anderem Inhalt hochgeladen; Session nicht abschließen.");
  }
  await db.prepare("UPDATE storage_uploads SET updated_at=? WHERE id=?").bind(new Date().toISOString(), uploadId).run();
  return { part_number: partNumber, etag: uploaded.etag, size_bytes: summary.sizeBytes, sha256: summary.sha256, duplicate: false };
}

async function failMultipart(db: D1Database, sessionId: string, fileId: number, actor: string) {
  await db.batch([
    db.prepare("UPDATE storage_uploads SET status='failed',updated_at=? WHERE id=?").bind(new Date().toISOString(), sessionId),
    db.prepare("UPDATE storage_files SET import_state='failed',updated_at=? WHERE id=?").bind(new Date().toISOString(), fileId),
    db.prepare("INSERT INTO storage_audit_events (file_id,action,actor_email) VALUES (?,?,?)").bind(fileId, "multipart_upload_failed", actor),
  ]);
}

export async function completeStorageUploadSession(db: D1Database, bucket: R2Bucket, uploadId: string, ownerEmail: string) {
  const session = await db.prepare("SELECT u.id,u.file_id,u.object_key,u.r2_upload_id,u.expected_size_bytes,u.status,f.customer_id,f.source_sha256,f.sha256,f.import_state FROM storage_uploads u JOIN storage_files f ON f.id=u.file_id WHERE u.id=? AND u.owner_email=?")
    .bind(uploadId, ownerEmail).first<{ id: string; file_id: number; object_key: string; r2_upload_id: string; expected_size_bytes: number; status: string; customer_id: number | null; source_sha256: string | null; sha256: string | null; import_state: string }>();
  if (!session) throw new StorageConflictError("Upload-Session nicht gefunden.");
  if (session.status === "complete" && (session.import_state === "stored" || session.import_state === "unresolved")) {
    return { file_id: session.file_id, import_state: session.import_state, size_bytes: session.expected_size_bytes, sha256: session.sha256, duplicate: true };
  }
  if (session.status !== "uploading") throw new StorageConflictError("Upload-Session ist nicht abschließbar.");

  let object = await bucket.head(session.object_key);
  if (!object) {
    const rows = await db.prepare("SELECT part_number,etag,size_bytes FROM storage_upload_parts WHERE upload_id=? ORDER BY part_number").bind(uploadId)
      .all<{ part_number: number; etag: string; size_bytes: number }>();
    const parts = rows.results;
    if (!parts.length || parts.length > MAX_MULTIPART_PARTS || parts.some((part, index) => part.part_number !== index + 1)) throw new Error("Uploadparts müssen lückenlos bei Part 1 beginnen.");
    const totalSize = parts.reduce((total, part) => total + part.size_bytes, 0);
    if (totalSize !== session.expected_size_bytes) throw new Error("Summe der Uploadparts stimmt nicht mit expected_size_bytes überein.");
    if (parts.slice(0, -1).some((part) => part.size_bytes < MIN_MULTIPART_PART_BYTES || part.size_bytes !== parts[0].size_bytes)) throw new Error("Alle Nicht-Endparts müssen gleich groß und mindestens 5 MiB sein.");
    if (parts.at(-1)!.size_bytes > STORAGE_PART_SIZE_BYTES) throw new Error("Letzter Part überschreitet 20 MiB.");
    try {
      await bucket.resumeMultipartUpload(session.object_key, session.r2_upload_id)
        .complete(parts.map((part) => ({ partNumber: part.part_number, etag: part.etag })));
      object = await bucket.head(session.object_key);
    } catch {
      throw new Error("R2 konnte die Multipart-Datei nicht abschließen; Uploadstatus bleibt prüfbar.");
    }
  }
  if (!object || object.size !== session.expected_size_bytes) {
    await failMultipart(db, session.id, session.file_id, ownerEmail);
    throw new Error("Gespeicherte Dateigröße stimmt nicht mit der Quelle überein.");
  }
  const storedObject = await bucket.get(session.object_key);
  if (!storedObject || !("body" in storedObject) || !storedObject.body) {
    await failMultipart(db, session.id, session.file_id, ownerEmail);
    throw new Error("Gespeichertes Objekt konnte nicht unabhängig geprüft werden.");
  }
  let targetHash: { sizeBytes: number; sha256: string };
  try { targetHash = await hashReadableStream(storedObject.body, session.expected_size_bytes); }
  catch {
    await failMultipart(db, session.id, session.file_id, ownerEmail);
    throw new Error("Gespeichertes Objekt konnte nicht vollständig geprüft werden.");
  }
  if (targetHash.sizeBytes !== session.expected_size_bytes || !session.source_sha256 || targetHash.sha256 !== session.source_sha256.toLowerCase()) {
    await failMultipart(db, session.id, session.file_id, ownerEmail);
    throw new Error("Gespeicherte Datei stimmt nicht mit Quellgröße und Quell-SHA-256 überein.");
  }
  const importState = session.customer_id === null ? "unresolved" : "stored";
  await db.batch([
    db.prepare("UPDATE storage_files SET size_bytes=?,sha256=?,import_state=?,updated_at=? WHERE id=?").bind(targetHash.sizeBytes, targetHash.sha256, importState, new Date().toISOString(), session.file_id),
    db.prepare("UPDATE storage_uploads SET status='complete',updated_at=? WHERE id=?").bind(new Date().toISOString(), uploadId),
    db.prepare("INSERT INTO storage_audit_events (file_id,action,actor_email) VALUES (?,?,?)").bind(session.file_id, "multipart_file_verified", ownerEmail),
  ]);
  return { file_id: session.file_id, import_state: importState, size_bytes: targetHash.sizeBytes, sha256: targetHash.sha256, duplicate: false };
}

export async function abortStorageUploadSession(db: D1Database, bucket: R2Bucket, uploadId: string, ownerEmail: string) {
  const session = await db.prepare("SELECT id,file_id,object_key,r2_upload_id,status FROM storage_uploads WHERE id=? AND owner_email=?").bind(uploadId, ownerEmail)
    .first<{ id: string; file_id: number; object_key: string; r2_upload_id: string; status: string }>();
  if (!session) throw new StorageConflictError("Upload-Session nicht gefunden.");
  if (session.status === "complete") throw new StorageConflictError("Abgeschlossene Dokumente werden nicht über Upload-Sessions gelöscht.");
  if (session.status !== "uploading") return { upload_id: uploadId, status: session.status };
  if (await bucket.head(session.object_key)) throw new StorageConflictError("R2-Objekt ist bereits abgeschlossen; Session über complete abschließen.");
  await bucket.resumeMultipartUpload(session.object_key, session.r2_upload_id).abort().catch(() => undefined);
  await db.batch([
    db.prepare("UPDATE storage_uploads SET status='aborted',updated_at=? WHERE id=?").bind(new Date().toISOString(), uploadId),
    db.prepare("UPDATE storage_files SET import_state='failed',updated_at=? WHERE id=?").bind(new Date().toISOString(), session.file_id),
    db.prepare("INSERT INTO storage_audit_events (file_id,action,actor_email) VALUES (?,?,?)").bind(session.file_id, "multipart_upload_aborted", ownerEmail),
  ]);
  return { upload_id: uploadId, status: "aborted" };
}

export async function getStoredFileRecord(db: D1Database, id: number) {
  return await db.prepare("SELECT id,customer_id,folder_id,file_name,object_key,size_bytes,mime_type,sha256,source_drive_id,source_item_id,source_version,source_path,import_state,created_at,created_by FROM storage_files WHERE id=?")
    .bind(id).first();
}
