import { lstat } from "node:fs/promises";
import path from "node:path";
import { DatabaseSync, type StatementSync, type SQLInputValue } from "node:sqlite";
import type { KratosToolBindings } from "./kratos-tool-service";

export class KratosSqliteReadError extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = "KratosSqliteReadError";
    this.code = code;
  }
}

function denied(operation: string): never {
  throw new KratosSqliteReadError("read_only_operation", `${operation} is unavailable on the read-only SQLite adapter.`);
}

function assertSingleSelect(sql: unknown): asserts sql is string {
  if (typeof sql !== "string" || sql.length > 20_000 || !/^\s*SELECT\b/i.test(sql) || sql.includes(";") || /--|\/\*/.test(sql)) {
    throw new KratosSqliteReadError("untrusted_query", "Only one SELECT statement without comments is supported.");
  }
}

function assertBindValues(values: unknown[]): asserts values is SQLInputValue[] {
  if (values.some((value) => !(value === null || typeof value === "string" || typeof value === "bigint" || (typeof value === "number" && Number.isFinite(value)) || value instanceof Uint8Array))) {
    throw new KratosSqliteReadError("invalid_bind_value", "SQLite bind values must be scalar data values.");
  }
}

function safeColumn(row: Record<string, unknown> | undefined, columnName?: string): unknown {
  if (!row) return null;
  if (columnName === undefined) return { ...row };
  if (!Object.hasOwn(row, columnName)) return null;
  return row[columnName];
}

class ReadOnlyBoundStatement {
  constructor(private readonly statement: StatementSync, private readonly parameters: readonly SQLInputValue[] = []) {}

  bind(...values: unknown[]): ReadOnlyBoundStatement {
    assertBindValues(values);
    return new ReadOnlyBoundStatement(this.statement, [...values]);
  }

  async first(columnName?: string): Promise<unknown> {
    try {
      return safeColumn(this.statement.get(...this.parameters) as Record<string, unknown> | undefined, columnName);
    } catch {
      throw new KratosSqliteReadError("query_failed", "The trusted SQLite read query could not be completed.");
    }
  }

  async all(): Promise<{ results: Record<string, unknown>[]; success: true }> {
    try {
      return { results: this.statement.all(...this.parameters) as Record<string, unknown>[], success: true };
    } catch {
      throw new KratosSqliteReadError("query_failed", "The trusted SQLite read query could not be completed.");
    }
  }

  run(): never { return denied("Statement.run"); }
  raw(): never { return denied("Statement.raw"); }
  dump(): never { return denied("Statement.dump"); }
  exec(): never { return denied("Statement.exec"); }
}

type ReadOnlyDatabaseFacade = {
  prepare(sql: string): ReadOnlyBoundStatement;
  run(..._args: unknown[]): never;
  batch(..._args: unknown[]): never;
  exec(..._args: unknown[]): never;
  dump(..._args: unknown[]): never;
  raw(..._args: unknown[]): never;
};

/**
 * A narrow D1-shaped read facade for the existing Kratos tool service.
 * It opens an existing database in native SQLite read-only mode; it is not a
 * D1 implementation and does not provide writes, transactions, migrations,
 * backups, or a general SQL endpoint.
 * The SELECT shape guard is not a table/column authorization policy. DB/bindings()
 * are internal application handles: expose only curated tool operations to clients.
 */
export class KratosSqliteReadAdapter {
  readonly DB: KratosToolBindings["DB"];
  #database: DatabaseSync;

  private constructor(database: DatabaseSync) {
    this.#database = database;
    const facade: ReadOnlyDatabaseFacade = {
      prepare: (sql) => {
        assertSingleSelect(sql);
        try {
          return new ReadOnlyBoundStatement(database.prepare(sql));
        } catch {
          throw new KratosSqliteReadError("query_rejected", "The trusted SQLite SELECT did not match this database schema.");
        }
      },
      run: () => denied("Database.run"),
      batch: () => denied("Database.batch"),
      exec: () => denied("Database.exec"),
      dump: () => denied("Database.dump"),
      raw: () => denied("Database.raw"),
    };
    // Localized boundary cast: runKratosTool only needs this minimal read facade
    // for its prepared SELECT branches; mutating D1 methods always throw above.
    this.DB = facade as unknown as KratosToolBindings["DB"];
  }

  static async open(databasePath: string): Promise<KratosSqliteReadAdapter> {
    if (typeof databasePath !== "string" || !path.isAbsolute(databasePath)) {
      throw new KratosSqliteReadError("invalid_database_path", "SQLite database path must be absolute.");
    }
    const resolvedPath = path.resolve(databasePath);
    let info;
    try { info = await lstat(resolvedPath); }
    catch { throw new KratosSqliteReadError("database_unavailable", "The existing SQLite database could not be opened read-only."); }
    if (!info.isFile() || info.isSymbolicLink()) throw new KratosSqliteReadError("unsafe_database_path", "SQLite path must be an existing regular file without a symbolic link.");
    try {
      return new KratosSqliteReadAdapter(new DatabaseSync(resolvedPath, { readOnly: true }));
    } catch {
      throw new KratosSqliteReadError("database_unavailable", "The existing SQLite database could not be opened read-only.");
    }
  }

  bindings(): KratosToolBindings { return { DB: this.DB }; }

  close(): void {
    this.#database.close();
  }
}
