export const KRATOS_READ_SCOPE = "kratos:read" as const;
export const KRATOS_GATEWAY_TOOLS = [
  "search_customers",
  "get_customer",
  "list_follow_ups",
  "list_customer_documents",
  "get_document_lookup",
  "search_stored_customer_files",
  "get_stored_customer_file",
] as const;
export const MCP_PROTOCOL_VERSIONS = ["2025-11-25", "2025-06-18", "2025-03-26"] as const;
export const GATEWAY_BODY_LIMIT_BYTES = 64 * 1024;

export type KratosGatewayToolName = (typeof KRATOS_GATEWAY_TOOLS)[number];
export type KratosVerifiedIdentity = { subject: string; scopes: string[] };
export type KratosToolDefinition = {
  name: KratosGatewayToolName;
  description: string;
  inputSchema: Record<string, unknown>;
  [key: string]: unknown;
};
export type KratosToolExecutor = (toolName: KratosGatewayToolName, args: Record<string, unknown>, identity: KratosVerifiedIdentity) => Promise<unknown> | unknown;
/** Must cryptographically verify signature, issuer, resource audience, expiry and delegated scopes. */
export type KratosAccessTokenVerifier = (token: string) => Promise<KratosVerifiedIdentity | null> | KratosVerifiedIdentity | null;
export type KratosGatewayConfig = {
  resourceOrigin: string;
  /** Fixed canonical resource identifier, either the origin or its exact /mcp endpoint. */
  resourceUrl?: string;
  issuer: string;
  verifyAccessToken?: KratosAccessTokenVerifier;
  allowedSubjects: string[];
  tools: KratosToolDefinition[];
  executeTool: KratosToolExecutor;
  bodyLimitBytes?: number;
  serverName?: string;
  serverVersion?: string;
  /** Externally requested OAuth scope; verified identities still require kratos:read. */
  externalReadScope?: string;
};

type JsonRpcId = string | number | null;
type JsonRpcRequest = { jsonrpc: "2.0"; id?: JsonRpcId; method: string; params?: Record<string, unknown> };
type GatewayResponse = Response;

const ALLOWED_TOOL_NAMES = new Set<string>(KRATOS_GATEWAY_TOOLS);
const JSON_HEADERS = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" };

function assertHttpsUrl(value: string, label: string): URL {
  let parsed: URL;
  try { parsed = new URL(value); } catch { throw new Error(`${label} must be an absolute HTTPS URL.`); }
  if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.search || parsed.hash) throw new Error(`${label} must be an absolute HTTPS URL without credentials, query, or fragment.`);
  return parsed;
}

function normalizeResourceOrigin(value: string): string {
  const parsed = assertHttpsUrl(value, "resourceOrigin");
  if (parsed.pathname !== "/") throw new Error("resourceOrigin must contain only the HTTPS origin.");
  return parsed.origin;
}

/** Deliberately narrow operator configuration; never inferred from request headers. */
export function resolveKratosResourceUrl(resourceOrigin: string, resourceUrl?: string): string {
  const origin = normalizeResourceOrigin(resourceOrigin);
  const resource = resourceUrl === undefined ? origin : resourceUrl;
  if (typeof resource !== "string" || (resource !== origin && resource !== `${origin}/mcp`)) {
    throw new Error("resourceUrl must be exactly the configured HTTPS origin or its /mcp endpoint.");
  }
  return resource;
}

function jsonResponse(value: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(value), { status, headers: { ...JSON_HEADERS, ...headers } });
}

function openApiForTools(origin: string, tools: KratosToolDefinition[], externalReadScope: string): Record<string, unknown> {
  const paths: Record<string, unknown> = {};
  for (const tool of tools) {
    paths[`/v1/tools/${tool.name}`] = {
      post: {
        operationId: tool.name,
        summary: tool.description,
        security: [{ bearerAuth: [] }],
        "x-kratos-required-oauth-scopes": [externalReadScope],
        "x-openai-isConsequential": false,
        requestBody: { required: true, content: { "application/json": { schema: tool.inputSchema } } },
        responses: {
          "200": { description: "Read-only Kratos tool result", content: { "application/json": { schema: { type: "object", additionalProperties: true } } } },
          "400": { description: "Invalid request" },
          "401": { description: "Bearer token required", headers: { "WWW-Authenticate": { schema: { type: "string" } } } },
          "403": { description: "Required scope or subject not allowed" },
        },
      },
    };
  }
  return {
    openapi: "3.1.0",
    info: { title: "Kratos read-only gateway", version: "1.0.0" },
    servers: [{ url: origin }],
    paths,
    components: {
      securitySchemes: { bearerAuth: { type: "http", scheme: "bearer", bearerFormat: "JWT" } },
    },
  };
}

async function readJsonBody(request: Request, maxBytes: number): Promise<unknown> {
  const reader = request.body?.getReader();
  if (!reader) throw new GatewayHttpError(400, "invalid_json");
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel().catch(() => {});
        throw new GatewayHttpError(413, "body_too_large");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  try {
    const bytes = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch (error) {
    if (error instanceof GatewayHttpError) throw error;
    throw new GatewayHttpError(400, "invalid_json");
  }
}

class GatewayHttpError extends Error {
  readonly status: number;
  readonly code: string;
  constructor(status: number, code: string) { super(code); this.status = status; this.code = code; }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isJsonRpcRequest(value: unknown): value is JsonRpcRequest {
  if (!isRecord(value) || value.jsonrpc !== "2.0" || typeof value.method !== "string") return false;
  if ("id" in value && value.id !== null && typeof value.id !== "string" && typeof value.id !== "number") return false;
  if ("params" in value && !isRecord(value.params)) return false;
  return true;
}

function rpcError(id: JsonRpcId, code: number, message: string): Record<string, unknown> {
  return { jsonrpc: "2.0", id, error: { code, message } };
}

export function createKratosGateway(config: KratosGatewayConfig): (request: Request) => Promise<GatewayResponse> {
  if (typeof config.verifyAccessToken !== "function") throw new Error("A JWT-verifying access-token verifier is required; token decoding is not supported.");
  if (typeof config.executeTool !== "function") throw new Error("A read-only tool executor is required.");
  const resourceOrigin = normalizeResourceOrigin(config.resourceOrigin);
  const resourceUrl = resolveKratosResourceUrl(resourceOrigin, config.resourceUrl);
  const metadataPath = `/.well-known/oauth-protected-resource${resourceUrl === resourceOrigin ? "" : "/mcp"}`;
  assertHttpsUrl(config.issuer, "issuer");
  const issuer = config.issuer;
  if (!Array.isArray(config.allowedSubjects) || config.allowedSubjects.length === 0 || config.allowedSubjects.some((s) => typeof s !== "string" || !s.trim())) {
    throw new Error("At least one explicit verified subject must be allowed.");
  }
  const allowedSubjects = new Set(config.allowedSubjects);
  if (!Array.isArray(config.tools) || config.tools.length === 0) throw new Error("At least one read-only tool definition is required.");
  const toolsByName = new Map<string, KratosToolDefinition>();
  for (const tool of config.tools) {
    if (!ALLOWED_TOOL_NAMES.has(tool.name) || toolsByName.has(tool.name) || typeof tool.description !== "string" || !isRecord(tool.inputSchema)) {
      throw new Error("Tool definitions must be unique members of the Kratos read-only allowlist with an input schema.");
    }
    toolsByName.set(tool.name, tool);
  }
  const bodyLimit = config.bodyLimitBytes ?? GATEWAY_BODY_LIMIT_BYTES;
  if (!Number.isSafeInteger(bodyLimit) || bodyLimit < 1 || bodyLimit > GATEWAY_BODY_LIMIT_BYTES) throw new Error("Request body limit must be between 1 byte and 64 KiB.");
  const externalReadScope = config.externalReadScope ?? KRATOS_READ_SCOPE;
  if (typeof externalReadScope !== "string" || !/^[\x21\x23-\x5b\x5d-\x7e]{1,512}$/.test(externalReadScope)) throw new Error("A single safe external OAuth scope is required.");
  const openApi = openApiForTools(resourceOrigin, [...toolsByName.values()], externalReadScope);
  const metadata = {
    resource: resourceUrl,
    authorization_servers: [issuer],
    scopes_supported: [externalReadScope],
    bearer_methods_supported: ["header"],
  };
  const challenge = `Bearer resource_metadata="${resourceOrigin}${metadataPath}", scope="${externalReadScope}"`;

  async function authenticate(request: Request): Promise<{ identity: KratosVerifiedIdentity | null; response?: Response }> {
    const header = request.headers.get("authorization") ?? "";
    const match = /^Bearer\s+([^\s]+)$/i.exec(header);
    if (!match) return { identity: null, response: jsonResponse({ error: "unauthorized" }, 401, { "www-authenticate": challenge }) };
    let identity: KratosVerifiedIdentity | null;
    try {
      identity = await config.verifyAccessToken!(match[1]);
    } catch {
      return { identity: null, response: jsonResponse({ error: "unauthorized" }, 401, { "www-authenticate": challenge }) };
    }
    if (!identity || typeof identity.subject !== "string" || !Array.isArray(identity.scopes) || !identity.scopes.every((scope) => typeof scope === "string")) {
      return { identity: null, response: jsonResponse({ error: "unauthorized" }, 401, { "www-authenticate": challenge }) };
    }
    if (!allowedSubjects.has(identity.subject) || !identity.scopes.includes(KRATOS_READ_SCOPE)) {
      return { identity: null, response: jsonResponse({ error: "forbidden" }, 403) };
    }
    return { identity };
  }

  function rejectCrossOrigin(request: Request): Response | null {
    const origin = request.headers.get("origin");
    const fetchSite = request.headers.get("sec-fetch-site");
    if (origin !== null || fetchSite === "cross-site") {
      try {
        if (!origin || origin === "null" || new URL(origin).origin !== resourceOrigin || fetchSite === "cross-site") return jsonResponse({ error: "cross_origin_request_rejected" }, 403);
      } catch { return jsonResponse({ error: "cross_origin_request_rejected" }, 403); }
    }
    return null;
  }

  async function dispatchTool(name: string, args: unknown, identity: KratosVerifiedIdentity): Promise<unknown> {
    if (!toolsByName.has(name)) throw new GatewayHttpError(404, "unknown_tool");
    if (!isRecord(args)) throw new GatewayHttpError(400, "invalid_arguments");
    return config.executeTool(name as KratosGatewayToolName, args, identity);
  }

  async function handleMcp(request: Request, identity: KratosVerifiedIdentity): Promise<Response> {
    const requestedHeaderVersion = request.headers.get("mcp-protocol-version");
    if (requestedHeaderVersion && !(MCP_PROTOCOL_VERSIONS as readonly string[]).includes(requestedHeaderVersion)) return jsonResponse({ error: "unsupported_protocol_version" }, 400);
    let body: unknown;
    try { body = await readJsonBody(request, bodyLimit); }
    catch (error) {
      if (error instanceof GatewayHttpError) return jsonResponse(rpcError(null, error.status === 413 ? -32600 : -32700, error.status === 413 ? "Invalid Request" : "Parse error"), error.status);
      return jsonResponse(rpcError(null, -32700, "Parse error"), 400);
    }
    if (Array.isArray(body)) return jsonResponse(rpcError(null, -32600, "Invalid Request"), 400);
    if (!isJsonRpcRequest(body)) return jsonResponse(rpcError(null, -32600, "Invalid Request"), 400);
    const { id, method, params = {} } = body;
    const notification = !Object.prototype.hasOwnProperty.call(body, "id");
    if (notification && method.startsWith("notifications/")) return new Response(null, { status: 202, headers: { "cache-control": "no-store" } });
    if (notification) return new Response(null, { status: 202, headers: { "cache-control": "no-store" } });
    const rpcId = id as JsonRpcId;
    try {
      if (method === "initialize") {
        const version = params.protocolVersion;
        if (typeof version !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(version) || (requestedHeaderVersion !== null && requestedHeaderVersion !== version)) {
          return jsonResponse(rpcError(rpcId, -32602, "Unsupported protocol version"));
        }
        const negotiatedVersion = (MCP_PROTOCOL_VERSIONS as readonly string[]).includes(version) ? version : MCP_PROTOCOL_VERSIONS[0];
        return jsonResponse({ jsonrpc: "2.0", id: rpcId, result: { protocolVersion: negotiatedVersion, capabilities: { tools: { listChanged: false } }, serverInfo: { name: config.serverName ?? "kratos", version: config.serverVersion ?? "1.0.0" } } });
      }
      if (method === "ping") return jsonResponse({ jsonrpc: "2.0", id: rpcId, result: {} });
      if (method === "tools/list") return jsonResponse({ jsonrpc: "2.0", id: rpcId, result: { tools: [...toolsByName.values()] } });
      if (method === "tools/call") {
        if (typeof params.name !== "string") return jsonResponse(rpcError(rpcId, -32602, "Invalid params"));
        if (!toolsByName.has(params.name)) return jsonResponse(rpcError(rpcId, -32602, "Unknown tool"));
        if (params.arguments !== undefined && !isRecord(params.arguments)) return jsonResponse(rpcError(rpcId, -32602, "Invalid params"));
        try {
          const result = await dispatchTool(params.name, params.arguments ?? {}, identity);
          const validContent = isRecord(result) && Array.isArray(result.content) && result.content.every((block) => isRecord(block) && typeof block.type === "string");
          const structuredContent = isRecord(result) ? result : { value: result ?? null };
          const businessError = isRecord(result) && result.isError === true;
          return jsonResponse({ jsonrpc: "2.0", id: rpcId, result: validContent ? result : { content: [{ type: "text", text: JSON.stringify(result ?? null) }], structuredContent, ...(businessError ? { isError: true } : {}) } });
        } catch {
          return jsonResponse({ jsonrpc: "2.0", id: rpcId, result: { content: [{ type: "text", text: "Tool execution failed." }], isError: true } });
        }
      }
      return jsonResponse(rpcError(rpcId, -32601, "Method not found"));
    } catch {
      return jsonResponse(rpcError(rpcId, -32603, "Internal error"));
    }
  }

  return async function handle(request: Request): Promise<Response> {
    const url = new URL(request.url);
    if (url.origin !== resourceOrigin) return jsonResponse({ error: "misdirected_request" }, 421);
    const path = url.pathname;
    if (request.method === "GET" && path === "/openapi.json") return jsonResponse(openApi);
    // Root discovery remains a fallback for the same configured resource, not another resource alias.
    if (request.method === "GET" && (path === "/.well-known/oauth-protected-resource" || path === metadataPath)) return jsonResponse(metadata);
    if (request.method !== "POST") return jsonResponse({ error: "method_not_allowed" }, 405, { allow: "GET, POST" });
    const originError = rejectCrossOrigin(request);
    if (originError) return originError;
    const auth = await authenticate(request);
    if (auth.response || !auth.identity) return auth.response!;
    if (request.headers.get("content-type")?.split(";")[0].trim().toLowerCase() !== "application/json") return jsonResponse({ error: "unsupported_media_type" }, 415);
    if (path === "/mcp") return handleMcp(request, auth.identity);
    const toolMatch = /^\/v1\/tools\/([a-z_]+)$/.exec(path);
    if (!toolMatch || !toolsByName.has(toolMatch[1])) return jsonResponse({ error: "not_found" }, 404);
    let args: unknown;
    try { args = await readJsonBody(request, bodyLimit); }
    catch (error) {
      if (error instanceof GatewayHttpError) return jsonResponse({ error: error.code }, error.status);
      return jsonResponse({ error: "invalid_json" }, 400);
    }
    if (!isRecord(args)) return jsonResponse({ error: "invalid_arguments" }, 400);
    try {
      const result = await dispatchTool(toolMatch[1], args, auth.identity);
      return jsonResponse(result ?? null);
    } catch (error) {
      if (error instanceof GatewayHttpError) return jsonResponse({ error: error.code }, error.status);
      return jsonResponse({ error: "tool_execution_failed" }, 500);
    }
  };
}
