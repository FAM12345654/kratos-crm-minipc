export const MAX_CHAT_FILE_BYTES = 20 * 1024 * 1024;

// File parameters are supplied by the host; never accept arbitrary network targets.
export async function fetchChatFile(value: unknown): Promise<File> {
  if (!value || typeof value !== "object") throw Error("Dateireferenz fehlt.");
  const file = value as Record<string, unknown>;
  if (typeof file.file_id !== "string" || !file.file_id || typeof file.download_url !== "string") throw Error("Ungültige Chat-Dateireferenz.");
  let url: URL;
  try { url = new URL(file.download_url); } catch { throw Error("Ungültige Dateiadresse."); }
  if (url.protocol !== "https:" || url.username || url.password || (url.port && url.port !== "443") || !(url.hostname === "oaiusercontent.com" || url.hostname.endsWith(".oaiusercontent.com"))) throw Error("Dateiadresse ist kein freigegebener Chat-Dateihost. Bitte den authentifizierten Kratos-Upload verwenden.");
  const response = await fetch(url, { redirect: "error", signal: AbortSignal.timeout(30000) });
  if (!response.ok || !response.body) throw Error("Chat-Datei ist nicht abrufbar; Dateireferenz erneuern.");
  const length = response.headers.get("content-length");
  if (length && Number(length) > MAX_CHAT_FILE_BYTES) { await response.body.cancel(); throw Error("Chat-Direktupload über 20 MiB: wiederaufnehmbaren Upload verwenden."); }
  const chunks: Uint8Array[] = []; let bytes = 0;
  const reader = response.body.getReader();
  try {
    for (;;) { const part = await reader.read(); if (part.done) break; bytes += part.value.byteLength; if (bytes > MAX_CHAT_FILE_BYTES) { await reader.cancel(); throw Error("Chat-Direktupload über 20 MiB: wiederaufnehmbaren Upload verwenden."); } chunks.push(part.value); }
  } finally { reader.releaseLock(); }
  const name = typeof file.file_name === "string" && file.file_name.trim() ? file.file_name : file.file_id;
  return new File(chunks as BlobPart[], name, { type: typeof file.mime_type === "string" ? file.mime_type : "application/octet-stream" });
}
