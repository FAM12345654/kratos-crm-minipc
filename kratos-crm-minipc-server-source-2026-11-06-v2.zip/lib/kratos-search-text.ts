/** German name folding shared by SQL matching and match explanations; no fuzzy identity merge. */
export function foldKratosSearchText(value: string): string {
  return value.normalize("NFC").toLocaleLowerCase("de-DE");
}

type SearchColumn = "first_name" | "last_name" | "email" | "adviser" | "status";
const COLUMNS = new Set(["first_name", "last_name", "email", "adviser", "status"]);

/** SQLite/D1 lower() only folds ASCII. Normalize German umlauts explicitly, with bound query values. */
export function kratosSearchColumn(column: SearchColumn): string {
  if (!COLUMNS.has(column)) throw new Error("Unsupported search column.");
  let expression: string = column;
  for (const [from, to] of [["A\u0308", "Ä"], ["O\u0308", "Ö"], ["U\u0308", "Ü"], ["a\u0308", "ä"], ["o\u0308", "ö"], ["u\u0308", "ü"], ["Ä", "ä"], ["Ö", "ö"], ["Ü", "ü"], ["ẞ", "ß"]]) {
    expression = `replace(${expression},'${from}','${to}')`;
  }
  return `lower(${expression})`;
}
