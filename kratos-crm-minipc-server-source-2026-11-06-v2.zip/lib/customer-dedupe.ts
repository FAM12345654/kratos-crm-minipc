export type CustomerIdentity = {
  id?: number;
  first_name: string;
  last_name: string;
  phone?: string | null;
  email?: string | null;
};

function normalizedPhone(value: string): string {
  return value.replace(/\D/g, "");
}

export function sameCustomerPhone(left: string, right: string): boolean {
  const leftDigits = normalizedPhone(left);
  return leftDigits.length >= 6 && leftDigits === normalizedPhone(right);
}

export function findPotentialCustomerDuplicate(
  candidate: CustomerIdentity,
  existing: CustomerIdentity[],
): CustomerIdentity | undefined {
  const firstName = candidate.first_name.trim().toLocaleLowerCase();
  const lastName = candidate.last_name.trim().toLocaleLowerCase();
  const phone = candidate.phone?.trim() || "";
  const email = candidate.email?.trim().toLocaleLowerCase() || "";

  return existing.find((row) => {
    if (row.id !== undefined && candidate.id === row.id) return false;
    if (row.first_name.trim().toLocaleLowerCase() !== firstName || row.last_name.trim().toLocaleLowerCase() !== lastName) return false;
    if (!phone && !email) return true;
    return Boolean(phone && row.phone && sameCustomerPhone(phone, row.phone)) ||
      Boolean(email && row.email && email === row.email.trim().toLocaleLowerCase());
  });
}
