import { belongsToCustomer, categoryFolders, documentCategories, listCustomerDocuments, registerCustomerDocument } from "./customer-documents";
import { findPotentialCustomerDuplicate } from "./customer-dedupe";
import { foldKratosSearchText, kratosSearchColumn } from "./kratos-search-text";
import { storedDocumentTools, runStoredDocumentTool } from "./mcp-stored-documents";

export const kratosTools = [
  ...storedDocumentTools,
  {
    name: "list_customer_documents",
    description: "List registered OneDrive documents for one Kratos customer, optionally by category. An empty index does not mean no files exist; check the customer's verified folder with SharePoint. Returns file links, not document contents.",
    annotations: { readOnlyHint: true },
    inputSchema: { type:"object", properties:{ customer_id:{type:"integer",minimum:1}, category:{type:"string",enum:documentCategories} }, required:["customer_id"], additionalProperties:false },
  },
  {
    name: "register_customer_document",
    description: "Register or reclassify one verified OneDrive file in a customer's Kratos document index. Call only after SharePoint confirms a successful upload or existing file metadata. Use its exact file_name and web URL. Does not upload bytes. Never register a guessed URL or claim a Chat attachment is saved before upload succeeds.",
    annotations: { readOnlyHint:false, destructiveHint:false, idempotentHint:true },
    inputSchema: { type:"object", properties:{ customer_id:{type:"integer",minimum:1}, category:{type:"string",enum:documentCategories}, file_name:{type:"string",minLength:1,maxLength:255}, file_url:{type:"string",minLength:1,maxLength:1500} }, required:["customer_id","category","file_name","file_url"], additionalProperties:false },
  },
  {
    name: "prepare_consultation_filing",
    description: "Prepare filing of files uploaded by the user after a consultation. First resolve the exact customer. Read only the uploaded documents needed to classify each file. For each original file choose Antrag, Vollmacht, Beratungsprotokoll or another category; ask on ambiguity. Use SharePoint to discover the exact customer folder, create missing category subfolders, and upload each Chat file reference separately without overwrite. If one PDF contains several documents, split into separate files with document tools before uploading, preserving the original. After each confirmed upload call register_customer_document with returned metadata. Report saved files and failures separately. Never send files to third parties as part of filing.",
    annotations: {readOnlyHint:true},
    inputSchema:{type:"object",properties:{customer_id:{type:"integer",minimum:1}},required:["customer_id"],additionalProperties:false},
  },
  {
    name: "list_follow_ups",
    description: "List Kratos customer follow-ups through an inclusive YYYY-MM-DD date. Dates are interpreted in Europe/Berlin. Returns a total and bounded results; does not send messages.",
    annotations: { readOnlyHint: true },
    inputSchema: { type: "object", properties: { through_date: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" }, limit: { type: "integer", minimum: 1, maximum: 100 } }, required: ["through_date"], additionalProperties: false },
  },
  {
    name: "get_document_lookup",
    description: "Get the verified OneDrive folder and search terms for a customer's requested document. This returns a lookup plan, not a file inventory. Use SharePoint to verify files and fetch only the requested document. Sending requires a specific recipient and user instruction.",
    annotations: { readOnlyHint: true },
    inputSchema: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 }, document_type: { type: "string", enum: ["Vollmacht", "Vertrag", "Antrag", "Beratungsprotokoll", "Schaden", "Schriftverkehr", "Sonstiges"] } }, required: ["customer_id", "document_type"], additionalProperties: false },
  },
  {
    name: "search_customers",
    description: "Search Kratos customers by partial or full name, phone, email, adviser, or status. Multiword names are matched across first and last name fields without mixing unrelated fields. Returns minimal candidate details and stable CRM IDs; use get_customer for full details after resolving the exact person. Results include total and pagination metadata. For documents, use SharePoint only inside the verified customer folder.",
    inputSchema: { type: "object", properties: { query: { type: "string", minLength: 2, maxLength: 100 }, limit: { type: "integer", minimum: 1, maximum: 25 }, offset: { type: "integer", minimum: 0, maximum: 10000 } }, required: ["query"], additionalProperties: false },
    outputSchema: { type: "object", properties: { count: { type: "integer" }, total_count: { type: "integer" }, offset: { type: "integer" }, has_more: { type: "boolean" }, next_offset: { type: ["integer", "null"] }, customers: { type: "array", items: { type: "object", properties: { id: { type: "integer" }, first_name: { type: "string" }, last_name: { type: "string" }, status: { type: "string" }, adviser: { type: ["string", "null"] }, matched_by: { type: "array", items: { type: "string", enum: ["name", "phone", "email", "adviser", "status"] } } }, required: ["id", "first_name", "last_name", "status", "adviser", "matched_by"], additionalProperties: false } }, document_lookup: { type: "string" } }, required: ["count", "total_count", "offset", "has_more", "next_offset", "customers", "document_lookup"], additionalProperties: false },
  },
  {
    name: "get_customer",
    description: "Get one Kratos customer by exact CRM id. Optionally request only the fields needed for the user task; if omitted, returns the full authorized CRM profile. Includes contact details, adviser, status, folder link, and follow-up fields. For documents, use SharePoint only inside the verified customer folder and fetch only the requested file.",
    inputSchema: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 }, fields: { type: "array", minItems: 1, maxItems: 18, uniqueItems: true, items: { type: "string", enum: ["first_name", "last_name", "phone", "email", "birthday", "authority_status", "adviser", "status", "folder_name", "folder_url", "internal_note", "last_contact_at", "next_follow_up_at", "next_follow_up_note", "created_at", "updated_at", "updated_by"] } } }, required: ["customer_id"], additionalProperties: false },
  },
  {
    name: "create_customer",
    description: "Create a Kratos customer record. Do not add contract, bank, health, or other sensitive document contents. Do not create a record unless the user explicitly asks. Resolve any natural-language follow-up date to an absolute Europe/Berlin calendar date (YYYY-MM-DD) before saving. Save the verified OneDrive folder URL only through sync_folder_links after checking the exact SharePoint folder.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false },
    inputSchema: { type: "object", properties: { first_name: { type: "string", minLength: 1, maxLength: 100 }, last_name: { type: "string", minLength: 1, maxLength: 100 }, phone: { type: "string", maxLength: 50 }, email: { type: "string", maxLength: 254 }, birthday: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" }, authority_status: { type: "string", enum: ["Ungeprüft", "Vorhanden", "Fehlt", "Widerrufen"] }, adviser: { type: "string", maxLength: 100 }, status: { type: "string", enum: ["Kunde", "Privat", "Zuordnung prüfen"] }, folder_name: { type: "string", maxLength: 200 }, internal_note: { type: "string", maxLength: 500 }, next_follow_up_at: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$", description: "Absolute ISO calendar date YYYY-MM-DD resolved for Europe/Berlin. Never store a natural-language phrase or time." }, next_follow_up_note: { type: "string", maxLength: 300 } }, required: ["first_name", "last_name"], additionalProperties: false },
  },
  {
    name: "update_customer",
    description: "Update an existing Kratos customer. Only contact, adviser, status, customer-folder label, and follow-up fields are editable. Do not store sensitive contract or bank details. Resolve natural-language follow-up dates to an absolute Europe/Berlin calendar date (YYYY-MM-DD) before saving. A folder label change clears its old URL; save a verified replacement only through sync_folder_links after checking the exact SharePoint folder.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true },
    inputSchema: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 }, first_name: { type: "string", minLength: 1, maxLength: 100 }, last_name: { type: "string", minLength: 1, maxLength: 100 }, phone: { type: "string", maxLength: 50 }, email: { type: "string", maxLength: 254 }, birthday: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" }, authority_status: { type: "string", enum: ["Ungeprüft", "Vorhanden", "Fehlt", "Widerrufen"] }, adviser: { type: "string", maxLength: 100 }, status: { type: "string", enum: ["Kunde", "Privat", "Zuordnung prüfen"] }, folder_name: { type: "string", maxLength: 200 }, internal_note: { type: "string", maxLength: 500 }, last_contact_at: { type: "string", maxLength: 30 }, next_follow_up_at: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$", description: "Absolute ISO calendar date YYYY-MM-DD resolved for Europe/Berlin. Never store a natural-language phrase or time." }, next_follow_up_note: { type: "string", maxLength: 300 } }, required: ["customer_id"], additionalProperties: false },
  },
  {
    name: "list_customer_contracts",
    description: "List structured insurance contract dates and status for one exact Kratos customer. Contract and cancellation dates are separate. Returns only metadata and verified SharePoint links, never document contents.",
    annotations: { readOnlyHint: true },
    inputSchema: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 } }, required: ["customer_id"], additionalProperties: false },
  },
  {
    name: "create_customer_contract",
    description: "Create one structured contract record for an exact CRM customer. Add only facts the user or a verified document confirms. Do not store policy numbers, premiums, bank, health, or document contents. Do not infer dates; document_url must be a verified SharePoint link.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false },
    inputSchema: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 }, insurance_type: { type: "string", minLength: 1, maxLength: 100 }, provider: { type: "string", maxLength: 100 }, status: { type: "string", enum: ["Ungeprüft", "Antrag", "Aktiv", "Gekündigt", "Beendet"] }, start_date: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" }, end_date: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" }, cancellation_deadline: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" }, document_url: { type: "string", maxLength: 1000 } }, required: ["customer_id", "insurance_type"], additionalProperties: false },
  },
  {
    name: "update_customer_contract",
    description: "Update verified structured fields of one existing Kratos contract. Keep contract end date, cancellation deadline, and status distinct; do not infer or replace unknown dates.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true },
    inputSchema: { type: "object", properties: { contract_id: { type: "integer", minimum: 1 }, insurance_type: { type: "string", minLength: 1, maxLength: 100 }, provider: { type: "string", maxLength: 100 }, status: { type: "string", enum: ["Ungeprüft", "Antrag", "Aktiv", "Gekündigt", "Beendet"] }, start_date: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" }, end_date: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" }, cancellation_deadline: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" }, document_url: { type: "string", maxLength: 1000 } }, required: ["contract_id"], additionalProperties: false },
  },
  {
    name: "sync_folder_links",
    description: "Save verified OneDrive customer-folder URLs for existing CRM records. Supply URLs returned by OneDrive metadata and the exact CRM ID plus folder name; every row is checked before any change. Does not read or store document contents.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true },
    inputSchema: { type: "object", properties: { links: { type: "array", minItems: 1, maxItems: 120, items: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 }, folder_name: { type: "string", minLength: 1, maxLength: 200 }, folder_url: { type: "string", minLength: 1, maxLength: 1000 } }, required: ["customer_id", "folder_name", "folder_url"], additionalProperties: false } } }, required: ["links"], additionalProperties: false },
  },
  {
    name: "import_customers",
    description: "One-time initial import of customer records explicitly approved by the user. Insert-only, maximum 120 rows, duplicate-safe by first name, last name and phone. Do not import non-customer business contacts or sensitive document details.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true },
    inputSchema: { type: "object", properties: { customers: { type: "array", maxItems: 120, items: { type: "object", properties: { first_name: { type: "string", minLength: 1, maxLength: 100 }, last_name: { type: "string", minLength: 1, maxLength: 100 }, phone: { type: "string", maxLength: 50 }, adviser: { type: "string", maxLength: 100 }, status: { type: "string", enum: ["Kunde"] }, folder_name: { type: "string", maxLength: 200 } }, required: ["first_name", "last_name"], additionalProperties: false } } }, required: ["customers"], additionalProperties: false },
  },
];

type Json = Record<string, unknown>;

export type KratosToolBindings = { DB?: D1Database; BUCKET?: R2Bucket };
const str = (v: unknown) => typeof v === "string" ? v.trim() : "";
const opt = (v: unknown) => str(v) || null;
const fail = (message: string) => ({ isError: true, message });
const validText = (v: unknown, max: number) => v === undefined || v === null || (typeof v === "string" && v.trim().length <= max);
const validFolderUrl = (v: unknown) => validText(v, 1000) && (v === undefined || v === null || String(v).trim() === "" || /^https:\/\/familienhelden2025-my\.sharepoint\.com\//i.test(String(v).trim()));
const validStatus = (v: unknown) => v === undefined || v === null || ["Kunde", "Privat", "Zuordnung prüfen"].includes(String(v));
const validDate = (v: unknown) => v === undefined || v === null || v === "" || (typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v) && Number.isFinite(Date.parse(`${v}T00:00:00.000Z`)) && new Date(`${v}T00:00:00.000Z`).toISOString().slice(0,10) === v);
const validFollowUpAt = (v: unknown) => v === undefined || v === null || v === "" || (typeof v === "string" && validDate(v.trim()));
const validAuthorityStatus = (v: unknown) => v === undefined || v === null || ["Ungeprüft", "Vorhanden", "Fehlt", "Widerrufen"].includes(String(v));
const validContractStatus = (v: unknown) => v === undefined || v === null || ["Ungeprüft", "Antrag", "Aktiv", "Gekündigt", "Beendet"].includes(String(v));

export async function runKratosTool(name: string, a: Json, actor: string, bindings: KratosToolBindings) {
  const db = bindings.DB;
  if (!db) return fail("CRM-Datenbank ist nicht verfügbar.");
  if (storedDocumentTools.some((tool) => tool.name === name)) return runStoredDocumentTool(db, bindings.BUCKET, name, a, actor);
  if (["list_customer_documents","prepare_consultation_filing"].includes(name)) {
    const id=Number(a.customer_id);
    if (!Number.isInteger(id)||id<1) return fail("Gültige Kunden-ID erforderlich.");
    if (a.category!==undefined&&!documentCategories.includes(a.category as typeof documentCategories[number])) return fail("Ungültige Dokumentart.");
    const result=await listCustomerDocuments(db,id,a.category as string|undefined);
    if (name==="list_customer_documents"||result.isError) return result;
    return {...result, category_folders:categoryFolders, workflow:["Kundenidentität und Mappe prüfen", "Anhänge einzeln klassifizieren; gemischte PDFs trennen, Original erhalten", "Zielordner über SharePoint verifizieren oder anlegen", "Jede Datei ohne Überschreiben hochladen", "Nur erfolgreich gespeicherte Dateien mit register_customer_document registrieren", "Gespeicherte Dateien und offene Punkte getrennt berichten"], note:"Nur ein Ablageplan. Noch keine Datei hochgeladen. Bei unklarer Zuordnung nachfragen."};
  }
  if (name==="register_customer_document") return registerCustomerDocument(db,a,actor);
  if (name === "list_follow_ups") {
    const date = str(a.through_date);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(`${date}T00:00:00Z`)) || new Date(`${date}T00:00:00Z`).toISOString().slice(0,10) !== date) return fail("Gültiges Datum im Format YYYY-MM-DD erforderlich.");
    const limit = a.limit === undefined ? 25 : Number(a.limit);
    if (!Number.isInteger(limit) || limit < 1 || limit > 100) return fail("Limit muss zwischen 1 und 100 liegen.");
    const where = "next_follow_up_at IS NOT NULL AND date(next_follow_up_at) IS NOT NULL AND date(next_follow_up_at)<=?";
    const count = await db.prepare(`SELECT count(*) AS total FROM customers WHERE ${where}`).bind(date).first<{total:number}>();
    const rows = await db.prepare(`SELECT id,first_name,last_name,adviser,folder_url,next_follow_up_at,next_follow_up_note FROM customers WHERE ${where} ORDER BY next_follow_up_at,id LIMIT ?`).bind(date,limit).all();
    return { total: count?.total ?? 0, returned: rows.results.length, through_date: date, timezone: "Europe/Berlin", customers: rows.results };
  }
  if (name === "get_document_lookup") {
    const id = Number(a.customer_id);
    const terms: Record<string,string[]> = { Vollmacht: ["Vollmacht", "VM"], Vertrag: ["Vertrag", "Polizze", "Police"], Antrag: ["Antrag"], Beratungsprotokoll: ["Beratungsprotokoll", "Beratung"], Schaden: ["Schaden", "Unfall"], Schriftverkehr: ["Schriftverkehr", "Korrespondenz"], Sonstiges: [] };
    const kind = str(a.document_type);
    if (!Number.isInteger(id) || id < 1 || !Object.hasOwn(terms,kind)) return fail("Gültige CRM-ID und Dokumentart erforderlich.");
    const row = await db.prepare("SELECT id,first_name,last_name,folder_name,folder_url FROM customers WHERE id=?").bind(id).first<{id:number;first_name:string;last_name:string;folder_name:string|null;folder_url:string|null}>();
    if (!row) return fail("Kunde nicht gefunden.");
    if (!row.folder_name || !row.folder_url || !validFolderUrl(row.folder_url)) return fail("Keine bestätigte OneDrive-Kundenmappe vorhanden; Zuordnung zuerst prüfen.");
    return { customer: row, document_type: kind, search_terms: terms[kind], inventory_verified: false, next_step: "Mit SharePoint ausschließlich diese Kundenmappe einschließlich Unterordnern prüfen. Dateitreffer verifizieren, bevor ein Download oder eine Weiterleitung angeboten wird." };
  }
  if (name === "search_customers") {
    const q = str(a.query).normalize("NFC");
    if (q.length < 2 || q.length > 100) return fail("Suchtext muss 2 bis 100 Zeichen lang sein.");
    const limit = Number(a.limit ?? 15), offset = Number(a.offset ?? 0);
    if (!Number.isInteger(limit) || limit < 1 || limit > 25 || !Number.isInteger(offset) || offset < 0 || offset > 10000) return fail("Limit muss 1 bis 25 und Offset 0 bis 10000 sein.");
    const cleanQuery = q.replace(/[^\p{L}\p{N}@.+-]/gu, " ").trim();
    const terms = cleanQuery.split(/\s+/).filter(Boolean);
    if (!terms.length) return fail("Suchtext enthält keine durchsuchbaren Zeichen.");
    const like = (value:string) => "%" + foldKratosSearchText(value).replace(/[\\%_]/g, "\\$&") + "%";
    const fullLike = like(cleanQuery);
    let where: string;
    let bindings: string[];
    const phoneDigits = q.replace(/\D/g, "");
    if (q.includes("@")) {
      where = kratosSearchColumn("email") + " LIKE ? ESCAPE '\\'";
      bindings = [like(q)];
    } else if (phoneDigits.length >= 6 && /^[+\d\s()./-]+$/.test(q)) {
      const normalizedPhone = "replace(replace(replace(replace(replace(replace(replace(phone,' ',''),'+',''),'-',''),'(',''),')',''),'/',''),'.','')";
      where = normalizedPhone + " LIKE ?";
      bindings = ["%" + phoneDigits + "%"];
    } else if (terms.length > 1) {
      const nameMatch = terms.map(() => "(" + kratosSearchColumn("first_name") + " LIKE ? ESCAPE '\\' OR " + kratosSearchColumn("last_name") + " LIKE ? ESCAPE '\\')").join(" AND ");
      where = "(" + nameMatch + " OR " + kratosSearchColumn("adviser") + " LIKE ? ESCAPE '\\' OR " + kratosSearchColumn("status") + " LIKE ? ESCAPE '\\')";
      bindings = terms.flatMap((term) => [like(term), like(term)]).concat(fullLike, fullLike);
    } else {
      const searchable = ["first_name", "last_name", "email", "adviser", "status"] as const;
      where = "(" + searchable.map((column) => kratosSearchColumn(column) + " LIKE ? ESCAPE '\\'").join(" OR ") + " OR phone LIKE ? ESCAPE '\\')";
      bindings = searchable.map(() => fullLike).concat(fullLike);
    }
    const count = await db.prepare("SELECT count(*) AS total FROM customers WHERE " + where).bind(...bindings).first();
    const rows = await db.prepare("SELECT id,first_name,last_name,status,adviser,phone,email FROM customers WHERE " + where + " ORDER BY last_name,first_name,id LIMIT ? OFFSET ?")
      .bind(...bindings, limit, offset).all<{id:number;first_name:string;last_name:string;status:string;adviser:string|null;phone:string|null;email:string|null}>();
    const total = Number(count?.total ?? 0);
    const hasMore = offset + rows.results.length < total;
    const queryLower = foldKratosSearchText(cleanQuery), termsLower = terms.map(foldKratosSearchText);
    const customers = rows.results.map((row) => {
      const first = foldKratosSearchText(row.first_name), last = foldKratosSearchText(row.last_name);
      const adviser = foldKratosSearchText(row.adviser ?? ""), status = foldKratosSearchText(row.status);
      const email = foldKratosSearchText(row.email ?? ""), phone = row.phone?.replace(/\D/g, "") ?? "";
      const matchedBy: string[] = [];
      if (q.includes("@")) { if (email.includes(q.toLocaleLowerCase("de-DE"))) matchedBy.push("email"); }
      else if (phoneDigits.length >= 6 && /^[+\d\s()./-]+$/.test(q)) { if (phone.includes(phoneDigits)) matchedBy.push("phone"); }
      else if (termsLower.length > 1) {
        if (termsLower.every((term) => first.includes(term) || last.includes(term))) matchedBy.push("name");
        if (adviser.includes(queryLower)) matchedBy.push("adviser");
        if (status.includes(queryLower)) matchedBy.push("status");
      } else {
        const term = termsLower[0];
        if (first.includes(term) || last.includes(term)) matchedBy.push("name");
        if (phoneDigits.length >= 3 && phone.includes(phoneDigits)) matchedBy.push("phone");
        if (email.includes(queryLower)) matchedBy.push("email");
        if (adviser.includes(queryLower)) matchedBy.push("adviser");
        if (status.includes(queryLower)) matchedBy.push("status");
      }
      return { id: row.id, first_name: row.first_name, last_name: row.last_name, status: row.status, adviser: row.adviser, matched_by: matchedBy };
    });
    return { count: customers.length, total_count: total, offset, has_more: hasMore, next_offset: hasMore ? offset + customers.length : null, customers, document_lookup: "Bei Dokumentfragen die passende OneDrive-Mappe Kunden/<folder_name> mit dem SharePoint-Plugin gezielt durchsuchen; nur angefragte Dateien abrufen." };
  }
  if (name === "get_customer") {
    const id = Number(a.customer_id);
    if (!Number.isInteger(id) || id < 1) return fail("Ungültige customer_id.");
    const allowed = ["first_name", "last_name", "phone", "email", "birthday", "authority_status", "adviser", "status", "folder_name", "folder_url", "internal_note", "last_contact_at", "next_follow_up_at", "next_follow_up_note", "created_at", "updated_at", "updated_by"];
    if (a.fields !== undefined && (!Array.isArray(a.fields) || a.fields.length < 1 || a.fields.length > allowed.length || a.fields.some((field) => typeof field !== "string" || !allowed.includes(field)) || new Set(a.fields).size !== a.fields.length)) return fail("Ungültige Feldliste für den Kundenabruf.");
    const fields = a.fields === undefined ? allowed : a.fields as string[];
    const columns = ["id", ...fields].join(",");
    const row = await db.prepare("SELECT " + columns + " FROM customers WHERE id = ?").bind(id).first();
    return row ?? fail("Kunde nicht gefunden.");
  }
  if (name === "create_customer") {
    if (Object.hasOwn(a,"folder_url")) return fail("Kundenordner-URLs ausschließlich nach Prüfung über sync_folder_links speichern.");
    const first = str(a.first_name), last = str(a.last_name);
    if (!first || !last) return fail("Vor- und Nachname sind erforderlich.");
    if (first.length > 100 || last.length > 100 || !validText(a.phone, 50) || !validText(a.email, 254) || !validDate(a.birthday) || !validAuthorityStatus(a.authority_status) || !validText(a.adviser, 100) || !validText(a.folder_name, 200) || !validFolderUrl(a.folder_url) || !validText(a.internal_note, 500) || !validText(a.next_follow_up_at, 30) || !validFollowUpAt(a.next_follow_up_at) || !validText(a.next_follow_up_note, 300) || !validStatus(a.status)) return fail("Ungültige Felder oder Status; Wiedervorlage muss ein gültiges ISO-Datum YYYY-MM-DD sein.");
    const phone = opt(a.phone);
    const email = opt(a.email);
    const sameName = await db.prepare("SELECT id,first_name,last_name,phone,email FROM customers WHERE lower(first_name)=lower(?) AND lower(last_name)=lower(?) ORDER BY id LIMIT 10")
      .bind(first, last).all<{id:number;first_name:string;last_name:string;phone:string|null;email:string|null}>();
    const duplicate = findPotentialCustomerDuplicate({ first_name:first, last_name:last, phone, email },sameName.results);
    if (duplicate) return fail(`Möglicher Dublettentreffer vorhanden (CRM-ID ${duplicate.id}); bitte erst prüfen.`);
    const now = new Date().toISOString();
    const results = await db.batch([
      db.prepare("INSERT INTO customers (first_name,last_name,phone,email,birthday,authority_status,adviser,status,folder_name,folder_url,internal_note,next_follow_up_at,next_follow_up_note,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .bind(first, last, phone, email, opt(a.birthday), opt(a.authority_status) ?? "Ungeprüft", opt(a.adviser), opt(a.status) ?? "Kunde", opt(a.folder_name), opt(a.folder_url), opt(a.internal_note), opt(a.next_follow_up_at), opt(a.next_follow_up_note), now, actor),
      db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) SELECT last_insert_rowid(),?,?,?")
        .bind("create", JSON.stringify(Object.keys(a)), actor),
    ]);
    const id = Number(results[0].meta.last_row_id);
    return await db.prepare("SELECT * FROM customers WHERE id=?").bind(id).first();
  }
  if (name === "update_customer") {
    const id = Number(a.customer_id);
    if (!Number.isInteger(id) || id < 1) return fail("Ungültige customer_id.");
    if (Object.hasOwn(a,"folder_url")) return fail("Kundenordner-URLs ausschließlich nach Prüfung über sync_folder_links speichern.");
    const fieldMap: Record<string, string> = { first_name: "first_name", last_name: "last_name", phone: "phone", email: "email", birthday: "birthday", authority_status: "authority_status", adviser: "adviser", status: "status", folder_name: "folder_name", folder_url: "folder_url", internal_note: "internal_note", last_contact_at: "last_contact_at", next_follow_up_at: "next_follow_up_at", next_follow_up_note: "next_follow_up_note" };
    let fields = Object.keys(fieldMap).filter((k) => Object.hasOwn(a, k));
    if (!fields.length) return fail("Keine änderbaren Felder übergeben.");
    const limits: Record<string, number> = { first_name: 100, last_name: 100, phone: 50, email: 254, birthday: 10, authority_status: 30, adviser: 100, status: 30, folder_name: 200, folder_url: 1000, internal_note: 500, last_contact_at: 30, next_follow_up_at: 30, next_follow_up_note: 300 };
    if (fields.some((k) => !validText(a[k], limits[k])) || (Object.hasOwn(a,"first_name") && !str(a.first_name)) || (Object.hasOwn(a,"last_name") && !str(a.last_name)) || !validDate(a.birthday) || !validAuthorityStatus(a.authority_status) || !validFollowUpAt(a.next_follow_up_at) || !validFolderUrl(a.folder_url) || !validStatus(a.status)) return fail("Ungültige Felder oder Status; Wiedervorlage muss ein gültiges ISO-Datum YYYY-MM-DD sein.");
    const current = await db.prepare("SELECT id,first_name,last_name,phone,email,folder_name FROM customers WHERE id=?").bind(id).first<{id:number;first_name:string;last_name:string;phone:string|null;email:string|null;folder_name:string|null}>();
    if (!current) return fail("Kunde nicht gefunden.");
    // A folder label change invalidates the old URL unless a newly verified URL is supplied with it.
    if (Object.hasOwn(a,"folder_name") && opt(a.folder_name) !== current.folder_name && !Object.hasOwn(a,"folder_url")) fields = [...fields,"folder_url"];
    if (fields.some(k => ["first_name","last_name","phone","email"].includes(k))) {
      const first = Object.hasOwn(a,"first_name") ? str(a.first_name) : current.first_name;
      const last = Object.hasOwn(a,"last_name") ? str(a.last_name) : current.last_name;
      const phone = Object.hasOwn(a,"phone") ? opt(a.phone) : current.phone;
      const email = Object.hasOwn(a,"email") ? opt(a.email) : current.email;
      const sameName = await db.prepare("SELECT id,first_name,last_name,phone,email FROM customers WHERE lower(first_name)=lower(?) AND lower(last_name)=lower(?) AND id<>? ORDER BY id LIMIT 10")
        .bind(first,last,id).all<{id:number;first_name:string;last_name:string;phone:string|null;email:string|null}>();
      const duplicate = findPotentialCustomerDuplicate({ id,first_name:first,last_name:last,phone,email },sameName.results);
      if (duplicate) return fail(`Möglicher Dublettentreffer vorhanden (CRM-ID ${duplicate.id}); Änderung wurde nicht gespeichert.`);
    }
    const now = new Date().toISOString();
    const sets = fields.map((k) => `${fieldMap[k]}=?`).concat(["updated_at=?", "updated_by=?"]);
    const values = fields.map((k) => opt(a[k]));
    await db.batch([
      db.prepare(`UPDATE customers SET ${sets.join(",")} WHERE id=?`).bind(...values, now, actor, id),
      db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(id, "update", JSON.stringify(fields), actor),
    ]);
    return await db.prepare("SELECT * FROM customers WHERE id=?").bind(id).first();
  }
  if (name === "list_customer_contracts") {
    const customerId = Number(a.customer_id);
    if (!Number.isInteger(customerId) || customerId < 1) return fail("Gültige Kunden-ID erforderlich.");
    const customer = await db.prepare("SELECT id FROM customers WHERE id=?").bind(customerId).first();
    if (!customer) return fail("Kunde nicht gefunden.");
    const rows = await db.prepare("SELECT id,customer_id,insurance_type,provider,status,start_date,end_date,cancellation_deadline,document_url,created_at,updated_at FROM customer_contracts WHERE customer_id=? ORDER BY COALESCE(end_date,'9999-12-31'),id").bind(customerId).all();
    return { customer_id: customerId, count: rows.results.length, contracts: rows.results };
  }
  if (name === "create_customer_contract") {
    const customerId = Number(a.customer_id), insuranceType = str(a.insurance_type);
    if (!Number.isInteger(customerId) || customerId < 1 || !insuranceType || insuranceType.length > 100 || !validText(a.provider, 100) || !validContractStatus(a.status) || !validDate(a.start_date) || !validDate(a.end_date) || !validDate(a.cancellation_deadline) || !validFolderUrl(a.document_url)) return fail("Ungültige Kunden-ID, Vertragsart, Status, Datumsangabe oder Dokument-URL.");
    const customer = await db.prepare("SELECT id,folder_url FROM customers WHERE id=?").bind(customerId).first<{id:number;folder_url:string|null}>();
    if (!customer) return fail("Kunde nicht gefunden; Vertrag wurde nicht angelegt.");
    const provider = opt(a.provider), startDate = opt(a.start_date), endDate = opt(a.end_date);
    if (startDate && endDate && startDate > endDate) return fail("Vertragsbeginn liegt nach dem Vertragsende.");
    const documentUrl = opt(a.document_url);
    if (documentUrl && (!customer.folder_url || !belongsToCustomer(documentUrl,customer.folder_url))) return fail("Das Vertragsdokument liegt nicht in der bestätigten Kundenmappe.");
    const duplicate = await db.prepare("SELECT id FROM customer_contracts WHERE customer_id=? AND lower(insurance_type)=lower(?) AND lower(COALESCE(provider,''))=lower(COALESCE(?,'')) AND COALESCE(start_date,'')=COALESCE(?, '') AND COALESCE(end_date,'')=COALESCE(?, '') LIMIT 1")
      .bind(customerId, insuranceType, provider, startDate, endDate).first<{id:number}>();
    if (duplicate) return fail(`Möglicher Vertragsdubletten-Treffer (Vertrags-ID ${duplicate.id}); bitte erst prüfen.`);
    const now = new Date().toISOString();
    const results = await db.batch([
      db.prepare("INSERT INTO customer_contracts (customer_id,insurance_type,provider,status,start_date,end_date,cancellation_deadline,document_url,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)")
        .bind(customerId, insuranceType, provider, opt(a.status) ?? "Ungeprüft", startDate, endDate, opt(a.cancellation_deadline), documentUrl, now, actor),
      db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)")
        .bind(customerId, "contract_create", JSON.stringify(["contract_id", ...Object.keys(a).filter(k => k !== "customer_id")]), actor),
    ]);
    const contractId = Number(results[0].meta.last_row_id);
    return await db.prepare("SELECT id,customer_id,insurance_type,provider,status,start_date,end_date,cancellation_deadline,document_url,created_at,updated_at FROM customer_contracts WHERE id=?").bind(contractId).first();
  }
  if (name === "update_customer_contract") {
    const contractId = Number(a.contract_id);
    if (!Number.isInteger(contractId) || contractId < 1) return fail("Ungültige Vertrags-ID.");
    const fieldMap: Record<string,string> = { insurance_type: "insurance_type", provider: "provider", status: "status", start_date: "start_date", end_date: "end_date", cancellation_deadline: "cancellation_deadline", document_url: "document_url" };
    const fields = Object.keys(fieldMap).filter(k => Object.hasOwn(a,k));
    if (!fields.length) return fail("Keine änderbaren Vertragsfelder übergeben.");
    const limits: Record<string,number> = { insurance_type: 100, provider: 100, status: 30, start_date: 10, end_date: 10, cancellation_deadline: 10, document_url: 1000 };
    if (fields.some(k => !validText(a[k],limits[k])) || !validContractStatus(a.status) || !validDate(a.start_date) || !validDate(a.end_date) || !validDate(a.cancellation_deadline) || !validFolderUrl(a.document_url) || (Object.hasOwn(a,"insurance_type") && !str(a.insurance_type))) return fail("Ungültige Vertragsart, Status, Datumsangabe oder Dokument-URL.");
    const current = await db.prepare("SELECT cc.id,cc.customer_id,cc.insurance_type,cc.provider,cc.start_date,cc.end_date,c.folder_url FROM customer_contracts cc JOIN customers c ON c.id=cc.customer_id WHERE cc.id=?").bind(contractId).first<{id:number;customer_id:number;insurance_type:string;provider:string|null;start_date:string|null;end_date:string|null;folder_url:string|null}>();
    if (!current) return fail("Vertrag nicht gefunden.");
    if (Object.hasOwn(a,"document_url") && opt(a.document_url) && (!current.folder_url || !belongsToCustomer(opt(a.document_url)!,current.folder_url))) return fail("Das Vertragsdokument liegt nicht in der bestätigten Kundenmappe.");
    const mergedStartDate = Object.hasOwn(a,"start_date") ? opt(a.start_date) : current.start_date;
    const mergedEndDate = Object.hasOwn(a,"end_date") ? opt(a.end_date) : current.end_date;
    if (mergedStartDate && mergedEndDate && mergedStartDate > mergedEndDate) return fail("Vertragsbeginn liegt nach dem Vertragsende.");
    if (fields.some(k => ["insurance_type","provider","start_date","end_date"].includes(k))) {
      const mergedInsuranceType = Object.hasOwn(a,"insurance_type") ? str(a.insurance_type) : current.insurance_type;
      const mergedProvider = Object.hasOwn(a,"provider") ? opt(a.provider) : current.provider;
      const duplicate = await db.prepare("SELECT id FROM customer_contracts WHERE customer_id=? AND id<>? AND lower(insurance_type)=lower(?) AND lower(COALESCE(provider,''))=lower(COALESCE(?,'')) AND COALESCE(start_date,'')=COALESCE(?, '') AND COALESCE(end_date,'')=COALESCE(?, '') LIMIT 1")
        .bind(current.customer_id,contractId,mergedInsuranceType,mergedProvider,mergedStartDate,mergedEndDate).first<{id:number}>();
      if (duplicate) return fail(`Möglicher Vertragsdubletten-Treffer (Vertrags-ID ${duplicate.id}); Änderung wurde nicht gespeichert.`);
    }
    const now = new Date().toISOString();
    const sets = fields.map(k => `${fieldMap[k]}=?`).concat(["updated_at=?","updated_by=?"]);
    const values = fields.map(k => opt(a[k]));
    await db.batch([
      db.prepare(`UPDATE customer_contracts SET ${sets.join(",")} WHERE id=?`).bind(...values,now,actor,contractId),
      db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(current.customer_id,"contract_update",JSON.stringify(fields),actor),
    ]);
    return await db.prepare("SELECT id,customer_id,insurance_type,provider,status,start_date,end_date,cancellation_deadline,document_url,created_at,updated_at FROM customer_contracts WHERE id=?").bind(contractId).first();
  }
  if (name === "sync_folder_links") {
    const links = Array.isArray(a.links) ? a.links as Json[] : [];
    if (links.length < 1 || links.length > 120) return fail("Der Linkabgleich muss 1 bis 120 Zuordnungen enthalten.");
    const rows = links.map((link) => ({ id: Number(link.customer_id), folder: str(link.folder_name), url: str(link.folder_url) }));
    if (rows.some((row) => !Number.isInteger(row.id) || row.id < 1 || !row.folder || row.folder.length > 200 || !row.url || !validFolderUrl(row.url)) || new Set(rows.map((row) => row.id)).size !== rows.length) return fail("Ungültiger OneDrive-Link oder doppelte CRM-ID; es wurde nichts geändert.");
    const current = await db.prepare("SELECT id,folder_name FROM customers").all<{id:number;folder_name:string|null}>();
    const folders = new Map(current.results.map((row) => [row.id, row.folder_name]));
    if (rows.some((row) => folders.get(row.id) !== row.folder)) return fail("Mindestens eine CRM-ID passt nicht exakt zum angegebenen Kundenordner; es wurde nichts geändert.");
    const now = new Date().toISOString();
    const statements: D1PreparedStatement[] = [];
    for (const row of rows) {
      statements.push(db.prepare("UPDATE customers SET folder_url=?,updated_at=?,updated_by=? WHERE id=? AND folder_name=?").bind(row.url, now, actor, row.id, row.folder));
      statements.push(db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) VALUES (?,?,?,?)").bind(row.id, "folder_link_sync", JSON.stringify(["folder_url"]), actor));
    }
    for (let i=0;i<statements.length;i+=80) await db.batch(statements.slice(i,i+80));
    return { updated: rows.length, unmatched: 0, document_contents_read: false };
  }
  if (name === "import_customers") {
    const rows = Array.isArray(a.customers) ? a.customers as Json[] : null;
    if (!rows || rows.length > 120) return fail("Import akzeptiert maximal 120 Datensätze.");
    let inserted = 0, duplicates = 0, skipped = 0;
    const existingRows = await db.prepare("SELECT first_name,last_name,phone FROM customers").all<{first_name:string;last_name:string;phone:string|null}>();
    const seen: { first_name:string; last_name:string; phone:string|null; email:null }[] = existingRows.results.map(r => ({ ...r,email:null }));
    const statements: D1PreparedStatement[] = [];
    for (const row of rows) {
      const first = str(row.first_name), last = str(row.last_name), phone = opt(row.phone);
      if (!first || !last || first.length > 100 || last.length > 100 || !validText(phone, 50) || !validText(row.adviser, 100) || !validText(row.folder_name, 200) || (row.status !== undefined && row.status !== "Kunde")) { skipped++; continue; }
      if (findPotentialCustomerDuplicate({first_name:first,last_name:last,phone},seen)) { duplicates++; continue; }
      seen.push({first_name:first,last_name:last,phone,email:null});
      const now = new Date().toISOString();
      statements.push(db.prepare("INSERT INTO customers (first_name,last_name,phone,adviser,status,folder_name,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?)")
        .bind(first, last, phone, opt(row.adviser), "Kunde", opt(row.folder_name) ?? `${first} ${last}`, now, actor));
      statements.push(db.prepare("INSERT INTO audit_events (customer_id,action,changed_fields,actor_email) SELECT last_insert_rowid(),'import',?,? ").bind(JSON.stringify(Object.keys(row)), actor));
    }
    for (let i=0; i<statements.length; i+=80) await db.batch(statements.slice(i, i+80));
    inserted = statements.length / 2;
    return { inserted, duplicates, skipped, total_received: rows.length };
  }
  return fail("Unbekanntes Tool.");
}


