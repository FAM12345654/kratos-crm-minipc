export const contractVerificationStatuses = ["unverified", "verified", "review_required"] as const;
export const contractLifecycles = ["current", "former", "unverified"] as const;
export const contractNoticePeriodUnits = ["days", "weeks", "months", "years"] as const;
export const contractStatuses = ["Ungeprüft", "Antrag", "Aktiv", "Gekündigt", "Beendet"] as const;

export const contractReviewableFields = [
  "insuranceType",
  "provider",
  "policyNumber",
  "status",
  "startDate",
  "endDate",
  "cancellationDeadline",
  "conclusionDate",
  "conclusionYear",
  "mainDueDate",
  "durationMonths",
  "noticePeriodCount",
  "noticePeriodUnit",
  "nextEligibleTerminationDate",
  "latestNoticeReceiptDate",
  "jurisdiction",
] as const;

type NoticePeriodUnit = typeof contractNoticePeriodUnits[number];
type VerificationStatus = typeof contractVerificationStatuses[number];
type ContractLifecycle = typeof contractLifecycles[number];
type ReviewableField = typeof contractReviewableFields[number];

export type ContractMetadataInput = {
  id?: unknown;
  customerId?: unknown;
  insuranceType?: unknown;
  provider?: unknown;
  policyNumber?: unknown;
  status?: unknown;
  startDate?: unknown;
  endDate?: unknown;
  cancellationDeadline?: unknown;
  conclusionDate?: unknown;
  conclusionYear?: unknown;
  mainDueDate?: unknown;
  durationMonths?: unknown;
  noticePeriodCount?: unknown;
  noticePeriodUnit?: unknown;
  nextEligibleTerminationDate?: unknown;
  latestNoticeReceiptDate?: unknown;
  jurisdiction?: unknown;
  verificationStatus?: unknown;
  sourceReference?: unknown;
  verifiedFields?: unknown;
  verifiedBy?: unknown;
  verifiedAt?: unknown;
  lifecycle?: unknown;
  replacementContractId?: unknown;
};

type EvidenceDocument = { id?: unknown; customerId?: unknown } | null | undefined;
type ReplacementContract = {
  id?: unknown;
  customerId?: unknown;
  verificationStatus?: unknown;
  sourceReference?: unknown;
  verifiedFields?: unknown;
  verifiedBy?: unknown;
  verifiedAt?: unknown;
} | null | undefined;

export type ContractReviewContext = {
  reviewConfirmed?: boolean;
  sourceDocument?: EvidenceDocument;
  replacementContract?: ReplacementContract;
  replacementSourceDocument?: EvidenceDocument;
};

// These checks validate recorded facts and explicit review metadata only. They do not inspect document bytes,
// determine whether an insurance term is legally effective, or calculate any statutory/contractual deadline.

function isEmpty(value: unknown): boolean {
  return value === undefined || value === null || value === "";
}

export function isIsoCalendarDate(value: unknown): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function isIsoDateTime(value: unknown): value is string {
  if (typeof value !== "string" || value.length > 50 || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/.test(value)) return false;
  return Number.isFinite(Date.parse(value));
}

function validPositiveInteger(value: unknown): boolean {
  return Number.isSafeInteger(value) && Number(value) > 0;
}

function hasEvidence(evidence: EvidenceDocument, referenceId: unknown, customerId: unknown): boolean {
  return Boolean(evidence && Number(evidence.id) === Number(referenceId) && Number(evidence.customerId) === Number(customerId));
}

function reviewedFieldList(value: unknown): ReviewableField[] | null {
  if (!Array.isArray(value) || value.length === 0 || value.some((field) => typeof field !== "string" || !contractReviewableFields.includes(field as ReviewableField))) return null;
  if (new Set(value).size !== value.length) return null;
  return value as ReviewableField[];
}

function validateEvidence(input: ContractMetadataInput, context: ContractReviewContext, errors: string[], prefix = "") {
  const sourceReference = input.sourceReference;
  const verifiedFields = reviewedFieldList(input.verifiedFields);
  if (!validPositiveInteger(sourceReference)) errors.push(`${prefix}sourceReference muss auf ein registriertes Kunden-Dokument verweisen.`);
  if (!hasEvidence(context.sourceDocument, sourceReference, input.customerId)) errors.push(`${prefix}Quellbeleg muss zum Vertragskunden und zur Referenz passen.`);
  if (context.reviewConfirmed !== true) errors.push(`${prefix}Explizite Feldprüfung muss bestätigt sein.`);
  if (!verifiedFields) errors.push(`${prefix}verifiedFields muss mindestens ein eindeutiges, erlaubtes Feld enthalten.`);
  else {
    const missing = contractReviewableFields.filter((field) => !isEmpty(input[field]) && !verifiedFields.includes(field));
    if (missing.length) errors.push(`${prefix}Prüffelder fehlen: ${missing.join(", ")}.`);
  }
  if (typeof input.verifiedBy !== "string" || !input.verifiedBy.trim() || input.verifiedBy.length > 254) errors.push(`${prefix}verifiedBy ist erforderlich.`);
  if (!isIsoDateTime(input.verifiedAt)) errors.push(`${prefix}verifiedAt muss ein ISO-Zeitpunkt sein.`);
}

export function validateContractMetadata(input: ContractMetadataInput, context: ContractReviewContext = {}) {
  const errors: string[] = [];
  // These are legacy contract columns: when supplied they must retain the same
  // primitive values and bounds as the existing Kratos API. New metadata fields
  // below remain optional unless a lifecycle/review rule requires them.
  if (input.insuranceType !== undefined && (typeof input.insuranceType !== "string" || !input.insuranceType.trim() || input.insuranceType.length > 100)) errors.push("insuranceType muss ein nicht-leerer Text mit höchstens 100 Zeichen sein.");
  if (input.provider !== undefined && input.provider !== null && (typeof input.provider !== "string" || input.provider.trim().length > 100)) errors.push("provider muss Text mit höchstens 100 Zeichen sein.");
  if (input.status !== undefined && (typeof input.status !== "string" || !contractStatuses.includes(input.status as typeof contractStatuses[number]))) errors.push("status ist ungültig.");

  const dateFields = ["startDate", "endDate", "cancellationDeadline", "conclusionDate", "mainDueDate", "nextEligibleTerminationDate", "latestNoticeReceiptDate"] as const;
  for (const field of dateFields) if (!isEmpty(input[field]) && !isIsoCalendarDate(input[field])) errors.push(`${field} muss ein gültiges Datum im Format YYYY-MM-DD sein.`);

  if (!isEmpty(input.conclusionYear) && (!Number.isInteger(input.conclusionYear) || Number(input.conclusionYear) < 1900 || Number(input.conclusionYear) > 9999)) errors.push("conclusionYear muss eine Jahreszahl zwischen 1900 und 9999 sein.");
  if (isIsoCalendarDate(input.conclusionDate) && !isEmpty(input.conclusionYear) && Number(input.conclusionDate.slice(0, 4)) !== Number(input.conclusionYear)) errors.push("conclusionYear muss mit conclusionDate übereinstimmen.");
  if (!isEmpty(input.durationMonths) && (!Number.isInteger(input.durationMonths) || Number(input.durationMonths) < 1 || Number(input.durationMonths) > 1200)) errors.push("durationMonths muss zwischen 1 und 1200 liegen.");
  if (!isEmpty(input.noticePeriodCount) && (!Number.isInteger(input.noticePeriodCount) || Number(input.noticePeriodCount) < 1 || Number(input.noticePeriodCount) > 1200)) errors.push("noticePeriodCount muss zwischen 1 und 1200 liegen.");
  if (!isEmpty(input.noticePeriodUnit) && !contractNoticePeriodUnits.includes(input.noticePeriodUnit as NoticePeriodUnit)) errors.push("noticePeriodUnit ist ungültig.");
  if (isEmpty(input.noticePeriodCount) !== isEmpty(input.noticePeriodUnit)) errors.push("noticePeriodCount und noticePeriodUnit müssen gemeinsam angegeben werden.");

  const verificationStatus = isEmpty(input.verificationStatus) ? "unverified" : input.verificationStatus as VerificationStatus;
  const lifecycle = isEmpty(input.lifecycle) ? "unverified" : input.lifecycle as ContractLifecycle;
  if (!contractVerificationStatuses.includes(verificationStatus)) errors.push("verificationStatus ist ungültig.");
  if (!contractLifecycles.includes(lifecycle)) errors.push("lifecycle ist ungültig.");
  if (!isEmpty(input.jurisdiction) && (typeof input.jurisdiction !== "string" || !input.jurisdiction.trim() || input.jurisdiction.length > 50)) errors.push("jurisdiction darf höchstens 50 Zeichen enthalten.");
  if (!isEmpty(input.policyNumber) && (typeof input.policyNumber !== "string" || input.policyNumber.length > 150)) errors.push("policyNumber darf höchstens 150 Zeichen enthalten.");
  if (!isEmpty(input.replacementContractId) && !validPositiveInteger(input.replacementContractId)) errors.push("replacementContractId muss eine positive ganze Zahl sein.");
  if (!isEmpty(input.id) && !validPositiveInteger(input.id)) errors.push("id muss eine positive ganze Zahl sein.");
  if (!isEmpty(input.customerId) && !validPositiveInteger(input.customerId)) errors.push("customerId muss eine positive ganze Zahl sein.");

  if (verificationStatus === "verified") validateEvidence(input, context, errors);
  if (lifecycle === "current" && verificationStatus !== "verified") errors.push("lifecycle current erfordert einen geprüften Vertragsdatensatz.");
  if (lifecycle === "former") {
    if (verificationStatus !== "verified") errors.push("lifecycle former erfordert einen geprüften Vertragsdatensatz.");
    if (!validPositiveInteger(input.replacementContractId)) errors.push("lifecycle former erfordert einen verknüpften Ersatzvertrag.");
    else if (!isEmpty(input.id) && Number(input.replacementContractId) === Number(input.id)) errors.push("Ein Vertrag kann nicht sich selbst ablösen.");
    const replacement = context.replacementContract;
    const sameCustomer = replacement && Number(replacement.customerId) === Number(input.customerId);
    const correctLink = replacement && Number(replacement.id) === Number(input.replacementContractId);
    if (!sameCustomer || !correctLink || replacement?.verificationStatus !== "verified") errors.push("Ersatzvertrag muss ein anderer, geprüfter Vertrag desselben Kunden sein.");
    if (replacement?.verificationStatus === "verified") {
      const replacementInput: ContractMetadataInput = {
        customerId: replacement.customerId,
        sourceReference: replacement.sourceReference,
        verifiedFields: replacement.verifiedFields,
        verifiedBy: replacement.verifiedBy,
        verifiedAt: replacement.verifiedAt,
      };
      validateEvidence(replacementInput, { reviewConfirmed: true, sourceDocument: context.replacementSourceDocument }, errors, "Ersatzvertrag: ");
    }
  }

  return { valid: errors.length === 0, errors };
}
