import { listStoredFiles, getStoredFileMetadata, storeUploadedFile } from "./kratos-storage";
import { fetchChatFile } from "./mcp-file-input";

export const storedDocumentTools = [
  { name: "search_stored_customer_files", description: "Search physical files in the private Kratos binary store for one exact customer ID. Returns metadata only and explicit pagination. An empty list does not prove the OneDrive migration is complete. Original OneDrive links remain a separate index.", annotations: { readOnlyHint: true }, inputSchema: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 }, query: { type: "string", maxLength: 200 }, limit: { type: "integer", minimum: 1, maximum: 100 }, offset: { type: "integer", minimum: 0 } }, required: ["customer_id"], additionalProperties: false } },
  { name: "get_stored_customer_file", description: "Get physical-file metadata and the private authenticated download path for an exact Kratos file ID. The link requires the user's Kratos session. This does not read document contents or create a public sharing link. Do not claim file contents were retrieved from metadata alone.", annotations: { readOnlyHint: true }, inputSchema: { type: "object", properties: { file_id: { type: "integer", minimum: 1 } }, required: ["file_id"], additionalProperties: false } },
  { name: "upload_customer_file", description: "Physically save one user-provided ChatGPT attachment to an exact Kratos customer after the user requests filing. Accepts a host file parameter, not an invented URL. Direct Chat uploads are limited to 20 MiB; larger files require the authenticated resumable upload. Never claim success if storage is unavailable or upload fails.", annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false }, _meta: { "openai/fileParams": ["file"] }, inputSchema: { type: "object", properties: { customer_id: { type: "integer", minimum: 1 }, folder_id: { type: "integer", minimum: 1 }, file: { type: "object", properties: { download_url: { type: "string" }, file_id: { type: "string" }, mime_type: { type: "string" }, file_name: { type: "string" } }, required: ["download_url", "file_id"], additionalProperties: false } }, required: ["customer_id", "file"], additionalProperties: false } },
];

export async function runStoredDocumentTool(db: D1Database, bucket: R2Bucket | undefined, name: string, a: Record<string, unknown>, actor: string) {
  const positive = (value: unknown) => Number.isSafeInteger(Number(value)) && Number(value) > 0;
  if (name === "get_stored_customer_file") {
    if (!positive(a.file_id)) return { isError: true, message: "Gültige Datei-ID erforderlich." };
    const file = await getStoredFileMetadata(db, Number(a.file_id));
    if (!file) return { isError: true, message: "Datei nicht gefunden." };
    return { file, download_path: `/api/storage/files/${Number(a.file_id)}`, authentication_required: true, contents_retrieved: false };
  }
  if (!positive(a.customer_id)) return { isError: true, message: "Gültige Kunden-ID erforderlich." };
  if (name === "search_stored_customer_files") return listStoredFiles(db, { customerId: Number(a.customer_id), query: typeof a.query === "string" ? a.query : "", limit: a.limit === undefined ? 25 : Number(a.limit), offset: a.offset === undefined ? 0 : Number(a.offset) });
  if (!bucket) return { isError: true, message: "Privater Binärspeicher ist noch nicht konfiguriert. Keine Datei gespeichert." };
  if (a.folder_id !== undefined && !positive(a.folder_id)) return { isError: true, message: "Ungültige Ordner-ID." };
  const file = await fetchChatFile(a.file);
  return storeUploadedFile(db, bucket, file, { customerId: Number(a.customer_id), folderId: a.folder_id === undefined ? null : Number(a.folder_id) }, actor);
}
