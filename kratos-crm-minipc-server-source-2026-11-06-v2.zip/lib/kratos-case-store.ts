import { createHash } from "node:crypto";
import {
  applyKratosCaseEvent,
  caseEventIdempotencyKey,
  createTodoistPlanProposal,
  createKratosCase,
  currentKratosCaseState,
  toKratosCaseId,
  type KratosCaseEvent,
  type KratosCaseSnapshot,
  type TodoistPlanProposal,
} from "./kratos-case-workflow";

type SqliteRow = Record<string, unknown>;
type SqliteMaybeRow = SqliteRow | undefined;
type SqliteRunResult = { changes: number | bigint; lastInsertRowid?: number | bigint };
type SqliteStatement = {
  get(...params: unknown[]): SqliteMaybeRow;
  all(...params: unknown[]): SqliteRow[];
  run(...params: unknown[]): SqliteRunResult;
};
export type NodeSqliteDatabase = {
  exec(sql: string): unknown;
  prepare(sql: string): SqliteStatement;
};

export type KratosCaseStoreOptions = {
  /** Injected by the authenticated boundary; this is never accepted per operation/event. */
  ownerSubject: string;
  /** Explicit allowlist supplied by trusted application configuration. */
  allowedOwnerSubjects: readonly string[] | ReadonlySet<string>;
  /** Injected by the authenticated boundary; event-supplied actor IDs are ignored. */
  actorId: string;
  /** Exact configured Todoist project ID, if plan proposals are enabled. */
  todoistProjectId?: string;
  now?: () => string;
};

export type StoredKratosCase = { snapshot: KratosCaseSnapshot; version: number };
export type StoredCaseEvent = {
  eventId: string;
  eventType: string;
  payloadFingerprint: string;
  actorId: string;
  appliedVersion: number;
  createdAt: string;
};
export type StoredCaseOutboxAction = {
  actionId: string;
  actionType: "todoist_plan";
  status: "pending_review";
  proposal: TodoistPlanProposal;
  createdAt: string;
};

export class KratosCaseStoreError extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = "KratosCaseStoreError";
    this.code = code;
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function hasOwn(record: object, key: string): boolean {
  return Object.hasOwn(record, key);
}

function stableValue(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableValue).join(",")}]`;
  if (isRecord(value)) return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableValue(value[key])}`).join(",")}}`;
  return JSON.stringify(value) ?? "null";
}

function eventFingerprint(event: KratosCaseEvent): string {
  return createHash("sha256").update(stableValue(event)).digest("hex");
}

function asString(value: unknown): value is string { return typeof value === "string"; }
function isOneOf<T extends string>(value: unknown, allowed: readonly T[]): value is T { return typeof value === "string" && allowed.includes(value as T); }
function isRiskFinding(value: unknown): boolean {
  return typeof value === "string" && ["identity_mismatch", "signature_unclear", "scope_unclear", "recipient_unclear", "attachment_unreadable", "other_review_required"].includes(value);
}

function normalizedRecord<T>(value: unknown, validate: (entry: unknown) => entry is T): Record<string, T> | null {
  if (!isRecord(value)) return null;
  const output = Object.create(null) as Record<string, T>;
  for (const [key, entry] of Object.entries(value)) {
    if (!key || !validate(entry)) return null;
    output[key] = entry;
  }
  return output;
}

function validateSnapshot(value: unknown, expectedCaseId: string): KratosCaseSnapshot | null {
  if (!isRecord(value) || value.caseId !== expectedCaseId || !isOneOf(value.state, ["received", "needs_review", "ready", "partial", "complete"])) return null;
  const assignment = value.customerAssignment;
  if (!isRecord(assignment) || !isOneOf(assignment.status, ["unconfirmed", "ambiguous", "confirmed"])) return null;
  if (assignment.status === "confirmed" && (!Number.isSafeInteger(assignment.customerId) || Number(assignment.customerId) < 1 || !asString(assignment.confirmedBy) || !asString(assignment.eventId))) return null;
  if (!Array.isArray(value.expectedScopeIds) || value.expectedScopeIds.length === 0 || value.expectedScopeIds.some((scope) => !asString(scope) || !scope || scope.trim() !== scope) || new Set(value.expectedScopeIds).size !== value.expectedScopeIds.length) return null;

  const artifacts = normalizedRecord(value.artifacts, (entry): entry is KratosCaseSnapshot["artifacts"][string] => {
    if (!isRecord(entry) || !asString(entry.artifactId) || !isOneOf(entry.kind, ["document", "insurer_response", "authorization"]) || typeof entry.attachmentPresent !== "boolean" || !asString(entry.receivedEventId) || !isOneOf(entry.review, ["pending", "accepted", "needs_review"]) || !Array.isArray(entry.riskFindings) || entry.riskFindings.some((finding) => !isRiskFinding(finding))) return false;
    return true;
  });
  const verifiedRecipientIds = normalizedRecord(value.verifiedRecipientIds, (entry): entry is { verifiedBy: string; eventId: string } => isRecord(entry) && asString(entry.verifiedBy) && asString(entry.eventId));
  const authorizationReviews = normalizedRecord(value.authorizationReviews, (entry): entry is KratosCaseSnapshot["authorizationReviews"][string] => isRecord(entry) && asString(entry.artifactId) && asString(entry.reviewedBy) && isOneOf(entry.validity, ["valid", "invalid", "needs_review"]) && typeof entry.signed === "boolean" && asString(entry.authorizedRecipientId) && asString(entry.eventId));
  const processedEvents = normalizedRecord(value.processedEvents, (entry): entry is string => asString(entry));
  if (!artifacts || Object.entries(artifacts).some(([key, artifact]) => key !== artifact.artifactId) || !verifiedRecipientIds || !authorizationReviews || !processedEvents || !Array.isArray(value.eventOrder) || value.eventOrder.some((event) => !asString(event))) return null;

  let response: KratosCaseSnapshot["insurerResponseReview"] = null;
  if (value.insurerResponseReview !== null) {
    const candidate = value.insurerResponseReview;
    if (!isRecord(candidate) || !asString(candidate.artifactId) || !asString(candidate.eventId) || !asString(candidate.reviewedBy) || !isOneOf(candidate.confirmation, ["confirmed", "unconfirmed", "needs_review"]) || !Array.isArray(candidate.scopeAssessments) || !Array.isArray(candidate.riskFindings) || candidate.riskFindings.some((finding) => !isRiskFinding(finding))) return null;
    if (candidate.scopeAssessments.some((assessment) => !isRecord(assessment) || !asString(assessment.scopeId) || !isOneOf(assessment.outcome, ["satisfied", "outstanding", "unclear"]))) return null;
    response = {
      artifactId: candidate.artifactId,
      eventId: candidate.eventId,
      reviewedBy: candidate.reviewedBy,
      confirmation: candidate.confirmation as "confirmed" | "unconfirmed" | "needs_review",
      scopeAssessments: candidate.scopeAssessments.map((item) => ({ scopeId: (item as { scopeId: string }).scopeId, outcome: (item as { outcome: "satisfied" | "outstanding" | "unclear" }).outcome })),
      riskFindings: [...candidate.riskFindings] as KratosCaseSnapshot["insurerResponseReview"] extends infer R ? R extends { riskFindings: infer F } ? F : never : never,
    };
  }

  const snapshot: KratosCaseSnapshot = {
    caseId: expectedCaseId as KratosCaseSnapshot["caseId"],
    state: value.state as KratosCaseSnapshot["state"],
    customerAssignment: assignment as KratosCaseSnapshot["customerAssignment"],
    expectedScopeIds: [...value.expectedScopeIds] as string[],
    artifacts,
    insurerResponseReview: response,
    verifiedRecipientIds,
    authorizationReviews,
    processedEvents,
    eventOrder: [...value.eventOrder] as string[],
  };
  if (snapshot.state !== currentKratosCaseState(snapshot)) return null;
  return snapshot;
}

function validateAndBindActor(input: unknown, caseId: string, actorId: string): KratosCaseEvent {
  if (!isRecord(input) || input.caseId !== caseId) throw new KratosCaseStoreError("case_id_mismatch", "Case event must reference the requested case.");
  if (!asString(input.eventId) || !input.eventId || input.eventId.trim() !== input.eventId || input.eventId.length > 255) throw new KratosCaseStoreError("invalid_event", "Event ID must be a non-empty exact identifier.");
  const text = (key: string) => asString(input[key]) && Boolean(input[key]) && input[key].trim() === input[key] && input[key].length <= 255;
  const findingsValid = input.riskFindings === undefined || (Array.isArray(input.riskFindings) && input.riskFindings.every(isRiskFinding));
  switch (input.type) {
    case "customer_assignment_confirmed":
      if (!Number.isSafeInteger(input.customerId) || Number(input.customerId) < 1) break;
      return { ...input, actorId } as unknown as KratosCaseEvent;
    case "document_received":
    case "insurer_response_received":
    case "authorization_received":
      if (text("artifactId") && typeof input.attachmentPresent === "boolean" && findingsValid) return { ...input, actorId } as unknown as KratosCaseEvent;
      break;
    case "artifact_reviewed":
      if (text("artifactId") && (input.outcome === "accepted" || input.outcome === "needs_review") && findingsValid) return { ...input, actorId } as unknown as KratosCaseEvent;
      break;
    case "insurer_response_reviewed":
      if (text("artifactId") && isOneOf(input.confirmation, ["confirmed", "unconfirmed", "needs_review"]) && Array.isArray(input.scopeAssessments) && input.scopeAssessments.every((a) => isRecord(a) && textOf(a.scopeId) && isOneOf(a.outcome, ["satisfied", "outstanding", "unclear"])) && findingsValid) return { ...input, actorId } as unknown as KratosCaseEvent;
      break;
    case "recipient_verified":
      if (text("recipientId")) return { ...input, actorId } as unknown as KratosCaseEvent;
      break;
    case "authorization_reviewed":
      if (text("artifactId") && text("authorizedRecipientId") && isOneOf(input.validity, ["valid", "invalid", "needs_review"]) && typeof input.signed === "boolean") return { ...input, actorId } as unknown as KratosCaseEvent;
      break;
    default: throw new KratosCaseStoreError("invalid_event_type", "Unsupported case event type.");
  }
  throw new KratosCaseStoreError("invalid_event", "Case event fields failed runtime validation.");
}

function textOf(value: unknown): boolean { return typeof value === "string" && value.length > 0 && value.trim() === value && value.length <= 255; }

function parseSnapshot(json: unknown, caseId: string): KratosCaseSnapshot {
  if (typeof json !== "string") throw new KratosCaseStoreError("corrupt_snapshot", "Stored case snapshot is not text.");
  let parsed: unknown;
  try { parsed = JSON.parse(json); }
  catch { throw new KratosCaseStoreError("corrupt_snapshot", "Stored case snapshot is invalid JSON."); }
  const snapshot = validateSnapshot(parsed, caseId);
  if (!snapshot) throw new KratosCaseStoreError("corrupt_snapshot", "Stored case snapshot failed structural validation.");
  return snapshot;
}

function validateOutboxProposal(value: TodoistPlanProposal, caseId: string): { actionId: string; json: string } {
  if (!isRecord(value) || value.status !== "explicit-plan" || value.explicitPlan !== true || value.caseId !== caseId || value.taskTitlesMaterialized !== false || value.externalWritePerformed !== false || !Array.isArray(value.taskTemplates) || typeof value.idempotencyKey !== "string" || !value.idempotencyKey.startsWith(caseId + ":") || !value.idempotencyKey.slice(caseId.length + 1) || !hasOwn(value, "taskTemplates")) {
    throw new KratosCaseStoreError("invalid_outbox_proposal", "Only a non-executing explicit workflow plan for this case can be placed in the review outbox.");
  }
  return { actionId: value.idempotencyKey, json: JSON.stringify(value) };
}

function rowNumber(row: SqliteRow, key: string): number {
  const value = row?.[key];
  const number = typeof value === "bigint" ? Number(value) : value;
  if (!Number.isSafeInteger(number)) throw new KratosCaseStoreError("corrupt_case_row", "Stored case version is invalid.");
  return Number(number);
}

/**
 * Node's synchronous SQLite adapter. Store transactions run under BEGIN IMMEDIATE;
 * this adapter is intentionally separate from D1 because D1 batch cannot expose a
 * zero-row CAS as a transaction-aborting exception without a dedicated transaction API.
 */
export class SqliteCaseDatabase {
  constructor(private readonly database: NodeSqliteDatabase) {
    database.exec("PRAGMA foreign_keys = ON");
    database.exec("PRAGMA busy_timeout = 5000");
  }

  transaction<T>(work: () => T): T {
    this.database.exec("BEGIN IMMEDIATE");
    try {
      const result = work();
      this.database.exec("COMMIT");
      return result;
    } catch (error) {
      try { this.database.exec("ROLLBACK"); } catch { /* rollback errors must not hide the original failure */ }
      throw error;
    }
  }

  get(sql: string, ...params: unknown[]): SqliteMaybeRow { return this.database.prepare(sql).get(...params); }
  all(sql: string, ...params: unknown[]): SqliteRow[] { return this.database.prepare(sql).all(...params); }
  run(sql: string, ...params: unknown[]): SqliteRunResult { return this.database.prepare(sql).run(...params); }
}

export class KratosCaseStore {
  private readonly ownerSubject: string;
  private readonly actorId: string;
  private readonly todoistProjectId?: string;
  private readonly now: () => string;

  constructor(private readonly database: SqliteCaseDatabase, options: KratosCaseStoreOptions) {
    if (typeof options.ownerSubject !== "string" || !options.ownerSubject || options.ownerSubject.trim() !== options.ownerSubject || options.ownerSubject.length > 255) {
      throw new KratosCaseStoreError("invalid_owner_subject", "An authenticated owner subject must be injected into the store.");
    }
    const allowed = options.allowedOwnerSubjects instanceof Set ? options.allowedOwnerSubjects : new Set(options.allowedOwnerSubjects);
    if (!allowed.has(options.ownerSubject)) throw new KratosCaseStoreError("owner_not_allowed", "Authenticated owner is not in the configured case-store allowlist.");
    this.ownerSubject = options.ownerSubject;
    if (typeof options.actorId !== "string" || !options.actorId || options.actorId.trim() !== options.actorId || options.actorId.length > 255) throw new KratosCaseStoreError("invalid_actor_id", "A trusted actor identity must be injected into the store.");
    this.actorId = options.actorId;
    this.todoistProjectId = options.todoistProjectId;
    this.now = options.now ?? (() => new Date().toISOString());
  }

  createCase(input: { caseId: string; expectedScopeIds: string[]; assignmentStatus?: "unconfirmed" | "ambiguous" }): StoredKratosCase {
    const snapshot = createKratosCase(input);
    return this.database.transaction(() => {
      const now = this.now();
      try {
        this.database.run("INSERT INTO kratos_cases (owner_subject,case_id,version,snapshot_json,created_at,updated_at) VALUES (?,?,?,?,?,?)", this.ownerSubject, snapshot.caseId, 1, JSON.stringify(snapshot), now, now);
      } catch (error) {
        if (this.database.get("SELECT 1 AS found FROM kratos_cases WHERE owner_subject=? AND case_id=?", this.ownerSubject, snapshot.caseId)) throw new KratosCaseStoreError("case_exists", "A case with this ID already exists for the authenticated owner.");
        throw error;
      }
      return { snapshot, version: 1 };
    });
  }

  getCase(caseIdValue: string): StoredKratosCase | null {
    const caseId = toKratosCaseId(caseIdValue);
    const row = this.database.get("SELECT version,snapshot_json FROM kratos_cases WHERE owner_subject=? AND case_id=?", this.ownerSubject, caseId);
    if (!row) return null;
    return { version: rowNumber(row, "version"), snapshot: parseSnapshot(row.snapshot_json, caseId) };
  }

  applyEvent(input: { caseId: string; expectedVersion: number; event: KratosCaseEvent }): StoredKratosCase & { duplicate: boolean; idempotencyKey: string; outboxActionId: string | null } {
    const caseId = toKratosCaseId(input.caseId);
    if (!Number.isSafeInteger(input.expectedVersion) || input.expectedVersion < 1) throw new KratosCaseStoreError("invalid_expected_version", "Expected case version must be a positive integer.");
    const event = validateAndBindActor(input.event, caseId, this.actorId);
    const fingerprint = eventFingerprint(event);
    const idempotencyKey = caseEventIdempotencyKey(caseId, event.eventId);

    return this.database.transaction(() => {
      const row = this.database.get("SELECT version,snapshot_json FROM kratos_cases WHERE owner_subject=? AND case_id=?", this.ownerSubject, caseId);
      if (!row) throw new KratosCaseStoreError("case_not_found", "Case not found for the authenticated owner.");
      const currentVersion = rowNumber(row, "version");
      const currentSnapshot = parseSnapshot(row.snapshot_json, caseId);
      const priorEvent = this.database.get("SELECT payload_fingerprint FROM kratos_case_events WHERE owner_subject=? AND case_id=? AND event_id=?", this.ownerSubject, caseId, event.eventId);
      if (priorEvent) {
        if (priorEvent.payload_fingerprint !== fingerprint) throw new KratosCaseStoreError("event_id_conflict", "The event ID was already used with different content.");
        const priorOutbox = this.database.get("SELECT action_id FROM kratos_case_outbox WHERE owner_subject=? AND case_id=? AND action_id=?", this.ownerSubject, caseId, idempotencyKey);
        return { snapshot: currentSnapshot, version: currentVersion, duplicate: true, idempotencyKey, outboxActionId: priorOutbox ? String(priorOutbox.action_id) : null };
      }
      if (input.expectedVersion !== currentVersion) throw new KratosCaseStoreError("version_conflict", "Case changed since the supplied expected version.");

      const applied = applyKratosCaseEvent(currentSnapshot, event);
      if (applied.duplicate) throw new KratosCaseStoreError("event_store_mismatch", "Workflow snapshot and durable event ledger disagree.");
      const nextVersion = currentVersion + 1;
      const now = this.now();
      const update = this.database.run("UPDATE kratos_cases SET version=?,snapshot_json=?,updated_at=? WHERE owner_subject=? AND case_id=? AND version=?", nextVersion, JSON.stringify(applied.snapshot), now, this.ownerSubject, caseId, currentVersion);
      if (Number(update.changes) !== 1) throw new KratosCaseStoreError("version_conflict", "Case compare-and-swap did not update exactly one row.");

      this.database.run("INSERT INTO kratos_case_events (owner_subject,case_id,event_id,event_type,payload_fingerprint,actor_id,applied_version,created_at) VALUES (?,?,?,?,?,?,?,?)", this.ownerSubject, caseId, event.eventId, event.type, fingerprint, this.actorId, nextVersion, now);
      const proposed = event.type === "insurer_response_reviewed" ? createTodoistPlanProposal(applied.snapshot, this.todoistProjectId) : null;
      const outbox = proposed?.status === "explicit-plan" ? validateOutboxProposal(proposed, caseId) : null;
      if (outbox) {
        const existing = this.database.get("SELECT case_id,action_type,status,proposal_json FROM kratos_case_outbox WHERE owner_subject=? AND action_id=?", this.ownerSubject, outbox.actionId);
        if (existing) {
          if (existing.case_id !== caseId || existing.action_type !== "todoist_plan" || existing.status !== "pending_review" || existing.proposal_json !== outbox.json) {
            throw new KratosCaseStoreError("outbox_conflict", "Stable outbox action ID already refers to different review content.");
          }
        } else {
          this.database.run("INSERT INTO kratos_case_outbox (owner_subject,case_id,action_id,action_type,status,proposal_json,created_at) VALUES (?,?,?,?,?,?,?)", this.ownerSubject, caseId, outbox.actionId, "todoist_plan", "pending_review", outbox.json, now);
        }
      }
      return { snapshot: applied.snapshot, version: nextVersion, duplicate: false, idempotencyKey, outboxActionId: outbox?.actionId ?? null };
    });
  }

  listEvents(caseIdValue: string): StoredCaseEvent[] {
    const caseId = toKratosCaseId(caseIdValue);
    return this.database.all("SELECT event_id,event_type,payload_fingerprint,actor_id,applied_version,created_at FROM kratos_case_events WHERE owner_subject=? AND case_id=? ORDER BY applied_version", this.ownerSubject, caseId).map((row) => ({
      eventId: String(row.event_id), eventType: String(row.event_type), payloadFingerprint: String(row.payload_fingerprint), actorId: String(row.actor_id), appliedVersion: rowNumber(row, "applied_version"), createdAt: String(row.created_at),
    }));
  }

  listOutbox(caseIdValue: string): StoredCaseOutboxAction[] {
    const caseId = toKratosCaseId(caseIdValue);
    return this.database.all("SELECT action_id,action_type,status,proposal_json,created_at FROM kratos_case_outbox WHERE owner_subject=? AND case_id=? ORDER BY created_at,action_id", this.ownerSubject, caseId).map((row) => {
      let proposal: unknown;
      try { proposal = JSON.parse(String(row.proposal_json)); }
      catch { throw new KratosCaseStoreError("corrupt_outbox", "Stored outbox proposal is invalid JSON."); }
      const checked = validateOutboxProposal(proposal as TodoistPlanProposal, caseId);
      if (checked.actionId !== String(row.action_id) || row.action_type !== "todoist_plan" || row.status !== "pending_review") throw new KratosCaseStoreError("corrupt_outbox", "Stored outbox row failed identity or status validation.");
      return { actionId: String(row.action_id), actionType: "todoist_plan", status: "pending_review", proposal: proposal as TodoistPlanProposal, createdAt: String(row.created_at) };
    });
  }
}
