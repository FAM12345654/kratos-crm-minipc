import { backup, DatabaseSync } from "node:sqlite";
import { lstat, mkdir, open, readFile, readdir, type FileHandle } from "node:fs/promises";
import path from "node:path";
import { assertKratosLocalPath, hashKratosLocalFile, localObjectPath, LOCAL_OBJECT_KEY, KratosLocalDocumentError } from "./kratos-local-document-store";

type Entry = { key: string; size: number; sha256: string };
type Manifest = { schema: 1; complete: true; database: { size: number; sha256: string }; objects: Entry[]; unreferencedObjectCount: number; createdAt: string };
function fail(code: string): never { throw new KratosLocalDocumentError(code); }

async function newDirectory(destination: string): Promise<void> {
  if (!path.isAbsolute(destination) || destination.startsWith("\\\\")) fail("invalid_backup_target");
  await assertKratosLocalPath(path.dirname(path.resolve(destination)), "directory");
  try { await mkdir(destination, { mode: 0o700 }); } catch { fail("backup_target_exists_or_unavailable"); }
  await assertKratosLocalPath(destination, "directory");
}
function notNested(source: string, target: string): void {
  const a = path.resolve(source).toLowerCase(), b = path.resolve(target).toLowerCase();
  if (a === b || a.startsWith(b + path.sep) || b.startsWith(a + path.sep)) fail("backup_target_overlaps_source");
}
function catalog(databasePath: string): Entry[] {
  const db = new DatabaseSync(databasePath, { readOnly: true });
  try {
    const check = db.prepare("PRAGMA quick_check").all();
    if (check.length !== 1 || Object.values(check[0])[0] !== "ok" || db.prepare("PRAGMA foreign_key_check").all().length) fail("backup_database_invalid");
    if (Number(db.prepare("SELECT count(*) AS n FROM storage_files WHERE import_state<>'stored'").get()!.n)) fail("unfinished_document_imports");
    const rows = db.prepare("SELECT object_key,size_bytes,sha256 FROM storage_files ORDER BY object_key").all();
    return rows.map((row) => {
      if (typeof row.object_key !== "string" || !LOCAL_OBJECT_KEY.test(row.object_key) || typeof row.size_bytes !== "number" || !Number.isSafeInteger(row.size_bytes) || row.size_bytes < 0 || typeof row.sha256 !== "string" || !/^[a-f0-9]{64}$/.test(row.sha256)) fail("nonlocal_or_invalid_document");
      return { key: row.object_key, size: row.size_bytes, sha256: row.sha256 } as Entry;
    });
  } catch (error) { if (error instanceof KratosLocalDocumentError) throw error; fail("backup_database_invalid"); }
  finally { db.close(); }
}
async function copyVerified(source: string, destination: string, expected: { size: number; sha256: string }): Promise<void> {
  const before = await hashKratosLocalFile(source);
  if (before.size !== expected.size || before.sha256 !== expected.sha256) fail("backup_integrity_mismatch");
  await assertKratosLocalPath(path.dirname(destination), "directory");
  const output = await open(destination, "wx", 0o600); let input: FileHandle | undefined;
  try {
    input = await open(source, "r");
    let position = 0; const buffer = Buffer.allocUnsafe(1024 * 1024);
    for (;;) {
      const part = await input.read(buffer, 0, buffer.length, position); if (!part.bytesRead) break;
      let written = 0;
      while (written < part.bytesRead) { const result = await output.write(buffer, written, part.bytesRead - written); if (!result.bytesWritten) fail("backup_write_failed"); written += result.bytesWritten; }
      position += part.bytesRead;
    }
    await output.sync();
  } finally { try { await input?.close(); } finally { await output.close(); } }
  const verified = await hashKratosLocalFile(destination);
  if (verified.size !== expected.size || verified.sha256 !== expected.sha256) fail("backup_integrity_mismatch");
}
async function readManifest(directory: string): Promise<Manifest> {
  await assertKratosLocalPath(directory, "directory");
  const manifestPath = path.join(directory, "manifest.json");
  await assertKratosLocalPath(manifestPath, "file");
  if ((await lstat(manifestPath)).size > 10 * 1024 * 1024) fail("invalid_backup_manifest");
  let manifest: Manifest;
  try { manifest = JSON.parse(await readFile(manifestPath, "utf8")); } catch { fail("invalid_backup_manifest"); }
  if (!manifest || manifest.schema !== 1 || manifest.complete !== true || !Array.isArray(manifest.objects) || !manifest.database || !Number.isSafeInteger(manifest.database.size) || manifest.database.size < 0 || !/^[a-f0-9]{64}$/.test(manifest.database.sha256)) fail("invalid_backup_manifest");
  const dbPath = path.join(directory, "database.sqlite");
  const dbHash = await hashKratosLocalFile(dbPath);
  if (dbHash.size !== manifest.database.size || dbHash.sha256 !== manifest.database.sha256) fail("backup_integrity_mismatch");
  // Catalog must come from the verified snapshot; a shortened manifest cannot omit referenced objects.
  const expected = catalog(dbPath);
  if (JSON.stringify(manifest.objects) !== JSON.stringify(expected)) fail("backup_catalog_mismatch");
  for (const entry of expected) {
    const checked = await hashKratosLocalFile(localObjectPath(path.join(directory, "documents"), entry.key));
    if (checked.sha256 !== entry.sha256 || checked.size !== entry.size) fail("backup_integrity_mismatch");
  }
  return manifest;
}

/** Immutable object files allow a coherent SQLite snapshot followed by catalog-bound copying. */
export async function createKratosLocalBackup(options: { databasePath: string; documentRoot: string; destination: string; privateTargetConfirmed: boolean }): Promise<{ files: number; bytes: number; manifestSha256: string; unreferencedObjectCount: number }> {
  if (options.privateTargetConfirmed !== true) fail("backup_access_denied");
  await assertKratosLocalPath(options.databasePath, "file"); await assertKratosLocalPath(options.documentRoot, "directory");
  notNested(options.documentRoot, options.destination); notNested(options.databasePath, options.destination);
  await newDirectory(options.destination);
  const databasePath = path.join(options.destination, "database.sqlite");
  const db = new DatabaseSync(options.databasePath, { readOnly: true });
  try { await backup(db, databasePath); } catch { fail("sqlite_backup_failed"); } finally { db.close(); }
  const database = await hashKratosLocalFile(databasePath), objects = catalog(databasePath);
  const documentTarget = path.join(options.destination, "documents");
  await mkdir(documentTarget, { mode: 0o700 }); await mkdir(path.join(documentTarget, "local"), { mode: 0o700 });
  for (const entry of objects) await copyVerified(localObjectPath(options.documentRoot, entry.key), localObjectPath(documentTarget, entry.key), entry);
  const referenced = new Set(objects.map((entry) => entry.key));
  await assertKratosLocalPath(path.join(options.documentRoot, "local"), "directory");
  const unreferencedObjectCount = (await readdir(path.join(options.documentRoot, "local"))).filter((entry) => !referenced.has(`local/${entry}`)).length;
  const manifest: Manifest = { schema: 1, complete: true, database, objects, unreferencedObjectCount, createdAt: new Date().toISOString() };
  const output = await open(path.join(options.destination, "manifest.json"), "wx", 0o600);
  try { await output.writeFile(JSON.stringify(manifest, null, 2)); await output.sync(); } finally { await output.close(); }
  await readManifest(options.destination);
  const manifestHash = await hashKratosLocalFile(path.join(options.destination, "manifest.json"));
  return { files: objects.length, bytes: objects.reduce((sum, item) => sum + item.size, 0), manifestSha256: manifestHash.sha256, unreferencedObjectCount };
}

/** Verify before allocating target; never merge into or replace a pre-existing installation. */
export async function restoreKratosLocalBackup(options: { backupDirectory: string; destination: string; privateTargetConfirmed: boolean; expectedManifestSha256: string }): Promise<{ files: number; bytes: number; databasePath: string; documentRoot: string }> {
  if (options.privateTargetConfirmed !== true || !/^[a-f0-9]{64}$/.test(options.expectedManifestSha256)) fail("backup_access_denied");
  notNested(options.backupDirectory, options.destination);
  const hash = await hashKratosLocalFile(path.join(options.backupDirectory, "manifest.json"));
  if (hash.sha256 !== options.expectedManifestSha256) fail("backup_manifest_identity_mismatch");
  const manifest = await readManifest(options.backupDirectory);
  await newDirectory(options.destination);
  const databasePath = path.join(options.destination, "database.sqlite"), documentRoot = path.join(options.destination, "documents");
  await mkdir(documentRoot, { mode: 0o700 }); await mkdir(path.join(documentRoot, "local"), { mode: 0o700 });
  await copyVerified(path.join(options.backupDirectory, "database.sqlite"), databasePath, manifest.database);
  for (const entry of manifest.objects) await copyVerified(localObjectPath(path.join(options.backupDirectory, "documents"), entry.key), localObjectPath(documentRoot, entry.key), entry);
  if (JSON.stringify(catalog(databasePath)) !== JSON.stringify(manifest.objects)) fail("backup_catalog_mismatch");
  const marker = await open(path.join(options.destination, "restore-complete.json"), "wx", 0o600);
  try { await marker.writeFile(JSON.stringify({ verified: true, manifestSha256: hash.sha256, files: manifest.objects.length })); await marker.sync(); } finally { await marker.close(); }
  return { files: manifest.objects.length, bytes: manifest.objects.reduce((sum, item) => sum + item.size, 0), databasePath, documentRoot };
}
